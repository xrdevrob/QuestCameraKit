using System;
using System.Linq;
using Unity.Pipeline.Commands;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;
using UnityEngine.SceneManagement;

namespace XRDevRob.QUAK.Editor.Pipeline
{
    [Serializable]
    public sealed class QuakEditorStatus
    {
        public int schemaVersion = 1;
        public bool ready;
        public bool compiling;
        public bool playing;
        public string activeScene;
        public string unityVersion;
        public string xrRuntime;
        public bool controllerInputAvailable;
        public string[] inputDevices;
        public string capabilitiesJson;
        public string stateJson;
        public QuakRuntimeStatus runtime;
    }

    public static class QuakPipelineCommands
    {
        [InitializeOnLoadMethod]
        private static void InitializeRecentLogCapture()
        {
            QuakRegistry.CaptureRecentLogs(1);
        }

        [CliCommand(
            "quak_status",
            "Returns Editor readiness plus the QUAK app capabilities and state.",
            MainThreadRequired = true)]
        public static QuakEditorStatus Status()
        {
            var capabilities = QuakRegistry.CaptureCapabilities();
            var state = QuakRegistry.CaptureState();
            var runtime = QuakRegistry.CaptureRuntimeStatus(capabilities, state);
            return new QuakEditorStatus
            {
                ready = !EditorApplication.isCompiling && runtime.ready,
                compiling = EditorApplication.isCompiling,
                playing = EditorApplication.isPlaying,
                activeScene = SceneManager.GetActiveScene().name,
                unityVersion = Application.unityVersion,
                xrRuntime = Environment.GetEnvironmentVariable("XR_RUNTIME_JSON") ?? string.Empty,
                controllerInputAvailable = InputSystem.devices.Any(device => device is XRController),
                inputDevices = InputSystem.devices.Select(device =>
                    $"{device.displayName} ({device.layout})").ToArray(),
                capabilitiesJson = JsonUtility.ToJson(capabilities),
                stateJson = JsonUtility.ToJson(state),
                runtime = runtime
            };
        }

        [CliCommand(
            "quak_get_capabilities",
            "Returns stable QUAK target IDs, state providers, and fixture actions.",
            MainThreadRequired = true)]
        public static QuakCapabilities GetCapabilities()
        {
            return QuakRegistry.CaptureCapabilities();
        }

        [CliCommand(
            "quak_get_state",
            "Returns independently assertable QUAK product state.",
            MainThreadRequired = true)]
        public static QuakStateSnapshot GetState()
        {
            return QuakRegistry.CaptureState();
        }

        [CliCommand(
            "quak_get_recent_logs",
            "Returns the newest bounded Unity log entries. Stack traces are omitted.",
            MainThreadRequired = true)]
        public static QuakRecentLogs GetRecentLogs(
            [CliArg("limit", "Newest entries to return (1-200; default 50).")] int limit =
                QuakRegistry.DefaultRecentLogLimit)
        {
            return QuakRegistry.CaptureRecentLogs(limit);
        }

        [CliCommand(
            "quak_invoke_action",
            "Runs an app-defined fixture/reset action. Persistent project changes require confirm=true.",
            MainThreadRequired = true)]
        public static QuakActionResult InvokeAction(
            [CliArg("action_id", "Stable action ID advertised by quak_get_capabilities.", Required = true)]
            string actionId,
            [CliArg("arguments_json", "JSON object passed to the action.")]
            string argumentsJson = "{}",
            [CliArg("confirm", "Confirm persistent Unity project mutation.")]
            bool confirm = false)
        {
            return QuakRegistry.InvokeAction(actionId, argumentsJson, confirm);
        }
    }
}
