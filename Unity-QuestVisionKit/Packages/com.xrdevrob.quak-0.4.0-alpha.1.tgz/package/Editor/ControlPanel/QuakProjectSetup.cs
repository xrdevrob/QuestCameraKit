using System;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using UnityEditor;
using UnityEditor.XR.OpenXR.Features;
using UnityEngine;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.Features;
using XRDevRob.QUAK.MetaOperator;
using XRDevRob.QUAK.Direct.Editor;

[assembly: InternalsVisibleTo("XRDevRob.QUAK.Tests.Editor")]

namespace XRDevRob.QUAK.Editor.ControlPanel
{
    public static class QuakProjectSetup
    {
        internal const string ConfigRelativePath = ".quak/config.json";
        internal const string SmokeTestRelativePath = "quak-tests/quak-connection-smoke.json";
        internal const string CodexSkillRelativePath = ".codex/skills/quak-test/SKILL.md";
        internal const string CodexAgentRelativePath = ".codex/skills/quak-test/agents/openai.yaml";
        internal const string LegacyEvidenceIgnoreEntry = ".quak/evidence/";
        internal static readonly string[] EvidenceMediaIgnoreEntries =
        {
            ".quak/evidence/**/.visual-frames/",
            ".quak/evidence/**/artifacts/**/*.png",
            ".quak/evidence/**/artifacts/**/*.jpg",
            ".quak/evidence/**/artifacts/**/*.jpeg",
            ".quak/evidence/**/artifacts/**/*.webp",
            ".quak/evidence/**/artifacts/**/*.mp4",
            ".quak/evidence/**/artifacts/**/*.mov"
        };
        private static readonly string[] LegacyEvidenceMediaIgnoreEntries =
        {
            LegacyEvidenceIgnoreEntry,
            ".quak/evidence/**/artifacts/*.png",
            ".quak/evidence/**/artifacts/*.jpg",
            ".quak/evidence/**/artifacts/*.jpeg",
            ".quak/evidence/**/artifacts/*.webp",
            ".quak/evidence/**/artifacts/*.mp4",
            ".quak/evidence/**/artifacts/*.mov"
        };
        internal const string MachinesRelativePath = ".quak/machines.local.json";
        internal const string MachinesIgnoreEntry = MachinesRelativePath;
        internal const string PackagesIgnoreEntry = ".quak/packages/";
        internal const string VenvIgnoreEntry = ".quak/venv/";

        internal static string ProjectRoot =>
            Directory.GetParent(Application.dataPath)?.FullName ?? Application.dataPath;

        public static void ConfigureProject()
        {
            try
            {
                foreach (var action in CoreSetupActions(ProjectRoot))
                    action();
                Debug.Log($"[QUAK] Project setup succeeded: {ProjectRoot}");
            }
            catch (Exception exception)
            {
                throw new InvalidOperationException(
                    $"[QUAK] Project setup failed for {ProjectRoot}: {exception.Message}",
                    exception);
            }
        }

        internal static Action[] CoreSetupActions(string projectRoot)
        {
            return new Action[]
            {
                () =>
                {
                    PreflightCore(projectRoot);
                    EnsureDirectFeatureEnabled();
                },
                () => EnsureConfig(projectRoot),
                () => EnsureEvidenceMediaIgnored(projectRoot),
                () => EnsureSmokeTest(projectRoot)
            };
        }

        internal static void PreflightCore(string projectRoot)
        {
            PreflightConfig(projectRoot);
            PreflightSmokeTest(projectRoot);
            PreflightEvidence(projectRoot);
        }

        internal static bool IsOperatorFeatureEnabled(BuildTargetGroup targetGroup)
        {
            var settings = OpenXRSettings.GetSettingsForBuildTargetGroup(targetGroup);
            return settings?.GetFeature<QuakOperatorFeature>()?.enabled == true;
        }

        internal static bool IsDirectFeatureEnabled()
        {
            var settings = OpenXRSettings.GetSettingsForBuildTargetGroup(
                BuildTargetGroup.Android);
            var feature = settings?.GetFeature<ApiLayersFeature>();
            return feature?.enabled == true &&
                   QuakDirectLayerBuildProcessor.IsLayerReady(feature) &&
                   settings.GetFeatures().Any(candidate =>
                       candidate != null && candidate.enabled &&
                       candidate.GetType().FullName ==
                       "XRDevRob.QUAK.Direct.QuakObservabilityFeature");
        }

        internal static void EnsureDirectFeatureEnabled()
        {
            FeatureHelpers.RefreshFeatures(BuildTargetGroup.Android);
            var settings = OpenXRSettings.GetSettingsForBuildTargetGroup(
                BuildTargetGroup.Android);
            var feature = settings?.GetFeature<ApiLayersFeature>();
            if (feature == null)
                throw new InvalidOperationException(
                    "Unity OpenXR API Layers feature is unavailable for Android.");
            if (!feature.enabled)
            {
                feature.enabled = true;
                EditorUtility.SetDirty(feature);
            }
            QuakDirectLayerBuildProcessor.EnsureLayerInstalled(feature);
            var observability = settings.GetFeatures().FirstOrDefault(candidate =>
                candidate != null && candidate.GetType().FullName ==
                "XRDevRob.QUAK.Direct.QuakObservabilityFeature");
            if (observability == null)
                throw new InvalidOperationException(
                    "QUAK runtime observability feature is unavailable for Android.");
            if (!observability.enabled)
            {
                observability.enabled = true;
                EditorUtility.SetDirty(observability);
            }
            AssetDatabase.SaveAssets();
        }

        [MenuItem("QUAK/Enable Meta XR Operator rollback", priority = 101)]
        public static void ConfigureOperatorRollback()
        {
            EnsureOperatorFeatureEnabled();
            Debug.Log("[QUAK] Meta XR Operator rollback bridge enabled.");
        }

        internal static void EnsureOperatorFeatureEnabled()
        {
            foreach (var targetGroup in new[]
                     {
                         BuildTargetGroup.Standalone,
                         BuildTargetGroup.Android
                     })
            {
                FeatureHelpers.RefreshFeatures(targetGroup);
                var settings = OpenXRSettings.GetSettingsForBuildTargetGroup(targetGroup);
                var feature = settings?.GetFeature<QuakOperatorFeature>();
                if (feature == null)
                    throw new InvalidOperationException(
                        $"QUAK Operator OpenXR feature is unavailable for {targetGroup}.");
                if (feature.enabled)
                    continue;
                feature.enabled = true;
                EditorUtility.SetDirty(feature);
            }
            AssetDatabase.SaveAssets();
        }

        internal static void PreflightConfig(string projectRoot)
        {
            RequireUnityProject(projectRoot);
            RequireDirectory(projectRoot, ".quak");
            RequireFile(projectRoot, ConfigRelativePath);
        }

        internal static void PreflightSmokeTest(string projectRoot)
        {
            RequireUnityProject(projectRoot);
            RequireDirectory(projectRoot, "quak-tests");
            RequireFile(projectRoot, SmokeTestRelativePath);
        }

        internal static void PreflightEvidence(string projectRoot)
        {
            RequireUnityProject(projectRoot);
            RequireFile(projectRoot, ".gitignore");
        }

        internal static void EnsureConfig(string projectRoot)
        {
            EnsureTemplate(projectRoot, "config.json", ConfigRelativePath);
        }

        internal static void EnsureSmokeTest(string projectRoot)
        {
            EnsureTemplate(projectRoot, "quak-connection-smoke.json", SmokeTestRelativePath);
        }

        internal static void EnsureEvidenceMediaIgnored(string projectRoot)
        {
            RemoveIgnored(projectRoot, LegacyEvidenceMediaIgnoreEntries);
            EnsureIgnored(
                projectRoot,
                EvidenceMediaIgnoreEntries[0],
                EvidenceMediaIgnoreEntries[1],
                EvidenceMediaIgnoreEntries[2],
                EvidenceMediaIgnoreEntries[3],
                EvidenceMediaIgnoreEntries[4],
                EvidenceMediaIgnoreEntries[5],
                EvidenceMediaIgnoreEntries[6],
                MachinesIgnoreEntry,
                PackagesIgnoreEntry,
                VenvIgnoreEntry);
        }

        internal static void EnsureMachinesIgnored(string projectRoot)
        {
            EnsureIgnored(projectRoot, MachinesIgnoreEntry);
        }

        private static void EnsureIgnored(string projectRoot, params string[] entries)
        {
            var path = Path.Combine(projectRoot, ".gitignore");
            var existing = File.Exists(path) ? File.ReadAllText(path) : string.Empty;
            var lines = existing.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var missing = entries.Where(entry => !lines.Contains(entry, StringComparer.Ordinal)).ToArray();
            if (missing.Length == 0)
                return;

            var separator = string.IsNullOrEmpty(existing) || existing.EndsWith("\n", StringComparison.Ordinal)
                ? string.Empty
                : Environment.NewLine;
            File.WriteAllText(
                path,
                existing + separator + string.Join(Environment.NewLine, missing) + Environment.NewLine);
        }

        private static void RemoveIgnored(string projectRoot, params string[] entries)
        {
            var path = Path.Combine(projectRoot, ".gitignore");
            if (!File.Exists(path))
                return;
            var lines = File.ReadAllLines(path);
            var retained = lines.Where(line =>
                !entries.Contains(line, StringComparer.Ordinal)).ToArray();
            if (retained.Length == lines.Length)
                return;
            File.WriteAllText(
                path,
                string.Join(Environment.NewLine, retained) +
                (retained.Length == 0 ? string.Empty : Environment.NewLine));
        }

        internal static void PreflightCodex(string projectRoot)
        {
            RequireUnityProject(projectRoot);
            RequireDirectory(projectRoot, ".codex");
            RequireDirectory(projectRoot, ".codex/skills");
            RequireDirectory(projectRoot, ".codex/skills/quak-test");
            RequireDirectory(projectRoot, ".codex/skills/quak-test/agents");
            RequireFile(projectRoot, CodexSkillRelativePath);
            RequireFile(projectRoot, ".codex/skills/quak-test/agents/openai.yaml");
        }

        internal static void InstallCodexSkill(string projectRoot)
        {
            EnsureTemplate(projectRoot, "quak-test/SKILL.md", CodexSkillRelativePath);
            EnsureTemplate(
                projectRoot,
                "quak-test/agents/openai.yaml",
                ".codex/skills/quak-test/agents/openai.yaml");
        }

        internal static bool IsCodexSkillInstalled(string projectRoot)
        {
            return File.Exists(Path.Combine(projectRoot, CodexSkillRelativePath)) &&
                   File.Exists(Path.Combine(projectRoot, CodexAgentRelativePath));
        }

        internal static bool IsEvidenceMediaIgnored(string projectRoot)
        {
            var path = Path.Combine(projectRoot, ".gitignore");
            if (!File.Exists(path))
                return false;
            var lines = File.ReadAllLines(path);
            return LegacyEvidenceMediaIgnoreEntries.All(entry =>
                       !lines.Contains(entry, StringComparer.Ordinal)) &&
                   EvidenceMediaIgnoreEntries.All(entry => lines.Contains(entry, StringComparer.Ordinal));
        }

        private static void EnsureTemplate(string projectRoot, string template, string destination)
        {
            var target = Path.Combine(projectRoot, destination);
            if (File.Exists(target))
                return;

            var source = TemplatePath(template);
            if (!File.Exists(source))
                throw new FileNotFoundException($"QUAK package is missing setup template: {template}", source);

            Directory.CreateDirectory(Path.GetDirectoryName(target) ?? projectRoot);
            File.Copy(source, target, false);
        }

        private static string TemplatePath(string relativePath)
        {
            var package = UnityEditor.PackageManager.PackageInfo.FindForAssembly(
                typeof(QuakProjectSetup).Assembly);
            if (package == null)
                throw new InvalidOperationException("QUAK package metadata is unavailable.");
            return Path.Combine(package.resolvedPath, "Editor", "ControlPanel", "Templates~", relativePath);
        }

        private static void RequireUnityProject(string projectRoot)
        {
            if (!Directory.Exists(projectRoot) ||
                !Directory.Exists(Path.Combine(projectRoot, "Assets")) ||
                !File.Exists(Path.Combine(projectRoot, "Packages", "manifest.json")) ||
                !File.Exists(Path.Combine(projectRoot, "ProjectSettings", "ProjectVersion.txt")))
                throw new InvalidOperationException($"Not a valid Unity project: {projectRoot}");
        }

        private static void RequireDirectory(string projectRoot, string relativePath)
        {
            var path = Path.Combine(projectRoot, relativePath);
            if (File.Exists(path))
                throw new IOException($"Setup requires a directory, but a file exists at {path}");
        }

        private static void RequireFile(string projectRoot, string relativePath)
        {
            var path = Path.Combine(projectRoot, relativePath);
            if (Directory.Exists(path))
                throw new IOException($"Setup requires a file, but a directory exists at {path}");
        }
    }
}
