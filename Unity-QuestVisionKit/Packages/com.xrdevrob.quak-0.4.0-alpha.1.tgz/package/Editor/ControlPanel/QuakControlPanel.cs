using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;
using UnityEngine.Video;
using Process = System.Diagnostics.Process;
using ProcessStartInfo = System.Diagnostics.ProcessStartInfo;

namespace XRDevRob.QUAK.Editor.ControlPanel
{
    public sealed class QuakControlPanel : EditorWindow
    {
        private static readonly string[] Tabs = { "Setup", "Tests", "Machines", "Settings" };
        private static readonly string[] TestTargets = { "quest", "editor", "simulator" };
        private static readonly string[] TestTargetLabels = { "Quest headset", "Unity Editor", "Meta XR Simulator" };
        private static readonly string[] VisualEvidenceLabels = { "Off", "Standard", "Advanced" };
        private static readonly string[] FocusClipValues =
            { "marked-and-failures", "all-interactions", "off" };
        private static readonly string[] FocusClipLabels =
            { "Titled interactions + failures", "Every interaction", "Off" };
        private static readonly string[] TargetHighlightValues =
            { "focused-clips", "all-recordings", "off" };
        private static readonly string[] TargetHighlightLabels =
            { "Focused clips only", "All recordings", "Off" };
        private static readonly string[] MachineTargets = { "quest", "simulator", "editor" };
        private static readonly string[] MachineTargetLabels = { "Quest headset", "Meta XR Simulator", "Unity Editor" };
        private static readonly string[] SetupMilestones = { "Project", "Config", "Evidence", "First test", "AI agent" };
        private static readonly SetupCategory[] SetupCategories =
        {
            SetupCategory.Project,
            SetupCategory.Integrations,
            SetupCategory.Packages,
            SetupCategory.Environment,
            SetupCategory.Editor
        };
        private static readonly string[] ReviewCategoryLabels =
            { "Product bug", "Test expectation", "Automation / input", "Visual quality", "Coverage gap" };
        private static readonly string[] ReviewCategories =
            { "product_bug", "test_expectation", "automation_input", "visual_quality", "coverage_gap" };
        private static readonly string[] HumanReviewDocumentFields =
        {
            "schema_version", "receipt_sha256", "video_sha256", "status", "reviewed_at", "annotations"
        };
        private static readonly string[] HumanReviewAnnotationFields =
            { "at_seconds", "category", "observed", "expected", "created_at" };
        private static readonly Regex HumanReviewSha256 = new(
            "^[a-f0-9]{64}$",
            RegexOptions.CultureInvariant);
        private static readonly Regex HumanReviewDateTime = new(
            @"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,7})?(?:Z|[+-][0-9]{2}:[0-9]{2})$",
            RegexOptions.CultureInvariant);

        private static readonly Color AccentColor = new(0.31f, 0.59f, 0.96f);
        private static readonly Color PassColor = new(0.35f, 0.84f, 0.57f);
        private static readonly Color WarningColor = new(0.96f, 0.72f, 0.31f);
        private static readonly Color FailColor = new(1f, 0.42f, 0.42f);
        private static readonly Color HeaderColor = new(0.075f, 0.09f, 0.13f);

        private readonly List<SetupCheck> setupChecks = new();
        private readonly List<TestFile> tests = new();
        private readonly List<ResultFile> results = new();
        private readonly List<TestMachine> machines = new();
        private readonly Dictionary<string, string> machineStates = new(StringComparer.Ordinal);
        private readonly Queue<string> machineOutput = new();
        private readonly Queue<string> verificationOutput = new();
        private readonly HashSet<string> protectedTestPaths = new(StringComparer.Ordinal);
        private readonly HashSet<SetupCategory> expandedSettingsCategories = new();
        private readonly List<ValidationDevice> validationDevices = new();

        private int activeTab;
        private int selectedSetupMilestone = -1;
        private int selectedTest = -1;
        private Vector2 scroll;
        private bool showAddTest;
        private string newTestDescription = string.Empty;
        private int newTestTarget;
        private int newTestVisualEvidence = 1;
        private int newTestFocusClips;
        private int newTestTargetHighlight;
        private string expandedResultTestPath = string.Empty;
        private int selectedValidationDevice;
        private string validationDeviceError = string.Empty;
        private string reviewDraftReceiptPath = string.Empty;
        private float reviewAtSeconds;
        private int reviewCategory;
        private string reviewObserved = string.Empty;
        private string reviewExpected = string.Empty;
        private GameObject reviewVideoObject;
        private VideoPlayer reviewVideoPlayer;
        private RenderTexture reviewVideoTexture;
        private string reviewVideoPath = string.Empty;
        private string reviewVideoError = string.Empty;
        private bool showReviewSubtitles = true;
        private bool hasRegressionCatalog;
        private int protectedTestCount;
        private RegressionReport regressionReport;
        private string regressionError = string.Empty;
        private string machinesError = string.Empty;
        private bool machinesDirty;
        private Process machineProcess;
        private int machineProgressId = -1;
        private bool machineCommandRunning;
        private bool? machineLastPassed;
        private string machineCommandAction = string.Empty;
        private string machineCommandMessage = string.Empty;
        private int machineProgressCompleted;
        private int machineProgressTotal;
        private double machineCommandStartedAt;
        private Process verificationProcess;
        private int verificationProgressId = -1;
        private bool verificationRunning;
        private bool? verificationLastPassed;
        private string verificationMessage = string.Empty;
        private readonly StringBuilder verificationDetails = new();

        private GUIStyle headerTitleStyle;
        private GUIStyle headerSubtitleStyle;
        private GUIStyle headerBadgeStyle;
        private GUIStyle tabStyle;
        private GUIStyle pageTitleStyle;
        private GUIStyle sectionTitleStyle;
        private GUIStyle detailStyle;
        private GUIStyle cardStyle;
        private GUIStyle cardTitleStyle;
        private GUIStyle statusStyle;
        private GUIStyle primaryButtonStyle;
        private GUIStyle milestoneLabelStyle;
        private GUIStyle reviewCaptionStyle;

        private string[] setupMilestones = Array.Empty<string>();
        private Action[] setupActions = Array.Empty<Action>();
        private int setupFirstMilestone;
        private int setupCompletedMilestones;
        private int setupCurrentMilestone = -1;
        private int setupProgressId = -1;
        private bool setupRunning;
        private bool setupStepStarted;
        private bool setupFailed;
        private string setupMessage = string.Empty;
        private string setupSuccessMessage = string.Empty;
        private double nextSetupTick;

        private static string ProjectRoot => QuakProjectSetup.ProjectRoot;

        private static string ValidationDevicePreferenceKey =>
            "QUAK.ValidationDevice." + ProjectRoot;

        private static string QuakExecutable
        {
            get
            {
                var candidates = new[]
                {
                    Path.Combine(ProjectRoot, ".quak", "venv", "bin", "quak"),
                    Path.Combine(ProjectRoot, ".quak", "venv", "Scripts", "quak.exe")
                };
                return candidates.FirstOrDefault(File.Exists) ?? "quak";
            }
        }

        private static string CodexExecutable
        {
            get
            {
                var executable = Application.platform == RuntimePlatform.WindowsEditor
                    ? "codex.exe"
                    : "codex";
                var candidates = new List<string>
                {
                    Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                        ".local",
                        "bin",
                        executable),
                    Path.Combine("/opt/homebrew/bin", executable),
                    Path.Combine("/usr/local/bin", executable)
                };
                var path = Environment.GetEnvironmentVariable("PATH");
                if (!string.IsNullOrWhiteSpace(path))
                    candidates.AddRange(path.Split(Path.PathSeparator)
                        .Where(folder => !string.IsNullOrWhiteSpace(folder))
                        .Select(folder => Path.Combine(folder, executable)));
                return candidates.FirstOrDefault(File.Exists);
            }
        }

        [MenuItem("QUAK/Control Panel", priority = 1)]
        public static void Open()
        {
            var window = GetWindow<QuakControlPanel>("QUAK");
            window.minSize = new Vector2(560f, 420f);
            window.Show();
        }

        private void OnEnable()
        {
            EditorApplication.update -= AdvanceSetup;
            EditorApplication.update -= AdvanceMachineCommand;
            EditorApplication.update -= AdvanceVerification;
            EditorApplication.update -= UpdateReviewVideo;
            EditorApplication.update += UpdateReviewVideo;
            setupMilestones = Array.Empty<string>();
            setupActions = Array.Empty<Action>();
            setupFirstMilestone = 0;
            setupCompletedMilestones = 0;
            setupCurrentMilestone = -1;
            setupProgressId = -1;
            setupRunning = false;
            setupStepStarted = false;
            setupFailed = false;
            setupMessage = string.Empty;
            machineProcess = null;
            machineProgressId = -1;
            machineCommandRunning = false;
            machineStates.Clear();
            lock (machineOutput)
                machineOutput.Clear();
            verificationProcess = null;
            verificationProgressId = -1;
            verificationRunning = false;
            lock (verificationOutput)
                verificationOutput.Clear();
            verificationDetails.Clear();
            RefreshValidationDevices();
            RefreshMachines();
            RefreshAll();
        }

        private void OnProjectChange()
        {
            RefreshTests();
            RefreshResults();
            Repaint();
        }

        private void OnFocus()
        {
            RefreshTests();
            RefreshResults();
            Repaint();
        }

        private void OnHierarchyChange()
        {
            RefreshSetup();
            Repaint();
        }

        private void OnDisable()
        {
            EditorApplication.update -= AdvanceSetup;
            EditorApplication.update -= AdvanceMachineCommand;
            EditorApplication.update -= AdvanceVerification;
            EditorApplication.update -= UpdateReviewVideo;
            ReleaseReviewVideo();
            if (setupProgressId >= 0 && Progress.Exists(setupProgressId))
                Progress.Finish(setupProgressId, Progress.Status.Canceled);
            setupRunning = false;
            CancelVerification(false);
            CancelMachineCommand(false);
        }

        private void OnGUI()
        {
            EnsureStyles();
            DrawHeader();
            DrawTabs();

            EditorGUILayout.Space(14f);
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Space(16f);
                using (new EditorGUILayout.VerticalScope())
                {
                    scroll = EditorGUILayout.BeginScrollView(scroll);
                    switch (activeTab)
                    {
                        case 0:
                            DrawSetup();
                            break;
                        case 1:
                            DrawTests();
                            break;
                        case 2:
                            DrawMachines();
                            break;
                        case 3:
                            DrawSettings();
                            break;
                    }
                    EditorGUILayout.Space(12f);
                    EditorGUILayout.EndScrollView();
                }
                GUILayout.Space(16f);
            }
        }

        private void EnsureStyles()
        {
            if (headerTitleStyle != null && milestoneLabelStyle != null && reviewCaptionStyle != null)
                return;

            headerTitleStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 24,
                normal = { textColor = Color.white }
            };
            headerSubtitleStyle = new GUIStyle(EditorStyles.label)
            {
                fontSize = 11,
                normal = { textColor = new Color(0.72f, 0.77f, 0.84f) }
            };
            headerBadgeStyle = new GUIStyle(EditorStyles.miniBoldLabel)
            {
                alignment = TextAnchor.MiddleCenter,
                normal = { textColor = Color.white }
            };
            tabStyle = new GUIStyle(EditorStyles.label)
            {
                fontSize = 12,
                alignment = TextAnchor.MiddleCenter
            };
            pageTitleStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 18,
                margin = new RectOffset(0, 0, 0, 2)
            };
            sectionTitleStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 12,
                margin = new RectOffset(0, 0, 2, 2)
            };
            detailStyle = new GUIStyle(EditorStyles.wordWrappedMiniLabel)
            {
                fontSize = 10
            };
            cardStyle = new GUIStyle(EditorStyles.helpBox)
            {
                padding = new RectOffset(12, 12, 10, 10),
                margin = new RectOffset(0, 0, 0, 7)
            };
            cardTitleStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 12
            };
            statusStyle = new GUIStyle(EditorStyles.miniBoldLabel)
            {
                alignment = TextAnchor.MiddleRight
            };
            primaryButtonStyle = new GUIStyle(GUI.skin.button)
            {
                fontStyle = FontStyle.Bold,
                fixedHeight = 32f
            };
            milestoneLabelStyle = new GUIStyle(detailStyle)
            {
                alignment = TextAnchor.UpperCenter,
                wordWrap = false
            };
            reviewCaptionStyle = new GUIStyle(EditorStyles.whiteLabel)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = 15,
                fontStyle = FontStyle.Bold,
                wordWrap = true,
                normal = { textColor = Color.white }
            };
        }

        private void DrawHeader()
        {
            var rect = GUILayoutUtility.GetRect(0f, 84f, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(rect, HeaderColor);
            GUI.Label(new Rect(rect.x + 16f, rect.y + 14f, 180f, 32f), "QUAK", headerTitleStyle);
            GUI.Label(
                new Rect(rect.x + 17f, rect.y + 48f, rect.width - 190f, 20f),
                "Test what users experience. Keep the evidence.",
                headerSubtitleStyle);

            var hasFailure = setupChecks.Any(check => check.Level == CheckLevel.Fail);
            var isConfigured = !setupChecks.Any(check => IsRequiredSetupCheck(check) && check.Level != CheckLevel.Pass);
            var connectionVerified = IsPassed(ConnectionSmokeResult());
            var status = verificationRunning ? "VERIFYING"
                : hasFailure ? "ISSUES FOUND"
                : connectionVerified ? "LAST VERIFIED"
                : isConfigured ? "CONFIGURED" : "NOT CONFIGURED";
            var color = verificationRunning ? AccentColor
                : hasFailure ? FailColor
                : connectionVerified ? PassColor : WarningColor;
            var badgeRect = new Rect(rect.xMax - 164f, rect.y + 26f, 148f, 28f);
            var previousColor = GUI.contentColor;
            GUI.contentColor = color;
            GUI.Label(badgeRect, $"●  {status}", headerBadgeStyle);
            GUI.contentColor = previousColor;
        }

        private void DrawTabs()
        {
            var rect = GUILayoutUtility.GetRect(0f, 36f, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(
                rect,
                EditorGUIUtility.isProSkin ? new Color(0.18f, 0.18f, 0.18f) : new Color(0.78f, 0.78f, 0.78f));
            var width = (rect.width - 24f) / Tabs.Length;
            for (var index = 0; index < Tabs.Length; index++)
            {
                var tabRect = new Rect(rect.x + 12f + index * width, rect.y, width, rect.height);
                EditorGUIUtility.AddCursorRect(tabRect, MouseCursor.Link);
                if (GUI.Button(tabRect, Tabs[index], tabStyle) && activeTab != index)
                {
                    if (activeTab == 1)
                        ReleaseReviewVideo();
                    activeTab = index;
                    scroll = Vector2.zero;
                }

                if (activeTab == index)
                    EditorGUI.DrawRect(new Rect(tabRect.center.x - 28f, tabRect.yMax - 3f, 56f, 3f), AccentColor);
            }
        }

        private void DrawSetup()
        {
            var coreReady = !setupChecks.Any(check =>
                IsRequiredSetupCheck(check) && check.Level != CheckLevel.Pass);
            var smokeResult = ConnectionSmokeResult();
            var connectionVerified = IsPassed(smokeResult);
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField("Setup", pageTitleStyle);
                if (GUILayout.Button(
                        new GUIContent("Refresh", "Re-run setup diagnostics."),
                        EditorStyles.miniButton,
                        GUILayout.Width(64f)))
                    RefreshSetup();
            }
            EditorGUILayout.LabelField("Connect QUAK to this Unity project.", detailStyle);
            EditorGUILayout.Space(10f);
            DrawMilestones();
            var milestoneCheck = SetupCheckForMilestone(VisibleSetupMilestone());
            if (milestoneCheck != null)
                DrawSetupCheck(milestoneCheck, milestoneCheck.StatusReason);
            else
                DrawSummaryCard(
                    connectionVerified ? "Last connection check passed"
                        : smokeResult == null ? "Project configured" : "Connection check failed",
                    connectionVerified
                        ? $"Historical {smokeResult.Target} receipt from " +
                          $"{DisplayTimestamp(smokeResult.Timestamp)}; it does not prove the current live session."
                        : smokeResult == null
                            ? "Run the live connection check to write the first evidence receipt."
                            : "Run the connection check again after resolving the reported issue.",
                    connectionVerified ? "LAST VERIFIED"
                        : smokeResult == null ? "CONFIGURED" : "CHECK FAILED",
                    connectionVerified ? PassColor
                        : smokeResult == null ? WarningColor : FailColor);

            if (coreReady)
            {
                DrawValidationDeviceSelector();
                EditorGUILayout.Space(6f);
                using (new EditorGUI.DisabledScope(
                           setupRunning || verificationRunning || machineCommandRunning ||
                           !SelectedValidationDevice.Runnable))
                {
                    if (GUILayout.Button("Verify connection", primaryButtonStyle))
                        StartVerification();
                }
                if (verificationRunning)
                    EditorGUILayout.HelpBox(verificationMessage, MessageType.Info);
                else if (verificationLastPassed == false)
                    EditorGUILayout.HelpBox(
                        verificationDetails.Length == 0
                            ? verificationMessage
                            : verificationDetails.ToString(),
                        MessageType.Error);
                else if (connectionVerified && GUILayout.Button("Reveal first receipt"))
                    EditorUtility.RevealInFinder(smokeResult.Path);
                EditorGUILayout.Space(10f);
            }

            if (!coreReady && (milestoneCheck == null || milestoneCheck.Action == null))
            {
                using (new EditorGUI.DisabledScope(setupRunning))
                {
                    if (GUILayout.Button("Set up QUAK", primaryButtonStyle))
                        EditorApplication.delayCall += StartCoreSetup;
                }
                EditorGUILayout.Space(10f);
            }

            if (setupFailed && !string.IsNullOrWhiteSpace(setupMessage))
                EditorGUILayout.HelpBox(setupMessage, MessageType.Error);
        }

        private void DrawMilestones()
        {
            var labels = setupRunning ? setupMilestones : SetupMilestones;
            if (labels.Length == 0)
                return;

            var complete = new bool[labels.Length];
            for (var index = 0; index < labels.Length; index++)
                complete[index] = setupRunning ? index < setupCompletedMilestones : MilestoneComplete(index);

            var current = setupRunning ? setupCurrentMilestone : -1;
            var selected = VisibleSetupMilestone();
            var rect = GUILayoutUtility.GetRect(0f, 62f, GUILayout.ExpandWidth(true));
            var startX = rect.x + 50f;
            var endX = rect.xMax - 50f;
            var lineY = rect.y + 16f;
            var spacing = labels.Length > 1 ? (endX - startX) / (labels.Length - 1) : 0f;
            var pendingColor = EditorGUIUtility.isProSkin
                ? new Color(0.34f, 0.36f, 0.39f)
                : new Color(0.65f, 0.67f, 0.7f);

            for (var index = 0; index < labels.Length - 1; index++)
            {
                var color = complete[index + 1]
                    ? PassColor
                    : current == index + 1 ? AccentColor : pendingColor;
                EditorGUI.DrawRect(
                    new Rect(startX + index * spacing, lineY - 1f, spacing, 2f),
                    color);
            }

            Handles.BeginGUI();
            for (var index = 0; index < labels.Length; index++)
            {
                var isCurrent = current == index;
                var radius = isCurrent
                    ? 7f + (float)Math.Sin(EditorApplication.timeSinceStartup * 8d)
                    : 6f;
                var center = new Vector3(startX + index * spacing, lineY);
                var nodeColor = complete[index] ? PassColor : isCurrent ? AccentColor : pendingColor;
                if (selected == index)
                {
                    Handles.color = AccentColor;
                    Handles.DrawSolidDisc(center, Vector3.forward, radius + 2f);
                }
                Handles.color = nodeColor;
                Handles.DrawSolidDisc(center, Vector3.forward, radius);
            }
            Handles.EndGUI();

            var labelColor = EditorGUIUtility.isProSkin
                ? new Color(0.72f, 0.75f, 0.8f)
                : new Color(0.28f, 0.3f, 0.33f);
            for (var index = 0; index < labels.Length; index++)
            {
                milestoneLabelStyle.fontStyle = selected == index ? FontStyle.Bold : FontStyle.Normal;
                milestoneLabelStyle.normal.textColor = selected == index ? AccentColor : labelColor;
                GUI.Label(
                    new Rect(startX + index * spacing - 50f, lineY + 12f, 100f, 28f),
                    labels[index],
                    milestoneLabelStyle);

                var clickRect = new Rect(startX + index * spacing - 50f, rect.y, 100f, 50f);
                EditorGUIUtility.AddCursorRect(clickRect, MouseCursor.Link);
                if (GUI.Button(
                        clickRect,
                        new GUIContent(string.Empty, $"Show details for {labels[index]}"),
                        GUIStyle.none))
                {
                    selectedSetupMilestone = selectedSetupMilestone == index ? -1 : index;
                    Repaint();
                }
            }

            if (setupRunning)
                Repaint();
        }

        private static bool MilestoneComplete(int index)
        {
            return index switch
            {
                0 => Directory.Exists(ProjectRoot) && Directory.Exists(Path.Combine(ProjectRoot, "Assets")),
                1 => File.Exists(Path.Combine(ProjectRoot, QuakProjectSetup.ConfigRelativePath)),
                2 => QuakProjectSetup.IsEvidenceMediaIgnored(ProjectRoot),
                3 => File.Exists(Path.Combine(ProjectRoot, QuakProjectSetup.SmokeTestRelativePath)),
                4 => true,
                _ => false
            };
        }

        private int VisibleSetupMilestone()
        {
            if (selectedSetupMilestone >= 0 && selectedSetupMilestone < SetupMilestones.Length)
                return selectedSetupMilestone;
            if (setupRunning && setupCurrentMilestone >= 0 && setupCurrentMilestone < SetupMilestones.Length)
                return setupCurrentMilestone;
            for (var index = 0; index < SetupMilestones.Length; index++)
                if (!IsOptionalMilestone(index) && !MilestoneComplete(index))
                    return index;
            return -1;
        }

        private SetupCheck SetupCheckForMilestone(int index)
        {
            var name = index switch
            {
                0 => "Unity project",
                1 => "QUAK configuration",
                2 => "QUAK evidence media",
                3 => "QUAK first test",
                4 => "AI agent guidance",
                _ => string.Empty
            };
            return setupChecks.FirstOrDefault(check => check.Name == name);
        }

        private void DrawSettings()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField("Settings", pageTitleStyle);
                if (GUILayout.Button(
                        new GUIContent("Refresh", "Re-run setup diagnostics."),
                        EditorStyles.miniButton,
                        GUILayout.Width(64f)))
                    RefreshSetup();
            }
            EditorGUILayout.LabelField(
                "Optional integrations and technical diagnostics.",
                detailStyle);
            EditorGUILayout.Space(10f);

            foreach (var category in SetupCategories)
            {
                var checks = setupChecks
                    .Where(check => check.Category == category)
                    .ToArray();
                if (checks.Length == 0)
                    continue;

                var noteCount = checks.Count(check => check.Level != CheckLevel.Pass);
                var expanded = expandedSettingsCategories.Contains(category);
                var label = $"{SetupCategoryLabel(category)} ({checks.Length})" +
                            (noteCount == 0 ? string.Empty : $" · {noteCount} note{(noteCount == 1 ? "" : "s")}");
                var next = EditorGUILayout.Foldout(expanded, label, true);
                if (next)
                    expandedSettingsCategories.Add(category);
                else
                    expandedSettingsCategories.Remove(category);

                if (next)
                {
                    EditorGUILayout.LabelField(SetupCategoryDetail(category), detailStyle);
                    EditorGUILayout.Space(4f);
                    foreach (var check in checks)
                        DrawSetupCheck(check);
                }
                EditorGUILayout.Space(8f);
            }

            if (setupFailed && !string.IsNullOrWhiteSpace(setupMessage))
                EditorGUILayout.HelpBox(setupMessage, MessageType.Error);
        }

        private void StartCoreSetup()
        {
            BeginSetup(
                "Setting up QUAK",
                SetupMilestones,
                0,
                QuakProjectSetup.CoreSetupActions(ProjectRoot),
                "QUAK setup complete. Start the selected runtime and verify the " +
                "connection before running tests.");
        }

        private void StartConfigSetup()
        {
            StartMilestoneSetup(
                "Creating QUAK configuration",
                1,
                () =>
                {
                    QuakProjectSetup.PreflightConfig(ProjectRoot);
                    QuakProjectSetup.EnsureConfig(ProjectRoot);
                },
                "QUAK configuration created.");
        }

        private void StartSmokeTestSetup()
        {
            StartMilestoneSetup(
                "Creating QUAK first test",
                3,
                () =>
                {
                    QuakProjectSetup.PreflightSmokeTest(ProjectRoot);
                    QuakProjectSetup.EnsureSmokeTest(ProjectRoot);
                },
                "QUAK first test created.");
        }

        private void StartEvidenceSetup()
        {
            StartMilestoneSetup(
                "Setting up QUAK evidence",
                2,
                () =>
                {
                    QuakProjectSetup.PreflightEvidence(ProjectRoot);
                    QuakProjectSetup.EnsureEvidenceMediaIgnored(ProjectRoot);
                },
                "QUAK media excluded from Git.");
        }

        private void StartCodexSetup()
        {
            BeginSetup(
                "Installing Codex integration",
                new[] { "Codex" },
                0,
                new Action[]
                {
                    () =>
                    {
                        QuakProjectSetup.PreflightCodex(ProjectRoot);
                        QuakProjectSetup.InstallCodexSkill(ProjectRoot);
                    }
                },
                "Codex integration installed.");
        }

        private void StartDirectFeatureSetup()
        {
            BeginSetup(
                "Enabling QUAK direct Quest layer",
                new[] { "OpenXR feature" },
                0,
                new Action[] { QuakProjectSetup.EnsureDirectFeatureEnabled },
                "QUAK direct API layer enabled for Android development builds.");
        }

        private void StartMilestoneSetup(string title, int milestone, Action action, string successMessage)
        {
            BeginSetup(title, SetupMilestones, milestone, new[] { action }, successMessage);
        }

        private void BeginSetup(
            string title,
            string[] milestones,
            int firstMilestone,
            Action[] actions,
            string successMessage)
        {
            if (setupRunning)
                return;

            setupMilestones = milestones;
            setupActions = actions;
            setupFirstMilestone = firstMilestone;
            setupCompletedMilestones = firstMilestone;
            setupCurrentMilestone = firstMilestone;
            selectedSetupMilestone = -1;
            setupStepStarted = false;
            setupFailed = false;
            setupMessage = string.Empty;
            setupSuccessMessage = successMessage;
            setupRunning = true;
            setupProgressId = Progress.Start(title, milestones[firstMilestone], Progress.Options.Synchronous);
            Progress.SetStepLabel(setupProgressId, "milestones");
            Progress.SetTimeDisplayMode(setupProgressId, Progress.TimeDisplayMode.ShowRemainingTime);
            Progress.SetRemainingTime(setupProgressId, actions.Length);
            Progress.RegisterCancelCallback(setupProgressId, CancelSetup);
            Progress.Report(setupProgressId, 0, actions.Length, milestones[firstMilestone]);
            nextSetupTick = EditorApplication.timeSinceStartup + 0.15d;
            EditorApplication.update += AdvanceSetup;
            Repaint();
        }

        private void AdvanceSetup()
        {
            if (!setupRunning || EditorApplication.timeSinceStartup < nextSetupTick)
                return;

            if (!setupStepStarted)
            {
                var completedActions = setupCompletedMilestones - setupFirstMilestone;
                setupCurrentMilestone = setupFirstMilestone + completedActions;
                setupStepStarted = true;
                Progress.Report(
                    setupProgressId,
                    completedActions,
                    setupActions.Length,
                    setupMilestones[setupCurrentMilestone]);
                Progress.SetRemainingTime(
                    setupProgressId,
                    Math.Max(1, setupActions.Length - completedActions));
                nextSetupTick = EditorApplication.timeSinceStartup + 0.3d;
                Repaint();
                return;
            }

            try
            {
                setupActions[setupCurrentMilestone - setupFirstMilestone]();
                setupCompletedMilestones++;
                setupCurrentMilestone = -1;
                setupStepStarted = false;
                Progress.Report(
                    setupProgressId,
                    setupCompletedMilestones - setupFirstMilestone,
                    setupActions.Length,
                    setupCompletedMilestones == setupFirstMilestone + setupActions.Length
                        ? "Finishing"
                        : setupMilestones[setupCompletedMilestones]);

                if (setupCompletedMilestones == setupFirstMilestone + setupActions.Length)
                {
                    CompleteSetup(Progress.Status.Succeeded, setupSuccessMessage);
                    return;
                }

                nextSetupTick = EditorApplication.timeSinceStartup + 0.1d;
                Repaint();
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                CompleteSetup(Progress.Status.Failed, exception.Message);
            }
        }

        private bool CancelSetup()
        {
            CompleteSetup(Progress.Status.Canceled, "Setup cancelled.");
            return true;
        }

        private void CompleteSetup(Progress.Status status, string message)
        {
            EditorApplication.update -= AdvanceSetup;
            setupRunning = false;
            setupCurrentMilestone = -1;
            setupStepStarted = false;
            setupFailed = status == Progress.Status.Failed;
            setupMessage = message;

            if (setupProgressId >= 0 && Progress.Exists(setupProgressId))
            {
                Progress.SetDescription(setupProgressId, message);
                Progress.Finish(setupProgressId, status);
            }
            setupProgressId = -1;
            setupActions = Array.Empty<Action>();
            RefreshAll();
            Repaint();
        }

        private void StartVerification()
        {
            if (verificationRunning)
                return;

            var smokeTest = Path.Combine(ProjectRoot, QuakProjectSetup.SmokeTestRelativePath);
            if (!File.Exists(smokeTest))
            {
                try
                {
                    QuakProjectSetup.PreflightSmokeTest(ProjectRoot);
                    QuakProjectSetup.EnsureSmokeTest(ProjectRoot);
                    RefreshTests();
                }
                catch (Exception exception)
                {
                    verificationLastPassed = false;
                    verificationMessage = exception.Message;
                    return;
                }
            }

            lock (verificationOutput)
                verificationOutput.Clear();
            verificationDetails.Clear();
            verificationLastPassed = null;
            verificationMessage = "Checking the live QUAK connection…";
            var device = SelectedValidationDevice;
            verificationProcess = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = QuakExecutable,
                    WorkingDirectory = ProjectRoot,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                }
            };
            verificationProcess.StartInfo.ArgumentList.Add("verify");
            verificationProcess.StartInfo.ArgumentList.Add("--project");
            verificationProcess.StartInfo.ArgumentList.Add(ProjectRoot);
            verificationProcess.StartInfo.ArgumentList.Add("--target");
            verificationProcess.StartInfo.ArgumentList.Add(device.Target);
            if (device.Target == "quest")
            {
                verificationProcess.StartInfo.ArgumentList.Add("--expected-application-id");
                verificationProcess.StartInfo.ArgumentList.Add(
                    PlayerSettings.GetApplicationIdentifier(NamedBuildTarget.Android));
            }
            if (!string.IsNullOrWhiteSpace(device.Serial))
            {
                verificationProcess.StartInfo.ArgumentList.Add("--device-serial");
                verificationProcess.StartInfo.ArgumentList.Add(device.Serial);
            }
            verificationProcess.OutputDataReceived += QueueVerificationOutput;
            verificationProcess.ErrorDataReceived += QueueVerificationOutput;

            try
            {
                if (!verificationProcess.Start())
                    throw new InvalidOperationException("Could not start QUAK.");
                verificationProcess.BeginOutputReadLine();
                verificationProcess.BeginErrorReadLine();
                verificationRunning = true;
                verificationProgressId = Progress.Start(
                    "Verifying QUAK connection",
                    verificationMessage,
                    Progress.Options.Synchronous);
                Progress.SetStepLabel(verificationProgressId, "steps");
                Progress.RegisterCancelCallback(verificationProgressId, CancelVerification);
                Progress.Report(verificationProgressId, 0, 2, verificationMessage);
                EditorApplication.update += AdvanceVerification;
                Repaint();
            }
            catch (Exception exception)
            {
                verificationMessage = exception.Message;
                verificationDetails.AppendLine(exception.Message);
                verificationLastPassed = false;
                KillProcessTree(verificationProcess);
                DisposeProcess(ref verificationProcess, QueueVerificationOutput);
                Repaint();
            }
        }

        private void QueueVerificationOutput(object sender, System.Diagnostics.DataReceivedEventArgs args)
        {
            if (string.IsNullOrWhiteSpace(args.Data))
                return;
            lock (verificationOutput)
                verificationOutput.Enqueue(args.Data);
        }

        private void AdvanceVerification()
        {
            DrainVerificationOutput();
            if (!verificationRunning || verificationProcess == null || !verificationProcess.HasExited)
                return;
            verificationProcess.WaitForExit();
            DrainVerificationOutput();
            CompleteVerification(
                verificationProcess.ExitCode == 0 ? Progress.Status.Succeeded : Progress.Status.Failed,
                verificationProcess.ExitCode == 0
                    ? "Connection verified. The first receipt is ready."
                    : "Connection verification failed. Follow the fix below and try again.");
        }

        private void DrainVerificationOutput()
        {
            while (true)
            {
                string line;
                lock (verificationOutput)
                {
                    if (verificationOutput.Count == 0)
                        break;
                    line = verificationOutput.Dequeue();
                }
                verificationDetails.AppendLine(line);
                verificationMessage = line;
                if (verificationProgressId >= 0 && Progress.Exists(verificationProgressId))
                {
                    var completed = line.StartsWith("[2/2]", StringComparison.Ordinal) ? 1
                        : line.StartsWith("Receipt:", StringComparison.Ordinal) ? 2 : 0;
                    Progress.Report(verificationProgressId, completed, 2, line);
                }
                Repaint();
            }
        }

        private bool CancelVerification()
        {
            CancelVerification(true);
            return true;
        }

        private void CancelVerification(bool showMessage)
        {
            if (verificationProcess != null)
                KillProcessTree(verificationProcess);
            if (verificationRunning)
                CompleteVerification(
                    Progress.Status.Canceled,
                    showMessage ? "Connection verification cancelled." : string.Empty);
        }

        private void CompleteVerification(Progress.Status status, string message)
        {
            EditorApplication.update -= AdvanceVerification;
            verificationRunning = false;
            verificationLastPassed = status == Progress.Status.Succeeded;
            if (!string.IsNullOrWhiteSpace(message))
                verificationMessage = message;
            if (verificationProgressId >= 0 && Progress.Exists(verificationProgressId))
            {
                Progress.SetDescription(verificationProgressId, verificationMessage);
                Progress.Finish(verificationProgressId, status);
            }
            verificationProgressId = -1;
            DisposeProcess(ref verificationProcess, QueueVerificationOutput);
            RefreshResults();
            Repaint();
        }

        private void DrawTests()
        {
            var invalid = tests.Count(test => !test.Valid);
            var unmatchedDefinitions = tests.Count(test =>
                test.Valid && string.IsNullOrWhiteSpace(CurrentSourceHash(test)));
            var passedRuns = tests.Count(test => test.Valid && IsPassed(LatestResult(test)));
            var failedRuns = tests.Count(test => test.Valid && IsFailed(LatestResult(test)));
            var noVerdictRuns = tests.Count(test =>
                test.Valid && LatestResult(test) != null &&
                !IsPassed(LatestResult(test)) && !IsFailed(LatestResult(test)));
            var rejectedRuns = tests.Count(test => test.Valid && IsHumanRejected(LatestResult(test)));
            var pendingReviews = tests.Count(test => test.Valid && NeedsHumanReview(LatestResult(test)));
            var unrunRuns = tests.Count(test =>
                test.Valid && !string.IsNullOrWhiteSpace(CurrentSourceHash(test)) &&
                LatestResult(test) == null);
            DrawPageHeader(
                "Tests",
                "Author, run, and review repeatable XR behaviors. Parsed definitions are not CLI-validated.");

            DrawValidationDeviceSelector();
            EditorGUILayout.Space(8f);

            if (GUILayout.Button(
                    showAddTest ? "Close test authoring" : "+ Add test with agent",
                    primaryButtonStyle))
                showAddTest = !showAddTest;
            if (showAddTest)
                DrawAddTest();
            EditorGUILayout.Space(8f);

            DrawSummaryCard(
                tests.Count == 0 ? "No tests yet"
                    : invalid > 0 ? $"{invalid} test definition{(invalid == 1 ? "" : "s")} need attention"
                    : $"{passedRuns}/{tests.Count} latest exact-source receipts passed" +
                      (failedRuns > 0 ? $"  •  {failedRuns} failed" : string.Empty) +
                      (noVerdictRuns > 0 ? $"  •  {noVerdictRuns} without a verdict" : string.Empty) +
                      (unmatchedDefinitions > 0 ? $"  •  {unmatchedDefinitions} without a source hash" : string.Empty) +
                      (unrunRuns > 0 ? $"  •  {unrunRuns} not run" : string.Empty) +
                      (rejectedRuns > 0 ? $"  •  {rejectedRuns} recording{(rejectedRuns == 1 ? "" : "s")} need changes" : string.Empty) +
                      (pendingReviews > 0 ? $"  •  {pendingReviews} recording{(pendingReviews == 1 ? "" : "s")} awaiting review" : string.Empty),
                tests.Count == 0
                    ? "Describe a user behavior above and hand it to your coding agent."
                    : invalid > 0 ? $"{invalid} failed the local parse checks; run quak validate for authoritative validation."
                    : unmatchedDefinitions > 0
                        ? "QUAK could not hash the current definition bytes, so historical receipts are not associated by name."
                    : failedRuns > 0 ? "Open a failed result below to see the failing step and assertion."
                    : noVerdictRuns > 0 ? "A historical receipt is incomplete or unreadable and cannot verify behavior."
                    : rejectedRuns > 0 ? "A human found visible behavior that the machine result missed."
                    : pendingReviews > 0
                        ? $"Review the remaining recording{(pendingReviews == 1 ? "" : "s")} before trusting the full suite."
                    : unrunRuns > 0 ? "Run the tests marked NOT RUN before trusting this suite."
                    : "Definitions are parsed locally, not CLI-validated. Matching source-file receipts passed; run again to verify the current app and session.",
                tests.Count == 0 ? "NO TESTS" : invalid > 0 ? "FIX TESTS"
                    : unmatchedDefinitions > 0 ? "EXACT MATCH NEEDED"
                    : failedRuns > 0 ? "TESTS FAILED" : noVerdictRuns > 0 ? "NO VERDICT"
                    : rejectedRuns > 0 ? "CHANGES REQUESTED"
                    : pendingReviews > 0 ? "REVIEW NEEDED" : unrunRuns > 0 ? "NOT RUN" : "LAST RUNS PASSED",
                tests.Count == 0 || invalid > 0
                    ? WarningColor
                    : unmatchedDefinitions > 0 ? WarningColor
                    : failedRuns > 0 || rejectedRuns > 0 ? FailColor
                    : noVerdictRuns > 0 ? WarningColor
                    : pendingReviews > 0 || unrunRuns > 0 ? WarningColor : PassColor);

            if (tests.Count == 0)
            {
                using (new EditorGUI.DisabledScope(setupRunning))
                {
                    if (GUILayout.Button("Set up QUAK", primaryButtonStyle))
                    {
                        activeTab = 0;
                        scroll = Vector2.zero;
                        EditorApplication.delayCall += StartCoreSetup;
                    }
                }
            }
            else
            {
                for (var index = 0; index < tests.Count; index++)
                    DrawTest(tests[index], index);
            }

            EditorGUILayout.Space(6f);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Refresh"))
                {
                    RefreshValidationDevices();
                    RefreshTests();
                    RefreshResults();
                }
                using (new EditorGUI.DisabledScope(!HasSelectedTest || !SelectedValidationDevice.Runnable))
                {
                    if (GUILayout.Button("Protect selected"))
                        CopyTestCommand("regression --accept", "Protect command copied");
                    if (GUILayout.Button("Copy run command"))
                        CopyTestCommand("run", "Run command copied");
                    if (GUILayout.Button("Reveal test"))
                        EditorUtility.RevealInFinder(tests[selectedTest].Path);
                }
            }

            EditorGUILayout.Space(12f);
            DrawSectionHeader("Regression protection", "Keep known-good tests green across builds.");
            DrawRegressionSummary();
        }

        private void DrawValidationDeviceSelector()
        {
            using (new EditorGUILayout.VerticalScope(cardStyle))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField("Validation device", cardTitleStyle, GUILayout.Width(130f));
                    var labels = validationDevices.Select(device => device.Label).ToArray();
                    var selected = EditorGUILayout.Popup(
                        Mathf.Clamp(selectedValidationDevice, 0, Math.Max(0, labels.Length - 1)),
                        labels);
                    if (selected != selectedValidationDevice && selected < validationDevices.Count)
                    {
                        selectedValidationDevice = selected;
                        EditorPrefs.SetString(
                            ValidationDevicePreferenceKey,
                            validationDevices[selected].Key);
                    }
                    if (GUILayout.Button("Refresh", GUILayout.Width(68f)))
                        RefreshValidationDevices();
                }

                var device = SelectedValidationDevice;
                EditorGUILayout.LabelField(device.Detail, detailStyle);
                if (!string.IsNullOrWhiteSpace(validationDeviceError))
                    EditorGUILayout.LabelField(validationDeviceError, detailStyle);
                if (!device.Runnable)
                    EditorGUILayout.HelpBox(
                        "This ADB device is not authorized and cannot run a test yet.",
                        MessageType.Warning);
                if (device.Target == "quest" && !EditorUserBuildSettings.development)
                    EditorGUILayout.HelpBox(
                        "Quest direct testing requires a Development Build. Enable Development Build " +
                        "in Build Profiles before building the APK.",
                        MessageType.Warning);
            }
        }

        private ValidationDevice SelectedValidationDevice =>
            validationDevices.Count == 0
                ? new ValidationDevice("auto", "Unity Editor", "editor", string.Empty, true,
                    "No device scan is available; using the open Unity Editor.")
                : validationDevices[Mathf.Clamp(selectedValidationDevice, 0, validationDevices.Count - 1)];

        private void RefreshValidationDevices()
        {
            var preferred = validationDevices.Count > 0 && selectedValidationDevice < validationDevices.Count
                ? validationDevices[selectedValidationDevice].Key
                : EditorPrefs.GetString(ValidationDevicePreferenceKey, "auto");
            validationDevices.Clear();
            validationDeviceError = string.Empty;

            var headsets = FindAdbDevices();
            var editor = new ValidationDevice(
                "editor",
                "Unity Editor",
                "editor",
                string.Empty,
                true,
                Application.platform == RuntimePlatform.OSXEditor
                    ? "Runs in the Editor workflow; Meta XR Simulator may provide its OpenXR runtime on macOS."
                    : "Runs against the currently open Unity Editor workflow.");
            var automatic = headsets.FirstOrDefault(device => device.Runnable) ?? editor;
            validationDevices.Add(new ValidationDevice(
                "auto",
                $"Automatic — {automatic.Label}",
                automatic.Target,
                automatic.Serial,
                true,
                $"Automatic priority: connected Quest → Unity Editor → Meta XR Simulator. Using {automatic.Label}."));
            validationDevices.AddRange(headsets);
            validationDevices.Add(editor);
            if (SupportsMetaXrSimulator())
                validationDevices.Add(new ValidationDevice(
                    "simulator",
                    "Meta XR Simulator",
                    "simulator",
                    string.Empty,
                    true,
                    "Optional desktop runtime supported on Windows and Apple-silicon macOS."));

            selectedValidationDevice = Math.Max(
                0,
                validationDevices.FindIndex(device => device.Key == preferred));
        }

        private List<ValidationDevice> FindAdbDevices()
        {
            var devices = new List<ValidationDevice>();
            var adb = FindAdb();
            if (string.IsNullOrWhiteSpace(adb))
            {
                validationDeviceError = "ADB was not found, so connected Quest headsets cannot be listed.";
                return devices;
            }

            try
            {
                using var process = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName = adb,
                        UseShellExecute = false,
                        CreateNoWindow = true,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true
                    }
                };
                process.StartInfo.ArgumentList.Add("devices");
                process.StartInfo.ArgumentList.Add("-l");
                process.Start();
                if (!process.WaitForExit(3000))
                {
                    process.Kill();
                    validationDeviceError = "ADB device scan timed out.";
                    return devices;
                }
                var output = process.StandardOutput.ReadToEnd();
                var error = process.StandardError.ReadToEnd();
                if (process.ExitCode != 0)
                {
                    validationDeviceError = string.IsNullOrWhiteSpace(error)
                        ? "ADB could not list devices."
                        : error.Trim();
                    return devices;
                }

                foreach (var line in output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    var parts = line.Split((char[])null, StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length < 2 || parts[0] == "List" || parts[0].StartsWith("*", StringComparison.Ordinal))
                        continue;
                    var serial = parts[0];
                    var state = parts[1];
                    var model = parts.FirstOrDefault(part => part.StartsWith("model:", StringComparison.Ordinal))
                        ?.Substring("model:".Length).Replace('_', ' ');
                    var ready = state == "device";
                    var label = $"Quest{(string.IsNullOrWhiteSpace(model) ? string.Empty : " " + model)} — {serial}" +
                                (ready ? string.Empty : $" ({state})");
                    devices.Add(new ValidationDevice(
                        "quest:" + serial,
                        label,
                        "quest",
                        serial,
                        ready,
                        ready
                            ? "Connected through ADB. QUAK will allocate a private direct-bridge port for this headset."
                            : $"ADB sees this headset as {state}. Authorize USB debugging in the headset."));
                }
            }
            catch (Exception exception)
            {
                validationDeviceError = $"ADB device scan failed: {exception.Message}";
            }
            return devices;
        }

        private static string FindAdb()
        {
            var executable = Application.platform == RuntimePlatform.WindowsEditor ? "adb.exe" : "adb";
            var candidates = new List<string>();
            foreach (var variable in new[] { "ANDROID_SDK_ROOT", "ANDROID_HOME" })
            {
                var root = Environment.GetEnvironmentVariable(variable);
                if (!string.IsNullOrWhiteSpace(root))
                    candidates.Add(Path.Combine(root, "platform-tools", executable));
            }
            var unitySdk = EditorPrefs.GetString("AndroidSdkRoot");
            if (!string.IsNullOrWhiteSpace(unitySdk))
                candidates.Add(Path.Combine(unitySdk, "platform-tools", executable));
            var path = Environment.GetEnvironmentVariable("PATH");
            if (!string.IsNullOrWhiteSpace(path))
                candidates.AddRange(path.Split(Path.PathSeparator)
                    .Where(folder => !string.IsNullOrWhiteSpace(folder))
                    .Select(folder => Path.Combine(folder, executable)));
            return candidates.FirstOrDefault(File.Exists);
        }

        private static bool SupportsMetaXrSimulator()
        {
            if (Application.platform == RuntimePlatform.WindowsEditor)
                return true;
            if (Application.platform != RuntimePlatform.OSXEditor)
                return false;
            var processor = SystemInfo.processorType ?? string.Empty;
            return processor.IndexOf("Apple", StringComparison.OrdinalIgnoreCase) >= 0 ||
                   processor.IndexOf("ARM", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private void DrawAddTest()
        {
            using (new EditorGUILayout.VerticalScope(cardStyle))
            {
                EditorGUILayout.LabelField("What should the user be able to do?", cardTitleStyle);
                EditorGUILayout.LabelField(
                    "A useful XR test may need stable targets and independent app state, so QUAK hands the complete job to your existing agent instead of creating an empty JSON file.",
                    detailStyle);
                EditorGUILayout.Space(4f);
                newTestDescription = EditorGUILayout.TextArea(
                    newTestDescription,
                    GUILayout.MinHeight(58f));
                newTestTarget = EditorGUILayout.Popup(
                    "Run on",
                    newTestTarget,
                    TestTargetLabels);
                newTestVisualEvidence = EditorGUILayout.Popup(
                    "Visual evidence",
                    newTestVisualEvidence,
                    VisualEvidenceLabels);
                if (newTestVisualEvidence > 0)
                {
                    if (newTestVisualEvidence == 2)
                    {
                        newTestFocusClips = EditorGUILayout.Popup(
                            "Focused clips",
                            newTestFocusClips,
                            FocusClipLabels);
                        newTestTargetHighlight = EditorGUILayout.Popup(
                            "Target highlight",
                            newTestTargetHighlight,
                            TargetHighlightLabels);
                        if (FocusClipValues[newTestFocusClips] == "off" &&
                            TargetHighlightValues[newTestTargetHighlight] == "focused-clips")
                            newTestTargetHighlight = Array.IndexOf(
                                TargetHighlightValues, "off");
                    }
                    EditorGUILayout.HelpBox(
                        "Standard records the full journey with step subtitles, retains the clean raw source, " +
                        "and creates highlighted clips for titled interactions and failures. " +
                        "Advanced changes clip selection or highlight scope.",
                        MessageType.Info);
                }
                else
                {
                    EditorGUILayout.HelpBox(
                        "Off records no visual evidence. Structured product assertions still run.",
                        MessageType.None);
                }

                using (new EditorGUILayout.HorizontalScope())
                using (new EditorGUI.DisabledScope(string.IsNullOrWhiteSpace(newTestDescription)))
                {
                    if (GUILayout.Button("Copy agent instruction"))
                        CopyToClipboard(BuildTestAuthoringInstruction(), "Agent instruction copied");
                    using (new EditorGUI.DisabledScope(string.IsNullOrWhiteSpace(CodexExecutable)))
                    {
                        if (GUILayout.Button("Copy & open Codex"))
                            OpenCodexForTest();
                    }
                }

                EditorGUILayout.LabelField(
                    "Paste the copied brief into ChatGPT, Claude, Codex, or another coding agent with project access.",
                    detailStyle);
            }
        }

        private void DrawMachines()
        {
            var enabled = machines.Where(machine => machine != null && machine.enabled).ToArray();
            var invalid = enabled.Count(machine => !string.IsNullOrEmpty(MachineIssue(machine)));
            var ready = enabled.Length - invalid;

            DrawPageHeader("Test machines", "Split protected tests across isolated Unity sessions.");
            var status = machineCommandRunning
                ? "RUNNING"
                : machineLastPassed == true ? "READY" : machineLastPassed == false ? "FAILED"
                : machines.Count == 0 ? "EMPTY" : invalid == 0 ? "CONFIGURED" : "FIX";
            var statusColor = machineCommandRunning || machineLastPassed == null && invalid == 0 && machines.Count > 0
                ? AccentColor
                : machineLastPassed == true ? PassColor
                : machineLastPassed == false || invalid > 0 ? FailColor
                : WarningColor;
            DrawSummaryCard(
                machines.Count == 0
                    ? "No machines configured"
                    : $"{ready} machine{(ready == 1 ? "" : "s")} configured",
                machineCommandRunning
                    ? machineCommandMessage
                    : !string.IsNullOrWhiteSpace(machineCommandMessage)
                        ? machineCommandMessage
                    : machines.Count == 0
                    ? "Add machines using SSH aliases from your local SSH config."
                    : invalid == 0
                        ? "Shard assignments are ready. Test connections before the first run."
                        : $"Fix {invalid} enabled machine{(invalid == 1 ? "" : "s")} before splitting tests.",
                status,
                statusColor);

            EditorGUILayout.LabelField(
                "No credentials are stored. One machine must control only one live Unity session or headset at a time.",
                detailStyle);
            EditorGUILayout.Space(8f);

            if (!string.IsNullOrWhiteSpace(machinesError))
                EditorGUILayout.HelpBox(machinesError, MessageType.Error);

            for (var index = 0; index < machines.Count; index++)
            {
                var machine = machines[index];
                if (machine == null)
                    continue;

                var remove = false;
                EditorGUI.BeginChangeCheck();
                using (new EditorGUILayout.VerticalScope(cardStyle))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        machine.enabled = EditorGUILayout.ToggleLeft(
                            string.IsNullOrWhiteSpace(machine.name) ? $"Machine {index + 1}" : machine.name,
                            machine.enabled);
                        if (GUILayout.Button("Remove", GUILayout.Width(70f)))
                            remove = true;
                    }

                    machine.name = EditorGUILayout.TextField("Name", machine.name ?? string.Empty);
                    machine.host = EditorGUILayout.TextField("SSH host", machine.host ?? string.Empty);
                    var targetIndex = Array.IndexOf(MachineTargets, machine.target);
                    var selectedTarget = EditorGUILayout.Popup("Run on", targetIndex, MachineTargetLabels);
                    if (selectedTarget >= 0)
                        machine.target = MachineTargets[selectedTarget];
                    machine.project_path = EditorGUILayout.TextField(
                        "Remote project",
                        machine.project_path ?? string.Empty);
                    machine.expected_application_id = EditorGUILayout.TextField(
                        machine.target == "quest" ? "Expected app ID" : "Expected app ID (optional)",
                        machine.expected_application_id ?? string.Empty);
                    machine.expected_scene = EditorGUILayout.TextField(
                        "Expected scene (optional)",
                        machine.expected_scene ?? string.Empty);

                    var issue = MachineIssue(machine);
                    if (!machine.enabled)
                    {
                        DrawStatusLabel("OFF", WarningColor, 82f);
                    }
                    else if (!string.IsNullOrEmpty(issue))
                    {
                        EditorGUILayout.LabelField(issue, detailStyle);
                        DrawStatusLabel("FIX", FailColor, 82f);
                    }
                    else
                    {
                        var lane = ReadyMachines(machine.target);
                        var shardIndex = lane.IndexOf(machine);
                        EditorGUILayout.LabelField(
                            $"{machine.target} shard {shardIndex + 1} of {lane.Count}",
                            detailStyle);
                        if (machineStates.TryGetValue(machine.name, out var machineState))
                        {
                            var stateColor = machineState == "READY" || machineState == "PASSED"
                                ? PassColor
                                : machineState == "FAILED" ? FailColor : AccentColor;
                            DrawStatusLabel(machineState, stateColor, 94f);
                        }
                        else
                        {
                            DrawStatusLabel("CONFIGURED", AccentColor, 94f);
                        }
                    }
                }

                if (EditorGUI.EndChangeCheck())
                    machinesDirty = true;
                if (remove)
                {
                    machines.RemoveAt(index);
                    machinesDirty = true;
                    index--;
                }
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Add machine"))
                {
                    machines.Add(new TestMachine
                    {
                        enabled = true,
                        name = $"Machine {machines.Count + 1}",
                        target = "quest",
                        project_path = ProjectRoot
                    });
                    machinesDirty = true;
                }
                using (new EditorGUI.DisabledScope(!machinesDirty))
                {
                    if (GUILayout.Button("Save"))
                        SaveMachines();
                }
                if (GUILayout.Button("Reload"))
                    RefreshMachines();
            }

            var canSplit = enabled.Length > 0 && invalid == 0 && !machineCommandRunning;
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(!canSplit))
                {
                    if (GUILayout.Button("Test connections", GUILayout.Height(30f)))
                        StartMachineCommand("check");
                }
                using (new EditorGUI.DisabledScope(!canSplit || !hasRegressionCatalog))
                {
                    if (GUILayout.Button("Run distributed suite", GUILayout.Height(30f)))
                        StartMachineCommand("run");
                }
            }
        }

        private string MachineIssue(TestMachine machine)
        {
            if (!machine.enabled)
                return string.Empty;
            if (string.IsNullOrWhiteSpace(machine.name))
                return "Name is required.";
            if (string.IsNullOrWhiteSpace(machine.host))
                return "SSH host is required.";
            if (machine.host.StartsWith("-", StringComparison.Ordinal) ||
                machine.host.Any(char.IsWhiteSpace))
                return "SSH host must be an alias or user@host without options.";
            if (!MachineTargets.Contains(machine.target))
                return "Run target must be Editor, Simulator, or Quest.";
            if (string.IsNullOrWhiteSpace(machine.project_path) ||
                machine.project_path.IndexOfAny(new[] { '\r', '\n' }) >= 0)
                return "Remote project path is required.";
            if (machine.target == "quest" && string.IsNullOrWhiteSpace(machine.expected_application_id))
                return "Quest machines require an expected app ID.";
            if (machines.Count(other => other != null && other.enabled &&
                                      string.Equals(other.name?.Trim(), machine.name.Trim(), StringComparison.Ordinal)) > 1)
                return "Machine names must be unique.";
            if (machines.Count(other => other != null && other.enabled &&
                                      string.Equals(other.host?.Trim(), machine.host.Trim(), StringComparison.Ordinal)) > 1)
                return "Each enabled machine needs a unique SSH host.";
            return string.Empty;
        }

        private List<TestMachine> ReadyMachines(string target)
        {
            return machines
                .Where(machine => machine != null && machine.enabled &&
                                  machine.target == target && string.IsNullOrEmpty(MachineIssue(machine)))
                .ToList();
        }

        private void RefreshMachines()
        {
            machines.Clear();
            machinesError = string.Empty;
            machinesDirty = false;
            var path = Path.Combine(ProjectRoot, QuakProjectSetup.MachinesRelativePath);
            if (!File.Exists(path))
                return;

            try
            {
                var config = JsonUtility.FromJson<MachineConfig>(File.ReadAllText(path));
                if (config == null || config.schema_version != 1 || config.machines == null)
                    throw new InvalidDataException(".quak/machines.local.json is invalid.");
                machines.AddRange(config.machines.Where(machine => machine != null));
            }
            catch (Exception exception)
            {
                machinesError = exception.Message;
            }
        }

        private void SaveMachines()
        {
            var path = Path.Combine(ProjectRoot, QuakProjectSetup.MachinesRelativePath);
            var temporary = path + ".tmp";
            try
            {
                foreach (var machine in machines.Where(machine => machine != null))
                {
                    machine.name = machine.name?.Trim();
                    machine.host = machine.host?.Trim();
                    machine.target = machine.target?.Trim();
                    machine.project_path = machine.project_path?.Trim();
                    machine.expected_application_id = string.IsNullOrWhiteSpace(machine.expected_application_id)
                        ? null
                        : machine.expected_application_id.Trim();
                    machine.expected_scene = string.IsNullOrWhiteSpace(machine.expected_scene)
                        ? null
                        : machine.expected_scene.Trim();
                }
                var issue = machines.Select(MachineIssue)
                    .FirstOrDefault(value => !string.IsNullOrEmpty(value));
                if (!string.IsNullOrEmpty(issue))
                    throw new InvalidDataException(issue);
                Directory.CreateDirectory(Path.GetDirectoryName(path) ?? ProjectRoot);
                QuakProjectSetup.EnsureMachinesIgnored(ProjectRoot);
                var config = new MachineConfig { machines = machines.ToArray() };
                File.WriteAllText(temporary, JsonUtility.ToJson(config, true) + Environment.NewLine);
                if (File.Exists(path))
                    File.Replace(temporary, path, null);
                else
                    File.Move(temporary, path);
                machinesDirty = false;
                machinesError = string.Empty;
                ShowNotification(new GUIContent("Test machines saved"));
            }
            catch (Exception exception)
            {
                machinesError = exception.Message;
            }
        }

        private void StartMachineCommand(string action)
        {
            if (machineCommandRunning)
                return;
            if (machinesDirty)
                SaveMachines();
            if (machinesDirty || !string.IsNullOrWhiteSpace(machinesError))
                return;

            machineStates.Clear();
            foreach (var machine in machines.Where(machine => machine != null && machine.enabled))
                machineStates[machine.name] = "CHECKING";
            lock (machineOutput)
                machineOutput.Clear();
            machineCommandAction = action;
            machineCommandMessage = action == "check" ? "Checking live machine readiness…" : "Checking machines before the run…";
            machineLastPassed = null;
            machineProgressCompleted = 0;
            machineProgressTotal = Math.Max(1, machines.Count(machine => machine != null && machine.enabled) * (action == "run" ? 2 : 1));
            machineCommandStartedAt = EditorApplication.timeSinceStartup;

            machineProcess = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = QuakExecutable,
                    WorkingDirectory = ProjectRoot,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                }
            };
            machineProcess.StartInfo.ArgumentList.Add("machines");
            machineProcess.StartInfo.ArgumentList.Add(action);
            machineProcess.StartInfo.ArgumentList.Add("--events");
            machineProcess.StartInfo.ArgumentList.Add("--project");
            machineProcess.StartInfo.ArgumentList.Add(ProjectRoot);
            machineProcess.OutputDataReceived += QueueMachineOutput;
            machineProcess.ErrorDataReceived += QueueMachineOutput;

            try
            {
                if (!machineProcess.Start())
                    throw new InvalidOperationException("Could not start QUAK.");
                machineProcess.BeginOutputReadLine();
                machineProcess.BeginErrorReadLine();
                machineCommandRunning = true;
                var title = action == "check" ? "Checking QUAK machines" : "Running QUAK regression suite";
                machineProgressId = Progress.Start(title, machineCommandMessage, Progress.Options.Synchronous);
                Progress.SetStepLabel(machineProgressId, "steps");
                Progress.SetTimeDisplayMode(machineProgressId, Progress.TimeDisplayMode.ShowRemainingTime);
                Progress.SetRemainingTime(machineProgressId, machineProgressTotal * 10L);
                Progress.RegisterCancelCallback(machineProgressId, CancelMachineCommand);
                Progress.Report(machineProgressId, 0, machineProgressTotal, machineCommandMessage);
                EditorApplication.update += AdvanceMachineCommand;
                Repaint();
            }
            catch (Exception exception)
            {
                machineCommandMessage = exception.Message;
                machineLastPassed = false;
                KillProcessTree(machineProcess);
                DisposeProcess(ref machineProcess, QueueMachineOutput);
                Repaint();
            }
        }

        private void QueueMachineOutput(object sender, System.Diagnostics.DataReceivedEventArgs args)
        {
            if (string.IsNullOrWhiteSpace(args.Data))
                return;
            lock (machineOutput)
                machineOutput.Enqueue(args.Data);
        }

        private void AdvanceMachineCommand()
        {
            DrainMachineOutput();
            if (!machineCommandRunning || machineProcess == null || !machineProcess.HasExited)
                return;
            machineProcess.WaitForExit();
            DrainMachineOutput();
            CompleteMachineCommand(
                machineProcess.ExitCode == 0 ? Progress.Status.Succeeded : Progress.Status.Failed,
                machineProcess.ExitCode == 0
                    ? machineCommandAction == "check" ? "All machine connections are ready." : "Distributed regression suite passed."
                    : string.IsNullOrWhiteSpace(machineCommandMessage) ? "QUAK machine command failed." : machineCommandMessage);
        }

        private void DrainMachineOutput()
        {
            while (true)
            {
                string line;
                lock (machineOutput)
                {
                    if (machineOutput.Count == 0)
                        break;
                    line = machineOutput.Dequeue();
                }
                if (!line.StartsWith("QUAK_EVENT ", StringComparison.Ordinal))
                {
                    machineCommandMessage = line;
                    continue;
                }

                var machineEvent = JsonUtility.FromJson<MachineEvent>(line.Substring("QUAK_EVENT ".Length));
                if (machineEvent == null)
                    continue;
                machineProgressCompleted = machineEvent.completed;
                machineProgressTotal = Math.Max(1, machineEvent.total);
                if (!string.IsNullOrWhiteSpace(machineEvent.detail))
                    machineCommandMessage = machineEvent.detail;
                if (!string.IsNullOrWhiteSpace(machineEvent.machine))
                {
                    machineStates[machineEvent.machine] = machineEvent.status switch
                    {
                        "ready" => machineCommandAction == "run" ? "QUEUED" : "READY",
                        "passed" => "PASSED",
                        "failed" => "FAILED",
                        _ => "RUNNING"
                    };
                }
                if (machineProgressId >= 0 && Progress.Exists(machineProgressId))
                {
                    Progress.Report(machineProgressId, machineProgressCompleted, machineProgressTotal, machineCommandMessage);
                    if (machineProgressCompleted > 0)
                    {
                        var elapsed = EditorApplication.timeSinceStartup - machineCommandStartedAt;
                        var remaining = elapsed / machineProgressCompleted * (machineProgressTotal - machineProgressCompleted);
                        Progress.SetRemainingTime(machineProgressId, Math.Max(0L, (long)Math.Ceiling(remaining)));
                    }
                }
                Repaint();
            }
        }

        private bool CancelMachineCommand()
        {
            CancelMachineCommand(true);
            return true;
        }

        private void CancelMachineCommand(bool showMessage)
        {
            if (machineProcess != null)
                KillProcessTree(machineProcess);
            if (machineCommandRunning)
                CompleteMachineCommand(Progress.Status.Canceled, showMessage ? "Machine run cancelled." : string.Empty);
        }

        private static void KillProcessTree(Process process)
        {
            int processId;
            try
            {
                if (process == null || process.HasExited)
                    return;
                processId = process.Id;
            }
            catch (InvalidOperationException)
            {
                return;
            }
            catch (System.ComponentModel.Win32Exception)
            {
                return;
            }

            if (Application.platform == RuntimePlatform.WindowsEditor)
            {
                var taskkill = new ProcessStartInfo
                {
                    FileName = "taskkill",
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                taskkill.ArgumentList.Add("/PID");
                taskkill.ArgumentList.Add(processId.ToString());
                taskkill.ArgumentList.Add("/T");
                taskkill.ArgumentList.Add("/F");
                try
                {
                    using var cancellation = Process.Start(taskkill);
                    cancellation?.WaitForExit(1000);
                }
                catch (Exception)
                {
                }
            }
            else
            {
                KillUnixDescendants(processId);
            }
            TryKill(process);
            try
            {
                process.WaitForExit(1000);
            }
            catch (InvalidOperationException)
            {
            }
        }

        private static void KillUnixDescendants(int parentId)
        {
            var childIds = new List<int>();
            var findChildren = new ProcessStartInfo
            {
                FileName = File.Exists("/usr/bin/pgrep") ? "/usr/bin/pgrep" : "pgrep",
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true
            };
            findChildren.ArgumentList.Add("-P");
            findChildren.ArgumentList.Add(parentId.ToString());
            try
            {
                using var query = Process.Start(findChildren);
                if (query != null)
                {
                    while (int.TryParse(query.StandardOutput.ReadLine(), out var childId))
                        childIds.Add(childId);
                    query.WaitForExit();
                }
            }
            catch (Exception)
            {
            }

            foreach (var childId in childIds)
            {
                KillUnixDescendants(childId);
                try
                {
                    using var child = Process.GetProcessById(childId);
                    TryKill(child);
                }
                catch (ArgumentException)
                {
                }
            }
        }

        private static void TryKill(Process process)
        {
            try
            {
                if (!process.HasExited)
                    process.Kill();
            }
            catch (InvalidOperationException)
            {
            }
            catch (System.ComponentModel.Win32Exception)
            {
            }
        }

        private static void DisposeProcess(
            ref Process process,
            System.Diagnostics.DataReceivedEventHandler outputHandler)
        {
            if (process == null)
                return;
            process.OutputDataReceived -= outputHandler;
            process.ErrorDataReceived -= outputHandler;
            process.Dispose();
            process = null;
        }

        private void CompleteMachineCommand(Progress.Status status, string message)
        {
            EditorApplication.update -= AdvanceMachineCommand;
            machineCommandRunning = false;
            machineLastPassed = status == Progress.Status.Succeeded;
            if (!string.IsNullOrWhiteSpace(message))
                machineCommandMessage = message;
            if (machineProgressId >= 0 && Progress.Exists(machineProgressId))
            {
                Progress.SetDescription(machineProgressId, machineCommandMessage);
                Progress.Finish(machineProgressId, status);
            }
            machineProgressId = -1;
            DisposeProcess(ref machineProcess, QueueMachineOutput);
            RefreshResults();
            Repaint();
        }

        private void DrawRegressionSummary()
        {
            if (!string.IsNullOrWhiteSpace(regressionError))
            {
                DrawSummaryCard(
                    "Regression status is unreadable",
                    regressionError,
                    "FIX",
                    FailColor);
                return;
            }

            var regressionCount = regressionReport?.regressions?.Length ?? 0;
            var latestPassed = string.Equals(
                regressionReport?.status,
                "passed",
                StringComparison.OrdinalIgnoreCase);
            var completeSuitePassed = latestPassed &&
                                      regressionReport.tested == protectedTestCount &&
                                      regressionReport.@protected == protectedTestCount;
            DrawSummaryCard(
                !hasRegressionCatalog
                    ? "Regression protection is off"
                    : regressionReport == null
                        ? $"{protectedTestCount} test{(protectedTestCount == 1 ? "" : "s")} protected"
                        : latestPassed
                            ? $"{protectedTestCount} test{(protectedTestCount == 1 ? "" : "s")} protected"
                            : $"{regressionCount} regression{(regressionCount == 1 ? "" : "s")} found",
                !hasRegressionCatalog
                    ? "Accept known-good tests once, then QUAK will guard them."
                    : regressionReport == null
                        ? "Run the protected suite to verify this build."
                        : completeSuitePassed
                            ? $"Latest suite passed {regressionReport.passed_tests} test{(regressionReport.passed_tests == 1 ? "" : "s")}."
                            : latestPassed
                                ? "Baseline updated; run the full protected suite."
                                : $"Latest suite passed {regressionReport.passed_tests} of {regressionReport.@protected} protected tests.",
                !hasRegressionCatalog ? "OFF" : regressionReport == null || latestPassed && !completeSuitePassed ? "NOT RUN" : latestPassed ? "PASSING" : "REGRESSION",
                !hasRegressionCatalog || regressionReport == null || latestPassed && !completeSuitePassed ? WarningColor : latestPassed ? PassColor : FailColor);

            if (GUILayout.Button(hasRegressionCatalog ? "Copy regression command" : "Copy protect-all command"))
            {
                var accept = hasRegressionCatalog ? string.Empty : " --accept";
                CopyToClipboard(
                    $"{ShellQuote(QuakExecutable)} regression{accept} --project {ShellQuote(ProjectRoot)}",
                    "Regression command copied");
            }
            EditorGUILayout.Space(10f);
        }

        private void DrawPageHeader(string title, string detail)
        {
            EditorGUILayout.LabelField(title, pageTitleStyle);
            EditorGUILayout.LabelField(detail, detailStyle);
            EditorGUILayout.Space(10f);
        }

        private void DrawSummaryCard(string title, string detail, string status, Color color)
        {
            using (new EditorGUILayout.VerticalScope(cardStyle))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(title, cardTitleStyle);
                    DrawStatusLabel(status, color, 94f);
                }
                EditorGUILayout.LabelField(detail, detailStyle);
            }
            EditorGUILayout.Space(6f);
        }

        private void DrawSectionHeader(string title, string detail)
        {
            EditorGUILayout.LabelField(title, sectionTitleStyle);
            EditorGUILayout.LabelField(detail, detailStyle);
            EditorGUILayout.Space(5f);
        }

        private void DrawSetupCheck(SetupCheck check, string detail = null)
        {
            using (new EditorGUILayout.VerticalScope(cardStyle))
            {
                var label = IsOptionalSetupCheck(check) ? "OPTIONAL" : check.Level switch
                {
                    CheckLevel.Pass => "OK",
                    CheckLevel.Warning when IsRequiredSetupCheck(check) => "MISSING",
                    CheckLevel.Warning => "WARNING",
                    _ => "FIX"
                };
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(check.Name, cardTitleStyle);
                    var color = IsOptionalSetupCheck(check)
                        ? AccentColor
                        : ColorFor(check.Level);
                    if (check.Navigate != null && GUILayout.Button(check.NavigateLabel, GUILayout.Width(150f)))
                        EditorApplication.delayCall += () => check.Navigate();
                    DrawStatusLabel(label, color, 76f, $"{label}: {check.StatusReason}");
                }
                EditorGUILayout.LabelField(detail ?? check.Detail, detailStyle);
                if (check.Action != null)
                {
                    using (new EditorGUI.DisabledScope(setupRunning))
                    {
                        if (GUILayout.Button(check.ActionLabel))
                            EditorApplication.delayCall += () => check.Action();
                    }
                }
            }
        }

        private static string SetupCategoryLabel(SetupCategory category) => category switch
        {
            SetupCategory.Editor => "Editor",
            SetupCategory.Packages => "Packages",
            SetupCategory.Project => "Project files",
            SetupCategory.Integrations => "Integrations",
            SetupCategory.Environment => "Runtime environment",
            _ => string.Empty
        };

        private static string SetupCategoryDetail(SetupCategory category) => category switch
        {
            SetupCategory.Editor => "Unity Editor compatibility for this project.",
            SetupCategory.Packages => "Unity packages QUAK requires.",
            SetupCategory.Project => "Local configuration, tests, and private evidence storage.",
            SetupCategory.Integrations => "Optional tools that extend QUAK.",
            SetupCategory.Environment => "Host settings used to run XR tests.",
            _ => string.Empty
        };

        private static bool IsRequiredSetupCheck(SetupCheck check)
        {
            return check.Name == "QUAK configuration" ||
                   check.Name == "QUAK evidence media" ||
                   check.Name == "QUAK direct Quest layer";
        }

        private static bool IsOptionalSetupCheck(SetupCheck check) =>
            check.Name == "QUAK first test" ||
            check.Name == "AI agent guidance" ||
            check.Name == "Codex integration";

        private static bool IsOptionalMilestone(int index) => index >= 3;

        private void DrawTest(TestFile test, int index)
        {
            var latest = test.Valid ? LatestResult(test) : null;
            var sourceHash = test.Valid ? CurrentSourceHash(test) : string.Empty;
            var relative = RelativePath(test.Path).Replace(Path.DirectorySeparatorChar, '/');
            var protectedTest = protectedTestPaths.Contains(relative);
            using (new EditorGUILayout.VerticalScope(cardStyle))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    var wasSelected = index == selectedTest;
                    var isSelected = GUILayout.Toggle(wasSelected, GUIContent.none, GUILayout.Width(18f));
                    if (isSelected != wasSelected)
                        selectedTest = isSelected ? index : -1;

                    using (new EditorGUILayout.VerticalScope())
                    {
                        EditorGUILayout.LabelField(test.Name, cardTitleStyle);
                        EditorGUILayout.LabelField(
                            $"{test.Target}  •  {test.StepCount} steps  •  {test.AssertionCount} assertions" +
                            (protectedTest ? "  •  protected" : string.Empty),
                            detailStyle);
                        EditorGUILayout.LabelField(RelativePath(test.Path), detailStyle);
                        EditorGUILayout.LabelField(
                            test.Valid
                                ? string.IsNullOrWhiteSpace(sourceHash)
                                    ? "Definition: PARSED LOCALLY • SOURCE HASH UNAVAILABLE"
                                    : "Definition: PARSED LOCALLY • EXACT SOURCE RECEIPTS ONLY"
                                : "Definition: LOCAL PARSE ERROR",
                            detailStyle);
                        if (!test.Valid)
                            EditorGUILayout.LabelField(test.Error, detailStyle);
                    }

                    using (new EditorGUILayout.VerticalScope(GUILayout.Width(118f)))
                    {
                        if (!test.Valid)
                            DrawStatusLabel("PARSE ERROR", FailColor, 118f);
                        else
                            DrawStatusLabel(
                                latest == null && string.IsNullOrWhiteSpace(sourceHash)
                                    ? "NO MATCH"
                                    : ResultBadge(latest),
                                ResultColor(latest),
                                118f);

                        using (new EditorGUI.DisabledScope(latest == null))
                        {
                            var isExpanded = string.Equals(
                                expandedResultTestPath,
                                test.Path,
                                StringComparison.Ordinal);
                            if (GUILayout.Button(isExpanded ? "Hide result" : "View result", GUILayout.Width(118f)))
                            {
                                expandedResultTestPath = isExpanded ? string.Empty : test.Path;
                                if (isExpanded)
                                    ReleaseReviewVideo();
                            }
                        }
                    }
                }

                if (index == selectedTest && test.Valid)
                    DrawEvidenceSettings(test);
                DrawRunSummary(latest, test.Valid, sourceHash);
                if (latest != null && string.Equals(
                        expandedResultTestPath,
                        test.Path,
                        StringComparison.Ordinal))
                    DrawResultDetails(test, latest);
            }
        }

        private void DrawEvidenceSettings(TestFile test)
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Visual evidence", cardTitleStyle);
                var currentMode = !test.VisualEvidenceEnabled ? 0
                    : test.FocusClips == "marked-and-failures" &&
                      test.TargetHighlight == "focused-clips" ? 1 : 2;
                var mode = EditorGUILayout.Popup(
                    "Mode",
                    currentMode,
                    VisualEvidenceLabels);
                var focus = Array.IndexOf(FocusClipValues, test.FocusClips);
                var highlight = Array.IndexOf(TargetHighlightValues, test.TargetHighlight);
                focus = Mathf.Max(0, focus);
                highlight = Mathf.Max(0, highlight);

                if (mode > 0)
                {
                    if (mode == 1)
                    {
                        focus = 0;
                        highlight = 0;
                    }
                    else
                    {
                        focus = EditorGUILayout.Popup("Focused clips", focus, FocusClipLabels);
                        highlight = EditorGUILayout.Popup(
                            "Target highlight", highlight, TargetHighlightLabels);
                        if (FocusClipValues[focus] == "off" &&
                            TargetHighlightValues[highlight] == "focused-clips")
                            highlight = Array.IndexOf(TargetHighlightValues, "off");
                    }
                    EditorGUILayout.LabelField(
                        "Full journey: timed step subtitles. Focus clips: short title, target zoom, highlight, " +
                        "and machine verdict. The unprocessed source recording is always retained." +
                        (TargetHighlightValues[highlight] == "all-recordings"
                            ? " With All recordings, its live target outline is intentionally visible in the source."
                            : string.Empty),
                        detailStyle);
                }
                else
                {
                    EditorGUILayout.LabelField(
                        "No visual recording. Structured assertions remain active.",
                        detailStyle);
                }

                var changed = mode != currentMode ||
                              mode > 0 &&
                              (FocusClipValues[focus] != test.FocusClips ||
                               TargetHighlightValues[highlight] != test.TargetHighlight);
                using (new EditorGUI.DisabledScope(!changed))
                {
                    if (GUILayout.Button("Apply evidence settings"))
                        ApplyEvidenceSettings(
                            test,
                            mode,
                            FocusClipValues[focus],
                            TargetHighlightValues[highlight]);
                }
            }
        }

        private void ApplyEvidenceSettings(
            TestFile test,
            int mode,
            string focusClips,
            string targetHighlight)
        {
            try
            {
                using var process = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName = QuakExecutable,
                        WorkingDirectory = ProjectRoot,
                        UseShellExecute = false,
                        CreateNoWindow = true,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true
                    }
                };
                foreach (var argument in new[]
                         {
                             "evidence-settings", test.Path,
                             "--project", ProjectRoot,
                             "--mode", mode == 0 ? "off" : mode == 1 ? "standard" : "advanced",
                             "--focus-clips", focusClips,
                             "--target-highlight", targetHighlight
                         })
                    process.StartInfo.ArgumentList.Add(argument);
                if (!process.Start())
                    throw new InvalidOperationException("Could not start QUAK.");
                if (!process.WaitForExit(5000))
                {
                    process.Kill();
                    throw new TimeoutException("QUAK evidence settings timed out.");
                }
                var output = process.StandardOutput.ReadToEnd().Trim();
                var error = process.StandardError.ReadToEnd().Trim();
                if (process.ExitCode != 0)
                    throw new InvalidOperationException(
                        string.IsNullOrWhiteSpace(error) ? output : error);
                RefreshTests();
                ShowNotification(new GUIContent(
                    mode == 0 ? "Visual evidence disabled" :
                    $"{VisualEvidenceLabels[mode]} visual evidence saved"));
                Repaint();
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                EditorUtility.DisplayDialog(
                    "QUAK could not update visual evidence",
                    exception.Message,
                    "OK");
            }
        }

        private void DrawRunSummary(ResultFile latest, bool testValid, string sourceHash)
        {
            if (!testValid)
                return;

            var label = string.IsNullOrWhiteSpace(sourceHash) ? "NO EXACT MATCH"
                : latest == null ? "NOT RUN YET" : IsPassed(latest)
                ? "LAST VERIFIED"
                : IsFailed(latest) ? "LAST RUN FAILED" : "NO VERDICT";
            var color = latest == null || (!IsPassed(latest) && !IsFailed(latest))
                ? WarningColor
                : IsPassed(latest) ? PassColor : FailColor;
            var detail = string.IsNullOrWhiteSpace(sourceHash)
                ? "The current source file could not be hashed; historical receipts are not guessed from the test name."
                : latest == null
                ? "No receipt with this exact source-file hash exists for the selected target."
                : $"{latest.Target}  •  source {ShortHash(latest.SourceHash)}  •  " +
                  $"execution {ShortHash(latest.ExecutionHash)}  •  " +
                  $"{latest.PassedStepCount}/{latest.StepCount} steps passed  •  " +
                  $"{latest.PassedAssertionCount}/{latest.AssertionCount} assertions passed" +
                  latest.VisualSummary +
                  ". Historical receipt only; not proof of the current live session.";
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    var previousColor = GUI.contentColor;
                    GUI.contentColor = color;
                    GUILayout.Label(label, cardTitleStyle);
                    GUI.contentColor = previousColor;
                    if (latest != null)
                    {
                        GUILayout.FlexibleSpace();
                        GUILayout.Label(DisplayTimestamp(latest.Timestamp), detailStyle);
                    }
                }
                GUILayout.Label(detail, detailStyle);
            }
        }

        private void DrawResultDetails(TestFile test, ResultFile result)
        {
            if (reviewDraftReceiptPath != result.Path)
            {
                reviewDraftReceiptPath = result.Path;
                reviewAtSeconds = 0f;
                reviewCategory = 0;
                reviewObserved = string.Empty;
                reviewExpected = string.Empty;
            }

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Latest historical receipt", cardTitleStyle);
                EditorGUILayout.LabelField(
                    IsPassed(result)
                        ? "QUAK completed the run and every recorded assertion passed."
                        : IsFailed(result)
                            ? "QUAK completed the run and recorded a failure."
                            : $"This receipt has status '{result.Status}' and provides no completed verdict.",
                    detailStyle);
                EditorGUILayout.LabelField(
                    $"Target: {result.Target}  •  Source hash: {result.SourceHash}  •  Execution hash: " +
                    (string.IsNullOrWhiteSpace(result.ExecutionHash)
                        ? "unavailable (legacy receipt)"
                        : result.ExecutionHash),
                    detailStyle);

                if (result.Failures.Length > 0)
                {
                    foreach (var failure in result.Failures.Take(5))
                        EditorGUILayout.HelpBox(failure, MessageType.Error);
                    if (result.Failures.Length > 5)
                        EditorGUILayout.LabelField(
                            $"{result.Failures.Length - 5} more failure details are saved with the evidence.",
                            detailStyle);
                }

                if (result.VisualDurationSeconds > 0d)
                {
                    EditorGUILayout.LabelField(
                        $"Visual evidence: {result.VisualDurationSeconds:0.#}s recording",
                        detailStyle);
                    EditorGUILayout.LabelField(
                        $"Capture: {DisplayProvenanceValue(result.CaptureKind)}  •  " +
                        $"Presentation: {DisplayProvenanceValue(result.PresentationKind)}  •  " +
                        $"Layer inventory: {DisplayProvenanceValue(result.LayerInventoryStatus)}",
                        detailStyle);
                    if (!string.IsNullOrWhiteSpace(result.LayerInventoryReason))
                        EditorGUILayout.LabelField(
                            $"Layer inventory detail: {result.LayerInventoryReason}",
                            detailStyle);
                    if (result.IsTransformedVisual)
                    {
                        EditorGUILayout.HelpBox(
                            "NOT RAW — this displayed evidence is annotated or reconstructed.",
                            MessageType.Warning);
                    }
                    if (result.FocusClips.Length > 0)
                    {
                        EditorGUILayout.LabelField(
                            $"Focused clips ({result.FocusClips.Length})",
                            cardTitleStyle);
                        foreach (var clip in result.FocusClips)
                        {
                            using (new EditorGUI.DisabledScope(
                                       string.IsNullOrWhiteSpace(clip.VideoPath)))
                            {
                                if (GUILayout.Button(
                                        $"Open {clip.Title} — {clip.Verdict}"))
                                    OpenLocalArtifact(clip.VideoPath);
                            }
                        }
                        EditorGUILayout.LabelField(
                            "Focused clips are issue-ready views of one interaction; " +
                            "the full journey remains the authoritative review.",
                            detailStyle);
                    }
                    DrawReviewVideo(result);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        using (new EditorGUI.DisabledScope(string.IsNullOrWhiteSpace(result.VideoPath)))
                        {
                            if (GUILayout.Button("Open recording externally"))
                                OpenLocalArtifact(result.VideoPath);
                        }
                        using (new EditorGUI.DisabledScope(string.IsNullOrWhiteSpace(result.ReviewPath)))
                        {
                            if (GUILayout.Button("Open visual report"))
                                OpenLocalArtifact(result.ReviewPath);
                        }
                    }

                    EditorGUILayout.Space(4f);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        EditorGUILayout.LabelField("Human visual review", cardTitleStyle);
                        DrawStatusLabel(
                            HumanReviewLabel(result),
                            IsHumanRejected(result) ? FailColor
                            : IsHumanApproved(result) ? PassColor : WarningColor,
                            138f);
                    }
                    if (!string.IsNullOrWhiteSpace(result.HumanReviewError))
                        EditorGUILayout.HelpBox(result.HumanReviewError, MessageType.Error);
                    if (!result.ReviewApprovable)
                        EditorGUILayout.HelpBox(
                            "Approval requires passing product checks and complete visual evidence. " +
                            "This recording is available for triage and change requests.",
                            MessageType.Info);

                    foreach (var annotation in result.HumanAnnotations)
                    {
                        EditorGUILayout.HelpBox(
                            $"{annotation.at_seconds:0.#}s · {ReviewCategoryLabel(annotation.category)}\n" +
                            $"Observed: {annotation.observed}\nExpected: {annotation.expected}",
                            MessageType.Warning);
                    }

                    if (NeedsHumanReview(result))
                    {
                        if (GUILayout.Button("Approve visible behavior"))
                            SaveHumanReview(result, "approved", null);
                        EditorGUILayout.LabelField(
                            "Approve only after watching the recording and comparing it with the assertions.",
                            detailStyle);
                    }

                    if (!IsHumanApproved(result))
                    {
                        EditorGUILayout.Space(4f);
                        EditorGUILayout.LabelField("Annotate a visible problem", cardTitleStyle);
                        EditorGUILayout.LabelField(
                            $"Annotation time: {FormatReviewTime(reviewAtSeconds)} (current playhead)",
                            detailStyle);
                        reviewCategory = EditorGUILayout.Popup(
                            "Category",
                            Mathf.Clamp(reviewCategory, 0, ReviewCategories.Length - 1),
                            ReviewCategoryLabels);
                        EditorGUILayout.LabelField("What did you see?", detailStyle);
                        reviewObserved = EditorGUILayout.TextArea(reviewObserved, GUILayout.MinHeight(42f));
                        EditorGUILayout.LabelField("What should happen instead?", detailStyle);
                        reviewExpected = EditorGUILayout.TextArea(reviewExpected, GUILayout.MinHeight(42f));
                        using (new EditorGUI.DisabledScope(
                                   string.IsNullOrWhiteSpace(reviewObserved) ||
                                   string.IsNullOrWhiteSpace(reviewExpected)))
                        {
                            if (GUILayout.Button("Request changes at this time"))
                            {
                                SaveHumanReview(
                                    result,
                                    "changes_requested",
                                    new HumanReviewAnnotation
                                    {
                                        at_seconds = Math.Round(reviewAtSeconds, 3),
                                        category = ReviewCategories[Mathf.Clamp(
                                            reviewCategory,
                                            0,
                                            ReviewCategories.Length - 1)],
                                        observed = reviewObserved.Trim(),
                                        expected = reviewExpected.Trim(),
                                        created_at = DateTime.UtcNow.ToString("O")
                                    });
                                reviewObserved = string.Empty;
                                reviewExpected = string.Empty;
                            }
                        }
                    }
                }
                else
                {
                    EditorGUILayout.LabelField("No visual recording was attached to this run.", detailStyle);
                }

                if (IsFailed(result) || IsHumanRejected(result))
                {
                    EditorGUILayout.Space(4f);
                    var buttonLabel = IsHumanRejected(result)
                        ? "Copy recording feedback"
                        : "Copy repair brief";
                    if (GUILayout.Button(buttonLabel, primaryButtonStyle))
                        CopyToClipboard(
                            BuildFailureInstruction(test, result),
                            "Repair brief copied");
                    EditorGUILayout.LabelField(
                        "Paste the receipt, recording details, and requested correction into your AI agent.",
                        detailStyle);
                }

                if (GUILayout.Button("Reveal evidence folder"))
                    EditorUtility.RevealInFinder(result.Path);
            }
        }

        private void DrawReviewVideo(ResultFile result)
        {
            EnsureReviewVideo(result.VideoPath);
            var height = Mathf.Clamp((EditorGUIUtility.currentViewWidth - 70f) * 9f / 16f, 220f, 420f);
            var videoRect = GUILayoutUtility.GetRect(0f, height, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(videoRect, Color.black);
            if (reviewVideoPlayer != null && reviewVideoPlayer.isPrepared)
            {
                GUI.DrawTexture(videoRect, reviewVideoTexture, ScaleMode.ScaleToFit, false);
                if (showReviewSubtitles)
                {
                    var caption = CurrentVisualCaption(result, reviewAtSeconds);
                    if (!string.IsNullOrWhiteSpace(caption))
                    {
                        var captionRect = new Rect(
                            videoRect.x + 18f,
                            videoRect.yMax - 52f,
                            videoRect.width - 36f,
                            42f);
                        EditorGUI.DrawRect(captionRect, new Color(0f, 0f, 0f, 0.78f));
                        var previousColor = GUI.contentColor;
                        GUI.contentColor = Color.white;
                        GUI.Label(captionRect, caption, reviewCaptionStyle ?? EditorStyles.whiteLabel);
                        GUI.contentColor = previousColor;
                    }
                }
            }
            else
            {
                GUI.Label(
                    videoRect,
                    string.IsNullOrWhiteSpace(reviewVideoError) ? "Preparing recording…" : reviewVideoError,
                    reviewCaptionStyle ?? EditorStyles.centeredGreyMiniLabel);
            }

            var duration = Math.Max(0.1f, (float)result.VisualDurationSeconds);
            using (new EditorGUILayout.HorizontalScope())
            {
                var ready = reviewVideoPlayer != null && reviewVideoPlayer.isPrepared;
                using (new EditorGUI.DisabledScope(!ready))
                {
                    if (GUILayout.Button(reviewVideoPlayer != null && reviewVideoPlayer.isPlaying ? "Pause" : "Play", GUILayout.Width(58f)))
                    {
                        if (reviewVideoPlayer.isPlaying)
                            reviewVideoPlayer.Pause();
                        else
                        {
                            if (reviewAtSeconds >= duration - 0.05f)
                            {
                                reviewVideoPlayer.time = 0d;
                                reviewAtSeconds = 0f;
                            }
                            reviewVideoPlayer.Play();
                        }
                    }
                    if (GUILayout.Button("Stop", GUILayout.Width(48f)))
                    {
                        reviewVideoPlayer.Pause();
                        reviewVideoPlayer.time = 0d;
                        reviewAtSeconds = 0f;
                    }
                }
                if (GUILayout.Button(
                        showReviewSubtitles ? "Hide subtitles" : "Show subtitles",
                        GUILayout.Width(98f)))
                    showReviewSubtitles = !showReviewSubtitles;

                GUILayout.Label(FormatReviewTime(reviewAtSeconds), detailStyle, GUILayout.Width(42f));
                EditorGUI.BeginChangeCheck();
                var playhead = GUILayout.HorizontalSlider(reviewAtSeconds, 0f, duration);
                if (EditorGUI.EndChangeCheck())
                {
                    reviewAtSeconds = playhead;
                    if (ready)
                        reviewVideoPlayer.time = playhead;
                    Repaint();
                }
                GUILayout.Label(FormatReviewTime(duration), detailStyle, GUILayout.Width(42f));
            }
        }

        private void EnsureReviewVideo(string path)
        {
            if (string.Equals(reviewVideoPath, path, StringComparison.Ordinal))
                return;
            ReleaseReviewVideo();
            reviewVideoPath = path;
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                reviewVideoError = "Recording file is unavailable.";
                return;
            }

            reviewVideoObject = new GameObject("QUAK Review Video")
            {
                hideFlags = HideFlags.HideAndDontSave
            };
            reviewVideoTexture = new RenderTexture(1280, 720, 0, RenderTextureFormat.ARGB32)
            {
                hideFlags = HideFlags.HideAndDontSave
            };
            reviewVideoTexture.Create();
            var activeTexture = RenderTexture.active;
            RenderTexture.active = reviewVideoTexture;
            GL.Clear(true, true, Color.black);
            RenderTexture.active = activeTexture;
            reviewVideoPlayer = reviewVideoObject.AddComponent<VideoPlayer>();
            reviewVideoPlayer.playOnAwake = false;
            reviewVideoPlayer.waitForFirstFrame = true;
            reviewVideoPlayer.audioOutputMode = VideoAudioOutputMode.None;
            reviewVideoPlayer.renderMode = VideoRenderMode.RenderTexture;
            reviewVideoPlayer.targetTexture = reviewVideoTexture;
            reviewVideoPlayer.url = new Uri(path).AbsoluteUri;
            reviewVideoPlayer.prepareCompleted += HandleReviewVideoPrepared;
            reviewVideoPlayer.errorReceived += HandleReviewVideoError;
            reviewVideoPlayer.Prepare();
        }

        private void UpdateReviewVideo()
        {
            if (reviewVideoPlayer == null || !reviewVideoPlayer.isPlaying)
                return;
            reviewAtSeconds = (float)reviewVideoPlayer.time;
            EditorApplication.QueuePlayerLoopUpdate();
            Repaint();
        }

        private void HandleReviewVideoPrepared(VideoPlayer player)
        {
            player.time = reviewAtSeconds;
            Repaint();
        }

        private void HandleReviewVideoError(VideoPlayer player, string message)
        {
            reviewVideoError = message;
            Repaint();
        }

        private void ReleaseReviewVideo()
        {
            if (reviewVideoPlayer != null)
            {
                reviewVideoPlayer.prepareCompleted -= HandleReviewVideoPrepared;
                reviewVideoPlayer.errorReceived -= HandleReviewVideoError;
                reviewVideoPlayer.Stop();
            }
            if (reviewVideoObject != null)
                DestroyImmediate(reviewVideoObject);
            if (reviewVideoTexture != null)
            {
                reviewVideoTexture.Release();
                DestroyImmediate(reviewVideoTexture);
            }
            reviewVideoObject = null;
            reviewVideoPlayer = null;
            reviewVideoTexture = null;
            reviewVideoPath = string.Empty;
            reviewVideoError = string.Empty;
        }

        private static string CurrentVisualCaption(ResultFile result, float atSeconds)
        {
            ReceiptVisualAnnotation current = null;
            var stepNumber = 0;
            var currentStepNumber = 0;
            foreach (var annotation in result.VisualAnnotations)
            {
                if (annotation == null)
                    continue;
                if (string.Equals(annotation.kind, "step", StringComparison.OrdinalIgnoreCase))
                    stepNumber++;
                if (annotation.at_seconds > atSeconds)
                    break;
                current = annotation;
                currentStepNumber = stepNumber;
            }
            if (current == null)
                return string.Empty;
            var label = string.Equals(current.kind, "step", StringComparison.OrdinalIgnoreCase)
                ? $"STEP {currentStepNumber}"
                : string.IsNullOrWhiteSpace(current.kind) ? "NOTE" : current.kind.ToUpperInvariant();
            return $"[{label}] {current.text ?? string.Empty}";
        }

        private static string FormatReviewTime(double seconds)
        {
            var value = TimeSpan.FromSeconds(Math.Max(0d, seconds));
            return $"{(int)value.TotalMinutes}:{value.Seconds + value.Milliseconds / 1000d:00.0}";
        }

        private void DrawStatusLabel(string label, Color color, float width, string tooltip = null)
        {
            var previousColor = GUI.contentColor;
            GUI.contentColor = color;
            var content = new GUIContent($"●  {label}", tooltip);
            GUILayout.Label(content, statusStyle, GUILayout.Width(Mathf.Max(width, statusStyle.CalcSize(content).x)));
            GUI.contentColor = previousColor;
        }

        private static Color ColorFor(CheckLevel level)
        {
            return level switch
            {
                CheckLevel.Pass => PassColor,
                CheckLevel.Warning => WarningColor,
                _ => FailColor
            };
        }

        private bool HasSelectedTest => selectedTest >= 0 && selectedTest < tests.Count;

        private void RefreshAll()
        {
            RefreshSetup();
            RefreshTests();
            RefreshResults();
        }

        private void RefreshSetup()
        {
            setupChecks.Clear();

            var usesUnity6 = Application.unityVersion.StartsWith("6000.", StringComparison.Ordinal);
            setupChecks.Add(new SetupCheck(
                "Unity",
                $"Unity {Application.unityVersion}",
                usesUnity6 ? CheckLevel.Pass : CheckLevel.Warning,
                category: SetupCategory.Editor,
                statusReason: usesUnity6
                    ? "QUAK supports Unity 6 and this project is using it."
                    : "QUAK requires Unity 6, but this project uses a different major version.",
                navigateLabel: "Open Player settings",
                navigate: () => SettingsService.OpenProjectSettings("Project/Player")));

            var package = UnityEditor.PackageManager.PackageInfo.FindForAssembly(
                typeof(QuakControlPanel).Assembly);
            setupChecks.Add(package == null
                ? new SetupCheck(
                    "QUAK package",
                    "Loaded, but package metadata was unavailable.",
                    CheckLevel.Warning,
                    category: SetupCategory.Packages,
                    statusReason: "QUAK is loaded, but Unity did not return its package metadata.",
                    navigateLabel: "Open Package Manager",
                    navigate: () => OpenPackage("com.xrdevrob.quak"))
                : new SetupCheck(
                    "QUAK package",
                    $"{package.name} {package.version}",
                    CheckLevel.Pass,
                    category: SetupCategory.Packages,
                    statusReason: $"Required package {package.name} {package.version} is installed.",
                    navigateLabel: "Open Package Manager",
                    navigate: () => OpenPackage(package.name)));
            AddDependencyChecks();

            var requiredFolders = new[] { "Assets", "Packages", "ProjectSettings" };
            var missingFolders = requiredFolders
                .Where(folder => !Directory.Exists(Path.Combine(ProjectRoot, folder)))
                .ToArray();
            setupChecks.Add(missingFolders.Length == 0
                ? new SetupCheck(
                    "Unity project",
                    ProjectRoot,
                    CheckLevel.Pass,
                    category: SetupCategory.Project,
                    statusReason: "Assets, Packages, and ProjectSettings are present.",
                    navigateLabel: "Reveal project",
                    navigate: () => EditorUtility.RevealInFinder(ProjectRoot))
                : new SetupCheck(
                    "Unity project",
                    $"Missing: {string.Join(", ", missingFolders)}",
                    CheckLevel.Fail,
                    category: SetupCategory.Project,
                    statusReason: $"This folder is missing required Unity project directories: {string.Join(", ", missingFolders)}.",
                    navigateLabel: "Reveal project",
                    navigate: () => EditorUtility.RevealInFinder(ProjectRoot)));

            AddProjectSetupChecks();

            var xrRuntime = Environment.GetEnvironmentVariable("XR_RUNTIME_JSON");
            if (string.IsNullOrWhiteSpace(xrRuntime))
            {
                setupChecks.Add(new SetupCheck(
                    "OpenXR runtime",
                    "XR_RUNTIME_JSON is not set. Editor-only tests can still run; Simulator tests need a focused runtime.",
                    CheckLevel.Warning,
                    category: SetupCategory.Environment,
                    statusReason: "XR_RUNTIME_JSON is unset, so Simulator tests cannot select a focused OpenXR runtime.",
                    navigateLabel: "Open XR settings",
                    navigate: () => SettingsService.OpenProjectSettings("Project/XR Plug-in Management")));
            }
            else
            {
                var runtimeExists = File.Exists(xrRuntime);
                setupChecks.Add(new SetupCheck(
                    "OpenXR runtime",
                    xrRuntime,
                    runtimeExists ? CheckLevel.Pass : CheckLevel.Fail,
                    category: SetupCategory.Environment,
                    statusReason: runtimeExists
                        ? "XR_RUNTIME_JSON points to an existing runtime manifest."
                        : "XR_RUNTIME_JSON points to a file that does not exist.",
                    navigateLabel: runtimeExists ? "Reveal runtime" : "Open XR settings",
                    navigate: runtimeExists
                        ? () => EditorUtility.RevealInFinder(xrRuntime)
                        : () => SettingsService.OpenProjectSettings("Project/XR Plug-in Management")));
            }
        }

        private void AddDependencyChecks()
        {
            var packages = UnityEditor.PackageManager.PackageInfo.GetAllRegisteredPackages();
            foreach (var dependency in new[]
                     {
                         new[] { "Unity OpenXR", "com.unity.xr.openxr" }
                     })
            {
                var package = packages?.FirstOrDefault(item => item.name == dependency[1]);
                setupChecks.Add(package == null
                    ? new SetupCheck(
                        dependency[0],
                        $"Missing package {dependency[1]}.",
                        CheckLevel.Fail,
                        category: SetupCategory.Packages,
                        statusReason: $"Required package {dependency[1]} is not installed.",
                        navigateLabel: "Open Package Manager",
                        navigate: () => OpenPackage(dependency[1]))
                    : new SetupCheck(
                        dependency[0],
                        $"{package.name} {package.version}",
                        CheckLevel.Pass,
                        category: SetupCategory.Packages,
                        statusReason: $"Required package {package.name} {package.version} is installed.",
                        navigateLabel: "Open Package Manager",
                        navigate: () => OpenPackage(package.name)));
            }

            var pipeline = packages?.FirstOrDefault(item => item.name == "com.unity.pipeline");
            setupChecks.Add(pipeline == null
                ? new SetupCheck(
                    "Unity Pipeline",
                    "Not installed; standalone-player tests use Operator for app state.",
                    CheckLevel.Warning,
                    category: SetupCategory.Packages,
                    statusReason: "Unity Pipeline is optional and needed only for the live Editor lane.",
                    navigateLabel: "Open Package Manager",
                    navigate: () => OpenPackage("com.unity.pipeline"))
                : new SetupCheck(
                    "Unity Pipeline",
                    $"{pipeline.name} {pipeline.version}",
                    CheckLevel.Pass,
                    category: SetupCategory.Packages,
                    statusReason: "The optional live Editor integration is installed.",
                    navigateLabel: "Open Package Manager",
                    navigate: () => OpenPackage(pipeline.name)));
        }

        private void AddProjectSetupChecks()
        {
            AddProjectFileCheck(
                "QUAK configuration",
                QuakProjectSetup.ConfigRelativePath,
                "Create configuration",
                StartConfigSetup);
            AddProjectFileCheck(
                "QUAK first test",
                QuakProjectSetup.SmokeTestRelativePath,
                "Create first test",
                StartSmokeTestSetup,
                optional: true);

            setupChecks.Add(QuakProjectSetup.IsEvidenceMediaIgnored(ProjectRoot)
                ? new SetupCheck(
                    "QUAK evidence media",
                    "Images and videos are excluded from Git; receipts and reviews remain versionable.",
                    CheckLevel.Pass,
                    category: SetupCategory.Project,
                    statusReason: "Captured images and videos are excluded from Git.",
                    navigateLabel: "Reveal .gitignore",
                    navigate: () => EditorUtility.RevealInFinder(Path.Combine(ProjectRoot, ".gitignore")))
                : new SetupCheck(
                    "QUAK evidence media",
                    "Protect captured images and videos while keeping receipts and reviews in Git.",
                    CheckLevel.Warning,
                    "Protect media",
                    StartEvidenceSetup,
                    SetupCategory.Project,
                    "Captured images and videos are not protected by media-only Git rules yet.",
                    "Reveal .gitignore",
                    () => EditorUtility.RevealInFinder(Path.Combine(ProjectRoot, ".gitignore"))));

            var directLayer = QuakProjectSetup.IsDirectFeatureEnabled();
            setupChecks.Add(directLayer
                ? new SetupCheck(
                    "QUAK direct Quest layer",
                    "QUAK's named arm64 API layer is installed and enabled.",
                    CheckLevel.Pass,
                    category: SetupCategory.Packages,
                    statusReason:
                        "XR_APILAYER_XRDEVROB_quak_injection is enabled for Android arm64.",
                    navigateLabel: "Open OpenXR settings",
                    navigate: () => SettingsService.OpenProjectSettings(
                        "Project/XR Plug-in Management/OpenXR"))
                : new SetupCheck(
                    "QUAK direct Quest layer",
                    "Enable Unity OpenXR API Layers; a Development Build imports QUAK's arm64 layer.",
                    CheckLevel.Warning,
                    "Enable API Layers feature",
                    StartDirectFeatureSetup,
                    SetupCategory.Packages,
                    "XR_APILAYER_XRDEVROB_quak_injection is not installed and enabled for Android arm64.",
                    "Open OpenXR settings",
                    () => SettingsService.OpenProjectSettings(
                        "Project/XR Plug-in Management/OpenXR")));

            setupChecks.Add(new SetupCheck(
                "AI agent guidance",
                "Copy a project-aware brief for ChatGPT, Claude, Codex, or another coding agent.",
                CheckLevel.Pass,
                "Copy agent brief",
                () => CopyToClipboard(BuildAgentGuidance(), "Agent brief copied"),
                SetupCategory.Integrations,
                "Copy a project-aware brief for ChatGPT, Claude, Codex, or another coding agent."));

            var codexSkill = QuakProjectSetup.CodexSkillRelativePath;
            setupChecks.Add(QuakProjectSetup.IsCodexSkillInstalled(ProjectRoot)
                ? new SetupCheck(
                    "Codex integration",
                    codexSkill,
                    CheckLevel.Pass,
                    category: SetupCategory.Integrations,
                    statusReason: "The optional Codex test-authoring skill is installed.",
                    navigateLabel: "Reveal skill",
                    navigate: () => EditorUtility.RevealInFinder(Path.Combine(ProjectRoot, codexSkill)))
                : new SetupCheck(
                    "Codex integration",
                    "Optional. Install it only for Codex-assisted test authoring.",
                    CheckLevel.Warning,
                    "Install Codex integration",
                    StartCodexSetup,
                    SetupCategory.Integrations,
                    "The optional Codex test-authoring skill is not installed; QUAK still works without it."));
        }

        private void AddProjectFileCheck(
            string name,
            string relativePath,
            string actionLabel,
            Action action,
            bool optional = false)
        {
            var path = Path.Combine(ProjectRoot, relativePath);
            setupChecks.Add(File.Exists(path)
                ? new SetupCheck(
                    name,
                    relativePath,
                    CheckLevel.Pass,
                    category: SetupCategory.Project,
                    statusReason: $"{relativePath} exists.",
                    navigateLabel: "Reveal file",
                    navigate: () => EditorUtility.RevealInFinder(path))
                : new SetupCheck(
                    name,
                    $"Missing {relativePath}.",
                    CheckLevel.Warning,
                    actionLabel,
                    action,
                    SetupCategory.Project,
                    optional
                        ? $"Optional starter test {relativePath} does not exist yet."
                        : $"Required project file {relativePath} does not exist yet."));
        }

        private static void OpenPackage(string packageName) =>
            UnityEditor.PackageManager.UI.Window.Open(packageName);

        private void RefreshTests()
        {
            tests.Clear();
            var paths = new HashSet<string>(StringComparer.Ordinal);
            foreach (var folderName in new[] { "quak-tests", "journeys" })
            {
                var folder = Path.Combine(ProjectRoot, folderName);
                if (!Directory.Exists(folder))
                    continue;
                try
                {
                    paths.UnionWith(Directory.GetFiles(folder, "*.json", SearchOption.AllDirectories));
                }
                catch (Exception exception)
                {
                    tests.Add(TestFile.Invalid(folder, exception.Message));
                }
            }

            var importedSamples = Path.Combine(ProjectRoot, "Assets", "Samples");
            if (Directory.Exists(importedSamples))
            {
                try
                {
                    foreach (var testFolder in Directory.GetDirectories(
                                 importedSamples,
                                 "Tests",
                                 SearchOption.AllDirectories))
                    {
                        paths.UnionWith(Directory.GetFiles(
                            testFolder,
                            "*.json",
                            SearchOption.AllDirectories));
                    }
                }
                catch (Exception exception)
                {
                    tests.Add(TestFile.Invalid(importedSamples, exception.Message));
                }
            }

            tests.AddRange(paths.Select(ReadTest));

            tests.Sort((left, right) => string.Compare(left.Path, right.Path, StringComparison.Ordinal));
            if (selectedTest >= tests.Count)
                selectedTest = -1;
        }

        private void RefreshResults()
        {
            RefreshRegression();
            results.Clear();
            var evidence = EvidenceRoot();
            if (!Directory.Exists(evidence))
                return;

            try
            {
                results.AddRange(Directory.GetFiles(evidence, "receipt.json", SearchOption.AllDirectories)
                    .Select(ReadResult)
                    .OrderByDescending(result => result.LastWriteTimeUtc)
                    .GroupBy(result => new
                    {
                        result.TestName,
                        result.Target,
                        result.SourceHash,
                        result.ExecutionHash
                    })
                    .Select(group => group.First()));
            }
            catch (Exception exception)
            {
                results.Add(ResultFile.Invalid(evidence, exception.Message));
            }
        }

        private void RefreshRegression()
        {
            hasRegressionCatalog = false;
            protectedTestCount = 0;
            protectedTestPaths.Clear();
            regressionReport = null;
            regressionError = string.Empty;

            var catalogPath = Path.Combine(ProjectRoot, ".quak", "regression.json");
            if (!File.Exists(catalogPath))
                return;

            try
            {
                var catalog = JsonUtility.FromJson<RegressionCatalog>(File.ReadAllText(catalogPath));
                if (catalog == null || catalog.schema_version != 1 || catalog.protected_tests == null)
                    throw new InvalidDataException(".quak/regression.json is invalid.");
                hasRegressionCatalog = true;
                protectedTestCount = catalog.protected_tests.Length;
                protectedTestPaths.UnionWith(catalog.protected_tests
                    .Where(entry => entry != null && !string.IsNullOrWhiteSpace(entry.path))
                    .Select(entry => entry.path));

                var evidenceRoot = EvidenceRoot();
                var reportPath = new[]
                    {
                        Path.Combine(evidenceRoot, "regression-latest.json"),
                        Path.Combine(evidenceRoot, "distributed-latest.json")
                    }
                    .Where(File.Exists)
                    .OrderByDescending(File.GetLastWriteTimeUtc)
                    .FirstOrDefault();
                if (string.IsNullOrWhiteSpace(reportPath))
                    return;
                regressionReport = JsonUtility.FromJson<RegressionReport>(File.ReadAllText(reportPath));
                if (regressionReport == null || regressionReport.schema_version != 1)
                    throw new InvalidDataException("The latest regression report is invalid.");
            }
            catch (Exception exception)
            {
                regressionError = exception.Message;
            }
        }

        private static string EvidenceRoot()
        {
            var evidenceRoot = Path.Combine(ProjectRoot, ".quak", "evidence");
            var configPath = Path.Combine(ProjectRoot, ".quak", "config.json");
            if (!File.Exists(configPath))
                return evidenceRoot;
            var config = JsonUtility.FromJson<QuakConfig>(File.ReadAllText(configPath));
            if (string.IsNullOrWhiteSpace(config?.evidence_dir))
                return evidenceRoot;
            return Path.IsPathRooted(config.evidence_dir)
                ? config.evidence_dir
                : Path.GetFullPath(Path.Combine(ProjectRoot, config.evidence_dir));
        }

        private static TestFile ReadTest(string path)
        {
            try
            {
                var source = File.ReadAllBytes(path);
                var definition = JsonUtility.FromJson<TestDefinition>(
                    new UTF8Encoding(false, true).GetString(source));
                if (definition == null)
                    return TestFile.Invalid(path, "JSON did not contain a test object.");

                var errors = new List<string>();
                if (definition.schema_version != 1)
                    errors.Add("schema_version must be 1");
                if (string.IsNullOrWhiteSpace(definition.name))
                    errors.Add("name is required");
                if (definition.target != "editor" && definition.target != "simulator" && definition.target != "quest")
                    errors.Add("target must be editor, simulator, or quest");
                if (definition.steps == null || definition.steps.Length == 0)
                    errors.Add("steps are required");

                var steps = definition.steps ?? Array.Empty<TestStep>();
                var duplicateStep = steps
                    .Where(step => step != null && !string.IsNullOrWhiteSpace(step.id))
                    .GroupBy(step => step.id, StringComparer.Ordinal)
                    .FirstOrDefault(group => group.Count() > 1);
                if (duplicateStep != null)
                    errors.Add($"duplicate step ID: {duplicateStep.Key}");
                if (steps.Any(step => step == null || string.IsNullOrWhiteSpace(step.id) ||
                                      string.IsNullOrWhiteSpace(step.provider) || string.IsNullOrWhiteSpace(step.tool)))
                    errors.Add("every step needs id, provider, and tool");

                var assertionCount = steps.Sum(step => step?.assertions?.Length ?? 0);
                if (assertionCount == 0)
                    errors.Add("at least one outcome assertion is required");
                return new TestFile(
                    path,
                    BytesSha256(source),
                    string.IsNullOrWhiteSpace(definition.name) ? Path.GetFileNameWithoutExtension(path) : definition.name,
                    string.IsNullOrWhiteSpace(definition.target) ? "unknown" : definition.target,
                    steps.Length,
                    assertionCount,
                    definition.visual_evidence != null,
                    definition.visual_evidence?.focus_clips ?? "marked-and-failures",
                    definition.visual_evidence?.target_highlight ?? "focused-clips",
                    errors.Count == 0,
                    string.Join("; ", errors));
            }
            catch (Exception exception)
            {
                return TestFile.Invalid(path, exception.Message);
            }
        }

        private static ResultFile ReadResult(string path)
        {
            try
            {
                var receipt = ParseReceipt(File.ReadAllText(path));
                if (receipt == null)
                    return ResultFile.Invalid(path, "JSON did not contain a receipt object.");
                var testName = !string.IsNullOrWhiteSpace(receipt.test) ? receipt.test : receipt.journey;
                var visual = receipt.visual_evidence;
                var reviewApprovable = IsReceiptReviewApprovable(receipt);
                var videoPath = ResolveArtifact(path, visual?.video?.artifact);
                var humanReview = ReadHumanReview(
                    path,
                    videoPath,
                    visual?.video?.sha256,
                    reviewApprovable);
                var steps = receipt.steps ?? Array.Empty<ReceiptStep>();
                var assertions = steps.SelectMany(step => step?.assertions ?? Array.Empty<ReceiptAssertion>()).ToArray();
                var failures = steps
                    .Where(step => step != null && !string.Equals(
                        step.status,
                        "passed",
                        StringComparison.OrdinalIgnoreCase))
                    .Select(step => string.IsNullOrWhiteSpace(step.error)
                        ? $"Step '{step.id}' failed."
                        : $"Step '{step.id}': {step.error}")
                    .Concat(steps
                        .Where(step => step != null)
                        .SelectMany(step => (step.assertions ?? Array.Empty<ReceiptAssertion>())
                            .Where(assertion => assertion != null && !assertion.passed)
                            .Select(assertion =>
                                $"Assertion failed in '{step.id}': {assertion.path} {assertion.op}.")))
                    .Distinct()
                    .ToArray();
                return new ResultFile(
                    path,
                    string.IsNullOrWhiteSpace(testName) ? "Unnamed test" : testName,
                    string.IsNullOrWhiteSpace(receipt.target) ? "unknown" : receipt.target,
                    string.IsNullOrWhiteSpace(receipt.status) ? "unknown" : receipt.status,
                    string.IsNullOrWhiteSpace(receipt.finished_at) ? receipt.started_at : receipt.finished_at,
                    File.GetLastWriteTimeUtc(path),
                    visual?.duration_seconds ?? 0d,
                    visual?.review_status ?? string.Empty,
                    videoPath,
                    (visual?.interaction_focus_clips ?? Array.Empty<ReceiptFocusClip>())
                        .Where(clip => clip != null)
                        .Select(clip => new ResultFocusClip(
                            clip.step_id,
                            clip.title,
                            clip.verdict,
                            ResolveArtifact(path, clip.video?.artifact)))
                        .ToArray(),
                    ResolveArtifact(path, visual?.review?.artifact),
                    visual?.annotations ?? Array.Empty<ReceiptVisualAnnotation>(),
                    visual?.video?.sha256 ?? string.Empty,
                    humanReview.Path,
                    humanReview.Document.status,
                    humanReview.Document.annotations,
                    humanReview.Error,
                    steps.Length,
                    steps.Count(step => step != null && string.Equals(
                        step.status,
                        "passed",
                        StringComparison.OrdinalIgnoreCase)),
                    assertions.Length,
                    assertions.Count(assertion => assertion != null && assertion.passed),
                    failures,
                    string.Empty,
                    receipt.test_definition?.source_sha256 ?? string.Empty,
                    receipt.test_definition?.execution_sha256 ?? string.Empty,
                    visual?.provenance?.capture_kind ?? string.Empty,
                    visual?.provenance?.presentation_kind ?? string.Empty,
                    visual?.provenance?.layer_inventory?.status ?? string.Empty,
                    visual?.provenance?.layer_inventory?.reason ?? string.Empty,
                    reviewApprovable);
            }
            catch (Exception exception)
            {
                return ResultFile.Invalid(path, exception.Message);
            }
        }

        private static HumanReviewRead ReadHumanReview(
            string receiptPath,
            string videoPath,
            string videoSha256,
            bool reviewApprovable)
        {
            var directory = Path.GetDirectoryName(receiptPath) ?? string.Empty;
            var path = Path.Combine(directory, "human-review.json");
            var pending = new HumanReviewDocument
            {
                status = "pending",
                annotations = Array.Empty<HumanReviewAnnotation>()
            };
            try
            {
                if (!File.Exists(path))
                    return new HumanReviewRead(path, pending, string.Empty);

                var actualVideoSha = string.IsNullOrWhiteSpace(videoPath)
                    ? string.Empty
                    : FileSha256(videoPath);
                if (!string.IsNullOrWhiteSpace(videoSha256) &&
                    !string.Equals(actualVideoSha, videoSha256, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("The recording no longer matches the hash in the receipt.");

                var document = ParseHumanReview(File.ReadAllText(path));
                if (document.status == "approved" &&
                    !CanApproveHumanReview(reviewApprovable, document.status))
                    throw new InvalidDataException(
                        "Human approval requires passing product checks and complete visual evidence.");
                if (!string.Equals(
                        document.receipt_sha256,
                        FileSha256(receiptPath),
                        StringComparison.Ordinal))
                    throw new InvalidDataException("The human review belongs to a different receipt.");
                if (!string.Equals(document.video_sha256, actualVideoSha, StringComparison.Ordinal))
                    throw new InvalidDataException("The human review belongs to a different recording.");
                return new HumanReviewRead(path, document, string.Empty);
            }
            catch (Exception exception)
            {
                return new HumanReviewRead(path, pending, exception.Message);
            }
        }

        private static HumanReviewDocument ParseHumanReview(string json)
        {
            ValidateHumanReviewJsonShape(json);
            HumanReviewDocument document;
            try
            {
                document = JsonUtility.FromJson<HumanReviewDocument>(json);
            }
            catch (Exception exception)
            {
                throw new InvalidDataException("human-review.json is malformed.", exception);
            }

            if (document == null || document.schema_version != 1)
                throw new InvalidDataException("human-review.json schema_version must be 1.");
            if (!HumanReviewSha256.IsMatch(document.receipt_sha256 ?? string.Empty) ||
                !HumanReviewSha256.IsMatch(document.video_sha256 ?? string.Empty))
                throw new InvalidDataException("Human review hashes must be lowercase SHA-256 values.");
            if (document.status != "approved" && document.status != "changes_requested")
                throw new InvalidDataException("Human review status must be approved or changes_requested.");
            if (!IsHumanReviewDateTime(document.reviewed_at))
                throw new InvalidDataException("Human review reviewed_at must be an RFC 3339 date-time.");
            if (document.annotations == null)
                throw new InvalidDataException("Human review annotations must be an array.");

            foreach (var annotation in document.annotations)
            {
                if (annotation == null)
                    throw new InvalidDataException("Human review annotations must be objects.");
                if (double.IsNaN(annotation.at_seconds) ||
                    double.IsInfinity(annotation.at_seconds) ||
                    annotation.at_seconds < 0d)
                    throw new InvalidDataException(
                        "Human review annotation timestamp must be finite and non-negative.");
                if (Array.IndexOf(ReviewCategories, annotation.category) < 0)
                    throw new InvalidDataException("Human review annotation category is invalid.");
                if (string.IsNullOrEmpty(annotation.observed))
                    throw new InvalidDataException("Human review annotation observed is required.");
                if (string.IsNullOrEmpty(annotation.expected))
                    throw new InvalidDataException("Human review annotation expected is required.");
                if (!IsHumanReviewDateTime(annotation.created_at))
                    throw new InvalidDataException(
                        "Human review annotation created_at must be an RFC 3339 date-time.");
            }

            return document;
        }

        private static bool IsHumanReviewDateTime(string value) =>
            !string.IsNullOrEmpty(value) &&
            HumanReviewDateTime.IsMatch(value) &&
            DateTimeOffset.TryParse(
                value,
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out _);

        private static void ValidateHumanReviewJsonShape(string json)
        {
            if (string.IsNullOrWhiteSpace(json))
                throw new InvalidDataException("human-review.json is malformed.");

            var objects = new Stack<HashSet<string>>();
            var rootObjects = 0;
            for (var index = 0; index < json.Length; index++)
            {
                if (json[index] == '{')
                {
                    if (objects.Count == 0)
                        rootObjects++;
                    objects.Push(new HashSet<string>(StringComparer.Ordinal));
                    continue;
                }
                if (json[index] == '}')
                {
                    if (objects.Count == 0)
                        throw new InvalidDataException("human-review.json is malformed.");
                    var depth = objects.Count;
                    var fields = objects.Pop();
                    var required = depth == 1
                        ? HumanReviewDocumentFields
                        : depth == 2
                            ? HumanReviewAnnotationFields
                            : null;
                    if (required == null)
                        throw new InvalidDataException(
                            "human-review.json contains an unexpected nested object.");
                    var missing = required.FirstOrDefault(field => !fields.Contains(field));
                    if (missing != null)
                        throw new InvalidDataException(
                            $"human-review.json is missing required field {missing}.");
                    continue;
                }
                if (json[index] != '"')
                    continue;

                var name = ReadJsonString(json, ref index);
                var cursor = index + 1;
                while (cursor < json.Length && char.IsWhiteSpace(json[cursor]))
                    cursor++;
                if (cursor >= json.Length || json[cursor] != ':')
                    continue;
                if (objects.Count == 0)
                    throw new InvalidDataException("human-review.json is malformed.");

                var allowed = objects.Count == 1
                    ? HumanReviewDocumentFields
                    : objects.Count == 2
                        ? HumanReviewAnnotationFields
                        : Array.Empty<string>();
                if (Array.IndexOf(allowed, name) < 0)
                    throw new InvalidDataException(
                        $"human-review.json contains unknown field {name}.");
                if (!objects.Peek().Add(name))
                    throw new InvalidDataException(
                        $"human-review.json contains duplicate field {name}.");

                cursor++;
                while (cursor < json.Length && char.IsWhiteSpace(json[cursor]))
                    cursor++;
                if (cursor >= json.Length)
                    throw new InvalidDataException("human-review.json is malformed.");
                var expectsNumber =
                    objects.Count == 1 && name == "schema_version" ||
                    objects.Count == 2 && name == "at_seconds";
                var expectsArray = objects.Count == 1 && name == "annotations";
                var validType = expectsNumber
                    ? json[cursor] == '-' || json[cursor] >= '0' && json[cursor] <= '9'
                    : expectsArray
                        ? json[cursor] == '['
                        : json[cursor] == '"';
                if (!validType)
                    throw new InvalidDataException(
                        $"human-review.json field {name} has the wrong JSON type.");
            }

            if (objects.Count != 0 || rootObjects != 1)
                throw new InvalidDataException("human-review.json is malformed.");
        }

        private static string ReadJsonString(string json, ref int index)
        {
            var value = new StringBuilder();
            for (index++; index < json.Length; index++)
            {
                var character = json[index];
                if (character == '"')
                    return value.ToString();
                if (character < ' ')
                    throw new InvalidDataException("human-review.json is malformed.");
                if (character != '\\')
                {
                    value.Append(character);
                    continue;
                }

                if (++index >= json.Length)
                    throw new InvalidDataException("human-review.json is malformed.");
                var escape = json[index];
                switch (escape)
                {
                    case '"': value.Append('"'); break;
                    case '\\': value.Append('\\'); break;
                    case '/': value.Append('/'); break;
                    case 'b': value.Append('\b'); break;
                    case 'f': value.Append('\f'); break;
                    case 'n': value.Append('\n'); break;
                    case 'r': value.Append('\r'); break;
                    case 't': value.Append('\t'); break;
                    case 'u':
                        if (index + 4 >= json.Length || !ushort.TryParse(
                                json.Substring(index + 1, 4),
                                NumberStyles.HexNumber,
                                CultureInfo.InvariantCulture,
                                out var codePoint))
                            throw new InvalidDataException("human-review.json is malformed.");
                        value.Append((char)codePoint);
                        index += 4;
                        break;
                    default:
                        throw new InvalidDataException("human-review.json is malformed.");
                }
            }

            throw new InvalidDataException("human-review.json is malformed.");
        }

        private void SaveHumanReview(
            ResultFile result,
            string status,
            HumanReviewAnnotation annotation)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(result.HumanReviewError))
                    throw new InvalidDataException(result.HumanReviewError);
                if (status == "approved" &&
                    !CanApproveHumanReview(ReadResult(result.Path).ReviewApprovable, result.HumanReviewStatus))
                    throw new InvalidOperationException(
                        IsHumanRejected(result)
                            ? "This local review has requested changes. Rerun after the fix before approving."
                            : "Human approval requires passing product checks and complete visual evidence.");
                var annotations = result.HumanAnnotations.ToList();
                if (annotation != null)
                    annotations.Add(annotation);
                var actualVideoSha = FileSha256(result.VideoPath);
                if (!string.IsNullOrWhiteSpace(result.VideoSha256) &&
                    !string.Equals(actualVideoSha, result.VideoSha256, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("The recording no longer matches the receipt.");

                var document = new HumanReviewDocument
                {
                    schema_version = 1,
                    receipt_sha256 = FileSha256(result.Path),
                    video_sha256 = actualVideoSha,
                    status = status,
                    reviewed_at = DateTime.UtcNow.ToString("O"),
                    annotations = annotations.ToArray()
                };
                var temporary = result.HumanReviewPath + ".tmp";
                File.WriteAllText(
                    temporary,
                    JsonUtility.ToJson(document, true) + Environment.NewLine,
                    new UTF8Encoding(false));
                if (File.Exists(result.HumanReviewPath))
                    File.Replace(temporary, result.HumanReviewPath, null);
                else
                    File.Move(temporary, result.HumanReviewPath);
                RefreshResults();
                ShowNotification(new GUIContent(
                    status == "approved" ? "Recording approved" : "Changes requested"));
                Repaint();
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                EditorUtility.DisplayDialog("QUAK could not save the review", exception.Message, "OK");
            }
        }

        private static string FileSha256(string path)
        {
            using var stream = File.OpenRead(path);
            using var sha256 = SHA256.Create();
            return BitConverter.ToString(sha256.ComputeHash(stream))
                .Replace("-", string.Empty)
                .ToLowerInvariant();
        }

        private static string BytesSha256(byte[] payload)
        {
            using var sha256 = SHA256.Create();
            return BitConverter.ToString(sha256.ComputeHash(payload))
                .Replace("-", string.Empty)
                .ToLowerInvariant();
        }

        private static bool IsSha256(string value) =>
            value != null && value.Length == 64 && value.All(Uri.IsHexDigit);

        private static string CurrentSourceHash(TestFile test) =>
            test != null && test.Valid && IsSha256(test.SourceHash)
                ? test.SourceHash
                : string.Empty;

        private static bool SourceHashesMatch(string current, string receipt) =>
            IsSha256(current) && IsSha256(receipt) &&
            string.Equals(current, receipt, StringComparison.OrdinalIgnoreCase);

        private ResultFile LatestResult(TestFile test)
        {
            var selectedTarget = SelectedValidationDevice.Target;
            var sourceHash = CurrentSourceHash(test);
            if (string.IsNullOrWhiteSpace(sourceHash))
                return null;
            return results.FirstOrDefault(result =>
                string.Equals(result.TestName, test.Name, StringComparison.Ordinal) &&
                string.Equals(result.Target, selectedTarget, StringComparison.Ordinal) &&
                SourceHashesMatch(sourceHash, result.SourceHash));
        }

        private ResultFile ConnectionSmokeResult()
        {
            var path = Path.GetFullPath(Path.Combine(
                ProjectRoot,
                QuakProjectSetup.SmokeTestRelativePath));
            var test = tests.FirstOrDefault(candidate =>
                string.Equals(Path.GetFullPath(candidate.Path), path, StringComparison.Ordinal));
            return test != null && test.Valid ? LatestResult(test) : null;
        }

        private static string ResolveArtifact(string receiptPath, string artifact)
        {
            if (string.IsNullOrWhiteSpace(artifact))
                return string.Empty;
            var evidenceDirectory = Path.GetDirectoryName(receiptPath);
            if (string.IsNullOrWhiteSpace(evidenceDirectory))
                return string.Empty;
            var resolved = Path.GetFullPath(Path.Combine(evidenceDirectory, artifact));
            var prefix = Path.GetFullPath(evidenceDirectory)
                .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) +
                         Path.DirectorySeparatorChar;
            return resolved.StartsWith(prefix, StringComparison.Ordinal) && File.Exists(resolved)
                ? resolved
                : string.Empty;
        }

        private static string DisplayTimestamp(string timestamp)
        {
            return DateTimeOffset.TryParse(timestamp, out var parsed)
                ? parsed.ToLocalTime().ToString("dd MMM yyyy, HH:mm")
                : timestamp;
        }

        private static string ShortHash(string value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? "unavailable"
                : value.Substring(0, Math.Min(12, value.Length));
        }

        private static string DisplayProvenanceValue(string value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? "unavailable"
                : value.Replace('_', ' ');
        }

        private static bool IsPassed(ResultFile result) =>
            result != null && string.Equals(result.Status, "passed", StringComparison.OrdinalIgnoreCase);

        private static bool IsFailed(ResultFile result) =>
            result != null && string.Equals(result.Status, "failed", StringComparison.OrdinalIgnoreCase);

        private static bool IsHumanApproved(ResultFile result) =>
            result != null && result.ReviewApprovable && string.Equals(
                result.HumanReviewStatus,
                "approved",
                StringComparison.OrdinalIgnoreCase);

        private static bool IsHumanRejected(ResultFile result) =>
            result != null && string.Equals(
                result.HumanReviewStatus,
                "changes_requested",
                StringComparison.OrdinalIgnoreCase);

        private static bool NeedsHumanReview(ResultFile result) =>
            result != null && result.VisualDurationSeconds > 0d &&
            CanApproveHumanReview(result.ReviewApprovable, result.HumanReviewStatus) &&
            !IsHumanApproved(result) && !IsHumanRejected(result);

        private static Receipt ParseReceipt(string json)
        {
            var receipt = JsonUtility.FromJson<Receipt>(json);
            // JsonUtility creates empty nested objects even when the field is absent.
            // Preserve Python's legacy distinction between absent outcomes and {}.
            var hasOutcomes = false;
            var depth = 0;
            for (var index = 0; index < json.Length; index++)
            {
                var character = json[index];
                if (character == '{' || character == '[') depth++;
                else if (character == '}' || character == ']') depth--;
                else if (character == '"')
                {
                    var name = ReadJsonString(json, ref index);
                    var cursor = index + 1;
                    while (cursor < json.Length && char.IsWhiteSpace(json[cursor])) cursor++;
                    if (depth != 1 || name != "outcomes" || cursor >= json.Length || json[cursor] != ':')
                        continue;
                    cursor++;
                    while (cursor < json.Length && char.IsWhiteSpace(json[cursor])) cursor++;
                    hasOutcomes = cursor < json.Length && json[cursor] == '{';
                }
            }
            if (receipt != null && !hasOutcomes) receipt.outcomes = null;
            return receipt;
        }

        private static bool IsReceiptReviewApprovable(Receipt receipt)
        {
            var visual = receipt?.visual_evidence;
            var evidenceValid = visual != null &&
                (visual.capture_errors == null || visual.capture_errors.Length == 0) &&
                !visual.duration_limit_exceeded && visual.inspection?.status == "complete";
            if (receipt?.status != "passed" || !evidenceValid)
                return false;
            var outcomes = receipt.outcomes;
            return outcomes == null ||
                (outcomes.overall == receipt.status && outcomes.product == "passed" &&
                 outcomes.evidence == "recorded_pending_review");
        }

        private static bool CanApproveHumanReview(
            bool reviewApprovable,
            string currentReviewStatus) =>
            reviewApprovable &&
            !string.Equals(
                currentReviewStatus,
                "changes_requested",
                StringComparison.OrdinalIgnoreCase);

        private static string HumanReviewLabel(ResultFile result) =>
            IsHumanApproved(result) ? "APPROVED"
            : IsHumanRejected(result) ? "CHANGES REQUESTED"
            : result == null || !result.ReviewApprovable ? "TRIAGE ONLY" : "PENDING";

        private static string ResultBadge(ResultFile result) =>
            result == null ? "NOT RUN" : IsFailed(result) ? "FAILED"
            : !IsPassed(result) ? "NO VERDICT"
            : IsHumanRejected(result) ? "CHANGES"
            : NeedsHumanReview(result) ? "REVIEW" : "LAST VERIFIED";

        private static Color ResultColor(ResultFile result) =>
            result == null || (!IsPassed(result) && !IsFailed(result)) || NeedsHumanReview(result)
                ? WarningColor
            : IsFailed(result) || IsHumanRejected(result) ? FailColor : PassColor;

        private static string ReviewCategoryLabel(string category)
        {
            var index = Array.IndexOf(ReviewCategories, category);
            return index >= 0 ? ReviewCategoryLabels[index] : category;
        }

        private static void OpenLocalArtifact(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
                return;
            Application.OpenURL(new Uri(path).AbsoluteUri);
        }

        private string BuildTestAuthoringInstruction()
        {
            var target = TestTargets[Mathf.Clamp(newTestTarget, 0, TestTargets.Length - 1)];
            var focus = newTestVisualEvidence == 1
                ? "marked-and-failures"
                : FocusClipValues[Mathf.Clamp(newTestFocusClips, 0, FocusClipValues.Length - 1)];
            var highlight = newTestVisualEvidence == 1
                ? "focused-clips"
                : TargetHighlightValues[Mathf.Clamp(
                    newTestTargetHighlight, 0, TargetHighlightValues.Length - 1)];
            var evidence = newTestVisualEvidence == 0
                ? "Omit visual_evidence entirely: visual evidence is Off. "
                : "Set visual_evidence.required=true, focus_clips=" +
                  $"{focus}, and target_highlight={highlight}. " +
                  "Give every interaction selected for a focused clip a concise visual_annotation title. ";
            return $"Help me add a {target} QUAK test in {ProjectRoot} for: " +
                   $"{newTestDescription.Trim()} Inspect the real interaction code, run the test end to end, " +
                   evidence + "Inspect any recording against the structured assertions, " +
                   "and leave the test in quak-tests/.";
        }

        private static string BuildAgentGuidance()
        {
            return $"Help me work with QUAK in {ProjectRoot}. Inspect the project's real interaction code " +
                   "before changing tests, use the existing quak-tests/ definitions and QUAK commands, " +
                   "and require bounded visual evidence when validating Simulator or Quest behavior.";
        }

        private string BuildFailureInstruction(TestFile test, ResultFile result)
        {
            var failures = result.Failures.Length == 0
                ? "- Machine assertions passed; the human visual review found the problem below."
                : string.Join(Environment.NewLine, result.Failures.Select(failure => $"- {failure}"));
            var visual = result.VisualDurationSeconds <= 0d
                ? "- No visual recording was attached."
                : $"- Recording ({result.VisualDurationSeconds:0.#}s): {result.VideoPath}" + Environment.NewLine +
                  $"- Video SHA-256: {result.VideoSha256}" + Environment.NewLine +
                  $"- Visual report: {result.ReviewPath}" + Environment.NewLine +
                  $"- Human review sidecar: {result.HumanReviewPath}";
            var review = result.HumanAnnotations.Length == 0
                ? "- No human timestamp annotation was saved."
                : string.Join(
                    Environment.NewLine,
                    result.HumanAnnotations.Select(annotation =>
                        $"- {annotation.at_seconds:0.###}s [{annotation.category}] " +
                        $"Observed: {annotation.observed} Expected: {annotation.expected}"));
            return $"Help me diagnose and fix this failed or visually rejected QUAK run in {ProjectRoot}." +
                   Environment.NewLine + Environment.NewLine +
                   $"Test: {test.Name}" + Environment.NewLine +
                   $"Executed target: {result.Target}" + Environment.NewLine +
                   $"Definition: {test.Path}" + Environment.NewLine +
                   $"Receipt: {result.Path}" + Environment.NewLine +
                   $"Completed: {DisplayTimestamp(result.Timestamp)}" + Environment.NewLine +
                   $"Outcome: {result.PassedStepCount}/{result.StepCount} steps passed; " +
                   $"{result.PassedAssertionCount}/{result.AssertionCount} assertions passed." +
                   Environment.NewLine + Environment.NewLine +
                   "Failures:" + Environment.NewLine + failures +
                   Environment.NewLine + Environment.NewLine +
                   "Visual evidence:" + Environment.NewLine + visual +
                   Environment.NewLine + Environment.NewLine +
                   $"Human visual review: {result.HumanReviewStatus}" + Environment.NewLine + review +
                   Environment.NewLine + Environment.NewLine +
                   "Reproduce the failure first. Cross-check the recording against the structured receipt, " +
                   "then decide whether this is a product bug, test-definition bug, or automation bug. " +
                   "Make the smallest correct fix without weakening valid assertions or dismissing the human note. " +
                   "Rerun with this exact command so the new receipt links back to this one:" +
                   Environment.NewLine + BuildRunCommand(test, result) +
                   Environment.NewLine + Environment.NewLine +
                   "Inspect the new recording before reporting the root cause, changed files, and new evidence path. " +
                   "Do not mark the old run approved; the new recording must receive a new human review.";
        }

        private void OpenCodexForTest()
        {
            OpenCodexWithInstruction(
                BuildTestAuthoringInstruction(),
                "Instruction copied — paste it into Codex");
        }

        private static void OpenCodexWithInstruction(string instruction, string notification)
        {
            CopyToClipboard(instruction, notification);
            try
            {
                var process = new ProcessStartInfo
                {
                    FileName = CodexExecutable,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                process.ArgumentList.Add("app");
                process.ArgumentList.Add(ProjectRoot);
                Process.Start(process)?.Dispose();
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"QUAK could not open Codex: {exception.Message}");
            }
        }

        private void CopyTestCommand(string verb, string notification)
        {
            if (!HasSelectedTest)
                return;
            var command = verb == "run"
                ? BuildRunCommand(tests[selectedTest])
                : $"{ShellQuote(QuakExecutable)} {verb} {ShellQuote(tests[selectedTest].Path)}";
            if (verb == "regression --accept")
                command += $" --project {ShellQuote(ProjectRoot)}";
            CopyToClipboard(command, notification);
        }

        private string BuildRunCommand(TestFile test, ResultFile supersedes = null)
        {
            var device = SelectedValidationDevice;
            var command = $"{ShellQuote(QuakExecutable)} run {ShellQuote(test.Path)}" +
                          $" --project {ShellQuote(ProjectRoot)} --target {device.Target}";
            if (device.Target == "quest")
                command += " --expected-application-id " + ShellQuote(
                    PlayerSettings.GetApplicationIdentifier(NamedBuildTarget.Android));
            if (!string.IsNullOrWhiteSpace(device.Serial))
                command += $" --device-serial {ShellQuote(device.Serial)}";
            if (supersedes != null)
                command += $" --supersedes {ShellQuote(supersedes.Path)}";
            return command;
        }

        private static void CopyToClipboard(string value, string notification)
        {
            EditorGUIUtility.systemCopyBuffer = value;
            if (focusedWindow != null)
                focusedWindow.ShowNotification(new GUIContent(notification));
        }

        private static string ShellQuote(string value)
        {
            if (Application.platform == RuntimePlatform.WindowsEditor)
                return "\"" + value.Replace("\"", "\"\"") + "\"";
            return "'" + value.Replace("'", "'\"'\"'") + "'";
        }

        private static string RelativePath(string fullPath)
        {
            var root = ProjectRoot.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) +
                       Path.DirectorySeparatorChar;
            return fullPath.StartsWith(root, StringComparison.Ordinal)
                ? fullPath.Substring(root.Length)
                : fullPath;
        }

        private enum CheckLevel
        {
            Pass,
            Warning,
            Fail
        }

        private enum SetupCategory
        {
            Editor,
            Packages,
            Project,
            Integrations,
            Environment
        }

        private sealed class ValidationDevice
        {
            public ValidationDevice(
                string key,
                string label,
                string target,
                string serial,
                bool runnable,
                string detail)
            {
                Key = key;
                Label = label;
                Target = target;
                Serial = serial;
                Runnable = runnable;
                Detail = detail;
            }

            public string Key { get; }
            public string Label { get; }
            public string Target { get; }
            public string Serial { get; }
            public bool Runnable { get; }
            public string Detail { get; }
        }

        private sealed class SetupCheck
        {
            public SetupCheck(
                string name,
                string detail,
                CheckLevel level,
                string actionLabel = null,
                Action action = null,
                SetupCategory category = SetupCategory.Project,
                string statusReason = null,
                string navigateLabel = null,
                Action navigate = null)
            {
                Name = name;
                Detail = detail;
                Level = level;
                ActionLabel = actionLabel;
                Action = action;
                Category = category;
                StatusReason = statusReason ?? detail;
                NavigateLabel = navigateLabel;
                Navigate = navigate;
            }

            public string Name { get; }
            public string Detail { get; }
            public CheckLevel Level { get; }
            public string ActionLabel { get; }
            public Action Action { get; }
            public SetupCategory Category { get; }
            public string StatusReason { get; }
            public string NavigateLabel { get; }
            public Action Navigate { get; }
        }

        private sealed class TestFile
        {
            public TestFile(
                string path,
                string sourceHash,
                string name,
                string target,
                int stepCount,
                int assertionCount,
                bool visualEvidenceEnabled,
                string focusClips,
                string targetHighlight,
                bool valid,
                string error)
            {
                Path = path;
                SourceHash = sourceHash;
                Name = name;
                Target = target;
                StepCount = stepCount;
                AssertionCount = assertionCount;
                VisualEvidenceEnabled = visualEvidenceEnabled;
                FocusClips = focusClips;
                TargetHighlight = targetHighlight;
                Valid = valid;
                Error = error;
            }

            public string Path { get; }
            public string SourceHash { get; }
            public string Name { get; }
            public string Target { get; }
            public int StepCount { get; }
            public int AssertionCount { get; }
            public bool VisualEvidenceEnabled { get; }
            public string FocusClips { get; }
            public string TargetHighlight { get; }
            public bool Valid { get; }
            public string Error { get; }

            public static TestFile Invalid(string path, string error) =>
                new(
                    path,
                    string.Empty,
                    System.IO.Path.GetFileNameWithoutExtension(path),
                    "unknown",
                    0,
                    0,
                    false,
                    "marked-and-failures",
                    "focused-clips",
                    false,
                    error);
        }

        private sealed class ResultFile
        {
            public ResultFile(
                string path,
                string testName,
                string target,
                string status,
                string timestamp,
                DateTime lastWriteTimeUtc,
                double visualDurationSeconds,
                string reviewStatus,
                string videoPath,
                ResultFocusClip[] focusClips,
                string reviewPath,
                ReceiptVisualAnnotation[] visualAnnotations,
                string videoSha256,
                string humanReviewPath,
                string humanReviewStatus,
                HumanReviewAnnotation[] humanAnnotations,
                string humanReviewError,
                int stepCount,
                int passedStepCount,
                int assertionCount,
                int passedAssertionCount,
                string[] failures,
                string error,
                string sourceHash = "",
                string executionHash = "",
                string captureKind = "",
                string presentationKind = "",
                string layerInventoryStatus = "",
                string layerInventoryReason = "",
                bool reviewApprovable = false)
            {
                Path = path;
                TestName = testName;
                Target = target;
                Status = status;
                Timestamp = timestamp;
                LastWriteTimeUtc = lastWriteTimeUtc;
                VisualDurationSeconds = visualDurationSeconds;
                ReviewStatus = reviewStatus;
                VideoPath = videoPath;
                FocusClips = focusClips ?? Array.Empty<ResultFocusClip>();
                ReviewPath = reviewPath;
                VisualAnnotations = visualAnnotations ?? Array.Empty<ReceiptVisualAnnotation>();
                VideoSha256 = videoSha256;
                HumanReviewPath = humanReviewPath;
                HumanReviewStatus = humanReviewStatus;
                HumanAnnotations = humanAnnotations ?? Array.Empty<HumanReviewAnnotation>();
                HumanReviewError = humanReviewError;
                StepCount = stepCount;
                PassedStepCount = passedStepCount;
                AssertionCount = assertionCount;
                PassedAssertionCount = passedAssertionCount;
                Failures = failures ?? Array.Empty<string>();
                Error = error;
                SourceHash = sourceHash;
                ExecutionHash = executionHash;
                CaptureKind = captureKind;
                PresentationKind = presentationKind;
                LayerInventoryStatus = layerInventoryStatus;
                LayerInventoryReason = layerInventoryReason;
                ReviewApprovable = reviewApprovable;
            }

            public string Path { get; }
            public string TestName { get; }
            public string Target { get; }
            public string Status { get; }
            public string Timestamp { get; }
            public DateTime LastWriteTimeUtc { get; }
            public double VisualDurationSeconds { get; }
            public string ReviewStatus { get; }
            public string VideoPath { get; }
            public ResultFocusClip[] FocusClips { get; }
            public string ReviewPath { get; }
            public ReceiptVisualAnnotation[] VisualAnnotations { get; }
            public string VideoSha256 { get; }
            public string HumanReviewPath { get; }
            public string HumanReviewStatus { get; }
            public HumanReviewAnnotation[] HumanAnnotations { get; }
            public string HumanReviewError { get; }
            public int StepCount { get; }
            public int PassedStepCount { get; }
            public int AssertionCount { get; }
            public int PassedAssertionCount { get; }
            public string[] Failures { get; }
            public string Error { get; }
            public string SourceHash { get; }
            public string ExecutionHash { get; }
            public string CaptureKind { get; }
            public string PresentationKind { get; }
            public string LayerInventoryStatus { get; }
            public string LayerInventoryReason { get; }
            public bool ReviewApprovable { get; }
            public bool IsTransformedVisual =>
                !string.IsNullOrWhiteSpace(PresentationKind) &&
                !string.Equals(PresentationKind, "raw", StringComparison.OrdinalIgnoreCase);
            public string VisualSummary => VisualDurationSeconds > 0d
                ? $"  •  {VisualDurationSeconds:0.#}s video" +
                  (FocusClips.Length > 0 ? $"  •  {FocusClips.Length} focus clips" : string.Empty) +
                  $"  •  human review {HumanReviewStatus}" +
                  (IsTransformedVisual ? "  •  NOT RAW" : string.Empty)
                : string.Empty;

            public static ResultFile Invalid(string path, string error) =>
                new(
                    path,
                    "Unreadable receipt",
                    "unknown",
                    "invalid",
                    string.Empty,
                    DateTime.MinValue,
                    0d,
                    string.Empty,
                    string.Empty,
                    Array.Empty<ResultFocusClip>(),
                    string.Empty,
                    Array.Empty<ReceiptVisualAnnotation>(),
                    string.Empty,
                    string.Empty,
                    "pending",
                    Array.Empty<HumanReviewAnnotation>(),
                    string.Empty,
                    0,
                    0,
                    0,
                    0,
                    Array.Empty<string>(),
                    error);
        }

        private sealed class ResultFocusClip
        {
            public ResultFocusClip(
                string stepId,
                string title,
                string verdict,
                string videoPath)
            {
                StepId = stepId;
                Title = string.IsNullOrWhiteSpace(title) ? stepId : title;
                Verdict = string.IsNullOrWhiteSpace(verdict) ? "recorded" : verdict;
                VideoPath = videoPath;
            }

            public string StepId { get; }
            public string Title { get; }
            public string Verdict { get; }
            public string VideoPath { get; }
        }

        [Serializable]
        private sealed class TestDefinition
        {
            public int schema_version;
            public string name;
            public string target;
            public TestVisualEvidence visual_evidence;
            public TestStep[] steps;
        }

        [Serializable]
        private sealed class TestVisualEvidence
        {
            public string focus_clips;
            public string target_highlight;
        }

        [Serializable]
        private sealed class TestStep
        {
            public string id;
            public string provider;
            public string tool;
            public TestAssertion[] assertions;
        }

        [Serializable]
        private sealed class TestAssertion
        {
            public string path;
            public string op;
        }

        [Serializable]
        private sealed class Receipt
        {
            public string test;
            public string journey;
            public string target;
            public string started_at;
            public string finished_at;
            public string status;
            public ReceiptStep[] steps;
            public ReceiptOutcomes outcomes;
            public ReceiptArtifact test_definition;
            public ReceiptVisualEvidence visual_evidence;
        }

        [Serializable]
        private sealed class ReceiptOutcomes
        {
            public string overall;
            public string product;
            public string evidence;
        }

        [Serializable]
        private sealed class ReceiptStep
        {
            public string id;
            public string status;
            public string error;
            public ReceiptAssertion[] assertions;
        }

        [Serializable]
        private sealed class ReceiptAssertion
        {
            public string path;
            public string op;
            public bool passed;
        }

        [Serializable]
        private sealed class ReceiptVisualEvidence
        {
            public double duration_seconds;
            public string review_status;
            public string[] capture_errors;
            public bool duration_limit_exceeded;
            public ReceiptInspection inspection;
            public ReceiptArtifact video;
            public ReceiptArtifact review;
            public ReceiptFocusClip[] interaction_focus_clips;
            public ReceiptVisualAnnotation[] annotations;
            public ReceiptVisualProvenance provenance;
        }

        [Serializable]
        private sealed class ReceiptInspection
        {
            public string status;
        }

        [Serializable]
        private sealed class ReceiptFocusClip
        {
            public string step_id;
            public string title;
            public string verdict;
            public ReceiptArtifact video;
        }

        [Serializable]
        private sealed class ReceiptVisualProvenance
        {
            public string capture_kind;
            public string presentation_kind;
            public ReceiptLayerInventory layer_inventory;
        }

        [Serializable]
        private sealed class ReceiptLayerInventory
        {
            public string status;
            public string reason;
        }

        [Serializable]
        private sealed class ReceiptVisualAnnotation
        {
            public double at_seconds;
            public string kind;
            public string text;
        }

        [Serializable]
        private sealed class ReceiptArtifact
        {
            public string artifact;
            public string sha256;
            public string source_sha256;
            public string execution_sha256;
        }

        private sealed class HumanReviewRead
        {
            public HumanReviewRead(string path, HumanReviewDocument document, string error)
            {
                Path = path;
                Document = document;
                Error = error;
            }

            public string Path { get; }
            public HumanReviewDocument Document { get; }
            public string Error { get; }
        }

        [Serializable]
        private sealed class HumanReviewDocument
        {
            public int schema_version = 1;
            public string receipt_sha256;
            public string video_sha256;
            public string status;
            public string reviewed_at;
            public HumanReviewAnnotation[] annotations;
        }

        [Serializable]
        private sealed class HumanReviewAnnotation
        {
            public double at_seconds;
            public string category;
            public string observed;
            public string expected;
            public string created_at;
        }

        [Serializable]
        private sealed class RegressionCatalog
        {
            public int schema_version;
            public RegressionCatalogEntry[] protected_tests;
        }

        [Serializable]
        private sealed class QuakConfig
        {
            public string evidence_dir;
        }

        [Serializable]
        private sealed class RegressionCatalogEntry
        {
            public string path;
        }

        [Serializable]
        private sealed class RegressionReport
        {
            public int schema_version;
            public string status;
            public int tested;
            public int @protected;
            public int passed_tests;
            public RegressionIssue[] regressions;
        }

        [Serializable]
        private sealed class RegressionIssue
        {
            public string kind;
        }

        [Serializable]
        private sealed class MachineConfig
        {
            public int schema_version = 1;
            public TestMachine[] machines = Array.Empty<TestMachine>();
        }

        [Serializable]
        private sealed class TestMachine
        {
            public bool enabled;
            public string name;
            public string host;
            public string target;
            public string project_path;
            public string expected_application_id;
            public string expected_scene;
        }

        [Serializable]
        private sealed class MachineEvent
        {
            public string phase;
            public string machine;
            public string status;
            public string detail;
            public int completed;
            public int total;
        }
    }
}
