---
name: quak-test
description: Create or update reliable, project-owned QUAK tests from natural-language acceptance requests for Unity XR interactions and UI. Use when asked to turn behavior such as grabbing, snapping, selecting, navigating, or validating into a repeatable QUAK test, wire the minimum QuakTarget/state/fixture adapter needed by that test, diagnose a misleading pass, or verify Editor, Simulator, and Quest evidence without conflating them.
---

# QUAK test authoring

Turn the user's product intent into a small reviewed test, not an open-ended
agent script. Keep app-specific tests and adapters in the Unity project; QUAK
itself stays generic.

## 1. Inspect before designing

1. Locate the Unity project, `.quak/config.json`, project test directory,
   installed QUAK package version, and existing tests. Read the repo's agent
   instructions and use its current schema/examples when available. Prefer the
   project-root `./quak` launcher when installed; otherwise use the explicitly
   selected CLI. Run `validate` with that CLI as the final
   format authority.
   Older releases may call a test a `journey`; preserve that file format only
   when compatibility requires it, while calling it a test to the user. Install
   QUAK from a release tarball or exact Git commit, never `#main`. The receipt
   stores a redacted test snapshot plus an exact execution hash; redacted values
   are not recoverable, and prose cannot amend what ran.
2. Find the actual interaction code, user-visible controls, current
   `QuakTarget` components, `IQuakStateProvider` implementations, and
   `IQuakActionHandler` fixtures. Do not infer behavior from object names alone.
3. Choose exactly one proof lane: `editor`, `simulator`, or `quest`. A result in
   one lane never proves another.
4. Prefer a normal Unity Edit Mode or Play Mode test when embodied XR input is
   not part of the acceptance behavior.

## 2. Lock the acceptance contract

Before editing, state the contract in concrete terms:

- **Arrange:** deterministic starting state and required scene/content.
- **Act:** the user interaction to reproduce through Meta XR Operator.
- **Assert:** observable product facts that decide pass or fail.
- **Negative control:** a wrong or incomplete action that must not satisfy the
  success facts, or a captured red-before-green failure of the real test.
- **Coverage:** every requested object, variant, or state transition. Missing
  coverage is a failure, never an implicit skip.

Resolve material ambiguity with the user. Once agreed, do not weaken an
assertion, delete coverage, change expected behavior, or replace real input
with a fixture merely to make a failing test pass without explicit approval.

## 3. Add the minimum project adapter

- Start with the automatically discovered targets from `quak_get_capabilities`.
  For each discovered target a durable test references, add `QuakTarget` with a
  semantic ID such as `assembly.ui.validate`; do this as part of authoring rather
  than asking the user to find objects in the Hierarchy. Add explicit targets
  directly for custom interactions and non-interactive destinations. IDs must
  survive hierarchy and display-name changes, and each target must sit on the
  real hit surface or destination anchor used by production interaction code.
  Prefer public `QuakTarget.Configure`; confirm owner, active state, bounds,
  raycast eligibility, source, and `coordinateSpace: world`. Generic
  `visibility` and `compositorLayer` are explicitly `unavailable`: active or
  raycast-eligible is not proof of rendered visibility or occlusion. An aligned
  duplicate surface is not direct compositor interaction; native mapping
  requires a project/vendor layer contract.
  For Unity 6.2+ world-space UI Toolkit, use `QuakUiToolkitTarget` on the live
  `UIDocument` plus its project-owned panel `BoxCollider`, name the exact live
  UXML control, and target the interactive parent rather than an overlay. Never
  cache or target a detached template. Before input, referenced IDs must be
  unique, active, world-space, and expose finite pose and bounds.
- Expose read-only, fast product facts through `IQuakStateProvider`. Assert
  domain state such as `redSnapped`, `placedCount`, and `validationResult`, not
  only a successful tool call, pose, or screenshot. Read authoritative
  production state; do not duplicate the matching rules in the provider or add
  an QUAK-only success flag that can agree with the test while the app is wrong.
  The reserved built-in `quak-runtime` provider proves only generic scene
  readiness; never use it as the product outcome.
  `QuakRegistry.CurrentCorrelationId` is QUAK action context echoed by registry
  snapshots; it does not prove a real hit handler, product event, or telemetry
  event carried the ID. When that chain matters, persist the ID in app-owned
  state inside the real event handler and assert that event-owned value.
- Use `IQuakActionHandler` only for deterministic setup, teardown, or reset.
  A fixture must never perform the interaction under test. Mark persistent
  asset or project-setting changes as project mutations. Pass action payloads
  through native `arguments` objects; do not hand-encode `arguments_json`.
- Keep state free of tokens, personal data, and device identifiers. Detect
  duplicate or empty target, provider, and action IDs before running.

## 4. Author a focused test

Use the format accepted by the installed QUAK version. Give every step a stable
ID and explicit assertions. The usual shape is:

1. Reset or arrange with a Unity fixture.
2. Prove the Editor/app is ready and capture the initial product state.
3. Perform the real interaction through the selected XR provider using stable target IDs.
4. Assert the resulting product state through Unity or another independent state
   path. Every input sequence closes with `quak_get_state` and marks at least
   one expected app-state value `"effect": true`. QUAK captures that provider
   before input and requires every marked value to change as well as match;
   already-true state cannot close the action. Use `changed`, `changed_to`, or
   `increased_by` when the delta itself is the contract; the receipt retains
   before/after values. Application-effect closures check immediately, then poll
   for up to 3 seconds at 0.1-second intervals by default. Set
   `wait_timeout_seconds` to `0` only for an explicitly instantaneous contract,
   or override it for a known slower transition. An explicit nonzero observation
   window is required before QUAK may retry one ambiguous semantic input; it
   queries the effect first and never retries when the state is unknown.
   When the contract is a final state regardless of its initial value, put
   `"ensure_effect": true` on the semantic input, omit transport assertions,
   and close with an idempotent assertion such as `equals`. QUAK skips the input
   when the complete closing state already passes; otherwise it sends it once
   and requires a correlated change. Never combine this mode with a delta
   assertion.
5. For Simulator and Quest acceptance, require bounded visual evidence. Add
   `visual_evidence` with `required: true`, a duration limit of 20 seconds or
   less, `focus_clips: marked-and-failures`, and `target_highlight:
   focused-clips`. This is the Standard preset: it retains the unprocessed
   source, the full captioned journey, and one short focused clip for each
   interaction `visual_annotation` plus failures. Omit `visual_evidence` for Off. Use
   Advanced only when the test explicitly needs `all-interactions`, no focus
   clips, or a different highlight scope. Leave `capture_policy` at
   `unattended` for automation: QUAK uses the
   selected Quest's OS-level screen recorder or a pre-authorized Simulator
   window and fails before input when neither is available. For reconstructed
   compositor snapshots, set `capture_source: compositor` and 1 fps; a Quest
   lane additionally requires `capture_policy: attended`. This bypasses display
   recording when virtual/OpenXR layers are part of the visual claim. Give
   interaction steps a short
   `visual_annotation` and failures concrete `failure_guidance`. Keep structured
   state as the product oracle; the recording independently makes that verdict
   inspectable. An accepted provider command is not input-delivery proof: no
   correlated app event or effect is `PRODUCT INCONCLUSIVE`, while a correlated
   changed effect that violates its assertion is `PRODUCT FAILED`. Start review
   with the per-interaction videos under `artifacts/focus/`, which crop around
   reported target bounds and burn in the title, highlight, and verdict. A
   full-frame fallback must be labeled as such in the receipt. Quest video is
   not a raw per-eye compositor dump. Expect
   `mirrored-simulator-evidence.mp4`, `quest-device-evidence.mp4`, or attended
   `reconstructed-compositor-evidence.mp4` and require retained raw sources.
   For compositor work, first run a short visual
   test that asserts the app's capture mode and surface counts; require a person
   to confirm the intended video/UI surfaces before a long journey.
   Layer inventory is unavailable unless its dedicated tool was advertised;
   frame info is context only, and inventory does not prove native-layer content
   appeared in the recording.
   Open `visual-review.html` first: one low-resolution FFmpeg pass mechanically
   checked every decodable frame and produced a 2 fps full-timeline storyboard.
   Review every flagged interval, scan the whole storyboard, then inspect the
   original video around product-critical events. This speeds review but does
   not turn mechanical coverage into a semantic verdict; keep visual acceptance
   pending until the visible behavior is actually checked.

For example, a Cube Assembly test resets three blocks, grabs each
`assembly.block.<color>` to its matching `assembly.socket.<color>` through
Operator, then asserts through an app state provider that the matching snap is
true and `placedCount` increases. It clicks `assembly.ui.validate` through XR
input and passes only when independent state reports `validationResult` as
`passed`. If the contract says every cube must snap only to its matching socket,
the negative coverage exercises every forbidden cube/socket pair, not one
representative pair. It verifies that each attempt really reached the app
through facts such as source/destination IDs and an attempt counter, then checks
the actual socket occupant IDs and completion state. It also activates Validate
while incomplete and verifies the app recorded and rejected that attempt, for
example through an incremented validation-attempt count. If the intended UX is
a disabled control, assert that contract explicitly instead of pretending a
click occurred.

When the acceptance behavior includes a magnetic or forgiving placement range,
do not drive `quak_grab_target_to_target` to a perfect destination pose and call
that sufficient evidence. Set `release_local_position_offset_m` and
`release_local_yaw_offset_degrees` to a deterministic destination-local pose
inside the intended allowance, then assert the independent snapped state. Add a
focused boundary test with offsets just outside each allowance and assert that
the app rejects them. Keep these release offsets distinct from the helper's
controller settlement tolerances.

For a trigger-held pointer drag, use first-class `quak_pointer_drag` with 2–32
aim poses. Do not assemble raw pose/button steps. The helper always attempts to
release Trigger, including on failure; a failed release fails the step. The next
`quak_get_state` step must still prove the product effect.

Prefer one focused test per acceptance behavior. Split unrelated flows instead
of creating a long scenario. Do not add loops, shell execution, generated code,
or timing-only assertions to the test document.

For paired performance, use `quak experiment <manifest>` with one parameterized
test and `{"$variant":"name"}`. Require counterbalanced AB/BA order, warmups,
repetitions, app-state phase boundaries, and declared metric meaning. Use
`quak validate <manifest>` before execution. Review both the JSON and adjacent
self-contained HTML report for raw samples, medians, means, p95, spread, percentage change,
valid/invalid counts, budget margin, availability, provenance, and caveats.
Assert every variant variable through `quak_get_state` with an app-state
equality assertion whose expected value uses the same `$variant`; this proves
which variant was active. Declare the measurement target, application, and scene
in the shared test; experiment-time identity overrides are rejected so receipt
hashes bind the scenario. QUAK rejects a changed headset alias, live session,
runtime/provider set, or Git/package provenance. If the installed binary itself
matters, Quest receipts retain the installed APK-set hash and runtime build;
expose and assert the app's embedded build ID through state. Performance
experiments reject dirty worktrees unless the manifest explicitly opts into a
caveated dirty-state hash. Never infer unavailable
provider metrics, sampling semantics, native-layer visibility, or thermal state.

For a Quest-targeted definition, set top-level `expected_application_id` to the
intended Android package; the test is invalid without it. Set `expected_scene`
when scene identity is part of the acceptance contract. Every live Quest
command enables and verifies Meta's experimental property and creates the
selected device's Operator ADB port forward. Do not add manual `setprop` or
`adb forward` steps. QUAK takes a host-local lease on the selected serial before
mutation; a multi-host lab still needs an external scheduler. It cannot bypass
developer-mode approval or disable Guardian/proximity focus requirements.

Use top-level `quest_preflight` only when the fixture must clear the exact app,
delete a conservative relative path below its external `cache/` or `files/`
directory, grant a bounded `grant_runtime_permissions` list, or launch a safe
product-owned absolute URI before Operator connects. It requires `confirm: true`,
a debuggable package, and the separate `--allow-device-reset` CLI confirmation.
QUAK grants only permissions declared by the exact package and listed as runtime
permissions, verifies each grant before launch, and reports a blocking system
permission prompt immediately. Despite its legacy name, the flag authorizes
force-stop/launch plus requested data resets or permission grants. QUAK rejects
shell commands and local-content URI schemes, force-stops before the operation,
and waits boundedly after launch. For lifecycle races, invoke app-owned actions normally, poll
`quak_get_recent_logs`, and use `logs_contain_in_order`; the runner excludes
entries at or before run start.

If a target animates or follows the user after reset, give
`quak_click_target` a bounded `target_settle_seconds` so it samples the target's
pose after that motion. Keep the resulting product-state assertion independent;
the delay is input setup, not proof that the app worked.

## 5. Prove the test is trustworthy

1. Run `quak validate <test-file>`.
2. Run `quak doctor --project <absolute-project-path> --target <lane>`. Add
   `--live` only when the intended Editor/OpenXR session is running. Live
   readiness must prove an `quak_status` backend callback; cached tools do not
   count. Check app/session identity, stable app/input/VR focus, state providers,
   and for Quest the selected serial and resumed package. For Quest, also pass
   `--expected-application-id <package>` and, when applicable,
   `--expected-scene <scene>`. `sessionAgeSeconds` is app-session age and
   `connection_check_age_seconds` is elapsed time since QUAK's readiness check;
   neither is backend-connection duration. Backend URL, true connection age,
   recent Unity logs, and layer inventory may be unavailable when their
   dedicated vendor/project tools do not report them.
3. Establish a false-positive defense:
   - first capture the expected failure before the product fix, then the pass;
     or
   - run negative controls that make the success assertion fail. Prove each
     rejected interaction was actually attempted; unchanged state alone can
     also mean that input never reached the app.
4. Run `quak run <test-file> --project <absolute-project-path>`. For a Quest APK
   claim, use `quak prove <apk> <test-file> --build-source-project <unity-project>
   --expected-source-commit <40-character-commit>` so source observation,
   installed APK identity, and the test share one receipt. This remains a local
   observation rather than a signed build attestation.
5. Open `artifacts/run-report.html` for the compact run summary, then the emitted
   `receipt.json` for the machine authority. Check the first failed step, resolved
   arguments, assertion actual/expected values, evidence lane, and captured
   artifacts. Input injection or a successful tool response alone is not a
   product pass. Confirm the test-definition artifact/hash, action-context
   correlation IDs, phase boundaries, and automatic state/log failure
   diagnostics are present. Failure-image capture is default-off; use
   `--capture-failure-image` only in an attended lane because Meta may show
   media-capture consent UI. Recent logs are expected only when their dedicated tool was
   available.
6. Open `artifacts/visual-review.html` and cross-check the visible action and
   result against the structured assertions. Review its all-frame mechanical
   findings and full-timeline storyboard, not only the annotated action moments.
   Use the relevant video under `artifacts/focus/` for a short issue attachment,
   but retain the full journey and unprocessed source as context.
   `review_status: pending` means the
   recording exists but has not been visually accepted; never describe that as
   visually verified.
7. Re-run from reset to catch state leakage. Treat missing providers, targets,
   tools, requested variants, receipts, or artifacts as failures, not skips.

If hardware or a live session is unavailable, validate what can be validated
statically and say exactly which lane remains unproved.
A development, test, or harness APK—or invented test-only navigation—never
proves the shipping application or its real path.
Generic target metadata cannot prove rendered visibility, occlusion, native
compositor-layer input mapping, or which layers appeared in a recording. Those
remain explicit project/vendor integration boundaries.

## Safety boundary

Start with read-only inspection. Never enable `--allow-project-mutations`,
mark a test step as a confirmed project mutation, or use Unity `eval`,
`eval_file`, hot reload, or equivalent live code execution unless the user has
explicitly authorized that exact operation. Treat live evaluation as arbitrary
trusted code execution inside the running Editor.

## Report back

Summarize the acceptance contract, files added or changed, false-positive
defense, exact commands run, receipt location, and separate status for Editor,
Simulator, and Quest. Never claim an untested lane passed.
