using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;
using XRDevRob.QUAK.MetaOperator;

namespace XRDevRob.QUAK.Samples.Quickstart.Editor
{
    public static class QuakQuickstartSceneGenerator
    {
        private const string SceneFolder = "Assets/QUAKQuickstart";
        private const string ScenePath = SceneFolder + "/QUAKQuickstart.unity";

        [MenuItem("QUAK/Quickstart/Create World-Space UGUI Scene", priority = 0)]
        public static void CreateScene()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                return;

            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null &&
                !EditorUtility.DisplayDialog(
                    "Replace QUAK Quickstart?",
                    $"{ScenePath} already exists. Replace it with a fresh Quickstart scene?",
                    "Replace",
                    "Cancel"))
            {
                return;
            }

            EnsureFolder();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var root = new GameObject("QUAK Quickstart");
            root.AddComponent<QuakQuickstartXrBootstrap>();

            var camera = CreateCamera(root.transform);
            CreateEventSystem(root.transform);
            CreateWorldSpaceUi(root.transform, camera, out var buttonObject);

            var bridgeObject = new GameObject("QUAK Operator Bridge");
            bridgeObject.transform.SetParent(root.transform, false);
            bridgeObject.AddComponent<QuakOperatorBridge>();

            EditorSceneManager.MarkSceneDirty(scene);
            if (!EditorSceneManager.SaveScene(scene, ScenePath))
                throw new InvalidOperationException($"Could not save QUAK Quickstart scene at {ScenePath}.");

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Selection.activeGameObject = buttonObject;
            EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath));
            Debug.Log(
                $"[QUAK Quickstart] Created {ScenePath}. Integrated Core-205 lane: start Meta XR " +
                "Simulator and enter Play mode. No-Core lane: follow Doctor's standalone-player " +
                "launch instructions. Then run the Quickstart test.");
        }

        private static Camera CreateCamera(Transform parent)
        {
            var cameraObject = new GameObject(
                "Main Camera",
                typeof(Camera),
                typeof(AudioListener),
                typeof(TrackedPoseDriver));
            cameraObject.tag = "MainCamera";
            cameraObject.transform.SetParent(parent, false);
            cameraObject.transform.position = new Vector3(0f, 1.6f, 0f);
            cameraObject.transform.rotation = Quaternion.LookRotation(
                new Vector3(0f, 1.4f, 1.5f) - cameraObject.transform.position,
                Vector3.up);

            var camera = cameraObject.GetComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.015f, 0.02f, 0.045f, 1f);
            camera.nearClipPlane = 0.01f;
            camera.farClipPlane = 100f;

            var driver = cameraObject.GetComponent<TrackedPoseDriver>();
            driver.ignoreTrackingState = true;
            driver.positionInput = new InputActionProperty(new InputAction(
                "Head Position", InputActionType.Value, "<XRHMD>/centerEyePosition"));
            driver.rotationInput = new InputActionProperty(new InputAction(
                "Head Rotation", InputActionType.Value, "<XRHMD>/centerEyeRotation"));
            return camera;
        }

        private static void CreateEventSystem(Transform parent)
        {
            var eventSystemObject = new GameObject(
                "EventSystem",
                typeof(EventSystem),
                typeof(InputSystemUIInputModule));
            eventSystemObject.transform.SetParent(parent, false);
            eventSystemObject.GetComponent<InputSystemUIInputModule>().AssignDefaultActions();
        }

        private static void CreateWorldSpaceUi(
            Transform parent,
            Camera eventCamera,
            out GameObject buttonObject)
        {
            var canvasObject = new GameObject(
                "QUAK Quickstart Canvas",
                typeof(RectTransform),
                typeof(Canvas),
                typeof(CanvasScaler),
                typeof(GraphicRaycaster),
                typeof(TrackedDeviceRaycaster));
            canvasObject.transform.SetParent(parent, false);

            var canvasTransform = canvasObject.GetComponent<RectTransform>();
            canvasTransform.sizeDelta = new Vector2(800f, 450f);
            canvasTransform.position = new Vector3(0f, 1.4f, 1.5f);
            canvasTransform.rotation = Quaternion.identity;
            canvasTransform.localScale = Vector3.one * 0.0015f;

            var canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvas.worldCamera = eventCamera;
            canvasObject.GetComponent<CanvasScaler>().dynamicPixelsPerUnit = 10f;

            var panel = CreateUiObject("Panel", canvasTransform, typeof(Image));
            Stretch(panel.GetComponent<RectTransform>());
            panel.GetComponent<Image>().color = new Color(0.045f, 0.065f, 0.12f, 0.96f);

            var heading = CreateText(
                "Heading",
                panel.transform,
                "QUAK CLOSED-LOOP QUICKSTART",
                38,
                FontStyle.Bold);
            SetRect(heading.rectTransform, new Vector2(0f, 125f), new Vector2(700f, 70f));

            buttonObject = CreateUiObject(
                "Demo Toggle Button",
                panel.transform,
                typeof(Image),
                typeof(Button),
                typeof(QuakTarget),
                typeof(QuakQuickstartToggle));
            SetRect(
                buttonObject.GetComponent<RectTransform>(),
                new Vector2(0f, 10f),
                new Vector2(420f, 120f));

            var buttonImage = buttonObject.GetComponent<Image>();
            buttonImage.color = new Color(0.18f, 0.42f, 0.95f, 1f);
            var button = buttonObject.GetComponent<Button>();
            button.targetGraphic = buttonImage;
            var colors = button.colors;
            colors.normalColor = new Color(0.18f, 0.42f, 0.95f, 1f);
            colors.highlightedColor = new Color(0.28f, 0.58f, 1f, 1f);
            colors.pressedColor = new Color(0.10f, 0.28f, 0.72f, 1f);
            colors.selectedColor = colors.highlightedColor;
            button.colors = colors;

            var buttonText = CreateText(
                "Label",
                buttonObject.transform,
                "CLICK WITH XR OPERATOR",
                30,
                FontStyle.Bold);
            Stretch(buttonText.rectTransform);

            var stateText = CreateText(
                "Product State",
                panel.transform,
                "Product state: waiting for a real click",
                24,
                FontStyle.Normal);
            SetRect(stateText.rectTransform, new Vector2(0f, -105f), new Vector2(700f, 60f));

            var target = buttonObject.GetComponent<QuakTarget>();
            target.Configure(
                "demo.toggle",
                "Quickstart UGUI Button whose product state changes only through Button.onClick.");

            var state = buttonObject.GetComponent<QuakQuickstartToggle>();
            var stateSerialized = new SerializedObject(state);
            stateSerialized.FindProperty("button").objectReferenceValue = button;
            stateSerialized.FindProperty("stateLabel").objectReferenceValue = stateText;
            stateSerialized.ApplyModifiedPropertiesWithoutUndo();
        }

        private static Text CreateText(
            string name,
            Transform parent,
            string value,
            int fontSize,
            FontStyle fontStyle)
        {
            var textObject = CreateUiObject(name, parent, typeof(Text));
            var text = textObject.GetComponent<Text>();
            text.text = value;
            text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.fontSize = fontSize;
            text.fontStyle = fontStyle;
            text.alignment = TextAnchor.MiddleCenter;
            text.color = Color.white;
            text.raycastTarget = false;
            return text;
        }

        private static GameObject CreateUiObject(string name, Transform parent, params Type[] components)
        {
            var objectComponents = new Type[components.Length + 1];
            objectComponents[0] = typeof(RectTransform);
            Array.Copy(components, 0, objectComponents, 1, components.Length);
            var gameObject = new GameObject(name, objectComponents);
            gameObject.transform.SetParent(parent, false);
            return gameObject;
        }

        private static void Stretch(RectTransform rectTransform)
        {
            rectTransform.anchorMin = Vector2.zero;
            rectTransform.anchorMax = Vector2.one;
            rectTransform.offsetMin = Vector2.zero;
            rectTransform.offsetMax = Vector2.zero;
        }

        private static void SetRect(RectTransform rectTransform, Vector2 position, Vector2 size)
        {
            rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchoredPosition = position;
            rectTransform.sizeDelta = size;
        }

        private static void EnsureFolder()
        {
            if (!AssetDatabase.IsValidFolder(SceneFolder))
                AssetDatabase.CreateFolder("Assets", "QUAKQuickstart");
        }
    }
}
