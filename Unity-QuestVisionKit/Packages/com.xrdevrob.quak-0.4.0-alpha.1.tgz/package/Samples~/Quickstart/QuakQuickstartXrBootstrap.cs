using System;
using UnityEngine;
using UnityEngine.XR.Management;

namespace XRDevRob.QUAK.Samples.Quickstart
{
    /// <summary>
    /// Makes the generated sample self-contained in projects that disable
    /// automatic XR startup. Production apps should keep their own XR lifecycle.
    /// </summary>
    [DisallowMultipleComponent]
    [DefaultExecutionOrder(-10000)]
    public sealed class QuakQuickstartXrBootstrap : MonoBehaviour
    {
        private bool ownsLoader;

        private void Start()
        {
            var manager = XRGeneralSettings.Instance != null
                ? XRGeneralSettings.Instance.Manager
                : null;
            if (manager == null)
            {
                Debug.LogError("[QUAK Quickstart] XR Plug-in Management is not configured.");
                return;
            }

            try
            {
                if (manager.activeLoader == null)
                {
                    manager.InitializeLoaderSync();
                    ownsLoader = manager.activeLoader != null;
                }

                if (manager.activeLoader == null)
                {
                    Debug.LogError(
                        "[QUAK Quickstart] No XR loader became active. Enable OpenXR for the selected runtime; rebuild and relaunch a Standalone player, or restart Play Mode in the integrated Editor lane.");
                    return;
                }

                manager.StartSubsystems();
                Debug.Log($"[QUAK Quickstart] XR loader ready: {manager.activeLoader.name}.");
            }
            catch (Exception exception)
            {
                Debug.LogError($"[QUAK Quickstart] XR startup failed: {exception.Message}");
            }
        }

        private void OnDestroy()
        {
            if (!ownsLoader || XRGeneralSettings.Instance == null)
                return;

            var manager = XRGeneralSettings.Instance.Manager;
            if (manager == null)
                return;

            manager.StopSubsystems();
            manager.DeinitializeLoader();
        }
    }
}
