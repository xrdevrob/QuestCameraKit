using System;
using UnityEngine;
using UnityEngine.UI;

namespace XRDevRob.QUAK.Samples.Quickstart
{
    /// <summary>
    /// Minimal product-state oracle for the Quickstart scene. The observed state
    /// changes only when the real UGUI Button raises its onClick event.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class QuakQuickstartToggle : MonoBehaviour, IQuakStateProvider, IQuakActionHandler
    {
        [SerializeField] private Button button;
        [SerializeField] private Text stateLabel;

        private bool clicked;
        private int clickCount;

        public string ProviderId => "quickstart";
        public string ActionId => "quickstart.reset";
        public string Description => "Reset the Quickstart product state before a test.";
        public bool IsProjectMutation => false;

        private void Awake()
        {
            clicked = false;
            clickCount = 0;
            RefreshPresentation();
        }

        private void OnEnable()
        {
            QuakRegistry.Register((IQuakStateProvider)this);
            QuakRegistry.Register((IQuakActionHandler)this);
            if (button != null)
                button.onClick.AddListener(HandleButtonClick);
        }

        private void OnDisable()
        {
            if (button != null)
                button.onClick.RemoveListener(HandleButtonClick);
            QuakRegistry.Unregister((IQuakStateProvider)this);
            QuakRegistry.Unregister((IQuakActionHandler)this);
        }

        public string CaptureStateJson()
        {
            return JsonUtility.ToJson(new Snapshot
            {
                ready = button != null,
                clicked = clicked,
                clickCount = clickCount
            });
        }

        public string Invoke(string argumentsJson)
        {
            clicked = false;
            clickCount = 0;
            RefreshPresentation();
            Debug.Log("[QUAK Quickstart] Fixture reset.");
            return CaptureStateJson();
        }

        private void HandleButtonClick()
        {
            clicked = !clicked;
            clickCount++;
            RefreshPresentation();
            Debug.Log($"[QUAK Quickstart] Button.onClick received; clicked={clicked}, clickCount={clickCount}.");
        }

        private void RefreshPresentation()
        {
            if (stateLabel != null)
            {
                stateLabel.text = clicked
                    ? $"Product state: CLICKED ({clickCount})"
                    : "Product state: waiting for a real click";
                stateLabel.color = clicked
                    ? new Color(0.37f, 1f, 0.62f, 1f)
                    : new Color(0.76f, 0.82f, 0.94f, 1f);
            }
        }

        [Serializable]
        private struct Snapshot
        {
            public bool ready;
            public bool clicked;
            public int clickCount;
        }
    }
}
