using System;
using UnityEngine;
using XRDevRob.QUAK;

namespace XRDevRob.QUAK.Samples
{
    /// <summary>
    /// Production-shaped example only: connect these fields to your real router
    /// and player. Operator should still perform the UI interaction being tested.
    /// </summary>
    [AddComponentMenu("QUAK/Samples/Media Kiosk Adapter")]
    public sealed class MediaKioskQuakAdapter : MonoBehaviour, IQuakStateProvider
    {
        [SerializeField] private string route = "catalog";
        [SerializeField] private string selectedContentId = "demo-001";
        [SerializeField] private bool playing;
        [SerializeField] private bool muted;
        [SerializeField] private float playbackSeconds;

        private DelegateAction prepareAction;
        private DelegateAction resetAction;

        public string ProviderId => "media-kiosk";

        private void OnEnable()
        {
            prepareAction = new DelegateAction(
                "fixture.media-kiosk",
                "Loads deterministic in-memory demo content.",
                PrepareFixture);
            resetAction = new DelegateAction(
                "reset.media-kiosk",
                "Resets the in-memory demo route and playback facts.",
                _ => ResetFixture());
            QuakRegistry.Register(this);
            QuakRegistry.Register(prepareAction);
            QuakRegistry.Register(resetAction);
        }

        private void OnDisable()
        {
            QuakRegistry.Unregister(this);
            QuakRegistry.Unregister(prepareAction);
            QuakRegistry.Unregister(resetAction);
        }

        public string CaptureStateJson()
        {
            return JsonUtility.ToJson(new State
            {
                route = route,
                selectedContentId = selectedContentId,
                playing = playing,
                muted = muted,
                playbackSeconds = playbackSeconds
            });
        }

        // Wire real product events to methods like these. Do not have QUAK press
        // the UI by calling them directly.
        public void ProductReportedPlaying(bool value) => playing = value;
        public void ProductReportedMuted(bool value) => muted = value;
        public void ProductReportedPlaybackTime(float value) => playbackSeconds = value;

        private string PrepareFixture(string argumentsJson)
        {
            var input = JsonUtility.FromJson<FixtureInput>(argumentsJson);
            route = "catalog";
            selectedContentId = input == null || string.IsNullOrWhiteSpace(input.contentId)
                ? "demo-001"
                : input.contentId;
            playing = false;
            muted = false;
            playbackSeconds = 0f;
            return CaptureStateJson();
        }

        private string ResetFixture()
        {
            route = "catalog";
            selectedContentId = null;
            playing = false;
            muted = false;
            playbackSeconds = 0f;
            return CaptureStateJson();
        }

        [Serializable]
        private sealed class FixtureInput
        {
            public string contentId;
        }

        [Serializable]
        private sealed class State
        {
            public string route;
            public string selectedContentId;
            public bool playing;
            public bool muted;
            public float playbackSeconds;
        }

        private sealed class DelegateAction : IQuakActionHandler
        {
            private readonly Func<string, string> callback;

            public DelegateAction(string id, string description, Func<string, string> callback)
            {
                ActionId = id;
                Description = description;
                this.callback = callback;
            }

            public string ActionId { get; }
            public string Description { get; }
            public bool IsProjectMutation => false;
            public string Invoke(string argumentsJson) => callback(argumentsJson);
        }
    }
}
