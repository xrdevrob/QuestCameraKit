using System;
using UnityEngine;

namespace XRDevRob.QUAK.Samples.BlockAssemblyLab
{
    /// <summary>A deterministic connection point for exactly one matching piece.</summary>
    [DisallowMultipleComponent]
    public sealed class QuakBlockLabSocket : MonoBehaviour
    {
        private const int ClickSampleRate = 48000;
        private const float ClickDurationSeconds = 0.075f;

        private static AudioClip placementClickClip;

        [SerializeField] private string socketId;
        [SerializeField] private string requiredBlockId;
        [SerializeField] private Transform snapPoint;
        [SerializeField, Min(0.01f)] private float snapRadius = 0.18f;
        [SerializeField, Range(1f, 89f)] private float snapAngleToleranceDegrees = 30f;
        [SerializeField, Min(0.01f)] private float hoverRadius = 0.22f;
        [SerializeField] private QuakBlockLabVisual guideVisual;
        [SerializeField] private AudioSource placementAudioSource;

        private Transform guideTransform;
        private Vector3 guideRestScale = Vector3.one;
        private bool guidePoseCaptured;

        public string SocketId => socketId;
        public string RequiredBlockId => requiredBlockId;
        public QuakBlockLabBlock OccupiedBlock { get; private set; }
        public Vector3 SnapPosition => snapPoint != null ? snapPoint.position : transform.position;
        public Quaternion SnapRotation => snapPoint != null ? snapPoint.rotation : transform.rotation;
        public float SnapRadius => snapRadius;
        public float SnapAngleToleranceDegrees => snapAngleToleranceDegrees;
        public bool IsHovered { get; private set; }
        public bool IsSnapReady { get; private set; }
        public float PreviewDistanceMetres { get; private set; } = float.PositiveInfinity;
        public float PreviewAngleDegrees { get; private set; } = 180f;
        public int PlacementClickCount { get; private set; }

        private void Awake()
        {
            ResolveFeedbackReferences();
        }

        internal float DistanceTo(QuakBlockLabBlock block)
        {
            return block == null
                ? float.PositiveInfinity
                : Vector3.Distance(SnapPosition, block.transform.position);
        }

        internal float AngleTo(QuakBlockLabBlock block)
        {
            return block == null
                ? 180f
                : Quaternion.Angle(SnapRotation, block.transform.rotation);
        }

        internal bool CanSnap(QuakBlockLabBlock block, out string failure)
        {
            if (block == null)
            {
                failure = "missing-block";
                return false;
            }
            if (OccupiedBlock == block && block.CurrentSocket == this)
            {
                failure = $"already-connected:{block.BlockId}->{socketId}";
                return false;
            }
            if (DistanceTo(block) > snapRadius)
            {
                failure = "outside-snap-radius";
                return false;
            }
            if (!string.Equals(block.BlockId, requiredBlockId, StringComparison.Ordinal))
            {
                failure = $"wrong-connection:{block.BlockId}->{socketId}";
                return false;
            }
            if (OccupiedBlock != null && OccupiedBlock != block)
            {
                failure = $"connection-occupied:{socketId}";
                return false;
            }

            var angle = AngleTo(block);
            if (angle > snapAngleToleranceDegrees)
            {
                failure = $"outside-snap-angle:{block.BlockId}:{angle:0.#}deg";
                return false;
            }

            failure = string.Empty;
            return true;
        }

        internal bool TrySnap(QuakBlockLabBlock block, out string failure)
        {
            if (!CanSnap(block, out failure))
                return false;

            OccupiedBlock = block;
            block.SnapTo(this);
            PlacementClickCount++;
            PlayPlacementClick();
            failure = string.Empty;
            return true;
        }

        internal void UpdatePlacementFeedback(QuakBlockLabBlock block, float time)
        {
            ResolveFeedbackReferences();
            PreviewDistanceMetres = DistanceTo(block);
            PreviewAngleDegrees = AngleTo(block);
            var matches = block != null &&
                          string.Equals(
                              block.BlockId,
                              requiredBlockId,
                              StringComparison.Ordinal) &&
                          OccupiedBlock == null;
            IsHovered = matches && PreviewDistanceMetres <= Mathf.Max(hoverRadius, snapRadius);
            IsSnapReady = matches && CanSnap(block, out _);

            var proximity = IsHovered
                ? 1f - Mathf.InverseLerp(
                    snapRadius,
                    Mathf.Max(hoverRadius, snapRadius + 0.001f),
                    PreviewDistanceMetres)
                : 0f;
            var pulse = 0.5f + 0.5f * Mathf.Sin(time * Mathf.PI * 4f);
            var highlight = IsSnapReady
                ? Mathf.Lerp(0.72f, 1f, pulse)
                : proximity * 0.38f;
            guideVisual?.SetHighlight(highlight);
            if (guideTransform != null && guidePoseCaptured)
            {
                var scaleAmount = IsSnapReady
                    ? Mathf.Lerp(0.055f, 0.085f, pulse)
                    : proximity * 0.025f;
                guideTransform.localScale = guideRestScale * (1f + scaleAmount);
            }
        }

        internal void ClearPlacementFeedback()
        {
            IsHovered = false;
            IsSnapReady = false;
            PreviewDistanceMetres = float.PositiveInfinity;
            PreviewAngleDegrees = 180f;
            guideVisual?.SetHighlight(0f);
            if (guideTransform != null && guidePoseCaptured)
                guideTransform.localScale = guideRestScale;
        }

        internal void Release(QuakBlockLabBlock block)
        {
            if (OccupiedBlock == block)
                OccupiedBlock = null;
        }

        internal void ResetSocket()
        {
            OccupiedBlock = null;
            PlacementClickCount = 0;
            ClearPlacementFeedback();
        }

        private void ResolveFeedbackReferences()
        {
            if (guideVisual == null)
                guideVisual = GetComponentInChildren<QuakBlockLabVisual>(true);
            if (guideVisual != null && guideTransform == null)
                guideTransform = guideVisual.transform;
            if (guideTransform != null && !guidePoseCaptured)
            {
                guideRestScale = guideTransform.localScale;
                guidePoseCaptured = true;
            }

            if (placementAudioSource == null)
                placementAudioSource = GetComponent<AudioSource>();
            if (placementAudioSource != null)
                return;
            placementAudioSource = gameObject.AddComponent<AudioSource>();
            placementAudioSource.playOnAwake = false;
            placementAudioSource.spatialBlend = 1f;
            placementAudioSource.volume = 0.72f;
            placementAudioSource.dopplerLevel = 0f;
            placementAudioSource.minDistance = 0.2f;
            placementAudioSource.maxDistance = 3f;
            placementAudioSource.rolloffMode = AudioRolloffMode.Linear;
        }

        private void PlayPlacementClick()
        {
            ResolveFeedbackReferences();
            if (placementAudioSource == null)
                return;
            placementAudioSource.PlayOneShot(GetPlacementClickClip());
        }

        private static AudioClip GetPlacementClickClip()
        {
            if (placementClickClip != null)
                return placementClickClip;

            var sampleCount = Mathf.CeilToInt(ClickSampleRate * ClickDurationSeconds);
            var samples = new float[sampleCount];
            for (var index = 0; index < sampleCount; index++)
            {
                var time = index / (float)ClickSampleRate;
                var attack = Mathf.Clamp01(time / 0.002f);
                var envelope = attack * Mathf.Exp(-52f * time);
                var body = Mathf.Sin(2f * Mathf.PI * 920f * time);
                var tick = Mathf.Sin(2f * Mathf.PI * 1680f * time);
                samples[index] = envelope * (body * 0.34f + tick * 0.16f);
            }

            placementClickClip = AudioClip.Create(
                "QUAK Block Placement Click",
                sampleCount,
                1,
                ClickSampleRate,
                false);
            placementClickClip.SetData(samples, 0);
            return placementClickClip;
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            socketId = socketId?.Trim();
            requiredBlockId = requiredBlockId?.Trim();
            snapRadius = Mathf.Max(0.01f, snapRadius);
            snapAngleToleranceDegrees = Mathf.Clamp(snapAngleToleranceDegrees, 1f, 89f);
            hoverRadius = Mathf.Max(snapRadius, hoverRadius);
        }
#endif
    }
}
