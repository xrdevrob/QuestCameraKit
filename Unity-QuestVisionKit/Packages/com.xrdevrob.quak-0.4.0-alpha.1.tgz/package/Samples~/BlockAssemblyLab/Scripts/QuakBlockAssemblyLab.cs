using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace XRDevRob.QUAK.Samples.BlockAssemblyLab
{
    /// <summary>
    /// Owns the Block Lab's game rules and exposes their result independently
    /// from the controller-input tool that attempted the interaction.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class QuakBlockAssemblyLab : MonoBehaviour,
        IQuakStateProvider,
        IQuakActionHandler
    {
        [SerializeField] private QuakBlockLabBlock[] blocks = Array.Empty<QuakBlockLabBlock>();
        [SerializeField] private QuakBlockLabSocket[] sockets = Array.Empty<QuakBlockLabSocket>();
        [SerializeField] private QuakBlockLabRuntimeTemplate runtimeTemplate;
        [SerializeField] private QuakBlockLabGrabber grabber;
        [SerializeField] private Slider boardSizeSlider;
        [SerializeField] private Button decreaseSizeButton;
        [SerializeField] private Button increaseSizeButton;
        [SerializeField] private Button newPuzzleButton;
        [SerializeField] private Button resetButton;
        [SerializeField] private Button validateButton;
        [SerializeField] private Text boardSizeLabel;
        [SerializeField] private Text statusLabel;

        private int selectedBoardSize = QuakBlockLabRuntimeTemplate.DefaultBoardSize;
        private int sizeSelectionCount;
        private int puzzleGenerationCount;
        private string heldPieceId = string.Empty;
        private int validationCount;
        private string validationResult = "not-run";
        private string validationMessage = "Assemble all five pieces in the square.";
        private string lastEvent = "ready";
        private string lastFailure = string.Empty;
        private string placementFeedbackState = string.Empty;

        public string ProviderId => "block-lab";
        public string ActionId => "block-lab.reset";
        public string Description => "Reset the current Block Assembly Lab puzzle without changing its seed.";
        public bool IsProjectMutation => false;
        public IReadOnlyList<QuakBlockLabBlock> Blocks => blocks;

        private void Awake()
        {
            selectedBoardSize = runtimeTemplate != null && runtimeTemplate.BoardSize > 0
                ? runtimeTemplate.BoardSize
                : QuakBlockLabRuntimeTemplate.DefaultBoardSize;
            boardSizeSlider?.SetValueWithoutNotify(selectedBoardSize);
            ResetLab();
        }

        private void OnEnable()
        {
            QuakRegistry.Register((IQuakStateProvider)this);
            QuakRegistry.Register((IQuakActionHandler)this);
            if (boardSizeSlider != null)
                boardSizeSlider.onValueChanged.AddListener(PreviewBoardSize);
            if (decreaseSizeButton != null)
                decreaseSizeButton.onClick.AddListener(DecreaseBoardSize);
            if (increaseSizeButton != null)
                increaseSizeButton.onClick.AddListener(IncreaseBoardSize);
            if (newPuzzleButton != null)
                newPuzzleButton.onClick.AddListener(GenerateNewPuzzle);
            if (resetButton != null)
                resetButton.onClick.AddListener(ResetLab);
            if (validateButton != null)
                validateButton.onClick.AddListener(ValidateAssembly);
            RefreshPresentation();
        }

        private void OnDisable()
        {
            ClearPlacementFeedback();
            if (boardSizeSlider != null)
                boardSizeSlider.onValueChanged.RemoveListener(PreviewBoardSize);
            if (decreaseSizeButton != null)
                decreaseSizeButton.onClick.RemoveListener(DecreaseBoardSize);
            if (increaseSizeButton != null)
                increaseSizeButton.onClick.RemoveListener(IncreaseBoardSize);
            if (newPuzzleButton != null)
                newPuzzleButton.onClick.RemoveListener(GenerateNewPuzzle);
            if (resetButton != null)
                resetButton.onClick.RemoveListener(ResetLab);
            if (validateButton != null)
                validateButton.onClick.RemoveListener(ValidateAssembly);
            QuakRegistry.Unregister((IQuakStateProvider)this);
            QuakRegistry.Unregister((IQuakActionHandler)this);
        }

        public string CaptureStateJson()
        {
            var previewSocket = sockets
                .Where(socket => socket != null && socket.IsHovered)
                .OrderByDescending(socket => socket.IsSnapReady)
                .ThenBy(socket => socket.PreviewDistanceMetres)
                .FirstOrDefault();
            return JsonUtility.ToJson(new Snapshot
            {
                ready = IsReady(),
                heldPieceId = grabber != null ? grabber.HeldPieceId : heldPieceId,
                placedCount = SnappedCount(),
                coralConnected = IsSnapped("coral"),
                azureConnected = IsSnapped("azure"),
                goldConnected = IsSnapped("gold"),
                mintConnected = IsSnapped("mint"),
                violetConnected = IsSnapped("violet"),
                shapeComplete = IsAssemblyComplete(),
                validationResult = validationResult,
                validationCount = validationCount,
                missingPieceCount = Mathf.Max(0, sockets.Length - SnappedCount()),
                snapCandidateId = previewSocket != null
                    ? previewSocket.RequiredBlockId
                    : string.Empty,
                snapReady = previewSocket != null && previewSocket.IsSnapReady,
                snapDistanceMetres = previewSocket != null
                    ? previewSocket.PreviewDistanceMetres
                    : -1f,
                snapAngleDegrees = previewSocket != null
                    ? previewSocket.PreviewAngleDegrees
                    : -1f,
                placementClickCount = sockets.Sum(socket =>
                    socket != null ? socket.PlacementClickCount : 0),
                boardSize = runtimeTemplate != null ? runtimeTemplate.BoardSize : 0,
                selectedBoardSize = selectedBoardSize,
                sizeSelectionCount = sizeSelectionCount,
                puzzleGenerationCount = puzzleGenerationCount,
                difficulty = runtimeTemplate != null
                    ? runtimeTemplate.Difficulty
                    : string.Empty,
                pieceCount = runtimeTemplate != null ? runtimeTemplate.PieceCount : 0,
                coveredCellCount = runtimeTemplate != null
                    ? runtimeTemplate.CoveredCellCount
                    : 0,
                expectedCellCount = runtimeTemplate != null
                    ? runtimeTemplate.ExpectedCellCount
                    : 0,
                pieceAreas = runtimeTemplate != null
                    ? runtimeTemplate.PieceAreas.ToArray()
                    : Array.Empty<int>(),
                templateSeed = runtimeTemplate != null ? runtimeTemplate.TemplateSeed : 0,
                templateSignature = runtimeTemplate != null
                    ? runtimeTemplate.TemplateSignature
                    : string.Empty,
                templateConnected = runtimeTemplate != null &&
                    runtimeTemplate.TemplateConnected,
                templateNonOverlapping = runtimeTemplate != null &&
                    runtimeTemplate.TemplateNonOverlapping,
                templateWithinWorkspace = runtimeTemplate != null &&
                    runtimeTemplate.TemplateWithinWorkspace,
                templateWithinReach = runtimeTemplate != null &&
                    runtimeTemplate.TemplateWithinReach,
                boardPhysicalSizeMetres =
                    QuakBlockLabRuntimeTemplate.BoardPhysicalSizeMetres,
                reachEnvelopeMaximumHorizontalDistanceMetres =
                    QuakBlockLabRuntimeTemplate
                        .ReachEnvelopeMaximumHorizontalDistanceMetres,
                reachEnvelopeMinimumHeightMetres =
                    QuakBlockLabRuntimeTemplate.ReachEnvelopeMinimumHeightMetres,
                reachEnvelopeMaximumHeightMetres =
                    QuakBlockLabRuntimeTemplate.ReachEnvelopeMaximumHeightMetres,
                templateTargetsSeparated = runtimeTemplate != null &&
                    runtimeTemplate.TemplateTargetsSeparated,
                templateSquare = runtimeTemplate != null &&
                    runtimeTemplate.TemplateSquare,
                templateCoverageComplete = runtimeTemplate != null &&
                    runtimeTemplate.TemplateCoverageComplete,
                templatePiecesConnected = runtimeTemplate != null &&
                    runtimeTemplate.TemplatePiecesConnected,
                templatePiecesUnique = runtimeTemplate != null &&
                    runtimeTemplate.TemplatePiecesUnique,
                templatePiecesStaged = runtimeTemplate != null &&
                    runtimeTemplate.TemplatePiecesStaged,
                templateUsedFallback = runtimeTemplate != null &&
                    runtimeTemplate.TemplateUsedFallback,
                templateGenerationAttempts = runtimeTemplate != null
                    ? runtimeTemplate.TemplateGenerationAttempts
                    : 0,
                generationRevision = runtimeTemplate != null
                    ? runtimeTemplate.GenerationRevision
                    : 0,
                templateError = runtimeTemplate != null
                    ? runtimeTemplate.TemplateError
                    : "missing-runtime-template",
                inputPoseReady = grabber != null && grabber.InputPoseReady,
                inputPointerWorldPosition = grabber != null
                    ? grabber.PointerWorldPosition
                    : default,
                inputPointerWorldRotation = grabber != null
                    ? grabber.PointerWorldRotation
                    : Quaternion.identity,
                inputGripValue = grabber != null ? grabber.GripValue : 0f,
                inputGripPressed = grabber != null && grabber.GripPressed,
                inputPositionControlCount = grabber != null
                    ? grabber.PositionControlCount
                    : 0,
                inputRotationControlCount = grabber != null
                    ? grabber.RotationControlCount
                    : 0,
                inputGripControlCount = grabber != null ? grabber.GripControlCount : 0,
                inputPositionControlPath = grabber != null
                    ? grabber.PositionControlPath
                    : string.Empty,
                inputRotationControlPath = grabber != null
                    ? grabber.RotationControlPath
                    : string.Empty,
                inputGripControlPath = grabber != null
                    ? grabber.GripControlPath
                    : string.Empty,
                lastEvent = lastEvent,
                lastFailure = lastFailure
            });
        }

        public string Invoke(string argumentsJson)
        {
            ResetLab();
            Debug.Log("[QUAK Block Lab] Current puzzle reset through block-lab.reset.");
            return CaptureStateJson();
        }

        internal void NotifyBlockGrabbed(QuakBlockLabBlock block)
        {
            ClearPlacementFeedback();
            heldPieceId = block != null ? block.BlockId : string.Empty;
            lastEvent = $"grabbed:{heldPieceId}";
            lastFailure = string.Empty;
            validationMessage = $"Holding {heldPieceId}.";
            RefreshPresentation();
            Debug.Log($"[QUAK Block Lab] {lastEvent}");
        }

        internal void NotifyGrabMiss()
        {
            lastEvent = "grip:no-piece-in-range";
            lastFailure = "no-piece-in-range";
            validationMessage = "Grip was pressed, but no piece was in range.";
            RefreshPresentation();
            Debug.LogWarning($"[QUAK Block Lab] {lastEvent}");
        }

        internal bool NotifyBlockMoved(QuakBlockLabBlock block)
        {
            QuakBlockLabSocket hovered = null;
            QuakBlockLabSocket ready = null;
            foreach (var socket in sockets)
            {
                if (socket == null)
                    continue;
                socket.UpdatePlacementFeedback(block, Time.unscaledTime);
                if (socket.IsSnapReady)
                    ready = socket;
                else if (hovered == null && socket.IsHovered)
                    hovered = socket;
            }

            var nextState = ready != null
                ? $"ready:{block.BlockId}"
                : hovered != null
                    ? $"align:{block.BlockId}"
                    : $"holding:{block.BlockId}";
            if (!string.Equals(
                    placementFeedbackState,
                    nextState,
                    StringComparison.Ordinal))
            {
                placementFeedbackState = nextState;
                if (ready != null)
                {
                    validationMessage = $"Release to place {block.BlockId}.";
                    lastEvent = $"placement-ready:{block.BlockId}";
                }
                else if (hovered != null)
                {
                    validationMessage =
                        $"Rotate {block.BlockId} until its guide pulses, then release.";
                    lastEvent = $"placement-align:{block.BlockId}";
                }
                else
                {
                    validationMessage =
                        $"Move {block.BlockId} over its matching guide.";
                    lastEvent = $"holding:{block.BlockId}";
                }
                RefreshPresentation();
            }
            return ready != null;
        }

        internal void ClearPlacementFeedback()
        {
            foreach (var socket in sockets)
                socket?.ClearPlacementFeedback();
            placementFeedbackState = string.Empty;
        }

        internal void NotifyBlockReleased(QuakBlockLabBlock block)
        {
            heldPieceId = string.Empty;
            if (block == null)
                return;

            var nearest = sockets
                .Where(socket => socket != null)
                .OrderBy(socket => socket.DistanceTo(block))
                .FirstOrDefault();
            if (nearest == null)
            {
                lastEvent = $"released:{block.BlockId}:no-connection";
                lastFailure = "no-connection-in-range";
                validationMessage = $"{block.BlockId} was released outside its destination.";
            }
            else if (nearest.TrySnap(block, out var failure))
            {
                lastEvent = $"connected:{block.BlockId}";
                lastFailure = string.Empty;
                validationMessage = IsAssemblyComplete()
                    ? "Square complete. Press Validate."
                    : $"Placed {block.BlockId} ({SnappedCount()}/{sockets.Length}).";
            }
            else
            {
                lastEvent = failure;
                lastFailure = failure;
                if (string.Equals(
                        failure,
                        "outside-snap-radius",
                        StringComparison.Ordinal))
                {
                    validationMessage =
                        $"{block.BlockId} was released outside its destination.";
                }
                else if (failure.StartsWith(
                             "outside-snap-angle:",
                             StringComparison.Ordinal))
                {
                    validationMessage =
                        $"Rotate {block.BlockId} until its guide pulses, then release.";
                }
                else
                {
                    validationMessage = $"Could not place {block.BlockId}: {failure}.";
                }
            }

            ClearPlacementFeedback();
            RefreshPresentation();
            Debug.Log($"[QUAK Block Lab] {lastEvent}");
        }

        private void PreviewBoardSize(float value)
        {
            selectedBoardSize = Mathf.Clamp(
                Mathf.RoundToInt(value),
                QuakBlockLabRuntimeTemplate.MinimumBoardSize,
                QuakBlockLabRuntimeTemplate.MaximumBoardSize);
            if (boardSizeSlider != null &&
                !Mathf.Approximately(boardSizeSlider.value, selectedBoardSize))
            {
                boardSizeSlider.SetValueWithoutNotify(selectedBoardSize);
            }
            RefreshBoardSizePresentation();
        }

        private void DecreaseBoardSize()
        {
            SetSelectedBoardSize(selectedBoardSize - 1);
        }

        private void IncreaseBoardSize()
        {
            SetSelectedBoardSize(selectedBoardSize + 1);
        }

        private void SetSelectedBoardSize(int value)
        {
            sizeSelectionCount++;
            selectedBoardSize = Mathf.Clamp(
                value,
                QuakBlockLabRuntimeTemplate.MinimumBoardSize,
                QuakBlockLabRuntimeTemplate.MaximumBoardSize);
            boardSizeSlider?.SetValueWithoutNotify(selectedBoardSize);
            lastEvent = $"size-selected:{selectedBoardSize}";
            RefreshBoardSizePresentation();
        }

        private void GenerateNewPuzzle()
        {
            puzzleGenerationCount++;
            CancelAndClearPieces();
            if (runtimeTemplate == null ||
                !runtimeTemplate.GenerateNewTemplate(selectedBoardSize))
            {
                validationResult = "generation-failed";
                validationMessage = runtimeTemplate != null
                    ? $"Could not generate square: {runtimeTemplate.TemplateError}"
                    : "Could not generate square: runtime template is missing.";
                lastEvent = "puzzle-generation-failed";
                lastFailure = runtimeTemplate != null
                    ? runtimeTemplate.TemplateError
                    : "missing-runtime-template";
                RefreshPresentation();
                return;
            }

            ResetAttemptState(
                $"New {runtimeTemplate.BoardSize}×{runtimeTemplate.BoardSize} " +
                $"{runtimeTemplate.Difficulty} puzzle. Place all five pieces.",
                $"puzzle-generated:{runtimeTemplate.BoardSize}x{runtimeTemplate.BoardSize}");
            Debug.Log(
                $"[QUAK Block Lab] Generated a new {runtimeTemplate.BoardSize}x" +
                $"{runtimeTemplate.BoardSize} puzzle from the world-space UI.");
        }

        private void ResetLab()
        {
            sizeSelectionCount = 0;
            puzzleGenerationCount = 0;
            CancelAndClearPieces();
            var size = runtimeTemplate != null && runtimeTemplate.BoardSize > 0
                ? runtimeTemplate.BoardSize
                : selectedBoardSize;
            ResetAttemptState(
                $"Place all five pieces in the {size}×{size} square.",
                "reset");
        }

        private void CancelAndClearPieces()
        {
            grabber?.CancelGrab(false);
            ClearPlacementFeedback();
            foreach (var socket in sockets)
                socket?.ResetSocket();
            foreach (var block in blocks)
                block?.ResetBlock();
        }

        private void ResetAttemptState(string message, string eventName)
        {
            heldPieceId = string.Empty;
            validationCount = 0;
            validationResult = "not-run";
            validationMessage = message;
            lastEvent = eventName;
            lastFailure = string.Empty;
            RefreshPresentation();
        }

        private void ValidateAssembly()
        {
            validationCount++;
            if (IsAssemblyComplete())
            {
                validationResult = "passed";
                validationMessage = $"{runtimeTemplate.BoardSize}×{runtimeTemplate.BoardSize} square complete.";
                lastEvent = "validated:complete";
                lastFailure = string.Empty;
            }
            else
            {
                validationResult = "failed";
                validationMessage =
                    $"Square incomplete: {SnappedCount()}/{sockets.Length} pieces placed.";
                lastEvent = "validated:incomplete";
                lastFailure = "shape-incomplete";
            }
            RefreshPresentation();
            Debug.Log($"[QUAK Block Lab] {lastEvent}");
        }

        private bool IsReady()
        {
            return blocks.Length == 5 && sockets.Length == 5 &&
                   runtimeTemplate != null && runtimeTemplate.HasTemplate &&
                   grabber != null && boardSizeSlider != null &&
                   decreaseSizeButton != null && increaseSizeButton != null &&
                   newPuzzleButton != null && resetButton != null &&
                   validateButton != null && boardSizeLabel != null &&
                   statusLabel != null &&
                   blocks.All(block => block != null &&
                       !string.IsNullOrWhiteSpace(block.BlockId)) &&
                   sockets.All(socket => socket != null &&
                       !string.IsNullOrWhiteSpace(socket.SocketId) &&
                       !string.IsNullOrWhiteSpace(socket.RequiredBlockId));
        }

        private int SnappedCount()
        {
            return sockets.Count(socket => socket != null && socket.OccupiedBlock != null);
        }

        private bool IsAssemblyComplete()
        {
            return sockets.Length > 0 && sockets.All(socket =>
                socket != null && socket.OccupiedBlock != null &&
                string.Equals(
                    socket.OccupiedBlock.BlockId,
                    socket.RequiredBlockId,
                    StringComparison.Ordinal));
        }

        private bool IsSnapped(string requiredBlockId)
        {
            var socket = sockets.FirstOrDefault(item =>
                item != null && string.Equals(
                    item.RequiredBlockId,
                    requiredBlockId,
                    StringComparison.Ordinal));
            return socket != null && socket.OccupiedBlock != null &&
                   string.Equals(
                       socket.OccupiedBlock.BlockId,
                       requiredBlockId,
                       StringComparison.Ordinal);
        }

        private void RefreshPresentation()
        {
            RefreshBoardSizePresentation();
            if (statusLabel == null)
                return;
            statusLabel.text = validationMessage;
            statusLabel.color = IsAssemblyComplete()
                ? new Color(0.37f, 1f, 0.62f, 1f)
                : new Color(0.78f, 0.84f, 0.95f, 1f);
        }

        private void RefreshBoardSizePresentation()
        {
            if (boardSizeLabel == null)
                return;
            var difficulty = QuakBlockLabRuntimeTemplate
                .GetDifficultyName(selectedBoardSize)
                .ToUpperInvariant();
            var pending = runtimeTemplate != null &&
                          runtimeTemplate.BoardSize > 0 &&
                          selectedBoardSize != runtimeTemplate.BoardSize
                ? " · PRESS NEW PUZZLE"
                : string.Empty;
            boardSizeLabel.text =
                $"BOARD SIZE  {selectedBoardSize} × {selectedBoardSize}  ·  {difficulty}{pending}";
        }

        [Serializable]
        private struct Snapshot
        {
            public bool ready;
            public string heldPieceId;
            public int placedCount;
            public bool coralConnected;
            public bool azureConnected;
            public bool goldConnected;
            public bool mintConnected;
            public bool violetConnected;
            public bool shapeComplete;
            public string validationResult;
            public int validationCount;
            public int missingPieceCount;
            public string snapCandidateId;
            public bool snapReady;
            public float snapDistanceMetres;
            public float snapAngleDegrees;
            public int placementClickCount;
            public int boardSize;
            public int selectedBoardSize;
            public int sizeSelectionCount;
            public int puzzleGenerationCount;
            public string difficulty;
            public int pieceCount;
            public int coveredCellCount;
            public int expectedCellCount;
            public int[] pieceAreas;
            public int templateSeed;
            public string templateSignature;
            public bool templateConnected;
            public bool templateNonOverlapping;
            public bool templateWithinWorkspace;
            public bool templateWithinReach;
            public float boardPhysicalSizeMetres;
            public float reachEnvelopeMaximumHorizontalDistanceMetres;
            public float reachEnvelopeMinimumHeightMetres;
            public float reachEnvelopeMaximumHeightMetres;
            public bool templateTargetsSeparated;
            public bool templateSquare;
            public bool templateCoverageComplete;
            public bool templatePiecesConnected;
            public bool templatePiecesUnique;
            public bool templatePiecesStaged;
            public bool templateUsedFallback;
            public int templateGenerationAttempts;
            public int generationRevision;
            public string templateError;
            public bool inputPoseReady;
            public Vector3 inputPointerWorldPosition;
            public Quaternion inputPointerWorldRotation;
            public float inputGripValue;
            public bool inputGripPressed;
            public int inputPositionControlCount;
            public int inputRotationControlCount;
            public int inputGripControlCount;
            public string inputPositionControlPath;
            public string inputRotationControlPath;
            public string inputGripControlPath;
            public string lastEvent;
            public string lastFailure;
        }
    }
}
