using UnityEngine;

namespace XRDevRob.QUAK.Samples.BlockAssemblyLab
{
    /// <summary>A movable assembly piece whose state is owned by the sample app.</summary>
    [DisallowMultipleComponent]
    public sealed class QuakBlockLabBlock : MonoBehaviour
    {
        [SerializeField] private string blockId;
        [SerializeField] private Rigidbody body;

        private Transform startParent;
        private Vector3 startPosition;
        private Quaternion startRotation;
        private QuakBlockLabSocket currentSocket;
        private bool startPoseCaptured;

        public string BlockId => blockId;
        public bool IsHeld { get; private set; }
        public QuakBlockLabSocket CurrentSocket => currentSocket;

        private void Awake()
        {
            CaptureStartPose();
            if (body == null)
                body = GetComponent<Rigidbody>();
            SetBodyKinematic(true);
        }

        internal void BeginGrab()
        {
            currentSocket?.Release(this);
            currentSocket = null;
            IsHeld = true;
            SetBodyKinematic(true);
        }

        internal void SetHeldPose(Vector3 position, Quaternion rotation)
        {
            if (!IsHeld)
                return;
            transform.SetPositionAndRotation(position, rotation);
        }

        internal void EndGrab()
        {
            IsHeld = false;
            SetBodyKinematic(true);
        }

        internal void SnapTo(QuakBlockLabSocket socket)
        {
            currentSocket?.Release(this);
            currentSocket = socket;
            IsHeld = false;
            SetBodyKinematic(true);
            transform.SetPositionAndRotation(socket.SnapPosition, socket.SnapRotation);
        }

        internal void ResetBlock()
        {
            CaptureStartPose();
            currentSocket?.Release(this);
            currentSocket = null;
            IsHeld = false;
            transform.SetParent(startParent, true);
            transform.SetPositionAndRotation(startPosition, startRotation);
            SetBodyKinematic(true);
        }

        internal void SetRuntimeHomePose(Vector3 position, Quaternion rotation)
        {
            currentSocket?.Release(this);
            currentSocket = null;
            IsHeld = false;
            startParent = transform.parent;
            startPosition = position;
            startRotation = rotation;
            startPoseCaptured = true;
            transform.SetParent(startParent, true);
            transform.SetPositionAndRotation(startPosition, startRotation);
            SetBodyKinematic(true);
        }

        private void CaptureStartPose()
        {
            if (startPoseCaptured)
                return;
            startParent = transform.parent;
            startPosition = transform.position;
            startRotation = transform.rotation;
            startPoseCaptured = true;
        }

        private void SetBodyKinematic(bool value)
        {
            if (body == null)
                return;
            body.isKinematic = value;
            body.useGravity = false;
            body.Sleep();
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            blockId = blockId?.Trim();
            if (body == null)
                body = GetComponent<Rigidbody>();
        }
#endif
    }
}
