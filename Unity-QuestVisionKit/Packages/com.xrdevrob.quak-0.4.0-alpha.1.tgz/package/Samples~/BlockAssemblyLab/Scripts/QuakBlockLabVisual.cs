using UnityEngine;

namespace XRDevRob.QUAK.Samples.BlockAssemblyLab
{
    /// <summary>Pipeline-independent sample coloring without material assets.</summary>
    [ExecuteAlways]
    [DisallowMultipleComponent]
    public sealed class QuakBlockLabVisual : MonoBehaviour
    {
        private static readonly int BaseColor = Shader.PropertyToID("_BaseColor");
        private static readonly int ColorProperty = Shader.PropertyToID("_Color");

        [SerializeField] private Color color = Color.white;
        [SerializeField] private Renderer[] renderers;

        private float highlight;

        private void OnEnable()
        {
            highlight = 0f;
            Apply();
        }

        /// <summary>
        /// Applies a reversible, material-independent highlight. A property
        /// block keeps this safe for shared and built-in materials.
        /// </summary>
        internal void SetHighlight(float value)
        {
            var clamped = Mathf.Clamp01(value);
            if (Mathf.Approximately(highlight, clamped))
                return;
            highlight = clamped;
            Apply();
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            Apply();
        }
#endif

        private void Apply()
        {
            if (renderers == null || renderers.Length == 0)
                renderers = GetComponentsInChildren<Renderer>(true);

            var visibleColor = Color.Lerp(
                color,
                new Color(0.78f, 1f, 0.94f, color.a),
                highlight);
            var properties = new MaterialPropertyBlock();
            foreach (var targetRenderer in renderers)
            {
                if (targetRenderer == null)
                    continue;
                targetRenderer.GetPropertyBlock(properties);
                properties.SetColor(BaseColor, visibleColor);
                properties.SetColor(ColorProperty, visibleColor);
                targetRenderer.SetPropertyBlock(properties);
                properties.Clear();
            }
        }
    }
}
