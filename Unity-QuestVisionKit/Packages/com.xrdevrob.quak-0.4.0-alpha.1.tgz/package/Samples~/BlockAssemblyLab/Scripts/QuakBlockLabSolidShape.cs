using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace XRDevRob.QUAK.Samples.BlockAssemblyLab
{
    /// <summary>
    /// Builds one continuous block mesh from a set of grid cells. Internal
    /// faces are omitted so a piece reads as one silhouette rather than as a
    /// collection of cubes.
    /// </summary>
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
    public sealed class QuakBlockLabSolidShape : MonoBehaviour
    {
        [SerializeField] private Vector2[] cells = { Vector2.zero };
        [SerializeField, Min(0.01f)] private float cellSize = 0.10f;
        [SerializeField, Min(0.005f)] private float height = 0.10f;
        [SerializeField] private MeshCollider meshCollider;

        private Mesh generatedMesh;

        public IReadOnlyList<Vector2> Cells => cells ?? Array.Empty<Vector2>();
        public float CellSize => cellSize;

        private void OnEnable()
        {
            Rebuild();
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            cellSize = Mathf.Max(0.01f, cellSize);
            height = Mathf.Max(0.005f, height);
            Rebuild();
        }
#endif

        private void OnDestroy()
        {
            ReleaseGeneratedMesh();
        }

        public void Rebuild()
        {
            var meshFilter = GetComponent<MeshFilter>();
            if (meshFilter == null)
                return;

            ReleaseGeneratedMesh();
            var occupied = new HashSet<Vector2>(cells ?? new Vector2[0]);
            if (occupied.Count == 0)
                occupied.Add(Vector2.zero);

            var vertices = new List<Vector3>();
            var triangles = new List<int>();
            foreach (var cell in occupied.OrderBy(value => value.y).ThenBy(value => value.x))
                AddCellGeometry(cell, occupied, vertices, triangles);

            generatedMesh = new Mesh
            {
                name = $"{name} Solid Shape",
                hideFlags = HideFlags.DontSave
            };
            generatedMesh.SetVertices(vertices);
            generatedMesh.SetTriangles(triangles, 0);
            generatedMesh.RecalculateNormals();
            generatedMesh.RecalculateBounds();
            meshFilter.sharedMesh = generatedMesh;

            if (meshCollider != null)
            {
                meshCollider.sharedMesh = null;
                meshCollider.sharedMesh = generatedMesh;
            }
        }

        public void SetCells(IEnumerable<Vector2> newCells)
        {
            cells = newCells == null
                ? Array.Empty<Vector2>()
                : newCells.Distinct().ToArray();
            Rebuild();
        }

        public void SetGeometry(IEnumerable<Vector2> newCells, float newCellSize)
        {
            cells = newCells == null
                ? Array.Empty<Vector2>()
                : newCells.Distinct().ToArray();
            cellSize = Mathf.Max(0.01f, newCellSize);
            Rebuild();
        }

        private void AddCellGeometry(
            Vector2 cell,
            ISet<Vector2> occupied,
            ICollection<Vector3> vertices,
            ICollection<int> triangles)
        {
            var halfCell = cellSize * 0.5f;
            var halfHeight = height * 0.5f;
            var centerX = cell.x * cellSize;
            var centerZ = cell.y * cellSize;
            var minX = centerX - halfCell;
            var maxX = centerX + halfCell;
            var minZ = centerZ - halfCell;
            var maxZ = centerZ + halfCell;

            AddQuad(
                new Vector3(minX, halfHeight, minZ),
                new Vector3(minX, halfHeight, maxZ),
                new Vector3(maxX, halfHeight, maxZ),
                new Vector3(maxX, halfHeight, minZ),
                vertices,
                triangles);
            AddQuad(
                new Vector3(minX, -halfHeight, minZ),
                new Vector3(maxX, -halfHeight, minZ),
                new Vector3(maxX, -halfHeight, maxZ),
                new Vector3(minX, -halfHeight, maxZ),
                vertices,
                triangles);

            if (!occupied.Contains(cell + Vector2.left))
            {
                AddQuad(
                    new Vector3(minX, -halfHeight, minZ),
                    new Vector3(minX, -halfHeight, maxZ),
                    new Vector3(minX, halfHeight, maxZ),
                    new Vector3(minX, halfHeight, minZ),
                    vertices,
                    triangles);
            }
            if (!occupied.Contains(cell + Vector2.right))
            {
                AddQuad(
                    new Vector3(maxX, -halfHeight, minZ),
                    new Vector3(maxX, halfHeight, minZ),
                    new Vector3(maxX, halfHeight, maxZ),
                    new Vector3(maxX, -halfHeight, maxZ),
                    vertices,
                    triangles);
            }
            if (!occupied.Contains(cell + Vector2.down))
            {
                AddQuad(
                    new Vector3(minX, -halfHeight, minZ),
                    new Vector3(minX, halfHeight, minZ),
                    new Vector3(maxX, halfHeight, minZ),
                    new Vector3(maxX, -halfHeight, minZ),
                    vertices,
                    triangles);
            }
            if (!occupied.Contains(cell + Vector2.up))
            {
                AddQuad(
                    new Vector3(minX, -halfHeight, maxZ),
                    new Vector3(maxX, -halfHeight, maxZ),
                    new Vector3(maxX, halfHeight, maxZ),
                    new Vector3(minX, halfHeight, maxZ),
                    vertices,
                    triangles);
            }
        }

        private static void AddQuad(
            Vector3 a,
            Vector3 b,
            Vector3 c,
            Vector3 d,
            ICollection<Vector3> vertices,
            ICollection<int> triangles)
        {
            var start = vertices.Count;
            vertices.Add(a);
            vertices.Add(b);
            vertices.Add(c);
            vertices.Add(d);
            triangles.Add(start);
            triangles.Add(start + 1);
            triangles.Add(start + 2);
            triangles.Add(start);
            triangles.Add(start + 2);
            triangles.Add(start + 3);
        }

        private void ReleaseGeneratedMesh()
        {
            if (generatedMesh == null)
                return;
            var meshFilter = GetComponent<MeshFilter>();
            if (meshFilter != null && meshFilter.sharedMesh == generatedMesh)
                meshFilter.sharedMesh = null;
            if (meshCollider != null && meshCollider.sharedMesh == generatedMesh)
                meshCollider.sharedMesh = null;

            if (Application.isPlaying)
                Destroy(generatedMesh);
            else
                DestroyImmediate(generatedMesh);
            generatedMesh = null;
        }
    }
}
