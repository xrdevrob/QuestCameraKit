using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace XRDevRob.QUAK.Samples.BlockAssemblyLab
{
    /// <summary>
    /// Creates a seeded square-packing puzzle at runtime. The five piece IDs
    /// remain stable while their connected shapes, home poses, and color-
    /// matched destination guides change with the board size and seed.
    /// </summary>
    [DefaultExecutionOrder(-1000)]
    [DisallowMultipleComponent]
    public sealed class QuakBlockLabRuntimeTemplate : MonoBehaviour
    {
        public const int MinimumBoardSize = 4;
        public const int MaximumBoardSize = 6;
        public const int DefaultBoardSize = 5;

        private const int RequiredPieceCount = 5;
        private const int MaximumGenerationAttempts = 12;
        private const int MaximumSearchNodes = 30000;
        public const float BoardPhysicalSizeMetres = 0.30f;
        public const float ReachEnvelopeMaximumHorizontalDistanceMetres = 0.92f;
        public const float ReachEnvelopeMinimumHeightMetres = 0.70f;
        public const float ReachEnvelopeMaximumHeightMetres = 1.30f;

        private const float MinimumSocketSeparationMetres = 0.045f;
        private const float HomePosePaddingMetres = 0.010f;
        private const float SquareGuideVerticalOffsetMetres = -0.022f;
        private const float WorkbenchMinimumX = -0.515f;
        private const float WorkbenchMaximumX = 0.515f;
        private const float WorkbenchMinimumZ = 0.055f;
        private const float TrayMaximumZ = 0.535f;
        private const float WorkbenchMaximumZ = 0.925f;

        private static readonly Vector2Int[] CardinalDirections =
        {
            Vector2Int.left,
            Vector2Int.right,
            Vector2Int.down,
            Vector2Int.up
        };

        private static readonly string[][] FallbackRows =
        {
            null,
            null,
            null,
            null,
            new[]
            {
                "DEEE",
                "DDCC",
                "ABBC",
                "ABBC"
            },
            new[]
            {
                "DDDEE",
                "DCEEB",
                "DCCEB",
                "AACCB",
                "AAABB"
            },
            new[]
            {
                "EEEEEE",
                "DDDDDE",
                "CCCDBB",
                "CCCDBB",
                "CAAABB",
                "AAAABB"
            }
        };

        [SerializeField] private QuakBlockLabBlock[] blocks =
            Array.Empty<QuakBlockLabBlock>();
        [SerializeField] private QuakBlockLabSocket[] sockets =
            Array.Empty<QuakBlockLabSocket>();
        [SerializeField] private QuakBlockLabSolidShape guideShape;
        [SerializeField] private QuakBlockLabSolidShape[] targetGuideShapes =
            Array.Empty<QuakBlockLabSolidShape>();
        [SerializeField] private Vector3[] pieceHomeCenters =
            Array.Empty<Vector3>();
        [SerializeField] private Vector3 assemblyOrigin =
            new Vector3(0.15f, 0.815f, 0.69f);
        [SerializeField, Range(MinimumBoardSize, MaximumBoardSize)]
        private int initialBoardSize = DefaultBoardSize;

        public int BoardSize { get; private set; }
        public string Difficulty => GetDifficultyName(BoardSize);
        public int PieceCount => RequiredPieceCount;
        public int ExpectedCellCount => BoardSize * BoardSize;
        public int CoveredCellCount { get; private set; }
        public IReadOnlyList<int> PieceAreas => pieceAreas;
        public int TemplateSeed { get; private set; }
        public string TemplateSignature { get; private set; } = string.Empty;
        public bool TemplateConnected { get; private set; }
        public bool TemplateNonOverlapping { get; private set; }
        public bool TemplateWithinWorkspace { get; private set; }
        public bool TemplateWithinReach { get; private set; }
        public bool TemplateTargetsSeparated { get; private set; }
        public bool TemplateSquare { get; private set; }
        public bool TemplateCoverageComplete { get; private set; }
        public bool TemplatePiecesConnected { get; private set; }
        public bool TemplatePiecesUnique { get; private set; }
        public bool TemplatePiecesStaged { get; private set; }
        public bool TemplateUsedFallback { get; private set; }
        public int TemplateGenerationAttempts { get; private set; }
        public int GenerationRevision { get; private set; }
        public string TemplateError { get; private set; } = string.Empty;
        public bool HasTemplate =>
            BoardSize >= MinimumBoardSize &&
            BoardSize <= MaximumBoardSize &&
            TemplateSeed > 0 &&
            !string.IsNullOrWhiteSpace(TemplateSignature) &&
            TemplateConnected &&
            TemplateNonOverlapping &&
            TemplateWithinWorkspace &&
            TemplateWithinReach &&
            TemplateTargetsSeparated &&
            TemplateSquare &&
            TemplateCoverageComplete &&
            TemplatePiecesConnected &&
            TemplatePiecesUnique &&
            TemplatePiecesStaged &&
            string.IsNullOrEmpty(TemplateError);

        private int[] pieceAreas = Array.Empty<int>();

        private void Awake()
        {
            GenerateTemplate(
                Mathf.Clamp(initialBoardSize, MinimumBoardSize, MaximumBoardSize),
                CreateRuntimeSeed());
        }

        public bool GenerateNewTemplate(int boardSize)
        {
            return GenerateTemplate(boardSize, CreateRuntimeSeed());
        }

        public bool GenerateTemplate(int seed)
        {
            var size = BoardSize >= MinimumBoardSize && BoardSize <= MaximumBoardSize
                ? BoardSize
                : Mathf.Clamp(initialBoardSize, MinimumBoardSize, MaximumBoardSize);
            return GenerateTemplate(size, seed);
        }

        /// <summary>
        /// Builds and validates a complete puzzle before applying any live
        /// transforms or meshes. A positive seed reproduces the same square
        /// across Editor, Mono, and IL2CPP because generation uses a local
        /// fixed xorshift PRNG.
        /// </summary>
        public bool GenerateTemplate(int boardSize, int seed)
        {
            if (boardSize < MinimumBoardSize || boardSize > MaximumBoardSize)
            {
                return FailGeneration(
                    $"Board size must be between {MinimumBoardSize} and {MaximumBoardSize}.");
            }
            if (seed <= 0)
                return FailGeneration("A template seed must be positive.");
            if (!TryReadPieceSources(out var sources, out var error))
                return FailGeneration(error);

            if (!TryCreatePuzzle(
                    boardSize,
                    seed,
                    out var regions,
                    out var attemptCount,
                    out var usedFallback,
                    out error))
            {
                TemplateGenerationAttempts = attemptCount;
                return FailGeneration(error);
            }

            var random = new StableRandom(DeriveSeed(seed, boardSize, attemptCount + 101));
            var cellSize = BoardPhysicalSizeMetres / boardSize;
            var layoutsReady = TryCreateLayoutsForAnyAssignment(
                    boardSize,
                    cellSize,
                    sources,
                    regions,
                    ref random,
                    out var layouts,
                    out var stagingAttempts,
                    out error);
            if (!layoutsReady && !usedFallback)
            {
                var fallbackRandom = new StableRandom(DeriveSeed(
                    seed,
                    boardSize,
                    MaximumGenerationAttempts + 1001));
                var fallbackRegions = CreateFallbackRegions(
                    boardSize,
                    fallbackRandom.Next(0, 8));
                layoutsReady = TryCreateLayoutsForAnyAssignment(
                    boardSize,
                    cellSize,
                    sources,
                    fallbackRegions,
                    ref fallbackRandom,
                    out layouts,
                    out var fallbackStagingAttempts,
                    out error);
                if (layoutsReady)
                {
                    regions = fallbackRegions;
                    stagingAttempts += fallbackStagingAttempts;
                    usedFallback = true;
                }
            }
            if (!layoutsReady)
            {
                TemplateGenerationAttempts = attemptCount;
                return FailGeneration(error);
            }

            EvaluateValidity(
                boardSize,
                cellSize,
                regions,
                layouts,
                out var coveredCount,
                out var connected,
                out var nonOverlapping,
                out var withinWorkspace,
                out var withinReach,
                out var targetsSeparated,
                out var square,
                out var coverageComplete,
                out var piecesConnected,
                out var piecesUnique,
                out var piecesStaged);
            if (!connected ||
                !nonOverlapping ||
                !withinWorkspace ||
                !withinReach ||
                !targetsSeparated ||
                !square ||
                !coverageComplete ||
                !piecesConnected ||
                !piecesUnique ||
                !piecesStaged)
            {
                TemplateGenerationAttempts = attemptCount;
                return FailGeneration("Generated square failed its runtime validity checks.");
            }

            var squareCells = CreateSquareGuideCells(boardSize);
            guideShape.transform.position = assemblyOrigin +
                new Vector3(0f, SquareGuideVerticalOffsetMetres, 0f);
            guideShape.SetGeometry(squareCells, cellSize);
            foreach (var layout in layouts)
            {
                layout.Source.Shape.SetGeometry(layout.LocalCells, cellSize);
                layout.Source.TargetGuide.SetGeometry(layout.LocalCells, cellSize);
                layout.Source.Socket.transform.SetPositionAndRotation(
                    layout.SocketPosition,
                    Quaternion.identity);
                layout.Source.Block.SetRuntimeHomePose(
                    layout.HomePosition,
                    layout.HomeRotation);
            }

            BoardSize = boardSize;
            CoveredCellCount = coveredCount;
            pieceAreas = layouts.Select(layout => layout.BoardCells.Length).ToArray();
            TemplateSeed = seed;
            TemplateSignature = CreateSignature(boardSize, layouts);
            TemplateConnected = connected;
            TemplateNonOverlapping = nonOverlapping;
            TemplateWithinWorkspace = withinWorkspace;
            TemplateWithinReach = withinReach;
            TemplateTargetsSeparated = targetsSeparated;
            TemplateSquare = square;
            TemplateCoverageComplete = coverageComplete;
            TemplatePiecesConnected = piecesConnected;
            TemplatePiecesUnique = piecesUnique;
            TemplatePiecesStaged = piecesStaged;
            TemplateUsedFallback = usedFallback;
            TemplateGenerationAttempts = attemptCount;
            TemplateError = string.Empty;
            GenerationRevision++;

            Debug.Log(
                $"[QUAK Block Lab] Generated {BoardSize}x{BoardSize} square " +
                $"seed={TemplateSeed} signature={TemplateSignature} " +
                $"attempts={TemplateGenerationAttempts} " +
                $"stagingAssignments={stagingAttempts} " +
                $"fallback={TemplateUsedFallback}.",
                this);
            return true;
        }

        /// <summary>Pure generator check used by Editor validation and stress tests.</summary>
        public static bool ValidatePuzzleSeed(int boardSize, int seed)
        {
            if (!TryCreatePuzzle(
                    boardSize,
                    seed,
                    out var regions,
                    out _,
                    out _,
                    out _))
            {
                return false;
            }

            return ValidateRegions(boardSize, regions, out _, out _, out _, out _);
        }

        public static string CreatePuzzleSignature(int boardSize, int seed)
        {
            if (!TryCreatePuzzle(
                    boardSize,
                    seed,
                    out var regions,
                    out _,
                    out _,
                    out _))
            {
                return string.Empty;
            }

            var description = new StringBuilder().Append(boardSize).Append('|');
            foreach (var region in regions
                         .Select(value => string.Join(
                             ";",
                             value.OrderBy(cell => cell.y)
                                 .ThenBy(cell => cell.x)
                                 .Select(cell => $"{cell.x},{cell.y}")))
                         .OrderBy(value => value, StringComparer.Ordinal))
            {
                description.Append(region).Append('|');
            }
            return $"v2:{HashDescription(description.ToString()):x16}";
        }

        public static string GetDifficultyName(int boardSize)
        {
            switch (boardSize)
            {
                case 4:
                    return "easy";
                case 6:
                    return "hard";
                default:
                    return "medium";
            }
        }

        private bool TryReadPieceSources(out PieceSource[] sources, out string error)
        {
            sources = Array.Empty<PieceSource>();
            error = string.Empty;
            if (guideShape == null)
            {
                error = "Missing square guide shape.";
                return false;
            }
            if (!IsFinite(assemblyOrigin))
            {
                error = "Assembly origin is not finite.";
                return false;
            }
            if (blocks == null ||
                sockets == null ||
                targetGuideShapes == null ||
                pieceHomeCenters == null ||
                blocks.Length != RequiredPieceCount ||
                sockets.Length != RequiredPieceCount ||
                targetGuideShapes.Length != RequiredPieceCount ||
                pieceHomeCenters.Length != RequiredPieceCount)
            {
                error = "Expected five pieces, connections, destination guides, and home poses.";
                return false;
            }

            var blockIds = new HashSet<string>(StringComparer.Ordinal);
            var socketIds = new HashSet<string>(StringComparer.Ordinal);
            var requiredIds = new HashSet<string>(StringComparer.Ordinal);
            foreach (var socket in sockets)
            {
                if (socket == null ||
                    string.IsNullOrWhiteSpace(socket.SocketId) ||
                    string.IsNullOrWhiteSpace(socket.RequiredBlockId) ||
                    !socketIds.Add(socket.SocketId) ||
                    !requiredIds.Add(socket.RequiredBlockId))
                {
                    error = "Connection IDs must be present and unique.";
                    return false;
                }
            }

            var result = new List<PieceSource>(RequiredPieceCount);
            for (var index = 0; index < RequiredPieceCount; index++)
            {
                var block = blocks[index];
                if (block == null ||
                    string.IsNullOrWhiteSpace(block.BlockId) ||
                    !blockIds.Add(block.BlockId))
                {
                    error = $"Piece {index} is missing a unique ID.";
                    return false;
                }

                var shape = block.GetComponent<QuakBlockLabSolidShape>();
                var targetGuide = targetGuideShapes[index];
                if (shape == null || targetGuide == null)
                {
                    error = $"Piece {block.BlockId} is missing a runtime or destination shape.";
                    return false;
                }
                if (!IsFinite(pieceHomeCenters[index]))
                {
                    error = $"Home pose for {block.BlockId} is not finite.";
                    return false;
                }

                var matchingSockets = sockets.Where(candidate =>
                    candidate != null && string.Equals(
                        candidate.RequiredBlockId,
                        block.BlockId,
                        StringComparison.Ordinal)).ToArray();
                if (matchingSockets.Length != 1)
                {
                    error = $"Piece {block.BlockId} needs exactly one matching connection.";
                    return false;
                }

                result.Add(new PieceSource(
                    block.BlockId,
                    block,
                    shape,
                    matchingSockets[0],
                    targetGuide,
                    pieceHomeCenters[index]));
            }

            if (!blockIds.SetEquals(requiredIds))
            {
                error = "Piece and required connection IDs do not match.";
                return false;
            }

            sources = result.ToArray();
            return true;
        }

        private static bool TryCreatePuzzle(
            int boardSize,
            int seed,
            out List<Vector2Int[]> regions,
            out int attemptCount,
            out bool usedFallback,
            out string error)
        {
            regions = new List<Vector2Int[]>();
            attemptCount = 0;
            usedFallback = false;
            error = string.Empty;
            if (boardSize < MinimumBoardSize ||
                boardSize > MaximumBoardSize ||
                seed <= 0)
            {
                error = "Puzzle size or seed is outside its supported range.";
                return false;
            }

            var profile = GetAreaProfile(boardSize);
            var fullMask = (1UL << (boardSize * boardSize)) - 1UL;
            for (var attempt = 1; attempt <= MaximumGenerationAttempts; attempt++)
            {
                attemptCount = attempt;
                var random = new StableRandom(DeriveSeed(seed, boardSize, attempt));
                var selectedMasks = new List<ulong>(RequiredPieceCount);
                var usedShapeKeys = new HashSet<string>(StringComparer.Ordinal);
                var search = new SearchContext(MaximumSearchNodes);
                if (!TrySolvePartition(
                        boardSize,
                        fullMask,
                        profile.ToList(),
                        selectedMasks,
                        usedShapeKeys,
                        search,
                        ref random))
                {
                    continue;
                }

                regions = selectedMasks
                    .Select(mask => CellsFromMask(mask, boardSize))
                    .ToList();
                var transform = random.Next(0, 8);
                regions = regions
                    .Select(region => TransformBoardRegion(region, boardSize, transform))
                    .ToList();
                if (ValidateRegions(boardSize, regions, out _, out _, out _, out _))
                    return true;
            }

            attemptCount = MaximumGenerationAttempts + 1;
            var fallbackRandom = new StableRandom(
                DeriveSeed(seed, boardSize, MaximumGenerationAttempts + 1));
            regions = CreateFallbackRegions(boardSize, fallbackRandom.Next(0, 8));
            if (!ValidateRegions(boardSize, regions, out _, out _, out _, out _))
            {
                error = "The curated square fallback failed validation.";
                return false;
            }

            usedFallback = true;
            return true;
        }

        private static bool TrySolvePartition(
            int boardSize,
            ulong freeMask,
            List<int> remainingAreas,
            List<ulong> selectedMasks,
            ISet<string> usedShapeKeys,
            SearchContext search,
            ref StableRandom random)
        {
            if (!search.TryVisitNode())
                return false;
            if (remainingAreas.Count == 0)
                return freeMask == 0UL;
            if (freeMask == 0UL)
                return false;

            var anchor = FirstSetBit(freeMask, boardSize * boardSize);
            var randomizedAreas = new List<RandomizedValue>();
            foreach (var value in remainingAreas.Distinct().OrderBy(value => value))
            {
                randomizedAreas.Add(new RandomizedValue(
                    value,
                    random.Next(0, 1000000)));
            }
            var areaOptions = randomizedAreas
                .OrderBy(value => value.RandomOrder)
                .ThenByDescending(value => value.Value)
                .ToArray();
            foreach (var areaOption in areaOptions)
            {
                var area = areaOption.Value;
                var candidateMasks = GenerateConnectedMasks(
                        boardSize,
                        anchor,
                        area,
                        freeMask)
                    .OrderBy(mask => mask)
                    .ToArray();
                var candidates = new List<RegionCandidate>(candidateMasks.Length);
                foreach (var candidateMask in candidateMasks)
                {
                    var cells = CellsFromMask(candidateMask, boardSize);
                    var shapeKey = CreateCanonicalShapeKey(cells);
                    if (usedShapeKeys.Contains(shapeKey))
                        continue;
                    var bounds = CalculateBounds(cells);
                    var compactness = bounds.Area * 5 + CalculatePerimeter(cells);
                    candidates.Add(new RegionCandidate(
                        candidateMask,
                        shapeKey,
                        compactness * 32 + random.Next(0, 320)));
                }

                candidates.Sort(RegionCandidate.Compare);
                var nextAreas = remainingAreas.ToList();
                nextAreas.Remove(area);
                foreach (var candidate in candidates)
                {
                    var nextFree = freeMask & ~candidate.Mask;
                    if (!CanComposeConnectedComponents(nextFree, nextAreas, boardSize))
                        continue;

                    selectedMasks.Add(candidate.Mask);
                    usedShapeKeys.Add(candidate.ShapeKey);
                    if (TrySolvePartition(
                            boardSize,
                            nextFree,
                            nextAreas,
                            selectedMasks,
                            usedShapeKeys,
                            search,
                            ref random))
                    {
                        return true;
                    }
                    usedShapeKeys.Remove(candidate.ShapeKey);
                    selectedMasks.RemoveAt(selectedMasks.Count - 1);
                }
            }

            return false;
        }

        private static IEnumerable<ulong> GenerateConnectedMasks(
            int boardSize,
            int anchor,
            int targetArea,
            ulong freeMask)
        {
            var current = new HashSet<ulong> { 1UL << anchor };
            for (var size = 1; size < targetArea; size++)
            {
                var next = new HashSet<ulong>();
                foreach (var mask in current.OrderBy(value => value))
                {
                    for (var index = 0; index < boardSize * boardSize; index++)
                    {
                        var bit = 1UL << index;
                        if ((mask & bit) == 0UL)
                            continue;
                        var x = index % boardSize;
                        var y = index / boardSize;
                        foreach (var direction in CardinalDirections)
                        {
                            var neighbourX = x + direction.x;
                            var neighbourY = y + direction.y;
                            if (neighbourX < 0 || neighbourY < 0 ||
                                neighbourX >= boardSize || neighbourY >= boardSize)
                            {
                                continue;
                            }
                            var neighbourBit = 1UL <<
                                (neighbourY * boardSize + neighbourX);
                            if ((freeMask & neighbourBit) == 0UL ||
                                (mask & neighbourBit) != 0UL)
                            {
                                continue;
                            }
                            next.Add(mask | neighbourBit);
                        }
                    }
                }
                current = next;
                if (current.Count == 0)
                    break;
            }
            return current;
        }

        private static bool CanComposeConnectedComponents(
            ulong mask,
            IReadOnlyList<int> remainingAreas,
            int boardSize)
        {
            if (mask == 0UL)
                return remainingAreas.Count == 0;
            var componentSizes = GetComponentSizes(mask, boardSize)
                .OrderByDescending(value => value)
                .ToArray();
            if (componentSizes.Length > remainingAreas.Count)
                return false;
            var capacities = componentSizes.ToArray();
            var areas = remainingAreas.OrderByDescending(value => value).ToArray();
            return TryAssignAreasToComponents(areas, 0, capacities);
        }

        private static bool TryAssignAreasToComponents(
            IReadOnlyList<int> areas,
            int areaIndex,
            int[] capacities)
        {
            if (areaIndex >= areas.Count)
                return capacities.All(value => value == 0);
            var area = areas[areaIndex];
            var triedCapacities = new HashSet<int>();
            for (var index = 0; index < capacities.Length; index++)
            {
                if (capacities[index] < area || !triedCapacities.Add(capacities[index]))
                    continue;
                capacities[index] -= area;
                if (TryAssignAreasToComponents(areas, areaIndex + 1, capacities))
                    return true;
                capacities[index] += area;
            }
            return false;
        }

        private static IEnumerable<int> GetComponentSizes(ulong mask, int boardSize)
        {
            var unseen = mask;
            while (unseen != 0UL)
            {
                var first = FirstSetBit(unseen, boardSize * boardSize);
                var pending = new Queue<int>();
                pending.Enqueue(first);
                unseen &= ~(1UL << first);
                var size = 0;
                while (pending.Count > 0)
                {
                    var index = pending.Dequeue();
                    size++;
                    var x = index % boardSize;
                    var y = index / boardSize;
                    foreach (var direction in CardinalDirections)
                    {
                        var neighbourX = x + direction.x;
                        var neighbourY = y + direction.y;
                        if (neighbourX < 0 || neighbourY < 0 ||
                            neighbourX >= boardSize || neighbourY >= boardSize)
                        {
                            continue;
                        }
                        var neighbourIndex = neighbourY * boardSize + neighbourX;
                        var neighbourBit = 1UL << neighbourIndex;
                        if ((unseen & neighbourBit) == 0UL)
                            continue;
                        unseen &= ~neighbourBit;
                        pending.Enqueue(neighbourIndex);
                    }
                }
                yield return size;
            }
        }

        private bool TryCreateLayoutsForAnyAssignment(
            int boardSize,
            float cellSize,
            IReadOnlyList<PieceSource> sources,
            IReadOnlyList<Vector2Int[]> regions,
            ref StableRandom random,
            out List<PieceLayout> layouts,
            out int attemptCount,
            out string error)
        {
            layouts = new List<PieceLayout>();
            attemptCount = 0;
            error = string.Empty;
            var assignmentOrders = CreateAssignmentOrders(RequiredPieceCount);
            Shuffle(assignmentOrders, ref random);
            foreach (var order in assignmentOrders)
            {
                attemptCount++;
                var assignedRegions = order
                    .Select(index => regions[index])
                    .ToArray();
                if (TryCreateLayouts(
                        boardSize,
                        cellSize,
                        sources,
                        assignedRegions,
                        ref random,
                        out layouts,
                        out error))
                {
                    return true;
                }
            }

            error = "The generated pieces could not be staged in any color assignment.";
            return false;
        }

        private static List<int[]> CreateAssignmentOrders(int count)
        {
            var result = new List<int[]>();
            BuildAssignmentOrders(
                count,
                0,
                new int[count],
                new bool[count],
                result);
            return result;
        }

        private static void BuildAssignmentOrders(
            int count,
            int depth,
            int[] current,
            bool[] used,
            ICollection<int[]> result)
        {
            if (depth >= count)
            {
                result.Add((int[])current.Clone());
                return;
            }

            for (var value = 0; value < count; value++)
            {
                if (used[value])
                    continue;
                used[value] = true;
                current[depth] = value;
                BuildAssignmentOrders(count, depth + 1, current, used, result);
                used[value] = false;
            }
        }

        private bool TryCreateLayouts(
            int boardSize,
            float cellSize,
            IReadOnlyList<PieceSource> sources,
            IReadOnlyList<Vector2Int[]> regions,
            ref StableRandom random,
            out List<PieceLayout> layouts,
            out string error)
        {
            layouts = new List<PieceLayout>(RequiredPieceCount);
            error = string.Empty;
            var boardCenter = (boardSize - 1) * 0.5f;
            for (var index = 0; index < RequiredPieceCount; index++)
            {
                var source = sources[index];
                var boardCells = regions[index]
                    .OrderBy(cell => cell.y)
                    .ThenBy(cell => cell.x)
                    .ToArray();
                var anchor = SelectAnchorCell(boardCells);
                var localCells = boardCells
                    .Select(cell => new Vector2(cell.x - anchor.x, cell.y - anchor.y))
                    .ToArray();
                var socketPosition = assemblyOrigin + new Vector3(
                    (anchor.x - boardCenter) * cellSize,
                    0f,
                    (anchor.y - boardCenter) * cellSize);
                if (!IsFinite(socketPosition))
                {
                    error = $"Connection pose for {source.Id} is not finite.";
                    return false;
                }
                layouts.Add(new PieceLayout(
                    source,
                    boardCells,
                    localCells,
                    anchor,
                    socketPosition));
            }

            if (!TryAssignHomePoses(layouts, cellSize, ref random))
            {
                error = "The generated pieces could not be staged without overlap.";
                return false;
            }
            return true;
        }

        private static bool TryAssignHomePoses(
            IList<PieceLayout> layouts,
            float cellSize,
            ref StableRandom random)
        {
            var choicesByLayout = new List<HomePoseChoice>[layouts.Count];
            for (var layoutIndex = 0; layoutIndex < layouts.Count; layoutIndex++)
            {
                var layout = layouts[layoutIndex];
                var choices = new List<HomePoseChoice>(4);
                for (var quarterTurns = 0; quarterTurns < 4; quarterTurns++)
                {
                    var rotatedCells = layout.LocalCells
                        .Select(cell => Rotate(cell, quarterTurns))
                        .ToArray();
                    var bounds = CalculateBounds(rotatedCells);
                    var width = bounds.Width * cellSize;
                    var depth = bounds.Height * cellSize;
                    var center = new Vector2(
                        (bounds.MinX + bounds.MaxX) * 0.5f,
                        (bounds.MinY + bounds.MaxY) * 0.5f);
                    var position = layout.Source.HomeCenter - new Vector3(
                        center.x * cellSize,
                        0f,
                        center.y * cellSize);
                    var rectangle = new WorldRect(
                        layout.Source.HomeCenter.x - width * 0.5f,
                        layout.Source.HomeCenter.x + width * 0.5f,
                        layout.Source.HomeCenter.z - depth * 0.5f,
                        layout.Source.HomeCenter.z + depth * 0.5f);
                    var preference =
                        Mathf.RoundToInt(depth * 10000f) + random.Next(0, 250);
                    if (!rectangle.IsInside(
                            WorkbenchMinimumX,
                            WorkbenchMaximumX,
                            WorkbenchMinimumZ,
                            TrayMaximumZ,
                            HomePosePaddingMetres))
                    {
                        continue;
                    }
                    choices.Add(new HomePoseChoice(
                        quarterTurns,
                        position,
                        rectangle,
                        preference));
                }

                choices.Sort(HomePoseChoice.Compare);
                if (choices.Count == 0)
                    return false;
                choicesByLayout[layoutIndex] = choices;
            }

            var assignmentOrder = Enumerable.Range(0, layouts.Count)
                .OrderBy(index => choicesByLayout[index].Count)
                .ThenByDescending(index => layouts[index].LocalCells.Length)
                .ThenBy(index => index)
                .ToArray();
            return TryAssignHomePoses(
                layouts,
                choicesByLayout,
                assignmentOrder,
                0,
                new List<WorldRect>(layouts.Count));
        }

        private static bool TryAssignHomePoses(
            IList<PieceLayout> layouts,
            IReadOnlyList<List<HomePoseChoice>> choicesByLayout,
            IReadOnlyList<int> assignmentOrder,
            int assignmentIndex,
            IList<WorldRect> occupied)
        {
            if (assignmentIndex >= assignmentOrder.Count)
                return true;

            var layoutIndex = assignmentOrder[assignmentIndex];
            var layout = layouts[layoutIndex];
            foreach (var choice in choicesByLayout[layoutIndex])
            {
                if (occupied.Any(rectangle => rectangle.Overlaps(
                        choice.Rectangle,
                        HomePosePaddingMetres)))
                {
                    continue;
                }

                layout.HomePosition = choice.Position;
                layout.HomeRotation = Quaternion.Euler(
                    0f,
                    choice.QuarterTurns * 90f,
                    0f);
                layout.HomeRectangle = choice.Rectangle;
                occupied.Add(choice.Rectangle);
                if (TryAssignHomePoses(
                        layouts,
                        choicesByLayout,
                        assignmentOrder,
                        assignmentIndex + 1,
                        occupied))
                {
                    return true;
                }
                occupied.RemoveAt(occupied.Count - 1);
            }
            return false;
        }

        private void EvaluateValidity(
            int boardSize,
            float cellSize,
            IReadOnlyList<Vector2Int[]> regions,
            IReadOnlyList<PieceLayout> layouts,
            out int coveredCount,
            out bool connected,
            out bool nonOverlapping,
            out bool withinWorkspace,
            out bool withinReach,
            out bool targetsSeparated,
            out bool square,
            out bool coverageComplete,
            out bool piecesConnected,
            out bool piecesUnique,
            out bool piecesStaged)
        {
            ValidateRegions(
                boardSize,
                regions,
                out coveredCount,
                out nonOverlapping,
                out piecesConnected,
                out piecesUnique);
            var allCells = new HashSet<Vector2Int>(regions.SelectMany(region => region));
            connected = IsConnected(allCells);
            square = allCells.All(cell =>
                         cell.x >= 0 && cell.y >= 0 &&
                         cell.x < boardSize && cell.y < boardSize) &&
                     CalculateBounds(allCells).Width == boardSize &&
                     CalculateBounds(allCells).Height == boardSize;
            coverageComplete = coveredCount == boardSize * boardSize &&
                               nonOverlapping && square;
            var halfBoard = BoardPhysicalSizeMetres * 0.5f;
            withinWorkspace =
                assemblyOrigin.x - halfBoard >= WorkbenchMinimumX &&
                assemblyOrigin.x + halfBoard <= WorkbenchMaximumX &&
                assemblyOrigin.z - halfBoard >= TrayMaximumZ &&
                assemblyOrigin.z + halfBoard <= WorkbenchMaximumZ;
            var boardRectangle = new WorldRect(
                assemblyOrigin.x - halfBoard,
                assemblyOrigin.x + halfBoard,
                assemblyOrigin.z - halfBoard,
                assemblyOrigin.z + halfBoard);
            withinReach = IsReachableHeight(assemblyOrigin.y) &&
                          boardRectangle.IsInsideHorizontalRadius(
                              ReachEnvelopeMaximumHorizontalDistanceMetres,
                              0f) &&
                          layouts.All(layout =>
                              IsReachableHeight(layout.HomePosition.y) &&
                              layout.HomeRectangle.IsInsideHorizontalRadius(
                                  ReachEnvelopeMaximumHorizontalDistanceMetres,
                                  HomePosePaddingMetres));
            targetsSeparated = AreSocketPivotsSeparated(layouts, cellSize);
            piecesStaged = layouts.All(layout => layout.HomeRectangle.IsInside(
                WorkbenchMinimumX,
                WorkbenchMaximumX,
                WorkbenchMinimumZ,
                TrayMaximumZ,
                HomePosePaddingMetres));
            for (var left = 0; left < layouts.Count; left++)
            for (var right = left + 1; right < layouts.Count; right++)
            {
                if (layouts[left].HomeRectangle.Overlaps(
                        layouts[right].HomeRectangle,
                        HomePosePaddingMetres))
                {
                    piecesStaged = false;
                }
            }
        }

        private static bool ValidateRegions(
            int boardSize,
            IReadOnlyList<Vector2Int[]> regions,
            out int coveredCount,
            out bool nonOverlapping,
            out bool piecesConnected,
            out bool piecesUnique)
        {
            coveredCount = 0;
            nonOverlapping = false;
            piecesConnected = false;
            piecesUnique = false;
            if (regions == null || regions.Count != RequiredPieceCount)
                return false;
            var allCells = new HashSet<Vector2Int>();
            var totalCells = 0;
            var shapeKeys = new HashSet<string>(StringComparer.Ordinal);
            piecesConnected = true;
            foreach (var region in regions)
            {
                if (region == null || region.Length == 0 ||
                    region.Any(cell =>
                        cell.x < 0 || cell.y < 0 ||
                        cell.x >= boardSize || cell.y >= boardSize))
                {
                    piecesConnected = false;
                    continue;
                }
                totalCells += region.Length;
                foreach (var cell in region)
                    allCells.Add(cell);
                piecesConnected &= IsConnected(new HashSet<Vector2Int>(region));
                shapeKeys.Add(CreateCanonicalShapeKey(region));
            }
            coveredCount = allCells.Count;
            nonOverlapping = totalCells == coveredCount;
            piecesUnique = shapeKeys.Count == RequiredPieceCount;
            return nonOverlapping &&
                   piecesConnected &&
                   piecesUnique &&
                   coveredCount == boardSize * boardSize;
        }

        private static bool AreSocketPivotsSeparated(
            IReadOnlyList<PieceLayout> layouts,
            float cellSize)
        {
            var minimumSquared =
                MinimumSocketSeparationMetres * MinimumSocketSeparationMetres;
            for (var left = 0; left < layouts.Count; left++)
            for (var right = left + 1; right < layouts.Count; right++)
            {
                var delta = layouts[left].Anchor - layouts[right].Anchor;
                if (delta.sqrMagnitude * cellSize * cellSize + 0.000001f <
                    minimumSquared)
                {
                    return false;
                }
            }
            return true;
        }

        private static Vector2Int SelectAnchorCell(IReadOnlyList<Vector2Int> cells)
        {
            var centroid = new Vector2(
                (float)cells.Average(cell => cell.x),
                (float)cells.Average(cell => cell.y));
            return cells
                .OrderBy(cell => (new Vector2(cell.x, cell.y) - centroid).sqrMagnitude)
                .ThenBy(cell => cell.y)
                .ThenBy(cell => cell.x)
                .First();
        }

        private static List<Vector2Int[]> CreateFallbackRegions(
            int boardSize,
            int transform)
        {
            var rows = FallbackRows[boardSize];
            var regions = new List<Vector2Int[]>(RequiredPieceCount);
            for (var piece = 0; piece < RequiredPieceCount; piece++)
            {
                var label = (char)('A' + piece);
                var cells = new List<Vector2Int>();
                for (var row = 0; row < rows.Length; row++)
                for (var column = 0; column < rows[row].Length; column++)
                {
                    if (rows[row][column] == label)
                    {
                        cells.Add(new Vector2Int(
                            column,
                            boardSize - row - 1));
                    }
                }
                regions.Add(TransformBoardRegion(cells, boardSize, transform));
            }
            return regions;
        }

        private static Vector2Int[] TransformBoardRegion(
            IEnumerable<Vector2Int> cells,
            int boardSize,
            int transform)
        {
            return cells.Select(cell => TransformBoardCell(cell, boardSize, transform))
                .OrderBy(cell => cell.y)
                .ThenBy(cell => cell.x)
                .ToArray();
        }

        private static Vector2Int TransformBoardCell(
            Vector2Int cell,
            int boardSize,
            int transform)
        {
            var x = cell.x;
            var y = cell.y;
            if (transform >= 4)
                x = boardSize - x - 1;
            switch (transform & 3)
            {
                case 1:
                    return new Vector2Int(boardSize - y - 1, x);
                case 2:
                    return new Vector2Int(boardSize - x - 1, boardSize - y - 1);
                case 3:
                    return new Vector2Int(y, boardSize - x - 1);
                default:
                    return new Vector2Int(x, y);
            }
        }

        private static IReadOnlyList<int> GetAreaProfile(int boardSize)
        {
            switch (boardSize)
            {
                case 4:
                    return new[] { 2, 3, 3, 4, 4 };
                case 6:
                    return new[] { 7, 7, 7, 7, 8 };
                default:
                    return new[] { 5, 5, 5, 5, 5 };
            }
        }

        private static IEnumerable<Vector2> CreateSquareGuideCells(int boardSize)
        {
            var center = (boardSize - 1) * 0.5f;
            for (var y = 0; y < boardSize; y++)
            for (var x = 0; x < boardSize; x++)
                yield return new Vector2(x - center, y - center);
        }

        private static Vector2Int[] CellsFromMask(ulong mask, int boardSize)
        {
            var result = new List<Vector2Int>();
            for (var index = 0; index < boardSize * boardSize; index++)
            {
                if ((mask & (1UL << index)) != 0UL)
                    result.Add(new Vector2Int(index % boardSize, index / boardSize));
            }
            return result.ToArray();
        }

        private static int FirstSetBit(ulong mask, int limit)
        {
            for (var index = 0; index < limit; index++)
            {
                if ((mask & (1UL << index)) != 0UL)
                    return index;
            }
            return -1;
        }

        private static string CreateCanonicalShapeKey(IEnumerable<Vector2Int> cells)
        {
            var source = cells.ToArray();
            var variants = new List<string>(8);
            for (var reflection = 0; reflection < 2; reflection++)
            for (var quarterTurns = 0; quarterTurns < 4; quarterTurns++)
            {
                var transformed = source.Select(cell =>
                {
                    var value = reflection == 0
                        ? cell
                        : new Vector2Int(-cell.x, cell.y);
                    for (var turn = 0; turn < quarterTurns; turn++)
                        value = new Vector2Int(-value.y, value.x);
                    return value;
                }).ToArray();
                var minimumX = transformed.Min(cell => cell.x);
                var minimumY = transformed.Min(cell => cell.y);
                variants.Add(string.Join(
                    ";",
                    transformed
                        .Select(cell => new Vector2Int(
                            cell.x - minimumX,
                            cell.y - minimumY))
                        .OrderBy(cell => cell.y)
                        .ThenBy(cell => cell.x)
                        .Select(cell => $"{cell.x},{cell.y}")));
            }
            variants.Sort(StringComparer.Ordinal);
            return variants[0];
        }

        private static int CalculatePerimeter(IReadOnlyCollection<Vector2Int> cells)
        {
            var occupied = new HashSet<Vector2Int>(cells);
            var perimeter = 0;
            foreach (var cell in cells)
            foreach (var direction in CardinalDirections)
            {
                if (!occupied.Contains(cell + direction))
                    perimeter++;
            }
            return perimeter;
        }

        private static bool IsConnected(ISet<Vector2Int> cells)
        {
            if (cells == null || cells.Count == 0)
                return false;
            var visited = new HashSet<Vector2Int>();
            var pending = new Queue<Vector2Int>();
            var first = cells.OrderBy(cell => cell.y).ThenBy(cell => cell.x).First();
            visited.Add(first);
            pending.Enqueue(first);
            while (pending.Count > 0)
            {
                var cell = pending.Dequeue();
                foreach (var direction in CardinalDirections)
                {
                    var neighbour = cell + direction;
                    if (cells.Contains(neighbour) && visited.Add(neighbour))
                        pending.Enqueue(neighbour);
                }
            }
            return visited.Count == cells.Count;
        }

        private static GridBounds CalculateBounds(IEnumerable<Vector2Int> cells)
        {
            var values = cells as Vector2Int[] ?? cells.ToArray();
            return new GridBounds(
                values.Min(cell => cell.x),
                values.Max(cell => cell.x),
                values.Min(cell => cell.y),
                values.Max(cell => cell.y));
        }

        private static FloatBounds CalculateBounds(IEnumerable<Vector2> cells)
        {
            var values = cells as Vector2[] ?? cells.ToArray();
            return new FloatBounds(
                values.Min(cell => cell.x),
                values.Max(cell => cell.x),
                values.Min(cell => cell.y),
                values.Max(cell => cell.y));
        }

        private static Vector2 Rotate(Vector2 value, int quarterTurns)
        {
            switch (quarterTurns & 3)
            {
                case 1:
                    return new Vector2(value.y, -value.x);
                case 2:
                    return new Vector2(-value.x, -value.y);
                case 3:
                    return new Vector2(-value.y, value.x);
                default:
                    return value;
            }
        }

        private static string CreateSignature(
            int boardSize,
            IEnumerable<PieceLayout> layouts)
        {
            var description = new StringBuilder().Append(boardSize).Append('|');
            foreach (var layout in layouts.OrderBy(
                         value => value.Source.Id,
                         StringComparer.Ordinal))
            {
                description.Append(layout.Source.Id).Append(':');
                foreach (var cell in layout.BoardCells
                             .OrderBy(value => value.y)
                             .ThenBy(value => value.x))
                {
                    description.Append(cell.x).Append(',').Append(cell.y).Append(';');
                }
                description.Append('|');
            }
            return $"v2:{HashDescription(description.ToString()):x16}";
        }

        private static ulong HashDescription(string description)
        {
            const ulong offsetBasis = 14695981039346656037UL;
            const ulong prime = 1099511628211UL;
            var hash = offsetBasis;
            unchecked
            {
                foreach (var value in Encoding.UTF8.GetBytes(description ?? string.Empty))
                {
                    hash ^= value;
                    hash *= prime;
                }
            }
            return hash;
        }

        private static uint DeriveSeed(int seed, int boardSize, int attempt)
        {
            unchecked
            {
                var value = (uint)seed;
                value ^= (uint)boardSize * 0x9e3779b9u;
                value ^= (uint)attempt * 0x85ebca6bu;
                value ^= value >> 16;
                value *= 0x7feb352du;
                value ^= value >> 15;
                return value == 0 ? 0x6d2b79f5u : value;
            }
        }

        private static int CreateRuntimeSeed()
        {
            var seed = BitConverter.ToInt32(Guid.NewGuid().ToByteArray(), 0) & int.MaxValue;
            return seed == 0 ? 1 : seed;
        }

        private static void Shuffle<T>(IList<T> values, ref StableRandom random)
        {
            for (var index = values.Count - 1; index > 0; index--)
            {
                var other = random.Next(0, index + 1);
                var value = values[index];
                values[index] = values[other];
                values[other] = value;
            }
        }

        private bool FailGeneration(string error)
        {
            BoardSize = 0;
            CoveredCellCount = 0;
            pieceAreas = Array.Empty<int>();
            TemplateSeed = 0;
            TemplateSignature = string.Empty;
            TemplateConnected = false;
            TemplateNonOverlapping = false;
            TemplateWithinWorkspace = false;
            TemplateWithinReach = false;
            TemplateTargetsSeparated = false;
            TemplateSquare = false;
            TemplateCoverageComplete = false;
            TemplatePiecesConnected = false;
            TemplatePiecesUnique = false;
            TemplatePiecesStaged = false;
            TemplateUsedFallback = false;
            TemplateError = error ?? "Unknown template generation error.";
            Debug.LogError($"[QUAK Block Lab] {TemplateError}", this);
            return false;
        }

        private static bool IsFinite(Vector3 value)
        {
            return !float.IsNaN(value.x) &&
                   !float.IsInfinity(value.x) &&
                   !float.IsNaN(value.y) &&
                   !float.IsInfinity(value.y) &&
                   !float.IsNaN(value.z) &&
                   !float.IsInfinity(value.z);
        }

        private static bool IsReachableHeight(float value)
        {
            return value >= ReachEnvelopeMinimumHeightMetres &&
                   value <= ReachEnvelopeMaximumHeightMetres;
        }

        private readonly struct PieceSource
        {
            public PieceSource(
                string id,
                QuakBlockLabBlock block,
                QuakBlockLabSolidShape shape,
                QuakBlockLabSocket socket,
                QuakBlockLabSolidShape targetGuide,
                Vector3 homeCenter)
            {
                Id = id;
                Block = block;
                Shape = shape;
                Socket = socket;
                TargetGuide = targetGuide;
                HomeCenter = homeCenter;
            }

            public string Id { get; }
            public QuakBlockLabBlock Block { get; }
            public QuakBlockLabSolidShape Shape { get; }
            public QuakBlockLabSocket Socket { get; }
            public QuakBlockLabSolidShape TargetGuide { get; }
            public Vector3 HomeCenter { get; }
        }

        private sealed class PieceLayout
        {
            public PieceLayout(
                PieceSource source,
                Vector2Int[] boardCells,
                Vector2[] localCells,
                Vector2Int anchor,
                Vector3 socketPosition)
            {
                Source = source;
                BoardCells = boardCells;
                LocalCells = localCells;
                Anchor = anchor;
                SocketPosition = socketPosition;
            }

            public PieceSource Source { get; }
            public Vector2Int[] BoardCells { get; }
            public Vector2[] LocalCells { get; }
            public Vector2Int Anchor { get; }
            public Vector3 SocketPosition { get; }
            public Vector3 HomePosition { get; set; }
            public Quaternion HomeRotation { get; set; }
            public WorldRect HomeRectangle { get; set; }
        }

        private sealed class SearchContext
        {
            private readonly int maximumNodes;
            private int visitedNodes;

            public SearchContext(int maximumNodes)
            {
                this.maximumNodes = maximumNodes;
            }

            public bool TryVisitNode()
            {
                visitedNodes++;
                return visitedNodes <= maximumNodes;
            }
        }

        private readonly struct RandomizedValue
        {
            public RandomizedValue(int value, int randomOrder)
            {
                Value = value;
                RandomOrder = randomOrder;
            }

            public int Value { get; }
            public int RandomOrder { get; }
        }

        private readonly struct RegionCandidate
        {
            public RegionCandidate(ulong mask, string shapeKey, int preference)
            {
                Mask = mask;
                ShapeKey = shapeKey;
                Preference = preference;
            }

            public ulong Mask { get; }
            public string ShapeKey { get; }
            private int Preference { get; }

            public static int Compare(RegionCandidate left, RegionCandidate right)
            {
                var result = left.Preference.CompareTo(right.Preference);
                if (result != 0)
                    return result;
                return left.Mask.CompareTo(right.Mask);
            }
        }

        private readonly struct HomePoseChoice
        {
            public HomePoseChoice(
                int quarterTurns,
                Vector3 position,
                WorldRect rectangle,
                int preference)
            {
                QuarterTurns = quarterTurns;
                Position = position;
                Rectangle = rectangle;
                Preference = preference;
            }

            public int QuarterTurns { get; }
            public Vector3 Position { get; }
            public WorldRect Rectangle { get; }
            private int Preference { get; }

            public static int Compare(HomePoseChoice left, HomePoseChoice right)
            {
                var result = left.Preference.CompareTo(right.Preference);
                return result != 0
                    ? result
                    : left.QuarterTurns.CompareTo(right.QuarterTurns);
            }
        }

        private readonly struct GridBounds
        {
            public GridBounds(int minX, int maxX, int minY, int maxY)
            {
                MinX = minX;
                MaxX = maxX;
                MinY = minY;
                MaxY = maxY;
            }

            public int MinX { get; }
            public int MaxX { get; }
            public int MinY { get; }
            public int MaxY { get; }
            public int Width => MaxX - MinX + 1;
            public int Height => MaxY - MinY + 1;
            public int Area => Width * Height;
        }

        private readonly struct FloatBounds
        {
            public FloatBounds(float minX, float maxX, float minY, float maxY)
            {
                MinX = minX;
                MaxX = maxX;
                MinY = minY;
                MaxY = maxY;
            }

            public float MinX { get; }
            public float MaxX { get; }
            public float MinY { get; }
            public float MaxY { get; }
            public float Width => MaxX - MinX + 1f;
            public float Height => MaxY - MinY + 1f;
        }

        private readonly struct WorldRect
        {
            public WorldRect(float minimumX, float maximumX, float minimumZ, float maximumZ)
            {
                MinimumX = minimumX;
                MaximumX = maximumX;
                MinimumZ = minimumZ;
                MaximumZ = maximumZ;
            }

            private float MinimumX { get; }
            private float MaximumX { get; }
            private float MinimumZ { get; }
            private float MaximumZ { get; }

            public bool IsInside(
                float minimumX,
                float maximumX,
                float minimumZ,
                float maximumZ,
                float padding)
            {
                return MinimumX - padding >= minimumX &&
                       MaximumX + padding <= maximumX &&
                       MinimumZ - padding >= minimumZ &&
                       MaximumZ + padding <= maximumZ;
            }

            public bool Overlaps(WorldRect other, float padding)
            {
                return MinimumX - padding < other.MaximumX + padding &&
                       MaximumX + padding > other.MinimumX - padding &&
                       MinimumZ - padding < other.MaximumZ + padding &&
                       MaximumZ + padding > other.MinimumZ - padding;
            }

            public bool IsInsideHorizontalRadius(float radius, float padding)
            {
                var furthestX = Mathf.Max(
                    Mathf.Abs(MinimumX - padding),
                    Mathf.Abs(MaximumX + padding));
                var furthestZ = Mathf.Max(
                    Mathf.Abs(MinimumZ - padding),
                    Mathf.Abs(MaximumZ + padding));
                return furthestX * furthestX + furthestZ * furthestZ <=
                       radius * radius + 0.000001f;
            }
        }

        private struct StableRandom
        {
            private uint state;

            public StableRandom(uint seed)
            {
                state = seed == 0 ? 0x9e3779b9u : seed;
            }

            public int Next(int minimum, int maximum)
            {
                if (maximum <= minimum)
                    return minimum;
                return minimum + (int)(NextUInt() % (uint)(maximum - minimum));
            }

            private uint NextUInt()
            {
                var value = state;
                value ^= value << 13;
                value ^= value >> 17;
                value ^= value << 5;
                state = value;
                return value;
            }
        }
    }
}
