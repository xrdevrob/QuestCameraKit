using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;

namespace XRDevRob.QUAK.Samples.BlockAssemblyLab
{
    /// <summary>
    /// Minimal right-controller grab path. The XR control provider moves the
    /// actual OpenXR
    /// pointer pose and press Grip; QUAK fixture actions never move a block.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class QuakBlockLabGrabber : MonoBehaviour
    {
        private const string RightPointerPosition =
            "<XRController>{RightHand}/pointerPosition";
        private const string RightPointerRotation =
            "<XRController>{RightHand}/pointerRotation";
        private const string RightGripPressed =
            "<XRController>{RightHand}/gripPressed";
        private const string RightHandPointerPosition =
            "<MetaAimHand>{RightHand}/devicePosition";
        private const string RightHandPointerRotation =
            "<MetaAimHand>{RightHand}/deviceRotation";
        private const string RightHandPinchPressed =
            "<MetaAimHand>{RightHand}/indexPressed";

        [SerializeField] private QuakBlockAssemblyLab lab;
        [SerializeField] private Transform trackingSpace;
        [SerializeField] private Transform pointerVisual;
        [SerializeField, Min(0.01f)] private float grabRadius = 0.18f;

        private InputAction pointerPositionAction;
        private InputAction pointerRotationAction;
        private InputAction gripPressedAction;
        private QuakBlockLabBlock heldBlock;
        private Vector3 positionOffset;
        private Quaternion rotationOffset;
        private bool previousGripPressed;
        private InputDevice gripPoseDevice;
        private QuakBlockLabVisual pointerFeedbackVisual;

        public string HeldPieceId => heldBlock != null ? heldBlock.BlockId : string.Empty;
        public bool InputPoseReady { get; private set; }
        public Vector3 PointerWorldPosition { get; private set; }
        public Quaternion PointerWorldRotation { get; private set; } = Quaternion.identity;
        public float GripValue { get; private set; }
        public bool GripPressed { get; private set; }
        public int PositionControlCount => pointerPositionAction?.controls.Count ?? 0;
        public int RotationControlCount => pointerRotationAction?.controls.Count ?? 0;
        public int GripControlCount => gripPressedAction?.controls.Count ?? 0;
        public string PositionControlPath { get; private set; } = string.Empty;
        public string RotationControlPath { get; private set; } = string.Empty;
        public string GripControlPath => gripPressedAction?.activeControl?.path ?? string.Empty;

        private void Awake()
        {
            if (pointerVisual != null)
                pointerFeedbackVisual = pointerVisual.GetComponent<QuakBlockLabVisual>();
            pointerPositionAction = new InputAction(
                "QUAK Right Pointer Position",
                InputActionType.Value,
                RightPointerPosition,
                expectedControlType: "Vector3");
            pointerPositionAction.AddBinding(RightHandPointerPosition);
            pointerRotationAction = new InputAction(
                "QUAK Right Pointer Rotation",
                InputActionType.Value,
                RightPointerRotation,
                expectedControlType: "Quaternion");
            pointerRotationAction.AddBinding(RightHandPointerRotation);
            gripPressedAction = new InputAction(
                "QUAK Right Grip",
                InputActionType.Button,
                RightGripPressed);
            gripPressedAction.AddBinding(RightHandPinchPressed);
        }

        private void OnEnable()
        {
            pointerPositionAction?.Enable();
            pointerRotationAction?.Enable();
            gripPressedAction?.Enable();
            previousGripPressed = false;
            gripPoseDevice = null;
        }

        private void OnDisable()
        {
            CancelGrab(false);
            pointerPositionAction?.Disable();
            pointerRotationAction?.Disable();
            gripPressedAction?.Disable();
            previousGripPressed = false;
            gripPoseDevice = null;
        }

        private void OnDestroy()
        {
            pointerPositionAction?.Dispose();
            pointerRotationAction?.Dispose();
            gripPressedAction?.Dispose();
        }

        private void Update()
        {
            GripValue = gripPressedAction?.ReadValue<float>() ?? 0f;
            GripPressed = gripPressedAction != null && gripPressedAction.IsPressed();
            InputPoseReady = TryReadPointerPose(out var position, out var rotation);
            if (!InputPoseReady)
            {
                CancelGrab(false);
                previousGripPressed = GripPressed;
                return;
            }

            PointerWorldPosition = position;
            PointerWorldRotation = rotation;

            var visual = pointerVisual != null ? pointerVisual : transform;
            visual.SetPositionAndRotation(position, rotation);

            if (GripPressed && !previousGripPressed)
                TryBeginGrab(position, rotation);

            if (heldBlock != null)
            {
                heldBlock.SetHeldPose(
                    position + rotation * positionOffset,
                    rotation * rotationOffset);
                var snapReady = lab != null && lab.NotifyBlockMoved(heldBlock);
                pointerFeedbackVisual?.SetHighlight(snapReady ? 1f : 0f);
            }

            if (!GripPressed && previousGripPressed)
                ReleaseGrab();

            previousGripPressed = GripPressed;
        }

        internal void CancelGrab(bool notifyLab)
        {
            pointerFeedbackVisual?.SetHighlight(0f);
            lab?.ClearPlacementFeedback();
            if (heldBlock == null)
                return;
            var block = heldBlock;
            heldBlock = null;
            block.EndGrab();
            if (notifyLab)
                lab?.NotifyBlockReleased(block);
        }

        private bool TryReadPointerPose(out Vector3 worldPosition, out Quaternion worldRotation)
        {
            worldPosition = default;
            worldRotation = Quaternion.identity;
            if (pointerPositionAction == null || pointerRotationAction == null ||
                pointerPositionAction.controls.Count == 0 ||
                pointerRotationAction.controls.Count == 0)
            {
                return false;
            }

            var device = GripPressed
                ? gripPressedAction?.activeControl?.device
                : previousGripPressed ? gripPoseDevice : null;
            if (GripPressed)
                gripPoseDevice = device;
            // Keep the controller pose through release: a newly active hand must
            // not move the held piece before ReleaseGrab evaluates its socket.
            device ??= pointerPositionAction.activeControl?.device;
            device ??= pointerRotationAction.activeControl?.device;
            if (!TryGetPoseControls(device, out var positionControl, out var rotationControl))
                return false;

            PositionControlPath = positionControl.path;
            RotationControlPath = rotationControl.path;
            var localPosition = positionControl.ReadValue();
            var localRotation = rotationControl.ReadValue();
            if (Quaternion.Dot(localRotation, localRotation) < 0.0001f)
                localRotation = Quaternion.identity;

            if (trackingSpace != null)
            {
                worldPosition = trackingSpace.TransformPoint(localPosition);
                worldRotation = trackingSpace.rotation * localRotation;
            }
            else
            {
                worldPosition = localPosition;
                worldRotation = localRotation;
            }
            return true;
        }

        private bool TryGetPoseControls(
            InputDevice device,
            out Vector3Control positionControl,
            out QuaternionControl rotationControl)
        {
            positionControl = null;
            rotationControl = null;
            if (device == null)
                return false;

            foreach (var control in pointerPositionAction.controls)
                if (control.device == device && control is Vector3Control position)
                {
                    positionControl = position;
                    break;
                }
            foreach (var control in pointerRotationAction.controls)
                if (control.device == device && control is QuaternionControl rotation)
                {
                    rotationControl = rotation;
                    break;
                }
            return positionControl != null && rotationControl != null;
        }

        private void TryBeginGrab(Vector3 pointerPosition, Quaternion pointerRotation)
        {
            if (heldBlock != null || lab == null)
                return;

            QuakBlockLabBlock nearest = null;
            var nearestDistance = grabRadius;
            foreach (var block in lab.Blocks)
            {
                if (block == null || !block.isActiveAndEnabled || block.IsHeld)
                    continue;
                var distance = Vector3.Distance(pointerPosition, block.transform.position);
                if (distance > nearestDistance)
                    continue;
                nearest = block;
                nearestDistance = distance;
            }

            if (nearest == null)
            {
                lab.NotifyGrabMiss();
                return;
            }

            heldBlock = nearest;
            heldBlock.BeginGrab();
            positionOffset = Quaternion.Inverse(pointerRotation) *
                             (heldBlock.transform.position - pointerPosition);
            rotationOffset = Quaternion.Inverse(pointerRotation) * heldBlock.transform.rotation;
            lab.NotifyBlockGrabbed(heldBlock);
        }

        private void ReleaseGrab()
        {
            pointerFeedbackVisual?.SetHighlight(0f);
            if (heldBlock == null)
                return;
            var block = heldBlock;
            heldBlock = null;
            block.EndGrab();
            lab?.NotifyBlockReleased(block);
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            grabRadius = Mathf.Max(0.01f, grabRadius);
        }
#endif
    }
}
