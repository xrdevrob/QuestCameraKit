using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;
using XRDevRob.QUAK.MetaOperator;

namespace XRDevRob.QUAK.Samples.BlockAssemblyLab.Editor
{
    /// <summary>
    /// Canonical authoring path for the shipped sample scene. The package
    /// includes a generated scene, while this menu item creates a fresh copy
    /// that is safe to modify inside the consuming project.
    /// </summary>
    public static class QuakBlockAssemblyLabSceneGenerator
    {
        private const string SceneFolder = "Assets/QUAKBlockAssemblyLab";
        private const string ScenePath = SceneFolder + "/BlockAssemblyLab.unity";
        private const float CellSize = 0.06f;
        private const float PieceHeight = 0.032f;

        private static readonly Vector3 AssemblyOrigin = new(0.15f, 0.815f, 0.69f);
        private static readonly Color Coral = new(0.95f, 0.29f, 0.30f, 1f);
        private static readonly Color Azure = new(0.16f, 0.55f, 1f, 1f);
        private static readonly Color Gold = new(1f, 0.72f, 0.12f, 1f);
        private static readonly Color Mint = new(0.21f, 0.85f, 0.54f, 1f);
        private static readonly Color Violet = new(0.67f, 0.36f, 1f, 1f);

        [MenuItem("QUAK/Block Assembly Lab/Validate Square Generator", priority = 21)]
        public static void ValidateRuntimeGenerator()
        {
            const int seedsPerSize = 64;
            var summaries = new List<string>();
            for (var boardSize = QuakBlockLabRuntimeTemplate.MinimumBoardSize;
                 boardSize <= QuakBlockLabRuntimeTemplate.MaximumBoardSize;
                 boardSize++)
            {
                var signatures = new HashSet<string>(StringComparer.Ordinal);
                for (var seed = 1; seed <= seedsPerSize; seed++)
                {
                    if (!QuakBlockLabRuntimeTemplate.ValidatePuzzleSeed(boardSize, seed))
                    {
                        throw new InvalidOperationException(
                            $"Square generator failed for size={boardSize}, seed={seed}.");
                    }
                    var first = QuakBlockLabRuntimeTemplate.CreatePuzzleSignature(
                        boardSize,
                        seed);
                    var replay = QuakBlockLabRuntimeTemplate.CreatePuzzleSignature(
                        boardSize,
                        seed);
                    if (string.IsNullOrEmpty(first) ||
                        !string.Equals(first, replay, StringComparison.Ordinal))
                    {
                        throw new InvalidOperationException(
                            $"Square generator was not deterministic for size={boardSize}, seed={seed}.");
                    }
                    signatures.Add(first);
                }

                summaries.Add(
                    $"{boardSize}x{boardSize}: {seedsPerSize}/{seedsPerSize} valid, " +
                    $"{signatures.Count} unique signatures");
            }

            Debug.Log(
                "[QUAK Block Lab] Square generator validation passed. " +
                string.Join("; ", summaries));
        }

        [MenuItem("QUAK/Block Assembly Lab/Create Fresh Scene", priority = 20)]
        public static void CreateScene()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                return;

            if (!Application.isBatchMode &&
                AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null &&
                !EditorUtility.DisplayDialog(
                    "Replace Block Assembly Lab?",
                    $"{ScenePath} already exists. Replace it with a fresh generated scene?",
                    "Replace",
                    "Cancel"))
            {
                return;
            }

            EnsureFolder();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var root = new GameObject("QUAK Block Assembly Lab");
            root.AddComponent<QuakBlockLabXrBootstrap>();
            var runtimeTemplate = root.AddComponent<QuakBlockLabRuntimeTemplate>();
            var lab = root.AddComponent<QuakBlockAssemblyLab>();

            var camera = CreateCamera(root.transform);
            CreateLighting(root.transform);
            CreateEventSystem(root.transform);
            CreateWorkbench(root.transform);

            var pieces = new[]
            {
                new PieceSpec(
                    "coral",
                    "Puzzle",
                    Coral,
                    new Vector3(-0.35f, 0.815f, 0.16f),
                    new Vector2(-1f, -2f),
                    new[]
                    {
                        new Vector2(-1f, 0f),
                        new Vector2(0f, 0f),
                        new Vector2(1f, 0f),
                        new Vector2(-1f, 1f),
                        new Vector2(0f, 1f)
                    }),
                new PieceSpec(
                    "azure",
                    "Puzzle",
                    Azure,
                    new Vector3(0f, 0.815f, 0.16f),
                    new Vector2(2f, -1f),
                    new[]
                    {
                        new Vector2(-1f, -1f),
                        new Vector2(0f, -1f),
                        new Vector2(0f, 0f),
                        new Vector2(0f, 1f),
                        new Vector2(0f, 2f)
                    }),
                new PieceSpec(
                    "gold",
                    "Puzzle",
                    Gold,
                    new Vector3(0.35f, 0.815f, 0.16f),
                    Vector2.zero,
                    new[]
                    {
                        new Vector2(0f, -1f),
                        new Vector2(1f, -1f),
                        new Vector2(-1f, 0f),
                        new Vector2(0f, 0f),
                        new Vector2(-1f, 1f)
                    }),
                new PieceSpec(
                    "mint",
                    "Puzzle",
                    Mint,
                    new Vector3(-0.175f, 0.815f, 0.43f),
                    new Vector2(-2f, 1f),
                    new[]
                    {
                        new Vector2(0f, -1f),
                        new Vector2(0f, 0f),
                        new Vector2(0f, 1f),
                        new Vector2(1f, 1f),
                        new Vector2(2f, 1f)
                    }),
                new PieceSpec(
                    "violet",
                    "Puzzle",
                    Violet,
                    new Vector3(0.175f, 0.815f, 0.43f),
                    new Vector2(1f, 1f),
                    new[]
                    {
                        new Vector2(0f, -1f),
                        new Vector2(-1f, 0f),
                        new Vector2(0f, 0f),
                        new Vector2(0f, 1f),
                        new Vector2(1f, 1f)
                    })
            };

            var guideShape = CreateAssemblyGuide(root.transform, pieces);
            var blocks = new QuakBlockLabBlock[pieces.Length];
            var sockets = new QuakBlockLabSocket[pieces.Length];
            var targetGuideShapes = new QuakBlockLabSolidShape[pieces.Length];
            for (var index = 0; index < pieces.Length; index++)
            {
                blocks[index] = CreatePiece(root.transform, pieces[index]);
                sockets[index] = CreateConnection(
                    root.transform,
                    pieces[index],
                    out targetGuideShapes[index]);
            }

            var grabber = CreateGrabber(root.transform, lab);
            CreateWorldSpaceUi(
                root.transform,
                camera,
                out var boardSizeSlider,
                out var decreaseSizeButton,
                out var increaseSizeButton,
                out var newPuzzleButton,
                out var resetButton,
                out var validateButton,
                out var boardSizeLabel,
                out var statusLabel);

            var bridgeObject = new GameObject("QUAK Operator Bridge");
            bridgeObject.transform.SetParent(root.transform, false);
            bridgeObject.AddComponent<QuakOperatorBridge>();

            ConfigureRuntimeTemplate(
                runtimeTemplate,
                blocks,
                sockets,
                guideShape,
                targetGuideShapes,
                pieces);
            ConfigureLab(
                lab,
                blocks,
                sockets,
                runtimeTemplate,
                grabber,
                boardSizeSlider,
                decreaseSizeButton,
                increaseSizeButton,
                newPuzzleButton,
                resetButton,
                validateButton,
                boardSizeLabel,
                statusLabel);

            EditorSceneManager.MarkSceneDirty(scene);
            if (!EditorSceneManager.SaveScene(scene, ScenePath))
                throw new InvalidOperationException($"Could not save Block Assembly Lab scene at {ScenePath}.");

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Selection.activeGameObject = root;
            EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath));
            Debug.Log(
                $"[QUAK Block Lab] Created {ScenePath}. Integrated Core-205 lane: activate Meta XR " +
                "Simulator and enter Play mode. No-Core lane: follow Doctor's standalone-player " +
                "launch instructions. Then run the Block Assembly test.");
        }

        private static Camera CreateCamera(Transform parent)
        {
            var cameraObject = new GameObject(
                "Main Camera",
                typeof(Camera),
                typeof(AudioListener),
                typeof(TrackedPoseDriver));
            cameraObject.tag = "MainCamera";
            cameraObject.transform.SetParent(parent, false);
            cameraObject.transform.position = new Vector3(0f, 1.58f, 0f);
            cameraObject.transform.rotation = Quaternion.LookRotation(
                new Vector3(0f, 0.92f, 0.65f) - cameraObject.transform.position,
                Vector3.up);

            var camera = cameraObject.GetComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0f, 0f, 0f, 0f);
            camera.fieldOfView = 72f;
            camera.nearClipPlane = 0.01f;
            camera.farClipPlane = 100f;

            var driver = cameraObject.GetComponent<TrackedPoseDriver>();
            driver.ignoreTrackingState = true;
            driver.positionInput = new InputActionProperty(new InputAction(
                "Head Position", InputActionType.Value, "<XRHMD>/centerEyePosition"));
            driver.rotationInput = new InputActionProperty(new InputAction(
                "Head Rotation", InputActionType.Value, "<XRHMD>/centerEyeRotation"));
            return camera;
        }

        private static void CreateLighting(Transform parent)
        {
            var lightObject = new GameObject("Key Light", typeof(Light));
            lightObject.transform.SetParent(parent, false);
            lightObject.transform.rotation = Quaternion.Euler(45f, -30f, 0f);
            var light = lightObject.GetComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1.2f;
            light.color = new Color(0.88f, 0.93f, 1f, 1f);
            RenderSettings.ambientLight = new Color(0.20f, 0.23f, 0.32f, 1f);
        }

        private static void CreateEventSystem(Transform parent)
        {
            var eventSystemObject = new GameObject(
                "EventSystem",
                typeof(EventSystem),
                typeof(InputSystemUIInputModule));
            eventSystemObject.transform.SetParent(parent, false);
            var input = eventSystemObject.GetComponent<InputSystemUIInputModule>();
            input.AssignDefaultActions();
            ReplaceBinding(
                input.trackedDevicePosition.action,
                "<XRController>/devicePosition",
                "<XRController>{RightHand}/pointerPosition");
            ReplaceBinding(
                input.trackedDeviceOrientation.action,
                "<XRController>/deviceRotation",
                "<XRController>{RightHand}/pointerRotation");
            ReplaceBinding(
                input.leftClick.action,
                "<XRController>/trigger",
                "<XRController>{RightHand}/trigger");
            input.trackedDevicePosition.action.AddBinding(
                "<MetaAimHand>{RightHand}/devicePosition");
            input.trackedDeviceOrientation.action.AddBinding(
                "<MetaAimHand>{RightHand}/deviceRotation");
            input.leftClick.action.AddBinding("<MetaAimHand>{RightHand}/indexPressed");
        }

        private static void ReplaceBinding(InputAction action, string oldPath, string newPath)
        {
            for (var index = 0; index < action.bindings.Count; index++)
            {
                if (action.bindings[index].path == oldPath)
                {
                    action.ChangeBinding(index).WithPath(newPath);
                    return;
                }
            }
            throw new InvalidOperationException($"Default UI action has no {oldPath} binding.");
        }

        private static void CreateWorkbench(Transform parent)
        {
            var table = CreatePrimitive("Workbench", parent, PrimitiveType.Cube);
            table.transform.position = new Vector3(0f, 0.775f, 0.49f);
            table.transform.localScale = new Vector3(1.08f, 0.045f, 0.92f);
            ConfigureVisual(table, new Color(0.075f, 0.10f, 0.15f, 0.94f));
        }

        private static QuakBlockLabBlock CreatePiece(
            Transform parent,
            PieceSpec spec)
        {
            var pieceObject = new GameObject(
                $"{Capitalize(spec.Id)} Puzzle Piece",
                typeof(MeshFilter),
                typeof(MeshRenderer),
                typeof(MeshCollider));
            pieceObject.transform.SetParent(parent, false);
            pieceObject.transform.position = spec.StartPosition;

            var meshCollider = pieceObject.GetComponent<MeshCollider>();
            meshCollider.convex = true;
            var solidShape = pieceObject.AddComponent<QuakBlockLabSolidShape>();
            ConfigureSolidShape(solidShape, spec.Cells, CellSize, PieceHeight, meshCollider);
            AssignBuiltinMaterial(pieceObject.GetComponent<Renderer>());

            var body = pieceObject.AddComponent<Rigidbody>();
            body.isKinematic = true;
            body.useGravity = false;

            var block = pieceObject.AddComponent<QuakBlockLabBlock>();
            var blockSerialized = new SerializedObject(block);
            blockSerialized.FindProperty("blockId").stringValue = spec.Id;
            blockSerialized.FindProperty("body").objectReferenceValue = body;
            blockSerialized.ApplyModifiedPropertiesWithoutUndo();

            var target = pieceObject.AddComponent<QuakTarget>();
            ConfigureTarget(
                target,
                $"assembly.piece.{spec.Id}",
                $"{Capitalize(spec.Id)} runtime-generated square-puzzle piece.");
            ConfigureVisual(pieceObject, spec.Color);
            return block;
        }

        private static QuakBlockLabSocket CreateConnection(
            Transform parent,
            PieceSpec spec,
            out QuakBlockLabSolidShape targetGuideShape)
        {
            var socketObject = new GameObject(
                $"{Capitalize(spec.Id)} Connection",
                typeof(AudioSource));
            socketObject.transform.SetParent(parent, false);
            socketObject.transform.position = AssemblyOrigin + new Vector3(
                spec.AssemblyOffset.x * CellSize,
                0f,
                spec.AssemblyOffset.y * CellSize);

            var socket = socketObject.AddComponent<QuakBlockLabSocket>();
            var socketSerialized = new SerializedObject(socket);
            socketSerialized.FindProperty("socketId").stringValue = spec.Id;
            socketSerialized.FindProperty("requiredBlockId").stringValue = spec.Id;
            socketSerialized.FindProperty("snapPoint").objectReferenceValue = socketObject.transform;
            socketSerialized.FindProperty("snapRadius").floatValue = 0.08f;
            socketSerialized.FindProperty("snapAngleToleranceDegrees").floatValue = 30f;
            socketSerialized.FindProperty("hoverRadius").floatValue = 0.13f;
            var placementAudioSource = socketObject.GetComponent<AudioSource>();
            placementAudioSource.playOnAwake = false;
            placementAudioSource.spatialBlend = 1f;
            placementAudioSource.volume = 0.72f;
            placementAudioSource.dopplerLevel = 0f;
            placementAudioSource.minDistance = 0.2f;
            placementAudioSource.maxDistance = 3f;
            placementAudioSource.rolloffMode = AudioRolloffMode.Linear;
            socketSerialized.FindProperty("placementAudioSource").objectReferenceValue =
                placementAudioSource;
            socketSerialized.ApplyModifiedPropertiesWithoutUndo();

            var target = socketObject.AddComponent<QuakTarget>();
            ConfigureTarget(
                target,
                $"assembly.connection.{spec.Id}",
                $"Color-matched destination for the {spec.Id} square-puzzle piece.");

            var guideObject = new GameObject(
                $"{Capitalize(spec.Id)} Destination Guide",
                typeof(MeshFilter),
                typeof(MeshRenderer));
            guideObject.transform.SetParent(socketObject.transform, false);
            guideObject.transform.localPosition = new Vector3(0f, -0.020f, 0f);
            targetGuideShape = guideObject.AddComponent<QuakBlockLabSolidShape>();
            ConfigureSolidShape(
                targetGuideShape,
                spec.Cells,
                CellSize,
                0.008f,
                null);
            AssignBuiltinMaterial(guideObject.GetComponent<Renderer>());
            ConfigureVisual(
                guideObject,
                Color.Lerp(new Color(0.055f, 0.07f, 0.12f, 1f), spec.Color, 0.48f));
            socketSerialized.Update();
            socketSerialized.FindProperty("guideVisual").objectReferenceValue =
                guideObject.GetComponent<QuakBlockLabVisual>();
            socketSerialized.ApplyModifiedPropertiesWithoutUndo();
            return socket;
        }

        private static QuakBlockLabSolidShape CreateAssemblyGuide(
            Transform parent,
            IReadOnlyList<PieceSpec> pieces)
        {
            var guide = new GameObject(
                "Square Assembly Backplate",
                typeof(MeshFilter),
                typeof(MeshRenderer));
            guide.transform.SetParent(parent, false);
            guide.transform.position = AssemblyOrigin + new Vector3(0f, -0.022f, 0f);

            var guideCells = new List<Vector2>();
            foreach (var piece in pieces)
            foreach (var cell in piece.Cells)
                guideCells.Add(piece.AssemblyOffset + cell);

            var solidShape = guide.AddComponent<QuakBlockLabSolidShape>();
            ConfigureSolidShape(solidShape, guideCells, CellSize, 0.008f, null);
            AssignBuiltinMaterial(guide.GetComponent<Renderer>());
            ConfigureVisual(guide, new Color(0.24f, 0.31f, 0.43f, 1f));
            return solidShape;
        }

        private static QuakBlockLabGrabber CreateGrabber(
            Transform parent,
            QuakBlockAssemblyLab lab)
        {
            var grabberObject = new GameObject("Right Controller Grab Probe");
            grabberObject.transform.SetParent(parent, false);
            var grabber = grabberObject.AddComponent<QuakBlockLabGrabber>();

            var visual = CreatePrimitive("Grip Probe", grabberObject.transform, PrimitiveType.Sphere);
            visual.transform.localPosition = Vector3.zero;
            visual.transform.localScale = Vector3.one * 0.033f;
            var collider = visual.GetComponent<Collider>();
            if (collider != null)
                UnityEngine.Object.DestroyImmediate(collider);
            ConfigureVisual(visual, new Color(0.30f, 1f, 0.90f, 1f));

            var serialized = new SerializedObject(grabber);
            serialized.FindProperty("lab").objectReferenceValue = lab;
            serialized.FindProperty("trackingSpace").objectReferenceValue = parent;
            serialized.FindProperty("pointerVisual").objectReferenceValue = visual.transform;
            serialized.FindProperty("grabRadius").floatValue = 0.11f;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            return grabber;
        }

        private static void CreateWorldSpaceUi(
            Transform parent,
            Camera eventCamera,
            out Slider boardSizeSlider,
            out Button decreaseSizeButton,
            out Button increaseSizeButton,
            out Button newPuzzleButton,
            out Button resetButton,
            out Button validateButton,
            out Text boardSizeLabel,
            out Text statusLabel)
        {
            var canvasObject = new GameObject(
                "Block Lab Canvas",
                typeof(RectTransform),
                typeof(Canvas),
                typeof(CanvasScaler),
                typeof(GraphicRaycaster),
                typeof(TrackedDeviceRaycaster));
            canvasObject.transform.SetParent(parent, false);

            var canvasTransform = canvasObject.GetComponent<RectTransform>();
            canvasTransform.sizeDelta = new Vector2(1040f, 570f);
            canvasTransform.position = new Vector3(0f, 1.14f, 0.86f);
            canvasTransform.rotation = Quaternion.identity;
            canvasTransform.localScale = Vector3.one * 0.00052f;

            var canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvas.worldCamera = eventCamera;
            canvasObject.GetComponent<CanvasScaler>().dynamicPixelsPerUnit = 10f;

            var panel = CreateUiObject("Panel", canvasTransform, typeof(Image));
            Stretch(panel.GetComponent<RectTransform>());
            panel.GetComponent<Image>().color = new Color(0.035f, 0.052f, 0.10f, 0.97f);

            var heading = CreateText(
                "Heading",
                panel.transform,
                "QUAK BLOCK ASSEMBLY LAB",
                32,
                FontStyle.Bold);
            SetRect(heading.rectTransform, new Vector2(0f, 235f), new Vector2(960f, 52f));

            var instructions = CreateText(
                "Instructions",
                panel.transform,
                "Fit each colored piece onto its matching guide to complete the square.",
                19,
                FontStyle.Normal);
            SetRect(instructions.rectTransform, new Vector2(0f, 185f), new Vector2(960f, 42f));

            boardSizeLabel = CreateText(
                "Board Size Label",
                panel.transform,
                "BOARD SIZE  5 × 5  ·  MEDIUM",
                22,
                FontStyle.Bold);
            SetRect(boardSizeLabel.rectTransform, new Vector2(0f, 125f), new Vector2(900f, 45f));

            decreaseSizeButton = CreateButton(
                "Decrease Size Button",
                panel.transform,
                "−",
                new Vector2(-370f, 65f),
                new Vector2(110f, 72f),
                new Color(0.24f, 0.31f, 0.47f, 1f),
                "assembly.ui.size.decrease",
                "Decrease the selected square size by one step.");
            boardSizeSlider = CreateBoardSizeSlider(panel.transform);
            increaseSizeButton = CreateButton(
                "Increase Size Button",
                panel.transform,
                "+",
                new Vector2(370f, 65f),
                new Vector2(110f, 72f),
                new Color(0.24f, 0.31f, 0.47f, 1f),
                "assembly.ui.size.increase",
                "Increase the selected square size by one step.");

            newPuzzleButton = CreateButton(
                "New Puzzle Button",
                panel.transform,
                "NEW PUZZLE",
                new Vector2(-325f, -45f),
                new Vector2(280f, 78f),
                new Color(0.45f, 0.28f, 0.78f, 1f),
                "assembly.ui.new-puzzle",
                "Apply the selected board size and generate a fresh runtime puzzle.");

            resetButton = CreateButton(
                "Reset Button",
                panel.transform,
                "RESET PIECES",
                new Vector2(0f, -45f),
                new Vector2(250f, 78f),
                new Color(0.25f, 0.31f, 0.45f, 1f),
                "assembly.ui.reset",
                "Reset all pieces while preserving the current size, seed, and puzzle.");
            validateButton = CreateButton(
                "Validate Button",
                panel.transform,
                "VALIDATE",
                new Vector2(325f, -45f),
                new Vector2(280f, 78f),
                new Color(0.16f, 0.52f, 0.92f, 1f),
                "assembly.ui.validate",
                "Validate the completed five-piece square through the real world-space UI.");

            statusLabel = CreateText(
                "Product State",
                panel.transform,
                "Place all five pieces in the 5×5 square.",
                21,
                FontStyle.Bold);
            SetRect(statusLabel.rectTransform, new Vector2(0f, -160f), new Vector2(960f, 72f));
        }

        private static Slider CreateBoardSizeSlider(Transform parent)
        {
            var sliderObject = CreateUiObject(
                "Board Size Slider",
                parent,
                typeof(Slider),
                typeof(QuakTarget));
            SetRect(
                sliderObject.GetComponent<RectTransform>(),
                new Vector2(0f, 65f),
                new Vector2(560f, 72f));

            var background = CreateUiObject("Background", sliderObject.transform, typeof(Image));
            SetRect(
                background.GetComponent<RectTransform>(),
                Vector2.zero,
                new Vector2(540f, 18f));
            background.GetComponent<Image>().color = new Color(0.13f, 0.18f, 0.29f, 1f);

            var fillArea = CreateUiObject("Fill Area", sliderObject.transform);
            SetRect(fillArea.GetComponent<RectTransform>(), Vector2.zero, new Vector2(500f, 18f));
            var fill = CreateUiObject("Fill", fillArea.transform, typeof(Image));
            Stretch(fill.GetComponent<RectTransform>());
            fill.GetComponent<Image>().color = new Color(0.28f, 0.63f, 1f, 1f);

            var handleArea = CreateUiObject("Handle Slide Area", sliderObject.transform);
            SetRect(handleArea.GetComponent<RectTransform>(), Vector2.zero, new Vector2(500f, 54f));
            var handle = CreateUiObject("Handle", handleArea.transform, typeof(Image));
            var handleTransform = handle.GetComponent<RectTransform>();
            handleTransform.sizeDelta = new Vector2(46f, 54f);
            handle.GetComponent<Image>().color = new Color(0.92f, 0.96f, 1f, 1f);

            var slider = sliderObject.GetComponent<Slider>();
            slider.fillRect = fill.GetComponent<RectTransform>();
            slider.handleRect = handleTransform;
            slider.targetGraphic = handle.GetComponent<Image>();
            slider.direction = Slider.Direction.LeftToRight;
            slider.minValue = QuakBlockLabRuntimeTemplate.MinimumBoardSize;
            slider.maxValue = QuakBlockLabRuntimeTemplate.MaximumBoardSize;
            slider.wholeNumbers = true;
            slider.value = QuakBlockLabRuntimeTemplate.DefaultBoardSize;
            ConfigureTarget(
                sliderObject.GetComponent<QuakTarget>(),
                "assembly.ui.size.slider",
                "Stepped board-size slider from 4x4 through 6x6.");
            return slider;
        }

        private static Button CreateButton(
            string name,
            Transform parent,
            string label,
            Vector2 position,
            Vector2 size,
            Color color,
            string targetId,
            string description)
        {
            var buttonObject = CreateUiObject(
                name,
                parent,
                typeof(Image),
                typeof(Button),
                typeof(QuakTarget));
            SetRect(buttonObject.GetComponent<RectTransform>(), position, size);
            var image = buttonObject.GetComponent<Image>();
            image.color = color;
            var button = buttonObject.GetComponent<Button>();
            button.targetGraphic = image;
            var colors = button.colors;
            colors.normalColor = color;
            colors.highlightedColor = Color.Lerp(color, Color.white, 0.25f);
            colors.pressedColor = Color.Lerp(color, Color.black, 0.25f);
            colors.selectedColor = colors.highlightedColor;
            button.colors = colors;

            var text = CreateText("Label", buttonObject.transform, label, 24, FontStyle.Bold);
            Stretch(text.rectTransform);
            ConfigureTarget(buttonObject.GetComponent<QuakTarget>(), targetId, description);
            return button;
        }

        private static void ConfigureLab(
            QuakBlockAssemblyLab lab,
            IReadOnlyList<QuakBlockLabBlock> blocks,
            IReadOnlyList<QuakBlockLabSocket> sockets,
            QuakBlockLabRuntimeTemplate runtimeTemplate,
            QuakBlockLabGrabber grabber,
            Slider boardSizeSlider,
            Button decreaseSizeButton,
            Button increaseSizeButton,
            Button newPuzzleButton,
            Button resetButton,
            Button validateButton,
            Text boardSizeLabel,
            Text statusLabel)
        {
            var serialized = new SerializedObject(lab);
            SetObjectArray(serialized.FindProperty("blocks"), blocks);
            SetObjectArray(serialized.FindProperty("sockets"), sockets);
            serialized.FindProperty("runtimeTemplate").objectReferenceValue = runtimeTemplate;
            serialized.FindProperty("grabber").objectReferenceValue = grabber;
            serialized.FindProperty("boardSizeSlider").objectReferenceValue = boardSizeSlider;
            serialized.FindProperty("decreaseSizeButton").objectReferenceValue = decreaseSizeButton;
            serialized.FindProperty("increaseSizeButton").objectReferenceValue = increaseSizeButton;
            serialized.FindProperty("newPuzzleButton").objectReferenceValue = newPuzzleButton;
            serialized.FindProperty("resetButton").objectReferenceValue = resetButton;
            serialized.FindProperty("validateButton").objectReferenceValue = validateButton;
            serialized.FindProperty("boardSizeLabel").objectReferenceValue = boardSizeLabel;
            serialized.FindProperty("statusLabel").objectReferenceValue = statusLabel;
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }

        private static void ConfigureRuntimeTemplate(
            QuakBlockLabRuntimeTemplate runtimeTemplate,
            IReadOnlyList<QuakBlockLabBlock> blocks,
            IReadOnlyList<QuakBlockLabSocket> sockets,
            QuakBlockLabSolidShape guideShape,
            IReadOnlyList<QuakBlockLabSolidShape> targetGuideShapes,
            IReadOnlyList<PieceSpec> pieces)
        {
            var serialized = new SerializedObject(runtimeTemplate);
            SetObjectArray(serialized.FindProperty("blocks"), blocks);
            SetObjectArray(serialized.FindProperty("sockets"), sockets);
            serialized.FindProperty("guideShape").objectReferenceValue = guideShape;
            SetObjectArray(serialized.FindProperty("targetGuideShapes"), targetGuideShapes);
            var homeCenters = serialized.FindProperty("pieceHomeCenters");
            homeCenters.arraySize = pieces.Count;
            for (var index = 0; index < pieces.Count; index++)
            {
                homeCenters.GetArrayElementAtIndex(index).vector3Value =
                    pieces[index].StartPosition;
            }
            serialized.FindProperty("assemblyOrigin").vector3Value = AssemblyOrigin;
            serialized.FindProperty("initialBoardSize").intValue =
                QuakBlockLabRuntimeTemplate.DefaultBoardSize;
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }

        private static void ConfigureTarget(QuakTarget target, string id, string description)
        {
            target.Configure(id, description);
        }

        private static void ConfigureVisual(GameObject target, Color color)
        {
            var visual = target.GetComponent<QuakBlockLabVisual>() ??
                         target.AddComponent<QuakBlockLabVisual>();
            var serialized = new SerializedObject(visual);
            serialized.FindProperty("color").colorValue = color;
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }

        private static void ConfigureSolidShape(
            QuakBlockLabSolidShape solidShape,
            IReadOnlyList<Vector2> cells,
            float cellSize,
            float height,
            MeshCollider meshCollider)
        {
            var serialized = new SerializedObject(solidShape);
            var cellsProperty = serialized.FindProperty("cells");
            cellsProperty.arraySize = cells.Count;
            for (var index = 0; index < cells.Count; index++)
                cellsProperty.GetArrayElementAtIndex(index).vector2Value = cells[index];
            serialized.FindProperty("cellSize").floatValue = cellSize;
            serialized.FindProperty("height").floatValue = height;
            serialized.FindProperty("meshCollider").objectReferenceValue = meshCollider;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            solidShape.Rebuild();
        }

        private static GameObject CreatePrimitive(
            string name,
            Transform parent,
            PrimitiveType primitiveType)
        {
            var gameObject = GameObject.CreatePrimitive(primitiveType);
            gameObject.name = name;
            gameObject.transform.SetParent(parent, false);

            // Keep the sample independent from materials that happen to exist
            // in the project used to author it. Editor-created primitives use
            // Unity's built-in extra material, which serializes without a
            // project-local GUID.
            var renderer = gameObject.GetComponent<Renderer>();
            AssignBuiltinMaterial(renderer);

            return gameObject;
        }

        private static void AssignBuiltinMaterial(Renderer renderer)
        {
            if (renderer == null)
                return;
            var defaultMaterial = AssetDatabase.GetBuiltinExtraResource<Material>(
                "Default-Material.mat");
            if (defaultMaterial != null)
            {
                renderer.sharedMaterial = defaultMaterial;
            }
        }

        private static Text CreateText(
            string name,
            Transform parent,
            string value,
            int fontSize,
            FontStyle fontStyle)
        {
            var textObject = CreateUiObject(name, parent, typeof(Text));
            var text = textObject.GetComponent<Text>();
            text.text = value;
            text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.fontSize = fontSize;
            text.fontStyle = fontStyle;
            text.alignment = TextAnchor.MiddleCenter;
            text.color = Color.white;
            text.raycastTarget = false;
            return text;
        }

        private static GameObject CreateUiObject(
            string name,
            Transform parent,
            params Type[] components)
        {
            var objectComponents = new Type[components.Length + 1];
            objectComponents[0] = typeof(RectTransform);
            Array.Copy(components, 0, objectComponents, 1, components.Length);
            var gameObject = new GameObject(name, objectComponents);
            gameObject.transform.SetParent(parent, false);
            return gameObject;
        }

        private static void Stretch(RectTransform rectTransform)
        {
            rectTransform.anchorMin = Vector2.zero;
            rectTransform.anchorMax = Vector2.one;
            rectTransform.offsetMin = Vector2.zero;
            rectTransform.offsetMax = Vector2.zero;
        }

        private static void SetRect(RectTransform rectTransform, Vector2 position, Vector2 size)
        {
            rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchoredPosition = position;
            rectTransform.sizeDelta = size;
        }

        private static void SetObjectArray<T>(
            SerializedProperty property,
            IReadOnlyList<T> values)
            where T : UnityEngine.Object
        {
            property.arraySize = values.Count;
            for (var index = 0; index < values.Count; index++)
                property.GetArrayElementAtIndex(index).objectReferenceValue = values[index];
        }

        private static string Capitalize(string value)
        {
            return string.IsNullOrEmpty(value)
                ? value
                : char.ToUpperInvariant(value[0]) + value.Substring(1);
        }

        private static void EnsureFolder()
        {
            if (!AssetDatabase.IsValidFolder(SceneFolder))
                AssetDatabase.CreateFolder("Assets", "QUAKBlockAssemblyLab");
        }

        private readonly struct PieceSpec
        {
            public PieceSpec(
                string id,
                string shapeName,
                Color color,
                Vector3 startPosition,
                Vector2 assemblyOffset,
                Vector2[] cells)
            {
                Id = id;
                ShapeName = shapeName;
                Color = color;
                StartPosition = startPosition;
                AssemblyOffset = assemblyOffset;
                Cells = cells;
            }

            public string Id { get; }
            public string ShapeName { get; }
            public Color Color { get; }
            public Vector3 StartPosition { get; }
            public Vector2 AssemblyOffset { get; }
            public Vector2[] Cells { get; }
        }
    }
}
