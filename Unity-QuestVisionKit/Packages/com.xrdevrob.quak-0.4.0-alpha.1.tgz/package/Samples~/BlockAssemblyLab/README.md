# Block Assembly Lab (MR)

This sample is QUAK's mixed-reality showcase. QUAK drives the app through its
direct OpenXR path, while the app independently reports whether a piece was
held, released, connected in the expected pose, and accepted by the live UI.
The camera clears to transparent black so Quest passthrough remains visible.

The layout is a reachable tabletop, not a room-scale scene. The board is 30 cm
square; its 5x5 default uses 6 cm cells, and the pieces are 3.2 cm thick. The
piece tray, board, and compact UI stay inside a declared tracking-origin reach
envelope: at most 0.92 m horizontally and 0.70-1.30 m above the floor. Runtime
generation rejects any puzzle whose board or staged piece bounds leave that
envelope, and `block-lab.templateWithinReach` records the result in receipts.

The input path accepts either a right Touch controller (`XRController`) or a
right-hand pinch (`MetaAimHand`) when the consuming Quest player enables the
corresponding OpenXR features. No XR Interaction Toolkit dependency is needed.

Open `Scenes/BlockAssemblyLab.unity` and enter Play mode for Simulator work.
The imported definitions under `Tests/` appear automatically in
**QUAK > Control Panel**. For a Quest MR proof, use
`block-assembly-mr.json`; it enables passthrough first, verifies a source-alpha
projection over Quest's required opaque environment, performs a representative
placement, and requires a 2 fps,
60-second unattended recording.

```bash
quak run "Assets/Samples/QUAK/0.4.0-alpha.1/MR Block Assembly Showcase/Tests/block-assembly-mr.json" \
  --project "$PWD"
```

Choose **Easy (4 x 4)**, **Medium (5 x 5)**, or **Hard (6 x 6)** with the
stepped slider or minus/plus buttons. **New Puzzle** applies the selected size
and generates a fresh seeded partition. **Reset Pieces** returns the five
stable color IDs to their starting poses without changing the active size,
seed, or layout.

Placement remains forgiving without accepting an incorrectly oriented piece.
A matching guide brightens inside the 13 cm preview zone and pulses inside the
8 cm position and 30-degree full-orientation allowances. The grab probe has an
11 cm radius. Successful releases correct only the remaining pose error and
play one spatial click; upside-down, distant, and wrong-destination pieces stay
loose.

`block-assembly-lab.json` completes the full five-piece puzzle. The
wrong-connection and placement-margin definitions are negative controls, and
the size-selector definition preserves coverage checks for seeded 4x4, 5x5,
and 6x6 puzzles. Each receipt includes size, difficulty, cell coverage, seed,
template signature, workspace validity, reach validity, and staging validity.
