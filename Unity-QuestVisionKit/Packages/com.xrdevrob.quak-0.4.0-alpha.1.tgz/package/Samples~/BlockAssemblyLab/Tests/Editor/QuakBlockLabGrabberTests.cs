using System.Reflection;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;

namespace XRDevRob.QUAK.Samples.BlockAssemblyLab.Tests
{
    public sealed class QuakBlockLabGrabberTests : InputTestFixture
    {
        private const BindingFlags PrivateInstance = BindingFlags.Instance | BindingFlags.NonPublic;

        [TestCase(false)]
        [TestCase(true)]
        public void ReleasingControllerCannotMoveHeldPieceToTrackedHand(bool disconnect)
        {
            InputSystem.RegisterLayout(@"{
                ""name"": ""QUAKReleasePose"",
                ""controls"": [
                    { ""name"": ""position"", ""layout"": ""Vector3"" },
                    { ""name"": ""rotation"", ""layout"": ""Quaternion"" },
                    { ""name"": ""grip"", ""layout"": ""Button"", ""format"": ""FLT"" }
                ]
            }");
            var controller = InputSystem.AddDevice("QUAKReleasePose");
            var hand = InputSystem.AddDevice("QUAKReleasePose");
            var owner = new GameObject("Release ownership test");
            try
            {
                var grabber = owner.AddComponent<QuakBlockLabGrabber>();
                ReplaceAction(grabber, "pointerPositionAction", "position", InputActionType.Value, controller, hand);
                ReplaceAction(grabber, "pointerRotationAction", "rotation", InputActionType.Value, controller, hand);
                ReplaceAction(grabber, "gripPressedAction", "grip", InputActionType.Button, controller, hand);
                var controllerPosition = new Vector3(1f, 0f, 0f);
                InputSystem.QueueDeltaStateEvent(controller.GetChildControl<Vector3Control>("position"), controllerPosition);
                InputSystem.QueueDeltaStateEvent(controller.GetChildControl<QuaternionControl>("rotation"), Quaternion.identity);
                InputSystem.QueueDeltaStateEvent(controller.GetChildControl<ButtonControl>("grip"), 1f);
                InputSystem.Update();
                Update(grabber);
                Assert.That(grabber.GripPressed, Is.True);

                var pieceObject = new GameObject("Held piece");
                pieceObject.transform.SetParent(owner.transform);
                pieceObject.transform.position = controllerPosition;
                var piece = pieceObject.AddComponent<QuakBlockLabBlock>();
                typeof(QuakBlockLabBlock).GetMethod("BeginGrab", PrivateInstance).Invoke(piece, null);
                typeof(QuakBlockLabGrabber).GetField("heldBlock", PrivateInstance).SetValue(grabber, piece);
                typeof(QuakBlockLabGrabber).GetField("rotationOffset", PrivateInstance)
                    .SetValue(grabber, Quaternion.identity);

                InputSystem.QueueDeltaStateEvent(hand.GetChildControl<Vector3Control>("position"), new Vector3(20f, 0f, 0f));
                InputSystem.QueueDeltaStateEvent(hand.GetChildControl<QuaternionControl>("rotation"), Quaternion.identity);
                if (disconnect)
                    InputSystem.RemoveDevice(controller);
                else
                    InputSystem.QueueDeltaStateEvent(controller.GetChildControl<ButtonControl>("grip"), 0f);
                InputSystem.Update();
                var positionAction = (InputAction)typeof(QuakBlockLabGrabber)
                    .GetField("pointerPositionAction", PrivateInstance).GetValue(grabber);
                Assert.That(positionAction.activeControl.device, Is.SameAs(hand), "hand must win ordinary pose arbitration");
                Update(grabber);

                Assert.That(piece.IsHeld, Is.False);
                Assert.That(piece.transform.position, Is.EqualTo(controllerPosition));
                var lab = owner.AddComponent<QuakBlockAssemblyLab>();
                typeof(QuakBlockAssemblyLab).GetField("grabber", PrivateInstance).SetValue(lab, grabber);
                typeof(QuakBlockAssemblyLab).GetField("heldPieceId", PrivateInstance).SetValue(lab, "coral");
                StringAssert.Contains("\"heldPieceId\":\"\"", lab.CaptureStateJson());
            }
            finally
            {
                var grabber = owner.GetComponent<QuakBlockLabGrabber>();
                foreach (var name in new[] { "pointerPositionAction", "pointerRotationAction", "gripPressedAction" })
                    ((InputAction)typeof(QuakBlockLabGrabber).GetField(name, PrivateInstance)
                        .GetValue(grabber))?.Dispose();
                Object.DestroyImmediate(owner);
                if (controller.added)
                    InputSystem.RemoveDevice(controller);
                InputSystem.RemoveDevice(hand);
                InputSystem.RemoveLayout("QUAKReleasePose");
            }
        }

        private static void Update(QuakBlockLabGrabber grabber) =>
            typeof(QuakBlockLabGrabber).GetMethod("Update", PrivateInstance).Invoke(grabber, null);

        private static void ReplaceAction(QuakBlockLabGrabber grabber, string fieldName,
            string control, InputActionType type, InputDevice controller, InputDevice hand)
        {
            var field = typeof(QuakBlockLabGrabber).GetField(fieldName, PrivateInstance);
            ((InputAction)field.GetValue(grabber))?.Dispose();
            var action = new InputAction(fieldName, type);
            action.AddBinding(controller[control].path);
            action.AddBinding(hand[control].path);
            field.SetValue(grabber, action);
            action.Enable();
        }
    }
}
