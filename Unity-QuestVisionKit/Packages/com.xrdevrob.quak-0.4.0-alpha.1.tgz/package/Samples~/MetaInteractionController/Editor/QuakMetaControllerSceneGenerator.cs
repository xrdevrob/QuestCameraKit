using System;
using Oculus.Interaction;
using Oculus.Interaction.OVR.Editor.QuickActions;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using XRDevRob.QUAK.MetaOperator;

namespace XRDevRob.QUAK.Samples.MetaInteractionController.Editor
{
    public static class QuakMetaControllerSceneGenerator
    {
        private const string SceneFolder = "Assets/QUAKMetaController";
        private const string ScenePath = SceneFolder + "/QUAKMetaController.unity";
        [MenuItem("QUAK/Samples/Create Meta Controller Grab Scene", priority = 20)]
        public static void CreateScene()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                return;
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null &&
                !EditorUtility.DisplayDialog(
                    "Replace Meta Controller Grab sample?",
                    $"{ScenePath} already exists.",
                    "Replace",
                    "Cancel"))
                return;

            EnsureFolder();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var root = new GameObject("QUAK Meta Controller Grab");
            CreateLighting(root.transform);

            OVRQuickActionsAPI.AddOVRInteractionRig(false);
            var cameraRig = UnityEngine.Object.FindFirstObjectByType<OVRCameraRig>();
            if (cameraRig == null)
                throw new InvalidOperationException("Meta Interaction SDK could not create an OVRCameraRig.");
            cameraRig.transform.SetParent(root.transform, false);
            var manager = cameraRig.GetComponent<OVRManager>();
            var managerSerialized = new SerializedObject(manager);
            managerSerialized.FindProperty("_trackingOriginType").enumValueIndex =
                (int)OVRManager.TrackingOrigin.FloorLevel;
            managerSerialized.ApplyModifiedPropertiesWithoutUndo();

            var bridgeObject = new GameObject("QUAK Operator Bridge", typeof(QuakOperatorBridge));
            bridgeObject.transform.SetParent(root.transform, false);

            CreateStage(root.transform, out var cube, out var body, out var grabInteractable, out var goal);
            ConfigureObserver(root, cube, body, grabInteractable, goal);

            EditorSceneManager.MarkSceneDirty(scene);
            if (!EditorSceneManager.SaveScene(scene, ScenePath))
                throw new InvalidOperationException($"Could not save {ScenePath}.");
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Selection.activeGameObject = cube;
            EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath));
            Debug.Log(
                "[QUAK Meta Controller] Scene created. In the integrated Core-205 Editor lane, " +
                "start Meta XR Simulator, enter Play mode, then run meta-controller-grab.json.");
        }

        private static void CreateStage(
            Transform parent,
            out GameObject cube,
            out Rigidbody body,
            out GrabInteractable grabInteractable,
            out Transform goal)
        {
            var table = CreatePrimitive("Table", PrimitiveType.Cube, parent);
            table.transform.position = new Vector3(0f, 0.9f, 1.15f);
            table.transform.localScale = new Vector3(1.5f, 0.08f, 0.7f);

            cube = CreatePrimitive("Controller Grab Cube", PrimitiveType.Cube, parent);
            cube.transform.position = new Vector3(-0.32f, 1.12f, 1.15f);
            cube.transform.localScale = Vector3.one * 0.18f;
            body = cube.AddComponent<Rigidbody>();
            body.isKinematic = true;
            body.useGravity = false;

            var grabbable = cube.AddComponent<Grabbable>();
            grabbable.MaxGrabPoints = 1;
            grabbable.InjectOptionalTargetTransform(cube.transform);
            grabbable.InjectOptionalRigidbody(body);
            grabbable.InjectOptionalThrowWhenUnselected(false);
            grabbable.InjectOptionalKinematicWhileSelected(true);

            grabInteractable = cube.AddComponent<GrabInteractable>();
            grabInteractable.InjectAllGrabInteractable(body);
            grabInteractable.InjectOptionalPointableElement(grabbable);
            grabInteractable.UseClosestPointAsGrabSource = true;
            ConfigureTarget(
                cube.AddComponent<QuakTarget>(),
                "isdk.controller.cube",
                "Cube selected and moved by Meta Interaction SDK's controller GrabInteractor.");

            var goalObject = CreatePrimitive("Controller Grab Goal", PrimitiveType.Sphere, parent);
            goalObject.transform.position = new Vector3(0.32f, 1.12f, 1.15f);
            goalObject.transform.localScale = Vector3.one * 0.22f;
            goal = goalObject.transform;
            ConfigureTarget(
                goalObject.AddComponent<QuakTarget>(),
                "isdk.controller.goal",
                "Destination pose for the controller-grab cube.");
        }

        private static void ConfigureObserver(
            GameObject root,
            GameObject cube,
            Rigidbody body,
            GrabInteractable grabInteractable,
            Transform goal)
        {
            var observer = root.AddComponent<QuakMetaControllerGrab>();
            var serialized = new SerializedObject(observer);
            serialized.FindProperty("grabInteractable").objectReferenceValue = grabInteractable;
            serialized.FindProperty("body").objectReferenceValue = body;
            serialized.FindProperty("goal").objectReferenceValue = goal;
            serialized.FindProperty("goalRadius").floatValue = 0.12f;
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }

        private static GameObject CreatePrimitive(string name, PrimitiveType type, Transform parent)
        {
            var gameObject = GameObject.CreatePrimitive(type);
            gameObject.name = name;
            gameObject.transform.SetParent(parent, false);
            var material = AssetDatabase.GetBuiltinExtraResource<Material>("Default-Material.mat");
            if (material != null)
                gameObject.GetComponent<Renderer>().sharedMaterial = material;
            return gameObject;
        }

        private static void ConfigureTarget(QuakTarget target, string id, string description)
        {
            target.Configure(id, description);
        }

        private static void CreateLighting(Transform parent)
        {
            var lightObject = new GameObject("Key Light", typeof(Light));
            lightObject.transform.SetParent(parent, false);
            lightObject.transform.rotation = Quaternion.Euler(45f, -30f, 0f);
            lightObject.GetComponent<Light>().type = LightType.Directional;
            lightObject.GetComponent<Light>().intensity = 1.2f;
            RenderSettings.ambientLight = new Color(0.22f, 0.24f, 0.3f);
        }

        private static void EnsureFolder()
        {
            if (!AssetDatabase.IsValidFolder(SceneFolder))
                AssetDatabase.CreateFolder("Assets", "QUAKMetaController");
        }
    }
}
