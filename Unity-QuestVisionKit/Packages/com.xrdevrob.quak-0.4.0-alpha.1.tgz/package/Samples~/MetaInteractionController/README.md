# Meta Interaction SDK controller grab

This optional sample proves that QUAK can drive and independently verify a real
Meta Interaction SDK controller grab. It does not add Interaction SDK as an
QUAK package dependency.

## Requirements

- Unity 6
- `com.meta.xr.sdk.interaction.ovr` 205.0.0
- Meta XR Simulator or a Quest controller session

After importing the sample, choose **QUAK > Samples > Create Meta Controller
Grab Scene**. The generator creates:

- Meta's `OVRCameraRig` and OVR comprehensive interaction rig, including
  the real controller `GrabInteractor` components;
- a cube backed by Interaction SDK `Grabbable` and `GrabInteractable`;
- QUAK source and destination targets; and
- a read-only state provider plus an in-memory reset fixture.

In the integrated Core-205 Editor lane, start Meta XR Simulator, enter Play
mode, and run:

```sh
quak run "Assets/Samples/QUAK/0.4.0-alpha.1/Meta Interaction SDK Controller Grab/Tests/meta-controller-grab.json" --project /absolute/path/to/project
```

The imported path includes the QUAK package version shown by Unity Package
Manager. Adjust it if your installed version differs. A pass requires both
Interaction SDK select/release events and the cube finishing inside the goal;
successful input injection alone is insufficient.

The sample is Simulator validated. Quest and human in-headset validation remain
separate evidence lanes.
