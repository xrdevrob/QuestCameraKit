using System;
using Oculus.Interaction;
using UnityEngine;

namespace XRDevRob.QUAK.Samples.MetaInteractionController
{
    [DisallowMultipleComponent]
    public sealed class QuakMetaControllerGrab : MonoBehaviour,
        IQuakStateProvider,
        IQuakActionHandler
    {
        [SerializeField] private GrabInteractable grabInteractable;
        [SerializeField] private Rigidbody body;
        [SerializeField] private Transform goal;
        [SerializeField, Min(0.01f)] private float goalRadius = 0.12f;

        private Vector3 startPosition;
        private Quaternion startRotation;
        private bool held;
        private int selectCount;
        private int releaseCount;

        public string ProviderId => "meta-controller-grab";
        public string ActionId => "meta-controller-grab.reset";
        public string Description => "Reset the controller-grab cube and observed Interaction SDK events.";
        public bool IsProjectMutation => false;

        private void Awake()
        {
            if (body != null)
            {
                startPosition = body.position;
                startRotation = body.rotation;
            }
        }

        private void OnEnable()
        {
            QuakRegistry.Register((IQuakStateProvider)this);
            QuakRegistry.Register((IQuakActionHandler)this);
            if (grabInteractable != null)
                grabInteractable.WhenPointerEventRaised += HandlePointerEvent;
        }

        private void OnDisable()
        {
            if (grabInteractable != null)
                grabInteractable.WhenPointerEventRaised -= HandlePointerEvent;
            QuakRegistry.Unregister((IQuakStateProvider)this);
            QuakRegistry.Unregister((IQuakActionHandler)this);
        }

        public string CaptureStateJson()
        {
            var distance = body != null && goal != null
                ? Vector3.Distance(body.position, goal.position)
                : -1f;
            return JsonUtility.ToJson(new Snapshot
            {
                ready = grabInteractable != null && body != null && goal != null,
                held = held,
                selectCount = selectCount,
                releaseCount = releaseCount,
                reachedGoal = releaseCount > 0 && distance >= 0f && distance <= goalRadius,
                distanceToGoalMeters = distance
            });
        }

        public string Invoke(string argumentsJson)
        {
            held = false;
            selectCount = 0;
            releaseCount = 0;
            if (body != null)
            {
                body.isKinematic = true;
                body.linearVelocity = Vector3.zero;
                body.angularVelocity = Vector3.zero;
                body.position = startPosition;
                body.rotation = startRotation;
            }
            return CaptureStateJson();
        }

        private void HandlePointerEvent(PointerEvent pointerEvent)
        {
            switch (pointerEvent.Type)
            {
                case PointerEventType.Select:
                    held = true;
                    selectCount++;
                    break;
                case PointerEventType.Unselect:
                    held = false;
                    releaseCount++;
                    break;
                case PointerEventType.Cancel:
                    held = false;
                    break;
            }
        }

        [Serializable]
        private struct Snapshot
        {
            public bool ready;
            public bool held;
            public int selectCount;
            public int releaseCount;
            public bool reachedGoal;
            public float distanceToGoalMeters;
        }
    }
}
