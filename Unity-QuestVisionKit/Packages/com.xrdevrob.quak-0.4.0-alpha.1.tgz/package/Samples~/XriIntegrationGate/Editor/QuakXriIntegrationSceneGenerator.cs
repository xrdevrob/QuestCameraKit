using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;
using UnityEngine.UIElements;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Inputs.Readers;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using UnityEngine.XR.Interaction.Toolkit.UI;
using XRDevRob.QUAK.MetaOperator;

namespace XRDevRob.QUAK.Samples.XriIntegrationGate.Editor
{
    public static class QuakXriIntegrationSceneGenerator
    {
        private const string SceneFolder = "Assets/QUAKXriIntegrationGate";
        private const string ScenePath = SceneFolder + "/QUAKXriIntegrationGate.unity";

        [MenuItem("QUAK/XRI Integration Gate/Create Scene", priority = 20)]
        public static void CreateScene()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                return;

            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null &&
                !Application.isBatchMode &&
                !EditorUtility.DisplayDialog(
                    "Replace XRI Integration Gate?",
                    $"{ScenePath} already exists. Replace it?",
                    "Replace",
                    "Cancel"))
            {
                return;
            }

            EnsureFolder();
            var visualTree = FindSingleAsset<VisualTreeAsset>("QuakXriPanel");
            var theme = FindSingleAsset<ThemeStyleSheet>("QuakXriRuntimeTheme");
            var panelSettings = CreatePanelSettings(theme);

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var root = new GameObject("QUAK XRI Integration Gate");
            root.AddComponent<QuakXriIntegrationXrBootstrap>();
            root.AddComponent<XRInteractionManager>();
            root.AddComponent<XRUIToolkitManager>();

            CreateLight(root.transform);
            CreateCamera(root.transform);
            CreateEventSystem(root.transform);
            CreateController(root.transform);
            var grabbable = CreateGrabbable(root.transform);
            var destination = CreateDestination(root.transform);
            var uiDocument = CreateWorldSpaceUi(root.transform, panelSettings, visualTree);

            var state = root.AddComponent<QuakXriIntegrationState>();
            var stateSerialized = new SerializedObject(state);
            stateSerialized.FindProperty("grabbable").objectReferenceValue = grabbable;
            stateSerialized.FindProperty("destination").objectReferenceValue = destination;
            stateSerialized.FindProperty("uiDocument").objectReferenceValue = uiDocument;
            stateSerialized.ApplyModifiedPropertiesWithoutUndo();

            var bridge = new GameObject("QUAK Operator Bridge");
            bridge.transform.SetParent(root.transform, false);
            bridge.AddComponent<QuakOperatorBridge>();

            EditorSceneManager.MarkSceneDirty(scene);
            if (!EditorSceneManager.SaveScene(scene, ScenePath))
                throw new InvalidOperationException($"Could not save {ScenePath}.");

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Selection.activeGameObject = grabbable.gameObject;
            EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath));
            Debug.Log($"[QUAK XRI] Created {ScenePath}.");
        }

        private static void CreateLight(Transform parent)
        {
            var lightObject = new GameObject("Directional Light", typeof(Light));
            lightObject.transform.SetParent(parent, false);
            lightObject.transform.rotation = Quaternion.Euler(45f, -25f, 0f);
            var light = lightObject.GetComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1.2f;
        }

        private static void CreateCamera(Transform parent)
        {
            var cameraObject = new GameObject(
                "Main Camera",
                typeof(Camera),
                typeof(AudioListener),
                typeof(TrackedPoseDriver));
            cameraObject.tag = "MainCamera";
            cameraObject.transform.SetParent(parent, false);
            cameraObject.transform.position = new Vector3(0f, 1.6f, 0f);

            var camera = cameraObject.GetComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.01f, 0.015f, 0.035f, 1f);
            camera.nearClipPlane = 0.01f;

            ConfigureTrackedPose(
                cameraObject.GetComponent<TrackedPoseDriver>(),
                "<XRHMD>/centerEyePosition",
                "<XRHMD>/centerEyeRotation",
                "Head");
        }

        private static void CreateEventSystem(Transform parent)
        {
            var eventSystemObject = new GameObject(
                "EventSystem",
                typeof(EventSystem),
                typeof(XRUIInputModule),
                typeof(PanelInputConfiguration));
            eventSystemObject.transform.SetParent(parent, false);

            eventSystemObject.GetComponent<XRUIInputModule>().bypassUIToolkitEvents = false;
            var panelInput = eventSystemObject.GetComponent<PanelInputConfiguration>();
            panelInput.processWorldSpaceInput = true;
            panelInput.panelInputRedirection =
                PanelInputConfiguration.PanelInputRedirection.Never;
        }

        private static void CreateController(Transform parent)
        {
            var controller = new GameObject(
                "Right Controller",
                typeof(TrackedPoseDriver),
                typeof(SphereCollider),
                typeof(XRDirectInteractor));
            controller.transform.SetParent(parent, false);
            ConfigureTrackedPose(
                controller.GetComponent<TrackedPoseDriver>(),
                "<XRController>{RightHand}/pointerPosition",
                "<XRController>{RightHand}/pointerRotation",
                "Right Hand Aim");

            var directCollider = controller.GetComponent<SphereCollider>();
            directCollider.radius = 0.12f;
            directCollider.isTrigger = true;
            controller.GetComponent<XRDirectInteractor>().selectInput =
                CreateButtonReader("Grip", "<XRController>{RightHand}/gripPressed");

            var rayObject = new GameObject("UI Ray", typeof(NearFarInteractor));
            rayObject.transform.SetParent(controller.transform, false);
            var ray = rayObject.GetComponent<NearFarInteractor>();
            ray.enableNearCasting = false;
            ray.uiPressInput =
                CreateButtonReader("UI Press", "<XRController>{RightHand}/triggerPressed");
        }

        private static XRGrabInteractable CreateGrabbable(Transform parent)
        {
            var cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            cube.name = "XRI Grabbable";
            cube.transform.SetParent(parent, false);
            cube.transform.position = new Vector3(-0.42f, 1.25f, 1.4f);
            cube.transform.localScale = Vector3.one * 0.18f;
            cube.GetComponent<Renderer>().material.color = new Color(0.2f, 0.55f, 1f);

            var body = cube.AddComponent<Rigidbody>();
            body.useGravity = false;
            var grabbable = cube.AddComponent<XRGrabInteractable>();
            SetTarget(cube.AddComponent<QuakTarget>(), "xri.grabbable",
                "Real XRGrabInteractable selected by the right-hand XRDirectInteractor.");
            return grabbable;
        }

        private static Transform CreateDestination(Transform parent)
        {
            var marker = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            marker.name = "Grab Destination";
            marker.transform.SetParent(parent, false);
            marker.transform.position = new Vector3(-0.05f, 1.25f, 1.7f);
            marker.transform.localScale = new Vector3(0.14f, 0.01f, 0.14f);
            UnityEngine.Object.DestroyImmediate(marker.GetComponent<Collider>());
            marker.GetComponent<Renderer>().material.color = new Color(0.25f, 1f, 0.45f);
            SetTarget(marker.AddComponent<QuakTarget>(), "xri.destination",
                "Destination pose for the XRI grab/release contract.");
            return marker.transform;
        }

        private static UIDocument CreateWorldSpaceUi(
            Transform parent,
            PanelSettings panelSettings,
            VisualTreeAsset visualTree)
        {
            var panelObject = new GameObject(
                "World-Space UI Toolkit Panel",
                typeof(BoxCollider),
                typeof(UIDocument));
            panelObject.transform.SetParent(parent, false);
            panelObject.transform.position = new Vector3(0.43f, 1.4f, 1.7f);
            panelObject.transform.localScale = Vector3.one * 0.2f;

            var collider = panelObject.GetComponent<BoxCollider>();
            collider.size = new Vector3(3.6f, 2.4f, 0.02f);

            var document = panelObject.GetComponent<UIDocument>();
            document.panelSettings = panelSettings;
            document.visualTreeAsset = visualTree;
            document.worldSpaceSizeMode = UIDocument.WorldSpaceSizeMode.Fixed;
            document.worldSpaceSize = new Vector2(360f, 240f);
            document.pivot = Pivot.Center;

            panelObject.AddComponent<QuakUiToolkitTarget>().Configure(
                "xri.ui.button",
                "xri-action",
                "Live bounds of the world-space UI Toolkit Button driven by NearFarInteractor.");
            return document;
        }

        private static PanelSettings CreatePanelSettings(ThemeStyleSheet theme)
        {
            var path = SceneFolder + "/QuakXriPanelSettings.asset";
            var panelSettings = AssetDatabase.LoadAssetAtPath<PanelSettings>(path);
            if (panelSettings == null)
            {
                panelSettings = ScriptableObject.CreateInstance<PanelSettings>();
                AssetDatabase.CreateAsset(panelSettings, path);
            }

            panelSettings.themeStyleSheet = theme;
            panelSettings.renderMode = PanelRenderMode.WorldSpace;
            var serialized = new SerializedObject(panelSettings);
            serialized.FindProperty("m_ColliderUpdateMode").enumValueIndex = 1;
            serialized.FindProperty("m_ColliderIsTrigger").boolValue = false;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(panelSettings);
            return panelSettings;
        }

        private static void ConfigureTrackedPose(
            TrackedPoseDriver driver,
            string positionBinding,
            string rotationBinding,
            string name)
        {
            driver.ignoreTrackingState = true;
            driver.positionInput = new InputActionProperty(new InputAction(
                name + " Position",
                InputActionType.Value,
                positionBinding));
            driver.rotationInput = new InputActionProperty(new InputAction(
                name + " Rotation",
                InputActionType.Value,
                rotationBinding));
        }

        private static XRInputButtonReader CreateButtonReader(string name, string binding)
        {
            var reader = new XRInputButtonReader(
                name,
                inputSourceMode: XRInputButtonReader.InputSourceMode.InputAction);
            reader.inputActionPerformed = new InputAction(
                name,
                InputActionType.Button,
                binding);
            reader.inputActionValue = new InputAction(
                name + " Value",
                InputActionType.Value,
                binding);
            return reader;
        }

        private static void SetTarget(QuakTarget target, string id, string description)
        {
            target.Configure(id, description);
        }

        private static T FindSingleAsset<T>(string name) where T : UnityEngine.Object
        {
            var guids = AssetDatabase.FindAssets($"{name} t:{typeof(T).Name}");
            if (guids.Length != 1)
            {
                throw new InvalidOperationException(
                    $"Expected exactly one {typeof(T).Name} named {name}; found {guids.Length}.");
            }

            return AssetDatabase.LoadAssetAtPath<T>(AssetDatabase.GUIDToAssetPath(guids[0]));
        }

        private static void EnsureFolder()
        {
            if (!AssetDatabase.IsValidFolder(SceneFolder))
                AssetDatabase.CreateFolder("Assets", "QUAKXriIntegrationGate");
        }
    }
}
