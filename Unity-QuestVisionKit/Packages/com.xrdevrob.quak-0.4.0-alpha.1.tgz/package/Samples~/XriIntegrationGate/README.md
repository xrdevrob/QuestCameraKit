# XRI and UI Toolkit Integration Gate

This optional sample generates one scene that exercises two real interaction
contracts through QUAK and Meta XR Operator:

- a right-hand `XRDirectInteractor` selects and releases an
  `XRGrabInteractable`; and
- a right-hand `NearFarInteractor` clicks a world-space UI Toolkit `Button`.

The tests assert independent product state populated by XRI selection events and
the UI Toolkit `Button.clicked` event. Input injection by itself is not treated as
success.

## Requirements

- Unity 6.2 or newer (world-space UI Toolkit input is unavailable in older
  Editors)
- XR Interaction Toolkit 3.3.1 (3.2.0 is the upstream minimum)
- QUAK's normal Meta XR Simulator and Meta XR Operator setup
- OpenXR enabled for the selected Editor or Standalone build target

XR Interaction Toolkit remains an optional consumer dependency and is not added
to QUAK's package dependencies. Install XRI 3.3.1 before importing this sample.

## Run

1. Choose **QUAK > XRI Integration Gate > Create Scene**.
2. In the integrated Core-205 Editor lane, start Meta XR Simulator, enter Play
   mode, and keep the generated scene open. In the no-Core lane, launch a built
   Development Player through the desktop Operator API layer instead.
3. Run `Tests/xri-grab-release.json` and
   `Tests/xri-ui-toolkit-button.json` through the normal QUAK CLI flow.

The generator configures the world-space `PanelSettings`, matching collider,
`PanelInputConfiguration` with **No input redirection**, `XRUIToolkitManager`,
and an `XRUIInputModule` that does not bypass UI Toolkit events.

The sample and its JSON contracts are compile/static validated in the repository.
Live simulator/device evidence is still pending and should be recorded before
claiming hardware or runtime coverage.
