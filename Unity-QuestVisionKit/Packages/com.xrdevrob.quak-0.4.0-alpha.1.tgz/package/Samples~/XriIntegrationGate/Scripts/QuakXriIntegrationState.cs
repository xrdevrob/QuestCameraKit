using System;
using UnityEngine;
using UnityEngine.UIElements;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

namespace XRDevRob.QUAK.Samples.XriIntegrationGate
{
    /// <summary>
    /// Exposes product-side XRI and UI Toolkit outcomes independently from the
    /// Operator input tool that attempted them.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class QuakXriIntegrationState : MonoBehaviour,
        IQuakStateProvider,
        IQuakActionHandler
    {
        [SerializeField] private XRGrabInteractable grabbable;
        [SerializeField] private Transform destination;
        [SerializeField] private UIDocument uiDocument;

        private Vector3 initialPosition;
        private Quaternion initialRotation;
        private Button actionButton;
        private Label stateLabel;
        private bool selected;
        private bool selectedOnce;
        private bool releasedNearDestination;
        private int selectCount;
        private int releaseCount;
        private int uiClickCount;

        public string ProviderId => "xri-integration";
        public string ActionId => "xri-integration.reset";
        public string Description => "Reset the optional XRI integration sample state.";
        public bool IsProjectMutation => false;

        private void Awake()
        {
            if (grabbable != null)
            {
                initialPosition = grabbable.transform.position;
                initialRotation = grabbable.transform.rotation;
            }
        }

        private void OnEnable()
        {
            QuakRegistry.Register((IQuakStateProvider)this);
            QuakRegistry.Register((IQuakActionHandler)this);
            if (grabbable != null)
            {
                grabbable.selectEntered.AddListener(OnSelectEntered);
                grabbable.selectExited.AddListener(OnSelectExited);
            }
        }

        private void Start()
        {
            BindUi();
            RefreshLabel();
        }

        private void Update()
        {
            if (actionButton == null)
                BindUi();
        }

        private void OnDisable()
        {
            if (actionButton != null)
                actionButton.clicked -= OnUiClicked;
            actionButton = null;
            stateLabel = null;

            if (grabbable != null)
            {
                grabbable.selectEntered.RemoveListener(OnSelectEntered);
                grabbable.selectExited.RemoveListener(OnSelectExited);
            }

            QuakRegistry.Unregister((IQuakStateProvider)this);
            QuakRegistry.Unregister((IQuakActionHandler)this);
        }

        public string CaptureStateJson()
        {
            return JsonUtility.ToJson(new Snapshot
            {
                ready = grabbable != null && destination != null && actionButton != null,
                selected = selected,
                selectedOnce = selectedOnce,
                releasedNearDestination = releasedNearDestination,
                selectCount = selectCount,
                releaseCount = releaseCount,
                uiReady = actionButton != null,
                uiClickCount = uiClickCount,
                grabbablePosition = grabbable != null
                    ? grabbable.transform.position
                    : Vector3.zero,
                destinationPosition = destination != null
                    ? destination.position
                    : Vector3.zero
            });
        }

        public string Invoke(string argumentsJson)
        {
            selected = false;
            selectedOnce = false;
            releasedNearDestination = false;
            selectCount = 0;
            releaseCount = 0;
            uiClickCount = 0;

            if (grabbable != null)
            {
                grabbable.transform.SetPositionAndRotation(initialPosition, initialRotation);
                if (grabbable.TryGetComponent<Rigidbody>(out var body))
                {
                    body.linearVelocity = Vector3.zero;
                    body.angularVelocity = Vector3.zero;
                }
            }

            RefreshLabel();
            return CaptureStateJson();
        }

        private void BindUi()
        {
            if (uiDocument == null || uiDocument.rootVisualElement == null)
                return;

            var nextButton = uiDocument.rootVisualElement.Q<Button>("xri-action");
            if (nextButton == null || nextButton == actionButton)
                return;

            if (actionButton != null)
                actionButton.clicked -= OnUiClicked;
            actionButton = nextButton;
            actionButton.clicked += OnUiClicked;
            stateLabel = uiDocument.rootVisualElement.Q<Label>("xri-state");
            RefreshLabel();
        }

        private void OnSelectEntered(SelectEnterEventArgs args)
        {
            selected = true;
            selectedOnce = true;
            selectCount++;
            RefreshLabel();
        }

        private void OnSelectExited(SelectExitEventArgs args)
        {
            selected = false;
            releaseCount++;
            releasedNearDestination = destination != null &&
                Vector3.Distance(grabbable.transform.position, destination.position) <= 0.25f;
            RefreshLabel();
        }

        private void OnUiClicked()
        {
            uiClickCount++;
            RefreshLabel();
        }

        private void RefreshLabel()
        {
            if (stateLabel != null)
            {
                stateLabel.text =
                    $"XRI selects: {selectCount} / releases: {releaseCount} / UI clicks: {uiClickCount}";
            }
        }

        [Serializable]
        private sealed class Snapshot
        {
            public bool ready;
            public bool selected;
            public bool selectedOnce;
            public bool releasedNearDestination;
            public int selectCount;
            public int releaseCount;
            public bool uiReady;
            public int uiClickCount;
            public Vector3 grabbablePosition;
            public Vector3 destinationPosition;
        }
    }
}
