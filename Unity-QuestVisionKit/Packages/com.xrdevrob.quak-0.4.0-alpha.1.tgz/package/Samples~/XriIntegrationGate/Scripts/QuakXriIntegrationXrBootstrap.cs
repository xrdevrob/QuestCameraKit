using System;
using UnityEngine;
using UnityEngine.XR.Management;

namespace XRDevRob.QUAK.Samples.XriIntegrationGate
{
    [DisallowMultipleComponent]
    [DefaultExecutionOrder(-10000)]
    public sealed class QuakXriIntegrationXrBootstrap : MonoBehaviour
    {
        private bool ownsLoader;

        private void Start()
        {
            var manager = XRGeneralSettings.Instance != null
                ? XRGeneralSettings.Instance.Manager
                : null;
            if (manager == null)
            {
                Debug.LogError("[QUAK XRI] XR Plug-in Management is not configured.");
                return;
            }

            try
            {
                if (manager.activeLoader == null)
                {
                    manager.InitializeLoaderSync();
                    ownsLoader = manager.activeLoader != null;
                }

                if (manager.activeLoader == null)
                {
                    Debug.LogError("[QUAK XRI] Enable OpenXR for the selected runtime; rebuild and relaunch a Standalone player, or restart Play Mode in the integrated Editor lane.");
                    return;
                }

                manager.StartSubsystems();
            }
            catch (Exception exception)
            {
                Debug.LogError($"[QUAK XRI] XR startup failed: {exception.Message}");
            }
        }

        private void OnDestroy()
        {
            if (!ownsLoader || XRGeneralSettings.Instance == null)
                return;

            var manager = XRGeneralSettings.Instance.Manager;
            if (manager == null)
                return;

            manager.StopSubsystems();
            manager.DeinitializeLoader();
        }
    }
}
