using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using XRDevRob.QUAK.Editor.ControlPanel;
using XRDevRob.QUAK.Direct;
using XRDevRob.QUAK.Direct.Editor;
using XRDevRob.QUAK.MetaOperator;
using UiToolkitButton = UnityEngine.UIElements.Button;
using VisualElement = UnityEngine.UIElements.VisualElement;

namespace XRDevRob.QUAK.Tests.Editor
{
    public sealed class QuakRegistryTests
    {
        [Test]
        public void ProjectSetupEntryPointIsPublicStaticAndParameterless()
        {
            var method = typeof(QuakProjectSetup).GetMethod(nameof(QuakProjectSetup.ConfigureProject));

            Assert.That(method, Is.Not.Null);
            Assert.That(method.IsPublic && method.IsStatic, Is.True);
            Assert.That(method.GetParameters(), Is.Empty);
            Assert.That(method.ReturnType, Is.EqualTo(typeof(void)));
        }

        [Test]
        public void DirectInternetPermissionIsDevelopmentBuildScoped()
        {
            var provider = new QuakDirectInternetPermissionProvider();
            try
            {
                QuakDirectLayerBuildProcessor.IncludeInternetPermission = false;
                Assert.That(provider.ProvideManifestRequirement(), Is.Null);

                QuakDirectLayerBuildProcessor.IncludeInternetPermission = true;
                var requirement = provider.ProvideManifestRequirement();
                Assert.That(requirement, Is.Not.Null);
                Assert.That(requirement.NewElements, Has.Count.EqualTo(2));
                Assert.That(
                    requirement.NewElements[0].Attributes["name"],
                    Is.EqualTo("android.permission.INTERNET"));
                Assert.That(
                    requirement.NewElements[1].Attributes["name"],
                    Is.EqualTo("com.oculus.feature.PASSTHROUGH"));
                Assert.That(
                    requirement.NewElements[1].Attributes["required"],
                    Is.EqualTo("true"));
            }
            finally
            {
                QuakDirectLayerBuildProcessor.IncludeInternetPermission = false;
            }
        }

        [Test]
        public void HorizonHandPermissionRewriteIsDevelopmentBuildScoped()
        {
            var projectRoot = Path.Combine(
                Path.GetTempPath(),
                $"quak-gradle-{System.Guid.NewGuid():N}");
            var manifestPath = Path.Combine(
                projectRoot, "src", "main", "AndroidManifest.xml");
            Directory.CreateDirectory(Path.GetDirectoryName(manifestPath));
            File.WriteAllText(
                manifestPath,
                "<uses-permission android:name=\"com.oculus.permission.HAND_TRACKING\" />");
            var processor = new QuakHorizonHandTrackingPermissionProcessor();

            try
            {
                QuakDirectLayerBuildProcessor.IncludeInternetPermission = false;
                processor.OnPostGenerateGradleAndroidProject(projectRoot);
                Assert.That(
                    File.ReadAllText(manifestPath),
                    Does.Contain("com.oculus.permission.HAND_TRACKING"));

                QuakDirectLayerBuildProcessor.IncludeInternetPermission = true;
                processor.OnPostGenerateGradleAndroidProject(projectRoot);
                Assert.That(
                    File.ReadAllText(manifestPath),
                    Does.Contain("horizonos.permission.HAND_TRACKING"));
            }
            finally
            {
                QuakDirectLayerBuildProcessor.IncludeInternetPermission = false;
                Directory.Delete(projectRoot, true);
            }
        }

        [Test]
        public void ProjectSetupFileStepsAreIdempotent()
        {
            var projectRoot = Path.Combine(
                Path.GetTempPath(),
                $"quak-setup-{System.Guid.NewGuid():N}");
            Directory.CreateDirectory(Path.Combine(projectRoot, "Assets"));
            Directory.CreateDirectory(Path.Combine(projectRoot, "Packages"));
            Directory.CreateDirectory(Path.Combine(projectRoot, "ProjectSettings"));
            File.WriteAllText(Path.Combine(projectRoot, "Packages", "manifest.json"), "{}");
            File.WriteAllText(Path.Combine(projectRoot, "ProjectSettings", "ProjectVersion.txt"), "");
            File.WriteAllText(
                Path.Combine(projectRoot, ".gitignore"),
                ".quak/evidence/**/artifacts/*.png\nkeep-me\n");

            try
            {
                Assert.That(QuakProjectSetup.IsEvidenceMediaIgnored(projectRoot), Is.False);
                QuakProjectSetup.PreflightCore(projectRoot);
                QuakProjectSetup.EnsureConfig(projectRoot);
                QuakProjectSetup.EnsureEvidenceMediaIgnored(projectRoot);
                QuakProjectSetup.EnsureSmokeTest(projectRoot);
                var firstGitIgnore = File.ReadAllText(Path.Combine(projectRoot, ".gitignore"));

                QuakProjectSetup.PreflightCore(projectRoot);
                QuakProjectSetup.EnsureConfig(projectRoot);
                QuakProjectSetup.EnsureEvidenceMediaIgnored(projectRoot);
                QuakProjectSetup.EnsureSmokeTest(projectRoot);

                Assert.That(File.ReadAllText(Path.Combine(projectRoot, ".gitignore")), Is.EqualTo(firstGitIgnore));
                var ignoreLines = File.ReadAllLines(Path.Combine(projectRoot, ".gitignore"));
                Assert.That(ignoreLines, Does.Not.Contain(".quak/evidence/**/artifacts/*.png"));
                Assert.That(ignoreLines, Does.Contain("keep-me"));
                foreach (var entry in QuakProjectSetup.EvidenceMediaIgnoreEntries)
                    Assert.That(ignoreLines.Count(line => line == entry), Is.EqualTo(1));
                Assert.That(QuakProjectSetup.IsEvidenceMediaIgnored(projectRoot), Is.True);
                Assert.That(File.Exists(Path.Combine(projectRoot, QuakProjectSetup.ConfigRelativePath)), Is.True);
                Assert.That(File.Exists(Path.Combine(projectRoot, QuakProjectSetup.SmokeTestRelativePath)), Is.True);
            }
            finally
            {
                Directory.Delete(projectRoot, true);
            }
        }

        [Test]
        public void UiToolkitTargetRejectsMissingDuplicateAndDetachedElements()
        {
            var root = new VisualElement();

            Assert.That(
                QuakRegistry.TryFindLiveUiToolkitElement(
                    root, "action", out _, out var missingError, out var missingUnavailable),
                Is.False);
            Assert.That(missingError, Does.Contain("no element"));
            Assert.That(missingUnavailable, Is.True);

            root.Add(new UiToolkitButton { name = "action" });
            Assert.That(
                QuakRegistry.TryFindLiveUiToolkitElement(
                    root, "action", out _, out var detachedError, out var detachedUnavailable),
                Is.False);
            Assert.That(detachedError, Does.Contain("detached"));
            Assert.That(detachedUnavailable, Is.True);

            root.Add(new UiToolkitButton { name = "action" });
            Assert.That(
                QuakRegistry.TryFindLiveUiToolkitElement(
                    root, "action", out _, out var duplicateError, out var duplicateUnavailable),
                Is.False);
            Assert.That(duplicateError, Does.Contain("2 elements"));
            Assert.That(duplicateUnavailable, Is.False);
        }

        [Test]
        public void UiToolkitTargetRetainsExplicitSemanticRole()
        {
            var gameObject = new GameObject("QUAK UI Toolkit Role");
            try
            {
                var target = gameObject.AddComponent<QuakUiToolkitTarget>();
                target.Configure("menu.play", "play", "Play media", "button");

                Assert.That(target.SemanticRole, Is.EqualTo("button"));
            }
            finally
            {
                Object.DestroyImmediate(gameObject);
            }
        }

        [Test]
        public void ExplicitTargetDiscoveryIncludesHideFlagsObjectsInLoadedScenes()
        {
            var gameObject = new GameObject("QUAK Hidden Explicit Target")
            {
                hideFlags = HideFlags.HideAndDontSave
            };
            try
            {
                SceneManager.MoveGameObjectToScene(gameObject, SceneManager.GetActiveScene());
                gameObject.AddComponent<QuakTarget>().Configure("hidden.explicit");

                Assert.That(
                    QuakRegistry.CaptureCapabilities().targets.Any(
                        item => item.id == "hidden.explicit"),
                    Is.True);
            }
            finally
            {
                Object.DestroyImmediate(gameObject);
            }
        }

        [Test]
        public void ExplicitTargetDiscoveryExcludesDontSavePrefabAssets()
        {
            var path = $"Assets/quak-target-{System.Guid.NewGuid():N}.prefab";
            var source = new GameObject("QUAK Prefab Target");
            try
            {
                source.AddComponent<QuakTarget>().Configure("prefab.explicit");
                PrefabUtility.SaveAsPrefabAsset(source, path);
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                prefab.hideFlags = HideFlags.DontSave;

                Assert.That(
                    QuakRegistry.IsDiscoverableExplicitTarget(
                        prefab.GetComponent<QuakTarget>()),
                    Is.False);
            }
            finally
            {
                Object.DestroyImmediate(source);
                AssetDatabase.DeleteAsset(path);
            }
        }

        [Test]
        public void UiToolkitTargetMapsSubBoundsThroughDocumentCollider()
        {
            var gameObject = new GameObject("QUAK UI Toolkit Bounds", typeof(BoxCollider));
            try
            {
                gameObject.transform.position = new Vector3(10f, 20f, 30f);
                gameObject.transform.localScale = new Vector3(2f, 3f, 4f);
                var collider = gameObject.GetComponent<BoxCollider>();
                collider.center = new Vector3(1f, 2f, 3f);
                collider.size = new Vector3(4f, 2f, 0.4f);

                var bounds = QuakRegistry.MapUiToolkitBounds(
                    collider,
                    new Rect(0f, 0f, 400f, 200f),
                    new Rect(100f, 50f, 100f, 50f),
                    out var center);

                Assert.That(center, Is.EqualTo(new Vector3(11f, 26.75f, 42f)));
                Assert.That(bounds.center, Is.EqualTo(center));
                Assert.That(
                    Vector3.Distance(bounds.size, new Vector3(2f, 1.5f, 1.6f)),
                    Is.LessThan(0.0001f));
            }
            finally
            {
                Object.DestroyImmediate(gameObject);
            }
        }

        [Test]
        public void OperatorBridgeBootstrapIsIdempotent()
        {
            var existing = Object.FindAnyObjectByType<QuakOperatorBridge>();
            var bridge = QuakOperatorBridge.EnsureBridgeInstance();
            try
            {
                Assert.That(QuakOperatorBridge.EnsureBridgeInstance(), Is.SameAs(bridge));
            }
            finally
            {
                if (existing == null)
                    Object.DestroyImmediate(bridge.gameObject);
            }
        }

        [Test]
        public void OperatorBridgeStopsUpdatingAfterRegistrationAttempt()
        {
            var existing = Object.FindAnyObjectByType<QuakOperatorBridge>();
            var bridge = QuakOperatorBridge.EnsureBridgeInstance();
            var attempted = typeof(QuakOperatorBridge).GetField(
                "registrationAttempted",
                BindingFlags.NonPublic | BindingFlags.Static);
            var update = typeof(QuakOperatorBridge).GetMethod(
                "Update",
                BindingFlags.NonPublic | BindingFlags.Instance);
            var reset = typeof(QuakOperatorBridge).GetMethod(
                "ResetStatics",
                BindingFlags.NonPublic | BindingFlags.Static);
            try
            {
                attempted.SetValue(null, true);
                update.Invoke(bridge, null);
                Assert.That(bridge.enabled, Is.False);
            }
            finally
            {
                reset.Invoke(null, null);
                if (existing == null)
                    Object.DestroyImmediate(bridge.gameObject);
                else
                    bridge.enabled = true;
            }
        }

        [Test]
        public unsafe void OperatorCallbackExecutesOnceAcrossNativeTwoCallFlow()
        {
            var calls = 0;
            var callback = new QuakOperatorToolCallback(
                "test.once",
                _ => (++calls).ToString());
            var handle = GCHandle.Alloc(callback);
            try
            {
                var parameters = Encoding.UTF8.GetBytes("{}\0");
                fixed (byte* parameterPointer = parameters)
                {
                    uint size = 0;
                    Assert.That(
                        QuakOperatorFeature.NativeCallbackTrampoline(
                            null,
                            0,
                            &size,
                            parameterPointer,
                            (void*)GCHandle.ToIntPtr(handle)),
                        Is.EqualTo(XrResult.Success));
                    Assert.That(size, Is.EqualTo(2));
                    Assert.That(calls, Is.EqualTo(1));

                    byte* output = stackalloc byte[(int)size];
                    Assert.That(
                        QuakOperatorFeature.NativeCallbackTrampoline(
                            output,
                            size,
                            &size,
                            parameterPointer,
                            (void*)GCHandle.ToIntPtr(handle)),
                        Is.EqualTo(XrResult.Success));
                    Assert.That(Marshal.PtrToStringUTF8((System.IntPtr)output), Is.EqualTo("1"));
                    Assert.That(calls, Is.EqualTo(1));

                    Assert.That(
                        QuakOperatorFeature.NativeCallbackTrampoline(
                            null,
                            0,
                            &size,
                            parameterPointer,
                            (void*)GCHandle.ToIntPtr(handle)),
                        Is.EqualTo(XrResult.Success));
                    Assert.That(calls, Is.EqualTo(2));
                }
            }
            finally
            {
                handle.Free();
            }
        }

        [Test]
        public void OperatorCallbackBoundsUnfinishedInterleavedResults()
        {
            var calls = 0;
            var callback = new QuakOperatorToolCallback(
                "test.pending",
                _ => (++calls).ToString());

            for (var index = 0; index < 16; index++)
                Assert.That(callback.ResultFor(index.ToString()), Is.EqualTo((index + 1).ToString()));
            Assert.That(callback.ResultFor("0"), Is.EqualTo("1"));
            Assert.That(calls, Is.EqualTo(16));
            Assert.Throws<System.InvalidOperationException>(() => callback.ResultFor("overflow"));
        }

        [Test]
        public void OperatorCallbackQueuesIdenticalInterleavedInvocations()
        {
            var calls = 0;
            var callback = new QuakOperatorToolCallback(
                "test.interleaved",
                _ => (++calls).ToString());

            Assert.That(callback.ResultFor("{}", true), Is.EqualTo("1"));
            Assert.That(callback.ResultFor("{}", true), Is.EqualTo("2"));
            Assert.That(callback.ResultFor("{}"), Is.EqualTo("1"));
            callback.Complete("{}");
            Assert.That(callback.ResultFor("{}"), Is.EqualTo("2"));
            callback.Complete("{}");
            Assert.That(calls, Is.EqualTo(2));
        }

        [Test]
        public void OperatorCallbackRecoversStaleUnfinishedResults()
        {
            long now = 0;
            var callback = new QuakOperatorToolCallback(
                "test.stale",
                value => value,
                () => now);
            for (var index = 0; index < 16; index++)
                callback.ResultFor(index.ToString(), true);
            Assert.Throws<System.InvalidOperationException>(() =>
                callback.ResultFor("overflow", true));

            now = System.TimeSpan.FromSeconds(31).Ticks;

            Assert.That(callback.ResultFor("recovered", true), Is.EqualTo("recovered"));
        }

        [Test]
        public void OperatorCallbackSerializesConcurrentPendingState()
        {
            var calls = 0;
            var results = new ConcurrentBag<string>();
            var callback = new QuakOperatorToolCallback(
                "test.concurrent",
                _ => Interlocked.Increment(ref calls).ToString());

            Parallel.For(0, 16, index =>
                results.Add(callback.ResultFor(index.ToString(), true)));

            Assert.That(results.Count(), Is.EqualTo(16));
            Assert.That(results.Distinct().Count(), Is.EqualTo(16));
            Assert.That(calls, Is.EqualTo(16));
            Parallel.For(0, 16, index => callback.Complete(index.ToString()));
        }

        [Test]
        public unsafe void OperatorResultBufferUsesOpenXrTwoCallContract()
        {
            const string content = "{\"value\":\"é\"}";
            var expectedSize = (uint)Encoding.UTF8.GetByteCount(content) + 1;
            uint size = 0;

            Assert.That(
                QuakOperatorFeature.WriteResultToBuffer(content, null, 0, &size),
                Is.EqualTo(XrResult.Success));
            Assert.That(size, Is.EqualTo(expectedSize));

            byte* tooSmall = stackalloc byte[(int)expectedSize - 1];
            Assert.That(
                QuakOperatorFeature.WriteResultToBuffer(
                    content,
                    tooSmall,
                    expectedSize - 1,
                    &size),
                Is.EqualTo(XrResult.ErrorSizeInsufficient));

            byte* output = stackalloc byte[(int)expectedSize];
            Assert.That(
                QuakOperatorFeature.WriteResultToBuffer(
                    content,
                    output,
                    expectedSize,
                    &size),
                Is.EqualTo(XrResult.Success));
            Assert.That(
                Marshal.PtrToStringUTF8((System.IntPtr)output),
                Is.EqualTo(content));
        }

        [Test]
        public void OperatorNativeStructLayoutMatchesMetax1Arm64Abi()
        {
            Assert.That(System.IntPtr.Size, Is.EqualTo(8));
            Assert.That(Marshal.SizeOf<XrAgenticExternalToolParameter>(), Is.EqualTo(5216));
            Assert.That(
                Marshal.OffsetOf<XrAgenticExternalToolParameter>(
                    nameof(XrAgenticExternalToolParameter.ParameterType)).ToInt32(),
                Is.EqualTo(1104));
            Assert.That(Marshal.SizeOf<XrAgenticExternalToolRegisterInfo>(), Is.EqualTo(1144));
            Assert.That(
                Marshal.OffsetOf<XrAgenticExternalToolRegisterInfo>(
                    nameof(XrAgenticExternalToolRegisterInfo.ToolParameters)).ToInt32(),
                Is.EqualTo(1112));
        }

        [Test]
        public void ReceiptSourceHashMatchingRejectsLegacyAndChangedDefinitions()
        {
            var matches = typeof(QuakControlPanel).GetMethod(
                "SourceHashesMatch",
                BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(matches, Is.Not.Null);
            var current = new string('a', 64);

            Assert.That(matches.Invoke(null, new object[] { current, current.ToUpperInvariant() }), Is.True);
            Assert.That(matches.Invoke(null, new object[] { current, string.Empty }), Is.False);
            Assert.That(matches.Invoke(null, new object[] { current, new string('b', 64) }), Is.False);
        }

        [Test]
        public void HumanReviewApprovalRequiresEligibleReceiptAndNoPriorRejection()
        {
            var canApprove = typeof(QuakControlPanel).GetMethod(
                "CanApproveHumanReview",
                BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(canApprove, Is.Not.Null);

            Assert.That(canApprove.Invoke(null, new object[] { true, "pending" }), Is.True);
            Assert.That(canApprove.Invoke(null, new object[] { false, "pending" }), Is.False);
            Assert.That(
                canApprove.Invoke(null, new object[] { true, "changes_requested" }),
                Is.False);
        }

        [Test]
        public void MissingHumanReviewDoesNotReadRecording()
        {
            var read = typeof(QuakControlPanel).GetMethod(
                "ReadHumanReview",
                BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(read, Is.Not.Null);
            var directory = Path.Combine(
                Path.GetTempPath(),
                $"quak-review-{System.Guid.NewGuid():N}");
            Directory.CreateDirectory(directory);

            try
            {
                var result = read.Invoke(null, new object[]
                {
                    Path.Combine(directory, "receipt.json"),
                    Path.Combine(directory, "missing-recording.mp4"),
                    new string('a', 64),
                    true
                });
                var error = result.GetType().GetProperty("Error");

                Assert.That(error, Is.Not.Null);
                Assert.That(error.GetValue(result), Is.EqualTo(string.Empty));
            }
            finally
            {
                Directory.Delete(directory, true);
            }
        }

        [TestCase("passed", "passed", "recorded_pending_review", "complete", false, false, true)]
        [TestCase("passed", "not_assessed", "recorded_pending_review", "complete", false, false, false)]
        [TestCase("passed", "passed", "failed", "complete", false, false, false)]
        [TestCase("failed", "passed", "recorded_pending_review", "complete", false, false, false)]
        [TestCase("passed", "passed", "recorded_pending_review", "failed", false, false, false)]
        [TestCase("passed", "passed", "recorded_pending_review", "complete", true, false, false)]
        [TestCase("passed", "passed", "recorded_pending_review", "complete", false, true, false)]
        [TestCase(null, null, null, "complete", false, false, true)]
        [TestCase(null, null, null, "complete", true, false, false)]
        [TestCase("", "", "", "complete", false, false, false)]
        public void ReceiptApprovalMatchesProductAndEvidenceOutcomes(
            string overall, string product, string evidence, string inspection,
            bool captureError, bool durationExceeded, bool expected)
        {
            var parse = typeof(QuakControlPanel).GetMethod("ParseReceipt", BindingFlags.NonPublic | BindingFlags.Static);
            var predicate = typeof(QuakControlPanel).GetMethod(
                "IsReceiptReviewApprovable", BindingFlags.NonPublic | BindingFlags.Static);
            var outcomes = overall == null ? string.Empty :
                $"\"outcomes\":{{\"overall\":\"{overall}\",\"product\":\"{product}\",\"evidence\":\"{evidence}\"}},";
            var errors = captureError ? "[\"capture failed\"]" : "[]";
            var json = "{\"status\":\"passed\"," + outcomes +
                "\"visual_evidence\":{\"inspection\":{\"status\":\"" + inspection + "\"}," +
                "\"capture_errors\":" + errors + ",\"duration_limit_exceeded\":" +
                (durationExceeded ? "true" : "false") + "}}";
            var receipt = parse.Invoke(null, new object[] { json });
            Assert.That(predicate.Invoke(null, new[] { receipt }), Is.EqualTo(expected));
        }

        [Test]
        public void ControlPanelCancellationTerminatesDescendantProcesses()
        {
            if (Application.platform == RuntimePlatform.WindowsEditor)
                Assert.Ignore("The process-tree regression fixture uses /bin/sh.");

            var startInfo = new System.Diagnostics.ProcessStartInfo
            {
                FileName = "/bin/sh",
                UseShellExecute = false,
                RedirectStandardOutput = true
            };
            startInfo.ArgumentList.Add("-c");
            startInfo.ArgumentList.Add(
                "/bin/sh -c '/bin/sleep 60 & echo $!; wait' & wait");
            using var process = System.Diagnostics.Process.Start(startInfo);
            Assert.That(process, Is.Not.Null);
            var childId = int.Parse(process.StandardOutput.ReadLine());
            var terminate = typeof(QuakControlPanel).GetMethod(
                "KillProcessTree",
                BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(terminate, Is.Not.Null);
            using (var unstarted = new System.Diagnostics.Process())
                Assert.DoesNotThrow(() => terminate.Invoke(null, new object[] { unstarted }));

            try
            {
                terminate.Invoke(null, new object[] { process });

                Assert.That(process.WaitForExit(5000), Is.True);
                Assert.That(
                    SpinWait.SpinUntil(() => ProcessExited(childId), 5000),
                    Is.True,
                    "The command's descendant survived cancellation.");
            }
            finally
            {
                if (!process.HasExited)
                    process.Kill();
                try
                {
                    using var child = System.Diagnostics.Process.GetProcessById(childId);
                    if (!child.HasExited)
                        child.Kill();
                }
                catch (System.ArgumentException)
                {
                }
            }
        }

#if QUAK_META_INTERACTION_SDK_TESTS
        [Test]
        public void MetaControllerDiscoveryScheduleDoesNotExpire()
        {
            var installer = System.AppDomain.CurrentDomain.GetAssemblies()
                .Single(assembly => assembly.GetName().Name == "XRDevRob.QUAK.MetaInteraction")
                .GetType("XRDevRob.QUAK.MetaInteraction.QuakMetaInteractionOpenXrInstaller");
            var advance = installer?.GetMethod(
                "AdvanceScanSchedule",
                BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(advance, Is.Not.Null);
            var schedule = new object[] { 0f, 0f };

            Assert.That(advance.Invoke(null, schedule), Is.True);
            Assert.That(schedule[1], Is.EqualTo(1f));
            schedule[0] = 0.5f;
            Assert.That(advance.Invoke(null, schedule), Is.False);
            schedule[0] = 3600f;
            Assert.That(advance.Invoke(null, schedule), Is.True);
            Assert.That(schedule[1], Is.EqualTo(3601f));
        }
#endif

        [Test]
        public void HumanReviewParserEnforcesTheSidecarSchema()
        {
            var parse = typeof(QuakControlPanel).GetMethod(
                "ParseHumanReview",
                BindingFlags.NonPublic | BindingFlags.Static);
            Assert.That(parse, Is.Not.Null);

            var receiptSha = new string('a', 64);
            var videoSha = new string('b', 64);
            const string reviewedAt = "2026-08-23T10:03:00Z";
            const string annotation =
                "[{\"at_seconds\":1.25,\"category\":\"product_bug\"," +
                "\"observed\":\"Menu stayed open\",\"expected\":\"Menu closes\"," +
                "\"created_at\":\"2026-08-23T10:02:00+00:00\"}]";
            string Review(string status, string annotations) =>
                "{\"schema_version\":1," +
                $"\"receipt_sha256\":\"{receiptSha}\"," +
                $"\"video_sha256\":\"{videoSha}\"," +
                $"\"status\":\"{status}\",\"reviewed_at\":\"{reviewedAt}\"," +
                $"\"annotations\":{annotations}}}";

            var valid = Review("changes_requested", annotation);
            Assert.That(parse.Invoke(null, new object[] { valid }), Is.Not.Null);
            Assert.That(
                parse.Invoke(null, new object[] { Review("approved", "[]") }),
                Is.Not.Null);

            var invalidReviews = new[]
            {
                new[]
                {
                    "boolean schema version",
                    valid.Replace("\"schema_version\":1", "\"schema_version\":true"),
                    "field schema_version has the wrong JSON type"
                },
                new[]
                {
                    "missing reviewed_at",
                    valid.Replace($"\"reviewed_at\":\"{reviewedAt}\",", string.Empty),
                    "missing required field reviewed_at"
                },
                new[]
                {
                    "unknown top-level field",
                    valid.Replace("\"annotations\":", "\"extra\":true,\"annotations\":"),
                    "unknown field extra"
                },
                new[]
                {
                    "invalid reviewed_at",
                    valid.Replace(
                        $"\"reviewed_at\":\"{reviewedAt}\"",
                        "\"reviewed_at\":\"2026-08-23T10:03:00\""),
                    "reviewed_at must be an RFC 3339 date-time"
                },
                new[]
                {
                    "unbounded reviewed_at variant",
                    valid.Replace(
                        $"\"reviewed_at\":\"{reviewedAt}\"",
                        "\"reviewed_at\":\"2026-08-23 10:03:00+0000\""),
                    "reviewed_at must be an RFC 3339 date-time"
                },
                new[]
                {
                    "excess timestamp precision",
                    valid.Replace(
                        $"\"reviewed_at\":\"{reviewedAt}\"",
                        "\"reviewed_at\":\"2026-08-23T10:03:00.12345678Z\""),
                    "reviewed_at must be an RFC 3339 date-time"
                },
                new[]
                {
                    "missing annotation timestamp",
                    valid.Replace("\"at_seconds\":1.25,", string.Empty),
                    "missing required field at_seconds"
                },
                new[]
                {
                    "annotation timestamp has wrong type",
                    valid.Replace("\"at_seconds\":1.25", "\"at_seconds\":null"),
                    "field at_seconds has the wrong JSON type"
                },
                new[]
                {
                    "negative annotation timestamp",
                    valid.Replace("\"at_seconds\":1.25", "\"at_seconds\":-1"),
                    "timestamp must be finite and non-negative"
                },
                new[]
                {
                    "invalid category",
                    valid.Replace("\"category\":\"product_bug\"", "\"category\":\"other\""),
                    "category is invalid"
                },
                new[]
                {
                    "empty observed",
                    valid.Replace("\"observed\":\"Menu stayed open\"", "\"observed\":\"\""),
                    "observed is required"
                },
                new[]
                {
                    "missing expected",
                    valid.Replace("\"expected\":\"Menu closes\",", string.Empty),
                    "missing required field expected"
                },
                new[]
                {
                    "invalid created_at",
                    valid.Replace(
                        "\"created_at\":\"2026-08-23T10:02:00+00:00\"",
                        "\"created_at\":\"not-a-date\""),
                    "created_at must be an RFC 3339 date-time"
                },
                new[]
                {
                    "unknown annotation field",
                    valid.Replace("\"created_at\":", "\"extra\":true,\"created_at\":"),
                    "unknown field extra"
                },
                new[]
                {
                    "malformed JSON",
                    valid.Substring(0, valid.Length - 1),
                    "malformed"
                }
            };

            foreach (var invalid in invalidReviews)
            {
                var exception = Assert.Throws<TargetInvocationException>(
                    () => parse.Invoke(null, new object[] { invalid[1] }),
                    invalid[0]);
                Assert.That(exception.InnerException, Is.TypeOf<InvalidDataException>(), invalid[0]);
                Assert.That(exception.InnerException.Message, Does.Contain(invalid[2]), invalid[0]);
            }
        }

        [Test]
        public void CaptureStateRejectsMalformedProviderJson()
        {
            var provider = new StubStateProvider("test.malformed-json", "{\"ready\":}");
            Assert.That(QuakRegistry.Register(provider), Is.True);
            try
            {
                var state = QuakRegistry.CaptureState();

                Assert.That(state.ready, Is.False);
                Assert.That(state.providers.Single(item => item.providerId == provider.ProviderId).error,
                    Is.EqualTo("Provider returned malformed JSON."));
                Assert.That(state.errors.Single(), Does.Contain("test.malformed-json"));
                Assert.That(QuakRegistry.CaptureRuntimeStatus(
                    QuakRegistry.CaptureCapabilities(), state).ready, Is.False);
            }
            finally
            {
                QuakRegistry.Unregister(provider);
            }
        }

        [Test]
        public void CaptureStateRejectsNonObjectJsonValues()
        {
            var provider = new StubStateProvider("test.non-object-json", "[]");
            Assert.That(QuakRegistry.Register(provider), Is.True);
            try
            {
                foreach (var json in new[] { "[]", "true", "42", "\"value\"", "null" })
                {
                    provider.Json = json;
                    var state = QuakRegistry.CaptureState();

                    Assert.That(state.ready, Is.False, json);
                    Assert.That(state.providers.Single(item => item.providerId == provider.ProviderId).error,
                        Is.EqualTo("Provider JSON must be an object."), json);
                    Assert.That(QuakRegistry.CaptureRuntimeStatus(
                        QuakRegistry.CaptureCapabilities(), state).ready, Is.False, json);
                }
            }
            finally
            {
                QuakRegistry.Unregister(provider);
            }
        }

        [Test]
        public void CaptureStateAcceptsValidJsonObject()
        {
            const string json = "{\"ready\":true,\"nested\":{\"value\":1}}";
            var provider = new StubStateProvider("test.valid-json", json);
            Assert.That(QuakRegistry.Register(provider), Is.True);
            try
            {
                var state = QuakRegistry.CaptureState();

                Assert.That(state.ready, Is.True);
                Assert.That(state.errors, Is.Empty);
                Assert.That(state.providers.Single(item => item.providerId == provider.ProviderId).json,
                    Is.EqualTo(json));
                Assert.That(QuakRegistry.CaptureRuntimeStatus(
                    QuakRegistry.CaptureCapabilities(), state).ready, Is.True);
            }
            finally
            {
                QuakRegistry.Unregister(provider);
            }
        }

        [Test]
        public void RecentLogsReturnTheNewestMessageWithoutStackTraces()
        {
            QuakRegistry.CaptureRecentLogs(1);
            var marker = "QUAK recent log " + System.Guid.NewGuid().ToString("N");
            Debug.Log(marker + " older");
            Debug.Log(marker + new string('x', QuakRegistry.MaxRecentLogMessageCharacters));

            var result = QuakRegistry.CaptureRecentLogs(QuakRegistry.MaxRecentLogEntries);
            var entries = result.entries.Where(entry => entry.message.StartsWith(marker)).ToList();

            Assert.That(result.capacity, Is.EqualTo(QuakRegistry.MaxRecentLogEntries));
            Assert.That(result.returned, Is.GreaterThanOrEqualTo(2));
            Assert.That(result.newestFirst, Is.True);
            Assert.That(entries, Has.Count.EqualTo(2));
            Assert.That(entries[0].sequence, Is.GreaterThan(entries[1].sequence));
            Assert.That(entries[1].sequence, Is.GreaterThan(0));
            Assert.That(entries[0].type, Is.EqualTo(LogType.Log.ToString()));
            Assert.That(entries[0].message.Length,
                Is.EqualTo(QuakRegistry.MaxRecentLogMessageCharacters));
            Assert.That(entries[0].truncated, Is.True);
        }

        [Test]
        public void WorldSpaceSelectablesAreAutomaticAndExplicitAliasWins()
        {
            const string automaticName = "QUAK Automatic Discovery Test Button";
            const string explicitName = "QUAK Explicit Discovery Test Button";
            const string explicitId = "test.discovery.explicit";
            GameObject canvasObject = null;

            try
            {
                canvasObject = new GameObject(
                    "QUAK Discovery Test Canvas",
                    typeof(RectTransform),
                    typeof(Canvas),
                    typeof(GraphicRaycaster));
                canvasObject.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
                var automaticButton = CreateButton(canvasObject.transform, automaticName);
                var explicitButton = CreateButton(canvasObject.transform, explicitName);
                var explicitRect = (RectTransform)explicitButton.transform;
                explicitRect.pivot = new Vector2(0.1f, 0.9f);
                explicitRect.sizeDelta = new Vector2(0.4f, 0.2f);
                var target = explicitButton.gameObject.AddComponent<QuakTarget>();
                target.Configure(explicitId, "Explicit test target");

                var capabilities = QuakRegistry.CaptureCapabilities();
                var automatic = capabilities.targets.Single(item => item.label == automaticName);
                var explicitInfo = capabilities.targets.Single(item => item.id == explicitId);

                Assert.That(automatic.id, Does.StartWith("auto:ugui:"));
                Assert.That(automatic.source, Is.EqualTo("ugui"));
                Assert.That(automatic.stable, Is.False);
                Assert.That(automatic.owner, Is.EqualTo(automaticName));
                Assert.That(automatic.componentType, Is.EqualTo(typeof(Button).FullName));
                Assert.That(automatic.uiSystem, Is.EqualTo("ugui"));
                Assert.That(automatic.coordinateSpace, Is.EqualTo("world"));
                Assert.That(automatic.visibility, Is.EqualTo("unavailable"));
                Assert.That(automatic.raycastEligible, Is.True);
                Assert.That(automatic.worldBoundsSize.x, Is.GreaterThan(0f));
                Assert.That(capabilities.targetCount, Is.EqualTo(capabilities.targets.Count));
                Assert.That(capabilities.activeTargetCount,
                    Is.EqualTo(capabilities.targets.Count(item => item.active)));
                Assert.That(capabilities.raycastEligibleTargetCount,
                    Is.EqualTo(capabilities.targets.Count(item => item.raycastEligible)));
                Assert.That(capabilities.targets.Count(item => item.id == explicitId), Is.EqualTo(1));
                Assert.That(Vector3.Distance(
                    explicitInfo.worldPosition,
                    explicitRect.TransformPoint(explicitRect.rect.center)), Is.LessThan(0.00001f));
                Assert.That(capabilities.targets.Count(
                    item => item.label == explicitName && item.source != QuakRegistry.ExplicitTargetSource),
                    Is.Zero);

                automaticButton.gameObject.AddComponent<CanvasGroup>().blocksRaycasts = false;
                Assert.That(QuakRegistry.CaptureCapabilities().targets.Single(
                    item => item.label == automaticName).raycastEligible, Is.False);
            }
            finally
            {
                if (canvasObject != null)
                    Object.DestroyImmediate(canvasObject);
            }
        }

        [Test]
        public void ScreenSpaceTargetDoesNotClaimWorldRaycastability()
        {
            GameObject canvasObject = null;
            try
            {
                canvasObject = new GameObject(
                    "QUAK Screen Space Test Canvas",
                    typeof(RectTransform),
                    typeof(Canvas),
                    typeof(GraphicRaycaster));
                canvasObject.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
                var button = CreateButton(canvasObject.transform, "QUAK Screen Space Test Button");
                button.gameObject.AddComponent<QuakTarget>().Configure(
                    "test.screen-space", "Unsupported screen-space target");

                var info = QuakRegistry.CaptureCapabilities().targets.Single(
                    item => item.id == "test.screen-space");

                Assert.That(info.coordinateSpace, Is.EqualTo("unavailable"));
                Assert.That(info.visibility, Is.EqualTo("unavailable"));
                Assert.That(info.raycastEligible, Is.False);
            }
            finally
            {
                if (canvasObject != null)
                    Object.DestroyImmediate(canvasObject);
            }
        }

        [Test]
        public void SelectableWithoutTargetGraphicUsesItsRaycastableChild()
        {
            var canvasObject = new GameObject(
                "QUAK Child Graphic Canvas",
                typeof(RectTransform),
                typeof(Canvas),
                typeof(GraphicRaycaster));
            try
            {
                canvasObject.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
                var buttonObject = new GameObject(
                    "QUAK Child Graphic Button", typeof(RectTransform), typeof(Button));
                buttonObject.transform.SetParent(canvasObject.transform, false);
                var child = new GameObject(
                    "Raycast Surface", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
                child.transform.SetParent(buttonObject.transform, false);

                var info = QuakRegistry.CaptureCapabilities().targets.Single(
                    item => item.label == buttonObject.name);

                Assert.That(buttonObject.GetComponent<Button>().targetGraphic, Is.Null);
                Assert.That(info.raycastEligible, Is.True);
            }
            finally
            {
                Object.DestroyImmediate(canvasObject);
            }
        }

        [Test]
        public void EvidenceMarkerOutlinesTheExactDiscoveredTarget()
        {
            var cameraObject = new GameObject(
                "QUAK Evidence Camera", typeof(Camera));
            cameraObject.tag = "MainCamera";
            var canvasObject = new GameObject(
                "QUAK Evidence Canvas",
                typeof(RectTransform),
                typeof(Canvas),
                typeof(GraphicRaycaster));
            QuakEvidenceMarker marker = null;
            try
            {
                canvasObject.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
                canvasObject.transform.position = Vector3.forward * 2f;
                var buttonObject = new GameObject(
                    "QUAK Evidence Button", typeof(RectTransform), typeof(Button));
                buttonObject.transform.SetParent(canvasObject.transform, false);
                var rect = buttonObject.GetComponent<RectTransform>();
                rect.sizeDelta = new Vector2(0.4f, 0.2f);
                var child = new GameObject(
                    "Raycast Surface", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
                child.transform.SetParent(buttonObject.transform, false);
                var targetId = QuakRegistry.CaptureCapabilities().targets.Single(
                    item => item.label == buttonObject.name).id;

                var hidden = QuakRegistry.MarkEvidenceTarget(
                    targetId, "failed", "mono", true);
                marker = Resources.FindObjectsOfTypeAll<QuakEvidenceMarker>().Single();
                var outline = marker.GetComponent<LineRenderer>();

                Assert.That(hidden.success, Is.True, hidden.error);
                Assert.That(hidden.outlineVisible, Is.False);
                Assert.That(outline.enabled, Is.False);
                Assert.That(marker.enabled, Is.False);
                Assert.That(hidden.screenBoundsNormalized, Is.Not.Null);
                Assert.That(hidden.screenBoundsNormalized.width, Is.GreaterThan(0f));
                Assert.That(hidden.screenBoundsNormalized.height, Is.GreaterThan(0f));

                var result = QuakRegistry.MarkEvidenceTarget(targetId, "failed");
                Assert.That(result.success, Is.True, result.error);
                Assert.That(result.outlineVisible, Is.True);
                Assert.That(outline.enabled, Is.True);
                Assert.That(marker.enabled, Is.True);
                Assert.That(outline.positionCount, Is.EqualTo(4));
                Assert.That(outline.startColor.r, Is.EqualTo(1f));

                Assert.That(QuakRegistry.MarkEvidenceTarget(targetId, "clear").success, Is.True);
                Assert.That(outline.enabled, Is.False);
                Assert.That(marker.enabled, Is.False);
            }
            finally
            {
                if (marker != null)
                    Object.DestroyImmediate(marker.gameObject);
                Object.DestroyImmediate(canvasObject);
                Object.DestroyImmediate(cameraObject);
            }
        }

        [Test]
        public void EvidenceMarkerTargetLookupDoesNotReuseStaleDiscovery()
        {
            const string targetId = "test.marker.fresh-discovery";
            var first = GameObject.CreatePrimitive(PrimitiveType.Cube);
            var second = GameObject.CreatePrimitive(PrimitiveType.Cube);
            QuakEvidenceMarker marker = null;
            try
            {
                first.AddComponent<QuakTarget>().Configure(targetId);
                Assert.That(
                    QuakRegistry.MarkEvidenceTarget(targetId, "targeted").success,
                    Is.True);

                second.AddComponent<QuakTarget>().Configure(targetId);
                var duplicate = QuakRegistry.MarkEvidenceTarget(targetId, "targeted");
                marker = Resources.FindObjectsOfTypeAll<QuakEvidenceMarker>().Single();

                Assert.That(duplicate.success, Is.False);
                Assert.That(duplicate.error, Does.Contain("Duplicate"));
            }
            finally
            {
                QuakRegistry.MarkEvidenceTarget(targetId, "clear");
                if (marker != null)
                    Object.DestroyImmediate(marker.gameObject);
                Object.DestroyImmediate(first);
                Object.DestroyImmediate(second);
            }
        }

        [Test]
        public void RuntimeStatusUsesBuiltInRuntimeStateAndReportsBuildFlavor()
        {
            var capabilities = QuakRegistry.CaptureCapabilities();
            var state = QuakRegistry.CaptureState();
            var status = QuakRegistry.CaptureRuntimeStatus(capabilities, state);
            var runtimeProvider = state.providers.Single(
                item => item.providerId == QuakRegistry.RuntimeStateProviderId);
            var runtimeState = JsonUtility.FromJson<QuakRuntimeState>(runtimeProvider.json);

            Assert.That(capabilities.stateProviders,
                Does.Contain(QuakRegistry.RuntimeStateProviderId));
            Assert.That(status.ready, Is.EqualTo(runtimeState.ready));
            Assert.That(status.isEditor, Is.EqualTo(Application.isEditor));
            Assert.That(status.runtimePlatform, Is.EqualTo(Application.platform.ToString()));
            Assert.That(status.developmentBuild, Is.EqualTo(Debug.isDebugBuild));
            Assert.That(runtimeState.activeScene,
                Is.EqualTo(UnityEngine.SceneManagement.SceneManager.GetActiveScene().name));
            Assert.That(runtimeState.applicationFocused, Is.EqualTo(Application.isFocused));
        }

        [Test]
        public void RuntimeStatusCarriesIdentityAndCorrelation()
        {
            QuakRegistry.SetCorrelationId(" test-run:step-1 ");

            var status = QuakRegistry.CaptureRuntimeStatus();

            Assert.That(status.sessionId, Is.Not.Empty);
            Assert.That(status.sessionAgeSeconds, Is.GreaterThanOrEqualTo(0f));
            Assert.That(status.applicationId, Is.Not.Null);
            Assert.That(status.unityVersion, Is.EqualTo(Application.unityVersion));
            Assert.That(status.activeScene, Is.EqualTo(
                UnityEngine.SceneManagement.SceneManager.GetActiveScene().name));
            Assert.That(status.correlationId, Is.EqualTo("test-run:step-1"));
            Assert.That(status.stateProviders, Is.Ordered);
            Assert.That(QuakRegistry.CaptureState().correlationId,
                Is.EqualTo("test-run:step-1"));
            Assert.That(QuakRegistry.CurrentCorrelationId,
                Is.EqualTo("test-run:step-1"));
        }

        [Test]
        public void DuplicateProviderErrorClearsWhenLiveRegistrationRecovers()
        {
            var first = new StubStateProvider("test.duplicate-provider", "{}");
            var second = new StubStateProvider("test.duplicate-provider", "{}");
            Assert.That(QuakRegistry.Register(first), Is.True);
            try
            {
                Assert.That(QuakRegistry.Register(second), Is.False);
                Assert.That(QuakRegistry.CaptureCapabilities().errors,
                    Does.Contain("Duplicate QUAK state provider ID: test.duplicate-provider"));
                Assert.That(QuakRegistry.Unregister(first), Is.True);
                Assert.That(QuakRegistry.Register(second), Is.True);
                Assert.That(QuakRegistry.CaptureCapabilities().errors,
                    Does.Not.Contain("Duplicate QUAK state provider ID: test.duplicate-provider"));
            }
            finally
            {
                QuakRegistry.Unregister(first);
                QuakRegistry.Unregister(second);
            }
        }

        [Test]
        public void DuplicateActionErrorClearsWhenLiveRegistrationRecovers()
        {
            var first = new StubAction("test.duplicate-action");
            var second = new StubAction("test.duplicate-action");
            Assert.That(QuakRegistry.Register(first), Is.True);
            try
            {
                Assert.That(QuakRegistry.Register(second), Is.False);
                Assert.That(QuakRegistry.CaptureCapabilities().errors,
                    Does.Contain("Duplicate QUAK action ID: test.duplicate-action"));
                Assert.That(QuakRegistry.Unregister(first), Is.True);
                Assert.That(QuakRegistry.Register(second), Is.True);
                Assert.That(QuakRegistry.CaptureCapabilities().errors,
                    Does.Not.Contain("Duplicate QUAK action ID: test.duplicate-action"));
            }
            finally
            {
                QuakRegistry.Unregister(first);
                QuakRegistry.Unregister(second);
            }
        }

        [Test]
        public void DirectBridgePureBoundariesRejectWrongTokensAndOversizedLines()
        {
            CollectionAssert.AreEquivalent(
                new[]
                {
                    "convert_unity_pose_to_openxr",
                    "math_build_quat",
                    "openxr_get_active_interaction_profile",
                    "openxr_get_controller_pose",
                    "openxr_get_frame_info",
                    "openxr_get_head_pose",
                    "openxr_get_haptic_events",
                    "openxr_get_instance_info",
                    "openxr_get_performance_metrics",
                    "openxr_get_session_info",
                    "openxr_get_session_state",
                    "openxr_get_system_info",
                    "openxr_set_controller_input",
                    "openxr_set_controller_pose",
                    "openxr_set_controller_poses",
                    "openxr_set_passthrough",
                    "quak_get_capabilities",
                    "quak_get_layer_inventory",
                    "quak_get_recent_logs",
                    "quak_get_state",
                    "quak_invoke_action",
                    "quak_mark_evidence_target",
                    "quak_set_context",
                    "quak_status"
                },
                QuakDirectDispatcher.BridgeTools);
            Assert.That(QuakDirectDispatcher.BridgeProtocolVersion, Is.EqualTo(1));
            Assert.That(QuakDirectNative.AbiVersion, Is.EqualTo(4));
            Assert.That(Marshal.SizeOf<QuakDirectNativeStatus>(), Is.EqualTo(208));
            Assert.That(Marshal.SizeOf<QuakDirectHapticEvent>(), Is.EqualTo(360));
            Assert.That(Marshal.SizeOf<QuakDirectPerformanceMetric>(), Is.EqualTo(280));
            Assert.That(Marshal.SizeOf<QuakDirectPassthroughState>(), Is.EqualTo(8));
            Assert.That(QuakDirectBridge.TokenEquals("secret", "secret"), Is.True);
            Assert.That(QuakDirectBridge.TokenEquals("secret", "Secret"), Is.False);
            Assert.That(QuakDirectBridge.TokenEquals("secret", "short"), Is.False);
            Assert.Throws<System.ArgumentException>(() => QuakDirectDispatcher.Invoke(
                "openxr_get_haptic_events", "{\"after_serial\":-1}"));
            Assert.Throws<System.ArgumentException>(() => QuakDirectDispatcher.Invoke(
                "openxr_get_haptic_events", "{\"limit\":65}"));
            Assert.Throws<System.ArgumentException>(() => QuakDirectDispatcher.Invoke(
                "openxr_set_passthrough", "{}"));
            Assert.Throws<System.ArgumentException>(() => QuakDirectDispatcher.Invoke(
                "openxr_set_passthrough", "{\"enabled\":1}"));
            Assert.Throws<System.ArgumentException>(() => QuakDirectDispatcher.Invoke(
                "openxr_set_passthrough", "{\"nested\":{\"enabled\":true}}"));

            using var stream = new MemoryStream(
                Enumerable.Repeat((byte)'x', QuakDirectBridge.MaxMessageBytes + 1).ToArray());
            Assert.Throws<IOException>(() => QuakDirectBridge.ReadBoundedLine(stream));
        }

        [Test]
        public void DirectInputCreatesRightControllerAndConvertsOpenXrPose()
        {
            try
            {
                QuakDirectInput.SetPoses(
                    1,
                    new Vector3(1f, 2f, -3f),
                    Quaternion.identity,
                    new Vector3(4f, 5f, -6f),
                    Quaternion.identity);
                QuakDirectInput.SetInput(1, 1, 1f);
                QuakDirectInput.SetInput(1, 2, 1f);
                QuakDirectInput.SetInput(1, 6, 0.5f);
                QuakDirectInput.SetInput(1, 7, -0.75f);

                var device = InputSystem.devices.Single(item =>
                    item.name == "QUAK_Virtual_Right_Controller");
                Assert.That(device.layout, Is.EqualTo("QUAKDirectController"));
                Assert.That(device.usages, Contains.Item(CommonUsages.RightHand));
                Assert.That(
                    device.TryGetChildControl<Vector3Control>("pointerPosition").ReadValue(),
                    Is.EqualTo(new Vector3(1f, 2f, 3f)));
                Assert.That(
                    device.TryGetChildControl<Vector3Control>("devicePosition").ReadValue(),
                    Is.EqualTo(new Vector3(4f, 5f, 6f)));
                Assert.That(
                    device.TryGetChildControl<ButtonControl>("gripPressed").IsPressed(),
                    Is.True);
                Assert.That(
                    device.TryGetChildControl<ButtonControl>("primaryButton").IsPressed(),
                    Is.True);
                Assert.That(
                    device.TryGetChildControl<Vector2Control>("thumbstick").ReadValue(),
                    Is.EqualTo(new Vector2(0.5f, -0.75f)));

                QuakDirectInput.ReleaseAll();
                Assert.That(
                    device.TryGetChildControl<ButtonControl>("gripPressed").IsPressed(),
                    Is.False);
                Assert.That(
                    device.TryGetChildControl<ButtonControl>("isTracked").IsPressed(),
                    Is.False);
                Assert.That(
                    device.TryGetChildControl<Vector2Control>("thumbstick").ReadValue(),
                    Is.EqualTo(Vector2.zero));
            }
            finally
            {
                QuakDirectInput.ReleaseAll();
                foreach (var device in InputSystem.devices.Where(item =>
                             item.name.StartsWith("QUAK_Virtual_")))
                    InputSystem.RemoveDevice(device);
            }
        }

        [Test]
        public void ConfigureRejectsEmptyIdsAndColliderSuppliesWorldIntrospection()
        {
            var gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            try
            {
                gameObject.name = "QUAK Collider Target";
                var target = gameObject.AddComponent<QuakTarget>();
                Assert.Throws<System.ArgumentException>(() => target.Configure(" "));
                target.Configure("test.collider", " Collider target ");

                var info = QuakRegistry.CaptureCapabilities().targets.Single(
                    item => item.id == "test.collider");
                Assert.That(target.Description, Is.EqualTo("Collider target"));
                Assert.That(info.owner, Is.EqualTo(gameObject.name));
                Assert.That(info.componentType, Is.EqualTo(typeof(BoxCollider).FullName));
                Assert.That(info.uiSystem, Is.EqualTo("none"));
                Assert.That(info.coordinateSpace, Is.EqualTo("world"));
                Assert.That(info.compositorLayer, Is.EqualTo("unavailable"));
                Assert.That(info.visibility, Is.EqualTo("unavailable"));
                Assert.That(info.raycastEligible, Is.True);
                Assert.That(info.worldBoundsSize, Is.EqualTo(Vector3.one));
            }
            finally
            {
                Object.DestroyImmediate(gameObject);
            }
        }

        private static Button CreateButton(Transform parent, string name)
        {
            var gameObject = new GameObject(
                name,
                typeof(RectTransform),
                typeof(CanvasRenderer),
                typeof(Image),
                typeof(Button));
            gameObject.transform.SetParent(parent, false);
            return gameObject.GetComponent<Button>();
        }

        private sealed class StubStateProvider : IQuakStateProvider
        {
            public StubStateProvider(string providerId, string json)
            {
                ProviderId = providerId;
                Json = json;
            }

            public string ProviderId { get; }
            public string Json { get; set; }
            public string CaptureStateJson() => Json;
        }

        private sealed class StubAction : IQuakActionHandler
        {
            public StubAction(string actionId)
            {
                ActionId = actionId;
            }

            public string ActionId { get; }
            public string Description => "Test action";
            public bool IsProjectMutation => false;
            public string Invoke(string argumentsJson) => "{}";
        }

        private static bool ProcessExited(int processId)
        {
            try
            {
                using var process = System.Diagnostics.Process.GetProcessById(processId);
                return process.HasExited;
            }
            catch (System.ArgumentException)
            {
                return true;
            }
        }
    }
}
