# Install QUAK

Install QUAK from a complete supplied release. Do not install from the `main`
branch.

## Prerequisites

QUAK requires:

- Python 3.11 or newer
- Unity 6
- Unity CLI and `unity auth login`
- OpenXR Plugin `1.17.1`
- ADB for direct Quest runs
- FFmpeg and `ffprobe` for tests that require visual evidence

Check the interpreter used by automation with `python3 --version`; macOS
`/usr/bin/python3` may still be 3.9. On Apple Silicon, invoke
`/opt/homebrew/bin/python3` directly or add `/opt/homebrew/bin` to the
non-interactive SSH/CI `PATH`.

For a Git LFS-backed Unity project, ensure LFS is on that same `PATH` and run
`git lfs pull` plus `git lfs fsck` before Unity import. A checkout made without
LFS can contain pointer files instead of assets and is not a valid test
worktree. Run `git lfs checkout` after restoring LFS if pointers remain.

Choose a control lane:

| Lane | Requirements | Status |
|---|---|---|
| Direct Quest | OpenXR `1.17.1`, Android Development Build, ADB | Primary; no Meta runtime/package dependency |
| Integrated Editor | Unity Pipeline `0.4.0-exp.1`, Meta XR Core SDK `205+`, and Meta XR SDK AI Tools | Validated |
| Operator rollback | Meta's Core/standalone Operator layer and MCP proxy | Optional/experimental on Quest |

Direct Quest uses the packaged QUAK explicit OpenXR API layer and an
authenticated loopback bridge. Its dynamic ADB forward and app-private token
are provisioned per run. It does not need Meta XR Core, Unity Pipeline, Unity
OpenXR Meta, an Operator AAR/layer, or the Operator MCP proxy.

The direct bridge and injection layer are enabled only in Android Development
Builds. QUAK contributes Android `INTERNET` permission while preparing that
direct Development Build; it does not add the permission to a release build or
remove a permission declared by the application. Before making a shipping
build, disable
`XR_APILAYER_XRDEVROB_quak_injection` in OpenXR API Layers; QUAK fails a
non-development build if the layer is still enabled.

For Simulator, install and configure Meta XR Simulator plus its chosen
Operator lane.

Follow Meta's current Operator documentation for vendor installation details.
Do not apply the standalone bundle's manual environment variables to a Unity
Editor session.

### Optional Operator rollback

QUAK does not redistribute Meta's binaries. Download **Meta XR Operator
Standalone 205.1** from [Meta's official download page](https://developers.meta.com/horizon/downloads/package/meta-xr-operator-standalone/).
The archive currently pinned by QUAK is
`meta-xr-operator-standalone-public.zip` with SHA-256:

```text
b5a5d155f0a98c8b02c8e93c41b58fb78603ae9ea825be4a0d088d299f94a4a1
```

Supply that archive only when provisioning the legacy Operator rollback:

```bash
python3 /absolute/path/to/QUAK-INSTALL.py \
  --project /absolute/path/to/MyUnityProject \
  --target quest \
  --operator-standalone-archive /absolute/path/to/meta-xr-operator-standalone-public.zip
```

QUAK verifies both the ZIP and its exact Unity Android AAR before setup writes
the plugin or other setup files, then installs the AAR under
`Assets/Plugins/Android/QUAK/`. A verified copy already elsewhere under
`Assets/` is reused; duplicate or different copies are preserved and reported
as `ACTION REQUIRED`. Do not use this option when Meta XR Core SDK `205+` is
installed; Core already supplies the layer. A local or non-versioned Core
dependency must resolve to a concrete version before QUAK will install the
standalone layer.

This archive option is Quest/Android-only. QUAK does not install or configure
the desktop layer. No-Core Simulator setup is manual and experimental: extract
the matching macOS arm64 or Windows x86-64 folder, build a standalone
Development Player, and launch it through that layer. Meta does not document
this flow for Unity projects, and QUAK has not live-validated desktop players.
On macOS, make the extracted proxy executable with `chmod +x` before configuring
it. Editor Play Mode belongs to the integrated Core-205 lane.

## Install the supplied release

Keep the supplied wheel, Unity package, installer, license, and `SHA256SUMS` in
one directory. Run:

```bash
python3 /absolute/path/to/QUAK-INSTALL.py \
  --project /absolute/path/to/MyUnityProject
```

The installer:

- verifies the release artifacts;
- creates a pinned project-local Python environment and `./quak` launcher;
- adds the Unity package through a portable project-relative reference;
- installs the connection smoke test; and
- runs the static prerequisite checks.

Pass `--install-codex-skill` only when the optional project-local Codex
test-authoring skill is wanted.

It preserves existing project files and custom package references. A package
reference previously managed by the release installer is advanced to the
supplied release. In terminals and agent sessions, run QUAK from the project
root through `./quak` so the CLI and Unity package remain on the same version.

The installer reports installation and static readiness separately. If Doctor
finds unmet prerequisites, it prints `[INSTALLATION SUCCEEDED]` followed by
`[READINESS ACTION REQUIRED]` and exits `1`; do not test until Doctor passes.
Use `--allow-unready` only for an explicit installation-only run. Setup problems
and Doctor execution errors remain non-zero and are labeled separately.

## Configure Unity

After Unity finishes compiling, choose either supported setup path.

Interactive setup:

1. Open **QUAK > Control Panel**.
2. Click **Set up QUAK**.

Headless setup (the exact equivalent of **Set up QUAK**):

```bash
"/absolute/path/to/Unity.app/Contents/MacOS/Unity" \
  -batchmode \
  -quit \
  -projectPath "/absolute/path/to/MyUnityProject" \
  -executeMethod XRDevRob.QUAK.Editor.ControlPanel.QuakProjectSetup.ConfigureProject \
  -logFile -
```

Invoke the Unity Editor executable shown above, not a separate Unity CLI
wrapper. Run this only after the QUAK package is installed and Unity can compile
the project. It preserves existing configuration and tests, so rerunning it is
safe. Success prints `[QUAK] Project setup succeeded:` and exits zero; any failed
preflight or setup step prints `[QUAK] Project setup failed` and exits non-zero.

Then:

1. Enable OpenXR for Standalone.
2. Enable the controller interaction profile reported by your selected runtime.
3. Select Simulator or Quest in the Control Panel.
4. Start the selected runtime as described below, then click **Verify connection**.

For the integrated Editor lane, activate Simulator and Operator before entering
Play Mode. For the no-Core Simulator lane, do not enter Editor Play Mode:
launch the built Development Player from the shell configured with Meta's
desktop layer, then run `./quak verify --target simulator`. Static Doctor
reports the selected lane and treats a missing desktop launch environment as
`ACTION REQUIRED`; live Doctor proves whether the layer is actually attached.

Setup enables the Unity OpenXR API Layers feature for direct Android testing.
The runtime bridge is created automatically in a Development Build; customer
scenes do not need a manually added bridge component. Use **QUAK > Enable Meta
XR Operator rollback** only for the optional vendor path.

Quest direct and Operator testing require a Unity Development Build. The Control Panel
warns before a release build, runtime status records `developmentBuild`, and
live Doctor rejects an explicitly detected release APK. QUAK does not silently
change the project's build setting.

The terminal equivalent for Simulator is:

```bash
./quak verify \
  --project /absolute/path/to/MyUnityProject \
  --target simulator
```

For Quest, identify the shipping application:

```bash
./quak verify \
  --project /absolute/path/to/MyUnityProject \
  --target quest \
  --device-serial <adb-serial> \
  --expected-application-id com.example.shippingapp \
  --expected-scene MainScene
```

`--expected-application-id` is required for live Quest verification.
`--expected-scene` is optional when scene identity is not part of the claim.
Add `--visual` to either `verify` example to require a bounded recording in the
smoke receipt.

If a newer dedicated test APK makes a later full development APK a version-code
downgrade, install the latter with
`adb -s <serial> install -r -d /absolute/path/to/app.apk`. This preserves data
only when the signing key matches. Uninstalling to resolve a signature mismatch
clears app data and downloaded content.

## Manual installation

If the installer cannot be used, verify `SHA256SUMS`, install the supplied
wheel with `pipx` or a virtual environment, and install the supplied `.tgz`
through **Window > Package Management > Package Manager > Install package from
tarball**.

For scripted setup, use an absolute package path:

```bash
quak setup \
  --project /absolute/path/to/MyUnityProject \
  --package-source file:/absolute/path/to/com.xrdevrob.quak-<version>.tgz
```

Next: [run the first test](first-test.md).
