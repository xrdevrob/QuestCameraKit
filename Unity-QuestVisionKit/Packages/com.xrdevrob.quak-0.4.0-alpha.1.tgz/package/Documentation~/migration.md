# Migrating to Quak

Quak 0.4.0-alpha.1 is the first release under the new name. Upgrade the CLI,
Unity package, project-owned tests, and development APK together.

| Before | Now |
| --- | --- |
| `xrqa`, `xrqa-head` | `quak`, `quak-head` |
| Python `xrqa` | Python `quak` (public test API: `quak.test`) |
| `com.xrdevrob.xrqa` | `com.xrdevrob.quak` |
| `XRDevRob.XRQA`, `Xrqa…` | `XRDevRob.QUAK`, `Quak…` |
| `xrqa_…` bridge tools | `quak_…` bridge tools |
| `.xrqa/config.json`, `.xrqa/evidence/` | `.quak/config.json`, `.quak/evidence/` |
| `XRQA_…` environment variables | `QUAK_…` environment variables |
| `xrqa-test` agent skill | `quak-test` agent skill |
| GitHub `xrdevrob/xrqa` | GitHub `xrdevrob/quak` |

1. Keep a backup or clean Git commit of the consuming Unity project. Remove the
   old UPM dependency and install `com.xrdevrob.quak` from this release. Do not
   install both packages: asset GUIDs have deliberately been preserved.
2. Update C# namespaces, type references and assembly references, Python imports,
   bridge tool names in project-owned test JSON, shell commands, and environment
   variables using the table. Update assembly-qualified serialized type names in
   project-owned assets where present. Shipped sample assets are already updated.
3. Run `quak init --project /absolute/path/to/project` to create new configuration,
   or copy the old configuration into `.quak/config.json` and update its evidence
   path. Re-select desktop tool and evidence folders in Settings.
4. Disable and remove the old XRQA API-layer registration and generated layer
   files from the consuming project's `Assets/XR/APILayers~` before running Quak
   project setup. Keep application-owned files. Rebuild the development APK:
   existing XRQA APKs use the old tool and library names and cannot be used with
   the renamed direct bridge.
5. Install the `quak-test` skill and verify the new CLI with `quak --version` and
   the normal static readiness checks before running a reviewed test.

Do not search-and-replace archived receipts, evidence JSON, recordings, hashes,
or human review files. Keep previous runs with the version that created them;
new Quak runs use `.quak/evidence/` by default. Historical release notes and
validation records retain the original product names and exact artifact paths.
The alpha.18 migration fixture also retains its original filename and hash.

The wheel and UPM package are the SDK release artifacts. Desktop source is
included, but this rename does not establish signed desktop distribution,
firmware hardware validation, or new Quest acceptance evidence.
