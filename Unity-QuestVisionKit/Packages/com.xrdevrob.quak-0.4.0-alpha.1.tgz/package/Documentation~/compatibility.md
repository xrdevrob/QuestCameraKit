# Compatibility

## Reference baseline

| Layer | Reference version | Notes |
|---|---:|---|
| Unity Editor | 6.0+ | Package authoring and integrated Editor host |
| Unity Pipeline | `0.4.0-exp.1` | Optional integrated-Editor adapter |
| OpenXR Plugin | `1.17.1` | QUAK package dependency |
| QUAK direct layer | arm64, OpenXR 1.0/1.1 | Primary Quest control; development builds only |
| Meta XR Operator | Core SDK `205+` or Standalone `205.1` | Optional Simulator/rollback provider |
| Meta XR Core SDK | `205+` | Optional integrated AI Tools lane |
| Unity OpenXR Meta | `2.4.0+` | Optional Operator-integrated Quest lane only |
| Python | 3.11+ | QUAK CLI |
| Meta XR Simulator | Current | Simulator interaction development |
| Quest 3 / Quest 3S | Current development devices | Quest 3 direct journey passed; same APK installed on Quest 3S, whose physical Sensor Lock still blocks live startup |

These versions are a tested reference, not a promise that every newer
experimental release is compatible. Pin the QUAK release and rerun `doctor`
plus the connection smoke test after vendor upgrades.

This package's `package.json` declares QUAK's direct Unity dependencies and
their requested versions; it is not a resolved lockfile. The consuming
project's reviewed `Packages/packages-lock.json` is authoritative for the exact
resolved graph. `quak doctor --json` reports the explicitly checked lane
baselines plus the exact FFmpeg executables it will use. QUAK does not
auto-install lane-specific Meta, Pipeline, or XRI packages because those change
the product project and can carry separate vendor terms.

Quest 3 has a successful direct receipt for the complete Block Assembly journey,
including concurrent physical hand tracking and the QUAK Unity controller. The
same APK installed on Quest 3S, but Meta's physical Sensor Lock still prevents
that model's app from starting. See the repository validation record for the
exact boundary.

## Covered interaction paths

The Block Assembly Lab covers:

```text
QUAK direct bridge
    -> native OpenXR layer + generic Unity XRController pose and Grip
    -> Unity Input System
    -> sample interaction rules
    -> QUAK application-state assertion and evidence
```

Optional samples separately exercise XRI 3.3/UI Toolkit and Meta Interaction
SDK 205 controller paths in Simulator. On Quest, QUAK can bridge either its
direct native OpenXR controller or Operator's controller into Meta Interaction
SDK when its OVR source reports disconnected. The bridge is limited to
Editor/development builds; connected OVR controllers are unchanged. A Core-205 MRMotifs lane
completed real UGUI hover/select and the asserted product-state transition.
Hand tracking, custom project interactions, and native compositor-layer input
require their own evidence.

## Current alpha limitations

- Test definitions use JSON; YAML is not supported.
- `quak prove` accepts one monolithic APK; Android App Bundles and split-APK
  installs are rejected because they cannot be byte-matched to one supplied file.
- Visual evidence has mechanical inspection, but no semantic baseline/diff
  acceptance engine.
- Unattended recording requires the selected Quest ADB screen recorder or a
  pre-authorized macOS Simulator window. Consent-gated Operator snapshots are
  available only with explicit `capture_policy: attended` and are not an
  automatic fallback.
- Simulator, Quest, and Editor results remain separate evidence lanes.
- Live direct Quest commands configure a dynamic per-device ADB forward and
  authenticate with the exact debuggable app's private token. Operator mode
  alone enables Meta's experimental property and owns fixed host port 8720.
  Static Doctor is read-only. QUAK holds a host-local lease for each selected
  serial, but it does not coordinate separate hosts or bypass developer mode,
  Guardian, or proximity focus requirements.
- Quest tests must identify the intended Android package.
- Generic targets report active state, bounds, and raycast eligibility, but not
  rendered visibility or native compositor-layer mapping.
- Direct injection covers controller Trigger/Grip, left X/Y/Menu, right
  A/B/System, thumbstick click and X/Y axes, plus aim/grip poses. Other OpenXR
  actions pass through unchanged.
- Operator tool names and behavior can change between experimental releases in
  the optional rollback lane.
- The separately downloadable standalone bundle must be validated for the
  exact bundle and platform used by the customer. QUAK's archive option installs
  only the Quest Android AAR; it does not configure the desktop API layer. The
  MCP proxy cannot supply that native layer.

Run `./quak doctor --help` and follow Doctor's current output rather than
copying old environment fixes.
