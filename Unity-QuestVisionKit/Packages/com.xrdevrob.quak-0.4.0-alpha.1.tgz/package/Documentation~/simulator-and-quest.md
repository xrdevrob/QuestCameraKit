# Simulator and Quest

Treat each runtime as a separate evidence lane. Do not use a Simulator receipt
to make a device claim.

## Meta XR Simulator

The validated integrated lane uses Unity Pipeline `0.4.0-exp.1`, Meta XR Core
SDK `205+`, Meta XR SDK AI Tools, and Meta XR Simulator.

Before the first integrated run on macOS:

1. Leave Play mode.
2. Choose **Meta > Meta XR Simulator > Activate**.
3. Activate Operator through Meta XR SDK AI Tools.
4. Enter Play mode.
5. Run live Doctor.

```bash
./quak doctor \
  --project /absolute/path/to/MyUnityProject \
  --target simulator \
  --live
```

The standalone/no-Core lane instead runs a development player through Meta's
standalone Operator layer. Do not apply its manual API-layer environment
variables to the Unity Editor. The MCP proxy only connects to an existing
Operator-enabled app; it cannot make `XR_METAX1_agentic_external_tool`
available. The pinned desktop binaries support macOS arm64 and Windows x86-64
only. In the shell used to launch the player, point `XR_API_LAYER_PATH` at the
corresponding extracted `macos` or `windows` folder and set
`XR_ENABLE_API_LAYERS=XR_APILAYER_METAX_operator`. Run static Doctor from that
environment, launch the player, then use live Doctor or `verify` to prove the
layer attached. On macOS, first run `chmod +x` on the extracted
`meta-xr-operator-mcp-proxy`. This Unity desktop-player adaptation is not
documented by Meta or live-validated by QUAK.

For optional Quest Operator rollback, download Meta XR Operator Standalone
205.1 and pass the archive to
`quak setup --operator-standalone-archive <zip>`. This is not needed by the
default direct lane. QUAK verifies the pinned ZIP and Unity AAR checksums before
installing the project-local Android plugin; it does not download or
redistribute the bundle.

If Unity reports no controller, enable the OpenXR interaction profile named by
Doctor. Restart Play Mode in the integrated Editor lane; rebuild and relaunch
the player through the desktop layer in the standalone-player lane.

## Quest

A Quest run requires:

- developer mode and an authorized ADB connection;
- an Android Development Build (QUAK adds `INTERNET` for the direct bridge);
- the Input System and matching controller interaction profile;
- the Unity OpenXR API Layers feature and QUAK direct layer enabled for Android;
- the intended package ID in the test or command; and
- local-floor tracking and stable application/input focus.

Verify the live app:

```bash
./quak verify \
  --project /absolute/path/to/MyUnityProject \
  --target quest \
  --device-serial <adb-serial> \
  --expected-application-id com.example.shippingapp \
  --expected-scene MainScene
```

Every live direct Quest command (`doctor --live`, `verify`, `targets`, and test
execution) allocates a dynamic host port for that device and authenticates the
exact debuggable app through its private token. QUAK removes that forward on
exit. Explicit `--quest-provider operator` instead provisions Meta's
experimental property and fixed port 8720. Static Doctor is read-only. QUAK
takes a host-local lease on the selected serial before any live mutation;
multiple devices can use direct mode concurrently, while multi-host labs still
need an external scheduler. It cannot bypass
developer-mode/USB approval or disable Guardian/proximity checks. Instead, live
readiness fails until the intended app has stable application, input, and VR
focus.

A test can request a confirmed pre-connection clear, deletion below its own
external `cache/` or `files/` directory, a bounded runtime-permission list, or a
safe product-owned startup URI through `quest_preflight`. Execution also
requires `--allow-device-reset`; despite its legacy name, that flag authorizes
force-stop/launch plus any requested data reset or permission grant. Arbitrary
shell commands, local-content URI schemes, absolute file paths, and parent
traversal are rejected. QUAK first proves the exact package is debuggable and
each permission is requested and runtime-grantable, force-stops it, verifies any
grant, and waits for the selected provider after the requested launch. A blocking permission
prompt fails immediately; a focus-placeholder timeout reports headset
wake/unlock, Guardian, and proximity remediation.
Completed and failed operations are recorded in the receipt's verification
metadata.

## Device recording boundary

QUAK can own a bounded ADB screen recording synchronized with a Quest test.
That is operating-system device output, not a raw per-eye compositor dump. It
does not by itself prove that protected or native composition layers appeared,
or that an application-owned mirror was not duplicated.

This lane runs unattended. QUAK removes the remote movie only after it was
pulled, decoded and inspected locally, and bound into hashed evidence. On any
failure the remote copy is preserved and QUAK prints the exact recovery
command. Consent-gated Operator compositor snapshots are available only with
explicit `capture_policy: attended` and `capture_source: compositor`; they
bypass ADB recording for layer-sensitive proof and are never an automatic
fallback. The resulting video is reconstructed from sampled frames, not a
continuous native stream.

When compositor presentation is part of acceptance:

1. expose capture mode and surface counts through application state;
2. run a short visual preflight;
3. inspect the original recording; and
4. save an explicit human review.
