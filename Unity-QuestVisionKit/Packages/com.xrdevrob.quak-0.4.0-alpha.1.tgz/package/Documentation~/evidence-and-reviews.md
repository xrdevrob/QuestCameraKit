# Evidence and reviews

Every QUAK run writes a machine receipt and supporting artifacts:

```text
.quak/evidence/<run-id>/
  events.ndjson
  receipt.json
  human-review.json
  artifacts/
    run-report.html
    quest-system.log
    visual-review.html
    focus/
      <step>-<title>.mp4
      <step>-<title>.vtt
    visual-evidence.vtt
    visual-inspection.json
    visual-storyboard.json
    visual-storyboard/
    <recording>.mp4
```

Some files exist only when the test requested visual evidence or a reviewer
saved a verdict.

Supervised Quest runs retain the bounded system log as `artifacts/quest-system.log`
before finalizing the receipt, including on cleanup failure. Its relative path,
SHA-256, and byte count make it part of the portable bundle. Raw logs and media
are not covered by JSON redaction: inspect them for private app/device data
before sharing. Older receipts with only an external log `path` do not include
that log in their ZIP; rerun to produce portable log evidence.

The Control Panel offers three modes:

- **Off** omits `visual_evidence` and records nothing.
- **Standard** retains the unprocessed source, records the full captioned
  journey, and creates focused clips for titled interactions and failures.
- **Advanced** changes which interactions get clips or whether the target
  highlight is off, focused-only, or visible in every recording.

These choices are saved in the test JSON, so local and CI runs use the same
policy. The editor invokes the same safe `quak evidence-settings` command used
by the CLI.

Quest focus uses the selected eye and a tested `quest_target_y_offset: 0.13`
for the stereo screen-recording mirror. Treat that as a hardware calibration:
change it only after checking a focused clip on a different recorder layout.

The default visual policy is unattended: QUAK uses native Quest ADB recording
or a pre-authorized macOS Simulator window and fails before input if neither is
available. Explicit `capture_source: compositor` bypasses the native recorder
so virtual/OpenXR layers are captured from the compositor instead of silently
dropped. Quest additionally requires `capture_policy: attended`. The result is
a sampled, reconstructed timeline rather than continuous native video. No
unattended Quest run silently opens capture consent.

## Start with the run report

Open `artifacts/run-report.html` for the concise execution view. It shows step
results, effect transitions, the first failure, diagnostics, provenance, and
artifact links. The raw `receipt.json` remains the machine authority.

The headline separates `OVERALL`, `PRODUCT`, and `EVIDENCE`. Product reflects
value assertions beneath an app-owned `IQuakStateProvider`; evidence reflects
capture and mechanical inspection; overall covers every declared assertion plus
the requested evidence gate and infrastructure/cleanup health. A diagnostic-only
test can therefore show `OVERALL PASSED · PRODUCT NOT_ASSESSED`. The reserved
`quak-runtime` provider and structural assertions such as `exists` never count as
a product oracle. A required recorder failure can honestly show `OVERALL FAILED ·
PRODUCT PASSED · EVIDENCE FAILED`. A complete recording is
`RECORDED_PENDING_REVIEW`, not a visual approval.

For interaction tests, `PRODUCT INCONCLUSIVE` means the selected provider accepted or
attempted the automation command but the application did not confirm a
correlated event or state change. `PRODUCT FAILED` is reserved for an observed
product value that violates its assertion. An attempted but unobserved or
partially evaluated product oracle is also inconclusive; an oracle that was
declared but never reached is `PRODUCT NOT_RUN`.

The receipt retains:

- a redacted snapshot of the executed definition;
- a hash of the exact definition;
- CLI and Unity package identity;
- environment and device provenance;
- assertions and before/after effect values; and
- hashes for captured artifacts.

Redacted values cannot be recovered from the receipt. Review app-defined state
and tool output before publishing evidence; redaction is defense in depth, not
a data-loss-prevention system.

## Review visual evidence

Open `artifacts/visual-review.html`. QUAK decodes every available frame once at
low resolution to flag timing, luminance, black-frame, and freeze problems. The
same pass creates a clickable storyboard spanning the complete recording.

Start with the videos under `artifacts/focus/` when present. Each covers one
interaction, burns in its title and machine verdict, crops around the runtime
target bounds, and changes a focused highlight from red to green at the
observed effect. If bounds are unavailable, the receipt labels the clip as a
full-frame fallback instead of pretending it was focused. Use the full journey
for surrounding context and the retained source for the original pixels.

This mechanical coverage accelerates review; it does not determine whether the
application looked semantically correct. In **QUAK > Control Panel > Tests**,
approve the recording or save timestamped requested changes. QUAK writes the
verdict to `human-review.json`, bound to the receipt and recording hashes.

Both the Control Panel and portable reviewer require `OVERALL PASSED`,
`PRODUCT PASSED`, and complete evidence marked `RECORDED_PENDING_REVIEW`
before allowing approval. Capture errors, exceeded duration, incomplete
inspection, and inconsistent outcomes block approval. Other recordings remain
available for triage and change requests. Legacy receipts without outcomes
require a passing status and complete visual evidence.

Human review does not rewrite the machine receipt: its `review_status` remains
`pending`, while the adjacent review file carries the later verdict.

## Send one portable review

For any completed visual receipt:

```bash
./quak review-bundle /absolute/path/to/receipt.json \
  --output /absolute/path/to/review.zip
```

The deterministic ZIP contains only receipt-declared, hash-checked artifacts,
plus events and an offline `review.html`. After extracting it, a reviewer can
watch the video, inspect the storyboard, and download a schema-compatible
`human-review.json` approval or timestamped observed/expected change request.
The page sends nothing to a server. Put the downloaded sidecar beside
`receipt.json` when returning it to QUAK.

After changes are requested, QUAK's local review UI directs reviewers to fix
the product or test, rerun it with `--supersedes <old-receipt>`, and review the
new recording instead of approving the old run. This is a workflow guard, not
a digital signature or trusted append-only boundary: local ZIPs and sidecars
can be copied, edited, or deleted. For Quest, `quak prove APK TEST` performs the
exact APK install, run, evidence capture, and review-bundle creation in one
command.

## State the claim precisely

| Label | What it establishes |
|---|---|
| Static validated | Schema, package, or source checks passed |
| Editor validated | Commands reached the intended Unity Editor instance |
| Simulator validated | A fresh Simulator session exposed the required tools and completed the test |
| Quest validated | The named device class and installed application completed the test |
| In-headset visual validated | A person confirmed the compositor-visible result |

Do not collapse these into “works on Quest.” A development or harness APK,
alternate package ID, or test-only navigation path does not prove the shipping
application or its real path.
