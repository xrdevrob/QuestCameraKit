# Integrate your app

An QUAK integration exposes only the product facts and durable interaction
targets needed by important tests. Do not mirror the entire Unity hierarchy.

## Add durable targets

QUAK automatically discovers world-space Unity UI controls. Their generated
`auto:` IDs are useful for inspection, but they are marked unstable because
layout or hierarchy changes can alter them.

Add `QuakTarget` only when a test needs a durable semantic ID or when the object
is a custom interaction or destination:

```text
assembly.piece.coral
assembly.connection.coral
assembly.ui.validate
menu.settings
```

Treat explicit IDs as an automation API. Keep them stable when designers
rename or rearrange GameObjects. Use the live inventory to inspect ownership,
bounds, active state, and hit eligibility:

```bash
./quak targets \
  --project /absolute/path/to/MyUnityProject \
  --target simulator
```

Active and raycast-eligible do not prove rendered visibility or lack of
occlusion. QUAK reports those properties as unavailable unless a project or
vendor adapter can supply them truthfully.

Target-based input refreshes capabilities at the moment the step runs and
rejects a missing, duplicate, inactive, non-world-space, non-finite, or
empty/negative-bounds target; clicks and grab sources must also be raycastable.
Targets used only after later
navigation are not startup prerequisites.

### Target live UI Toolkit controls

For a world-space UI Toolkit document on Unity 6.2 or newer, add one
`QuakUiToolkitTarget` component per control that a test uses. Put each component
on the same GameObject as the live `UIDocument` and its panel-sized
`BoxCollider`, then set the durable target ID and the control's exact UXML
`name`. The collider is the explicit project-owned mapping of the document's
full layout area into world space.

QUAK queries `UIDocument.rootVisualElement` again on every capability capture;
it never holds a template or cached `VisualElement`. A control that has not yet
been cloned or attached is simply unavailable and does not block earlier
navigation; it appears as soon as the live document advertises it. Attempting
to use it before then fails that step. Duplicate names and invalid static
mapping remain capability errors. A valid target reports the named element's
current clipped bounds mapped through the collider, whether its live hierarchy
is active, and whether the element (or one of its children) is the top pick at
the reported center. Add the component to the interactive parent, such as the
`Slider`, rather than a decorative overlay.

## Expose product state

QUAK always exposes the reserved `quak-runtime` provider with generic scene
readiness, active scene, and application focus. This is enough for connection
verification, so a project no longer needs a temporary provider just to make
the smoke test ready. Doctor still warns when this is the only provider because
it cannot prove product behavior. Do not register an app provider with the
reserved `quak-runtime` ID.

Implement `IQuakStateProvider` on a component that can read the application's
real state whenever a behavior test needs product facts:

```csharp
using UnityEngine;
using XRDevRob.QUAK;

public sealed class AssemblyQaState : MonoBehaviour, IQuakStateProvider
{
    [SerializeField] private AssemblyBoard board;

    public string ProviderId => "assembly";

    private void OnEnable() => QuakRegistry.Register(this);
    private void OnDisable() => QuakRegistry.Unregister(this);

    public string CaptureStateJson()
    {
        return JsonUtility.ToJson(new Snapshot
        {
            placedCount = board.PlacedCount,
            complete = board.IsComplete,
            validationResult = board.ValidationResult
        });
    }

    [System.Serializable]
    private struct Snapshot
    {
        public int placedCount;
        public bool complete;
        public string validationResult;
    }
}
```

State capture must be read-only, fast, and safe on Unity's main thread. Do not
include credentials, personal information, or stable device identifiers.

After semantic input, assert the resulting state through `quak_get_state`.
Mark at least one value with `"effect": true`; QUAK then requires that value to
both change from its pre-input value and match the expectation. Use `changed`,
`changed_to`, or `increased_by` when the delta itself is the contract.

When the contract is “end in this state” regardless of the starting state, put
`"ensure_effect": true` on the semantic input and close it with an idempotent
final-state assertion such as `equals`. QUAK reads the closing state first,
skips the input if every assertion already passes, and records that skip. If
the state is not satisfied, it sends the input once and still requires a real
correlated state change. Do not use a delta assertion with `ensure_effect`.

## Add deterministic fixture actions

Implement `IQuakActionHandler` only for setup that cannot be expressed cleanly
through production UI, such as resetting an in-memory tutorial flag or
selecting a local test catalog.

A fixture must not perform the interaction under test. If the test verifies
placing a piece, the fixture may reset the board, but the selected XR provider
must still grab, move, and release the piece.

Mark actions that change project assets or settings with
`IsProjectMutation = true`. Running them then requires both `confirm: true` in
the test and `--allow-project-mutations` on the command line.

## Keep correlation meaningful

`QuakRegistry.CurrentCorrelationId` identifies the current QUAK action context.
The registry echoes it in state snapshots. If a test must prove that a product
event handled a specific input, copy the correlation ID into app-owned event
state inside the real event handler and assert that field.

Next: [write a state-closed test](writing-tests.md).
