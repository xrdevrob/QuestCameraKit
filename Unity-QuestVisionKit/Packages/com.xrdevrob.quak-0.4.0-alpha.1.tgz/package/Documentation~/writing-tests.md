# Write tests

QUAK tests are JSON documents with deterministic setup, semantic input, and
independent state assertions. Keep each test focused on one user-visible
behavior.

## Minimal structure

```json
{
  "schema_version": 1,
  "name": "Validate a completed assembly",
  "description": "Clicks Validate and proves the app accepted the board.",
  "target": "simulator",
  "steps": [
    {
      "id": "click-validate",
      "provider": "operator",
      "tool": "quak_click_target",
      "arguments": {
        "target_id": "assembly.ui.validate",
        "hand": "right",
        "hold_duration": 0.15,
        "post_click_wait_seconds": 0.25
      },
      "assertions": [
        {
          "path": "$.data.input_injected",
          "op": "equals",
          "expected": true
        }
      ]
    },
    {
      "id": "assert-validation-result",
      "provider": "unity",
      "tool": "quak_get_state",
      "arguments": {},
      "wait_timeout_seconds": 2,
      "poll_interval_seconds": 0.1,
      "assertions": [
        {
          "path": "$.data.data.result.state.assembly.validationResult",
          "op": "changed_to",
          "expected": "passed",
          "effect": true
        }
      ]
    }
  ]
}
```

The schema retains `"provider": "operator"` as a portable semantic-input alias.
On Quest, the default direct lane executes those steps through QUAK's own layer;
receipts preserve the declared alias and record the actual provider as `direct`.
Use `--quest-provider operator` only for explicit rollback.

The first assertion shows that the selected provider injected the input. The second proves
that the application changed to the expected product state. Without the second
step, this is only an input-transport test. Application-effect closures check
immediately, then poll for up to three seconds at 0.1-second intervals by
default. Set `wait_timeout_seconds` to `0` only for an explicitly instantaneous
contract, or override it for a known slower transition.

For an idempotent action such as “open the menu,” omit transport assertions,
set `"ensure_effect": true` on the semantic input, and close it with a final
state assertion:

```json
[
{
  "id": "ensure-menu-open",
  "provider": "operator",
  "tool": "quak_click_target",
  "arguments": {"target_id": "playback.menu"},
  "ensure_effect": true
},
{
  "id": "menu-is-open",
  "provider": "operator",
  "tool": "quak_get_state",
  "assertions": [
    {
      "path": "$.data.data.result.state.playback.menuOpen",
      "op": "equals",
      "expected": true,
      "effect": true
    }
  ]
}
]
```

QUAK skips the click when the closing assertions already pass; otherwise it
clicks once and requires the correlated state to change. Delta assertions such
as `changed_to` are invalid with `ensure_effect`.

## Validate before running

```bash
./quak validate quak-tests/validate-assembly.json \
  --project /absolute/path/to/MyUnityProject
```

Then run it:

```bash
./quak run quak-tests/validate-assembly.json \
  --project /absolute/path/to/MyUnityProject
```

## Authoring rules

- Arrange through deterministic fixtures or production UI.
- Act through the selected XR provider when embodied input is part of the claim.
- Close every input sequence with independent application state.
- Use an explicit polling bound for asynchronous read-only state or log checks.
- Include a negative control for important acceptance boundaries.
- Keep Simulator, Quest, and Editor results as separate tests or evidence lanes.
- Do not put secrets or personal data in definitions or provider output.

Use `quak_pointer_drag` for a trigger-held pointer drag. Supply 2–32 OpenXR aim
poses; QUAK positions the pointer, presses Trigger, moves through the poses, and
always attempts to release Trigger, including on failure; a failed release fails
the step. The next step must independently assert the product effect:

```json
[
{
  "id": "drag-carousel-left",
  "provider": "operator",
  "tool": "quak_pointer_drag",
  "arguments": {
    "hand": "right",
    "poses": [
      {"position": [0.18, 1.25, -0.55], "orientation": [0, 0, 0, 1]},
      {"position": [-0.18, 1.25, -0.55], "orientation": [0, 0, 0, 1]}
    ],
    "duration_seconds": 0.5
  }
},
{
  "id": "carousel-moved",
  "provider": "operator",
  "tool": "quak_get_state",
  "assertions": [
    {
      "path": "$.data.data.result.state.carousel.index",
      "op": "changed_to",
      "expected": 6,
      "effect": true
    }
  ]
}
]
```

Quest-targeted definitions must include the intended application:

```json
{
  "target": "quest",
  "expected_application_id": "com.example.shippingapp",
  "expected_scene": "MainScene"
}
```

`expected_scene` is optional unless scene identity is part of the test claim.

## Reproduce a Quest lifecycle race

Use `quest_preflight` only for pre-connection device cleanup or a deterministic
product-owned startup route. It first proves that the exact installed package
is debuggable and force-stops it, then accepts an explicit app-data clear,
deletion below that app's external `cache/` or `files/` directory, a bounded
runtime-permission list, and/or a safe absolute `https://` or custom app URI. It
never accepts a shell command or a local-content URI scheme:

```json
"quest_preflight": {
  "clear_app_data": true,
  "delete_app_files": ["cache/SplatCache/example.asset"],
  "grant_runtime_permissions": ["android.permission.CAMERA"],
  "launch_uri": "shippingapp://catalog/carousel",
  "launch_app": true,
  "confirm": true
}
```

Run that definition with the second, command-line confirmation:

```bash
./quak run quak-tests/download-prewarm.json \
  --project /absolute/path/to/MyUnityProject \
  --device-serial <adb-serial> \
  --allow-device-reset
```

Despite its legacy name, `--allow-device-reset` authorizes the whole confirmed
preflight: force-stop/launch plus any requested data reset or runtime-permission
grant. QUAK verifies each permission is requested and runtime-grantable before
mutation, then verifies the grant before launch.

`launch_app` is always true when present and defaults to true. When
`launch_uri` is present QUAK launches that requested route instead of the
package launcher, then waits up to the run timeout for selected-provider readiness.

After connection, use the existing `quak_invoke_action` fixture tool to start
the download and load the scene. Poll recent logs with the same bounded wait
fields used for state, then prove chronological lifecycle order:

```json
{
  "id": "download-prewarm-order",
  "provider": "operator",
  "tool": "quak_get_recent_logs",
  "arguments": {"limit": 200},
  "wait_timeout_seconds": 20,
  "poll_interval_seconds": 0.25,
  "assertions": [
    {
      "path": "$.data",
      "op": "logs_contain_in_order",
      "expected": [
        "download already in flight",
        "download cached",
        "prewarm expectation registered",
        "prewarm ready and bound",
        "playback began"
      ]
    }
  ]
}
```

The runner snapshots the newest log sequence at run start. The matcher ignores
older entries, reads the log object's `newestFirst` flag, and evaluates the
remaining fragments chronologically. Keep the final product-state assertion as
the behavior verdict; logs prove ordering, not user-visible success by
themselves.

## Add visual evidence

Require a bounded recording only when appearance matters:

```json
"visual_evidence": {
  "required": true,
  "capture_policy": "unattended",
  "capture_source": "automatic",
  "eye": "left",
  "fps": 1,
  "max_duration_seconds": 20,
  "focus_clips": "marked-and-failures",
  "target_highlight": "focused-clips"
}
```

This is the **Standard** preset in **QUAK > Control Panel > Tests**. It retains
the unprocessed source, creates a full journey with timed step subtitles, and
creates short focused clips for interaction steps with `visual_annotation` and
for failures.
Omitting `visual_evidence` is **Off**. **Advanced** exposes two deterministic
fields: `focus_clips` (`off`, `marked-and-failures`, or `all-interactions`) and
`target_highlight` (`off`, `focused-clips`, or `all-recordings`). With
`all-recordings`, the live outline is intentionally present in the source.
Quest's stereo screen-recording mirror uses a tested normalized vertical
calibration of `0.13`; set `quest_target_y_offset` only after visual validation
on a different recorder layout (`-0.3` to `0.3`).

QUAK checks the resulting media mechanically and creates a review timeline. It
does not automatically approve its semantic appearance. `unattended` uses a
selected Quest's ADB screen recorder or a pre-authorized macOS Simulator
window, and fails before input when neither is available. It never silently
falls back to a consent prompt.

Set `capture_policy` to `attended` only when a person is present to accept Meta's
compositor-capture consent. That policy also permits an explicit
`openxr_capture_composited_image` step; unattended definitions containing that
tool are invalid.

When virtual/OpenXR compositor layers are part of the visual claim, set
`capture_source` to `compositor`; on Quest, also set `capture_policy` to
`attended`. QUAK then bypasses ADB/window recording and reconstructs the
evidence video from composited frames. The source preserves compositor layers,
but it samples at `fps` (maximum 10), does not represent motion between samples,
and may omit protected content.

Automatic failure diagnostics do not capture images. Add
`--capture-failure-image` only for attended runs after accepting that Meta may
show a media-capture consent screen and move focus away from the app. Explicit
`visual_evidence` remains the bounded, reviewable path for a visual claim.

For the connection smoke only, `./quak verify --visual ...` adds the same
bounded recording without modifying the installed smoke definition.

## Author with a coding agent

Install the optional `quak-test` skill with the release installer's
`--install-codex-skill` option or the Control Panel's Codex integration action.
A useful request is:

```text
Use $quak-test to add a Simulator test for checkout confirmation. Exercise the
real world-space control, prove the confirmation state changed, and include a
passing negative control for an invalid selection.
```

The agent should inspect the real interaction code, add only the necessary
adapter surface, validate the definition, and demonstrate the negative case
before accepting the positive result.
