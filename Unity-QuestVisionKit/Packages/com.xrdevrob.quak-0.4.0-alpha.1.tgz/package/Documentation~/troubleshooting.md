# Troubleshooting

Start with Doctor. It checks the installed versions, configuration, executable
paths, Unity state, selected XR control provider, OpenXR focus, controllers,
and QUAK app tools available for the selected lane.

```bash
./quak doctor \
  --project /absolute/path/to/MyUnityProject \
  --target simulator \
  --live
```

Apply the first reported fix, restart the affected session when requested, and
run Doctor again.

## Python or Homebrew tools are missing over SSH

QUAK requires Python 3.11 or newer. Check `python3 --version`; macOS
`/usr/bin/python3` may still be 3.9 even when Homebrew Python is installed. On
Apple Silicon, invoke `/opt/homebrew/bin/python3` explicitly or set the
non-interactive shell path before running the installer:

```bash
export PATH="/opt/homebrew/bin:$PATH"
python3 --version
```

The same issue can hide `git-lfs`. If a checkout occurred without it, the Unity
worktree can contain small LFS pointer files instead of real assets. Restore the
path, then run `git lfs version`, `git lfs pull`, and `git lfs fsck` before
opening or building the project. Run `git lfs checkout` if pointers remain.

## Installer succeeded but Doctor needs action

This is an installed-but-not-ready result. The installer prints
`[INSTALLATION SUCCEEDED]` and `[READINESS ACTION REQUIRED]` and exits `1` by
default. Resolve Doctor's findings before testing. Use `--allow-unready` only
for an explicit installation-only run. Setup problems and Doctor execution
errors remain non-zero and have distinct labels.

## The project-local command is being bypassed

Run commands from the Unity project root with `./quak`. The installer pins this
launcher to the matching CLI. A global `quak` may be a different version and is
not the supported path for an installed customer project.

## Direct Quest bridge is unavailable

Confirm the app is a debuggable Android Development Build, is focused, and
contains `XR_APILAYER_XRDEVROB_quak_injection`. `adb shell run-as <package>`
must succeed; QUAK uses it to read the rotating app-private token. Do not expose
device port 8720 on the LAN—QUAK creates a temporary dynamic host forward and
removes that exact forward on exit.

If Doctor reports no local-floor space, restore headset tracking/Guardian and
restart the app. QUAK intentionally refuses a local-space fallback because it
would make controller coordinates ambiguous.

## Optional Operator proxy not found

Set the absolute executable path in `.quak/config.json` as instructed by
Doctor. Do not copy a path from another machine or commit a machine-specific
path for teammates. The proxy is only the MCP connector; finding it does not
prove that the native Operator API layer exists or is attached.

## Desktop Operator API layer is missing

This is an `ACTION REQUIRED` result for `lane=standalone-player`. QUAK's
standalone archive option installs only the Android AAR for Quest. Manually
extract Meta XR Operator Standalone 205.1, set `XR_API_LAYER_PATH` to its
`macos` or `windows` folder and
`XR_ENABLE_API_LAYERS=XR_APILAYER_METAX_operator`, then launch a standalone
Development Player from that environment. Do not launch through Editor Play
Mode and do not export those variables into the Unity Editor. Run
`./quak doctor --target simulator --live` or `verify` after launch; only the
live connection proves attachment. The pinned binaries support macOS arm64 and
Windows x86-64 only. On macOS, run `chmod +x` on the extracted
`meta-xr-operator-mcp-proxy` before configuring it.

## Simulator runtime is missing

For the integrated macOS lane, leave Play mode and choose **Meta > Meta XR
Simulator > Activate** in the same Unity Editor process. Then restart Play mode
and rerun live Doctor.

For the standalone lane, launch the development player through Meta's
standalone Operator environment. Do not export those environment variables
into the Unity Editor.

## No XR controller is available

Enable the OpenXR controller interaction profile named by Doctor. Restart Play
Mode in the integrated Editor lane; rebuild and relaunch the player through the
desktop layer in the standalone-player lane. The Input System and the runtime's
matching profile must both be active before Operator input can reach the
application. In direct mode, the same profile must be active before the QUAK
layer can override its supported controller actions.

## QUAK custom tools are missing

Open **QUAK > Control Panel** and click **Set up QUAK**. That enables the QUAK
direct Android layer. Rebuild a Development APK and relaunch it. In the
integrated Editor lane, stop Play mode, allow session teardown to finish,
restart Unity if needed, and establish a fresh Operator session. In the no-Core
Simulator lane, rebuild and relaunch the standalone player through the
configured desktop layer instead.

Only for explicit Quest Operator rollback, rerun `quak setup` with the verified,
user-supplied Meta XR Operator Standalone 205.1 archive. For an integrated Core
`205+` project, do not install the standalone AAR as well.

## Doctor reports a release Quest build

Enable **Development Build** in Unity Build Profiles, rebuild, reinstall, and
rerun live Doctor. QUAK warns in the Control Panel and records the runtime build
flavor, but it never changes this project setting automatically.

## Quest is connected but verification fails

Check that:

- `adb devices` shows the selected serial as authorized;
- developer mode and the in-headset debugging prompt were approved;
- the Development Build has the Android `INTERNET` permission contributed by
  QUAK while its direct layer is selected;
- the QUAK direct API layer is enabled in Android OpenXR settings;
- the expected package is installed and focused; and
- the test or command supplies `expected_application_id`.

Then rerun `verify` with `--device-serial` and the intended package ID. Direct
mode will create and later remove a dynamic forward for that device. If using
explicit `--quest-provider operator`, also verify Meta's experimental boot
property and fixed Operator port forward.

## ADB rejects an older development APK

Alternating a dedicated test build and the full app can make generated Android
version codes decrease. If both development APKs use the same signing key, run:

```bash
adb -s <serial> install -r -d /absolute/path/to/app.apk
```

`-r` replaces the app while preserving data; `-d` permits the version-code
downgrade. A signature mismatch cannot be bypassed this way. Uninstalling first
clears app data and downloaded content, so preserve anything needed before that
destructive fallback.

## Input succeeded but the test failed

This usually means the application did not reach the expected state. Open
`artifacts/run-report.html` and inspect the first failed assertion plus its
before/after values. Do not weaken the assertion merely because the control
provider reported successful injection.

## A recording exists but review is pending

That is expected. Open `artifacts/visual-review.html`, inspect the full timeline
and original video, then save an approval or timestamped requested changes in
the Unity Control Panel. The verdict is stored next to the machine receipt,
which review does not rewrite. The local sidecar is a workflow record, not a
trusted append-only security boundary.
