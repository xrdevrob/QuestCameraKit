# Run your first test

The MR Block Assembly Showcase demonstrates the complete QUAK loop: deterministic
reset, real OpenXR controller input, independent application state, a passing
negative control, and saved evidence.

## Import the sample

In **Window > Package Manager**, select **QUAK**, expand **Samples**, and import
**MR Block Assembly Showcase**.

Open the scene at:

```text
Assets/Samples/QUAK/<installed-version>/MR Block Assembly Showcase/Scenes/BlockAssemblyLab.unity
```

The sample creates five uniquely shaped and colored pieces. QUAK grabs each
piece through OpenXR, carries it to a color-matched socket, and releases it
slightly off-pose. The application decides whether the magnetic snap and final
validation succeeded.

## Start the runtime

For direct Quest, build and launch an Android Development APK, authorize the
headset over ADB, and verify the exact package:

```bash
./quak doctor \
  --project /absolute/path/to/MyUnityProject \
  --target quest \
  --quest-provider direct \
  --device-serial <adb-serial> \
  --expected-application-id com.example.shippingapp \
  --live
```

Direct is the default Quest provider, so `--quest-provider direct` is optional.
It requires no Meta XR package or Operator process.

For the integrated Simulator Editor lane:

1. Leave Play mode.
2. Choose **Meta > Meta XR Simulator > Activate**.
3. Activate Meta XR Operator through Meta XR SDK AI Tools.
4. Enter Play mode and wait for the OpenXR session to focus.

For the standalone Simulator lane, build a development player and launch it through
Meta's standalone Operator layer instead of running the Editor lane. Run Doctor
from that launch environment; a configured MCP proxy alone is insufficient.

Verify the live session:

```bash
./quak doctor \
  --project /absolute/path/to/MyUnityProject \
  --target simulator \
  --live
```

Follow the printed fix for every failed check before continuing.

## Run the passing path

From the Unity project root:

```bash
./quak run \
  "Assets/Samples/QUAK/<installed-version>/MR Block Assembly Showcase/Tests/block-assembly-lab.json" \
  --project /absolute/path/to/MyUnityProject
```

The test selects a puzzle size, connects all five pieces, clicks **Validate**,
and checks application state after every interaction.

## Run the negative control

```bash
./quak run \
  "Assets/Samples/QUAK/<installed-version>/MR Block Assembly Showcase/Tests/block-assembly-wrong-socket.json" \
  --project /absolute/path/to/MyUnityProject
```

This test passes only when the application proves that the wrong placement was
attempted and rejected. It demonstrates why successful input injection is not
enough.

## Review the result

Every run writes evidence under:

```text
.quak/evidence/<run-id>/
```

Start with `artifacts/run-report.html`. If the test recorded video, use
`artifacts/visual-review.html` to inspect mechanical findings, the complete
storyboard, and the original recording. A machine pass with visual evidence
still requires an explicit human or vision review when appearance is part of
the acceptance claim.

Next: [integrate QUAK into your application](integrating-your-app.md).
