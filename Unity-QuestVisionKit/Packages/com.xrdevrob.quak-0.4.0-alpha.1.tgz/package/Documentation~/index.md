# QUAK

QUAK turns Unity CLI and QUAK-owned direct OpenXR commands into repeatable XR
product tests. It gives an automation agent stable interaction targets,
read-only application state, deterministic setup actions, and evidence for
every run. Meta XR Operator remains an optional Simulator/rollback provider.

Use QUAK when a test must exercise the application through OpenXR. Use a normal
Unity test when embodied input is not part of the behavior you need to prove.

!!! warning "Alpha software"
    QUAK and its supported vendor tools are experimental. Pin the supplied
    release, record exact tool versions, and rerun the connection smoke test
    after upgrades.

## Start here

1. [Install QUAK](installation.md) from a supplied release.
2. [Run the Block Assembly test](first-test.md) in Meta XR Simulator.
3. [Expose your application's targets and state](integrating-your-app.md).
4. [Write a state-closed test](writing-tests.md).

## What an QUAK pass means

A successful input call is not a product assertion. QUAK separates four parts:

```text
deterministic setup
    -> OpenXR input through the selected provider
    -> independent application-state assertion
    -> hash-bound receipt and review artifacts
```

For example, "Grip was pressed" does not prove that a piece connected. An QUAK
test can move the controller, press Grip, release near the intended socket, and
then require the application to report that the correct piece connected.

## Core concepts

- **Targets** give important controls and destinations durable semantic IDs.
- **State providers** expose product facts such as selection, placement, route,
  score, or validation result.
- **Fixture actions** provide deterministic setup and reset without performing
  the interaction under test.
- **Tests** arrange, act, and assert with explicit time and environment bounds.
- **Receipts** retain the exact test definition, results, provenance, and
  artifact hashes.

## Choose an environment

| Environment | Use it for |
|---|---|
| Unity Editor | Setup, static checks, and Editor-only control-plane work |
| Meta XR Simulator | Repeatable OpenXR interaction development |
| Quest | Device-specific interaction and performance evidence |

These are separate evidence lanes. A Simulator pass is not a Quest pass, and a
recording is not semantic visual approval. See [Evidence and reviews](evidence-and-reviews.md)
for the exact claim boundaries.
