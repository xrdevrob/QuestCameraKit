# CLI reference

`quak desktop` opens the optional local Quest QA window. See
[the desktop workflow](desktop.md) for running supplied builds without Unity
Editor. Tk is required only for this command.

For integrations, `quak prove ... --json --progress-json` writes one final
result JSON object to stdout and newline-delimited progress objects to stderr.
Progress objects contain `schema_version: 1`, `stage`, and `message`; they report
checking, installing, running, and packaging. Stderr may also contain ordinary
error lines. Progress is not a result or proof of success: consume the final
result and exit code. The final result JSON shape is unchanged.

Run the project-local launcher from the Unity project root:

```bash
./quak --version
```

The launcher selects the CLI pinned alongside the installed Unity package.

## Commands

| Command | Purpose |
|---|---|
| `setup` | Add missing project configuration, smoke test, launcher, and agent skill |
| `doctor` | Check local prerequisites; add `--live` to check the running session |
| `verify` | Prove the selected live connection and write a smoke-test receipt |
| `validate` | Validate a test, parameterized suite, or experiment manifest without running it |
| `run` | Run one test and write evidence |
| `suite` | Run one test across declared case values and write a parent receipt |
| `prove` | Install one exact development APK on Quest, run one test, and bind both identities in the receipt |
| `review-bundle` | Package a visual receipt as a portable offline review ZIP |
| `targets` | List live targets and their hit metadata |
| `regression` | Accept, run, or retire protected tests |
| `experiment` | Run a counterbalanced test-variable or Quest APK experiment |
| `machines` | Check configured workers or run protected tests across them |

Run `./quak <command> --help` for the complete option list installed with your
release.

Quest commands default to `--quest-provider direct`. Add
`--quest-provider operator` only for the provisioned rollback lane. Both use
the same reviewed JSON journeys.

For Simulator, Doctor reports `lane=integrated-editor` or
`lane=standalone-player` with the detected Core version. In the standalone
lane, the proxy and native desktop API layer are separate checks. Static Doctor
requires the exact pinned OpenXR layer manifest/library hashes and launch
environment; live Doctor or `verify` proves that the layer is attached to a
matching non-Editor desktop player.

## Common examples

```bash
# Static project checks
./quak doctor --project /absolute/path/to/MyUnityProject

# Live Simulator checks
./quak doctor --project /absolute/path/to/MyUnityProject \
  --target simulator --live

# Connection smoke with a bounded recording
./quak verify --project /absolute/path/to/MyUnityProject \
  --target simulator --visual

# Validate and run one test
./quak validate quak-tests/checkout.json \
  --project /absolute/path/to/MyUnityProject
./quak run quak-tests/checkout.json \
  --project /absolute/path/to/MyUnityProject

# Run every declared case through the same test and link the child receipts
./quak suite quak-tests/checkout-suite.json \
  --project /absolute/path/to/MyUnityProject

# Compare two declared non-debuggable APKs on one leased Quest
./quak experiment quak-tests/release-artifacts.json \
  --project /absolute/path/to/MyUnityProject \
  --device-serial <adb-serial>

# Install an exact development APK on one Quest and prove one Quest test
./quak prove /absolute/path/to/app.apk quak-tests/checkout-quest.json \
  --project /absolute/path/to/MyUnityProject \
  --build-source-project /absolute/path/to/MyUnityProject \
  --expected-source-commit <40-character-git-commit> \
  --device-serial <adb-serial>

# Explicit rollback; requires the Meta layer and proxy
./quak run quak-tests/checkout-quest.json \
  --project /absolute/path/to/MyUnityProject \
  --target quest --quest-provider operator \
  --device-serial <adb-serial>

# Package any completed visual receipt for management review
./quak review-bundle /absolute/path/to/receipt.json \
  --output /absolute/path/to/checkout-review.zip

# Inspect semantic targets
./quak targets --project /absolute/path/to/MyUnityProject \
  --target simulator

# Protect a known-good test
./quak regression --accept quak-tests/checkout.json \
  --project /absolute/path/to/MyUnityProject

# Run the protected suite
./quak regression --project /absolute/path/to/MyUnityProject
```

`suite` applies `--target` and fills absent `expected_application_id` /
`expected_scene` fields from CLI flags before validating and hashing the
execution definition. Declared identity fields keep precedence. The parent
retains the original file hash separately from `execution_sha256` and requires
each child to match both hashes and its case values.

Distributed regression derives every worker's expected paths from the local
catalog and shard selector. A passing report needs one distinct receipt per
assigned test and matching tested/passed/protected counts. An empty shard is
valid only when the coordinator assigned it no tests.

## Sensitive capabilities

Tests cannot execute shell commands. Project-mutating fixture actions require
`confirm: true` and `--allow-project-mutations`. Unity evaluation tools require
`--allow-eval` and can execute arbitrary code inside the Editor; use them only
with reviewed local code in a disposable or version-controlled checkout.

A Quest `quest_preflight` requires `confirm: true` in the definition and
`--allow-device-reset` on the command. Despite its legacy name, that flag
authorizes the whole preflight—force-stop/launch plus any requested data reset
or runtime-permission grant. Before mutation, QUAK proves that the exact
declared package is debuggable and that every listed permission is requested and
runtime-grantable. It can only clear that package, delete conservative relative
paths below its external `cache/` or `files/` directory, grant the explicit
permission list, or launch a safe absolute product URI. Grants are verified
before launch. A blocking permission prompt fails immediately with remediation;
other launches get a bounded selected-provider readiness wait.
Completed and failed operations are retained in receipt verification metadata.
Because every Quest run immediately needs the app bridge, `launch_app` cannot be
false.

Experiment schema v2 with `mode: "artifact"` runs only on one resolved Quest
and uses the manifest's application and APK identities. Add
`--allow-device-reset` when its `cache_policy` is `clear_app_data`; preserving
app data needs no reset authorization. Every artifact experiment declares
`app_frames_per_second` from PID-bound, fresh `VrApi` logcat samples with an
absolute floor of at least 30 FPS. This keeps CPU or GPU activity from passing
as live XR rendering. Unity/OpenXR apps can additionally declare Quest KGSL GPU
busy and application-process CPU metrics. Gfxinfo metrics remain available for
apps that render through Android UI; a missing declared counter or live
frame-rate sample makes the pair inconclusive.

Live direct Quest commands allocate a dynamic ADB forward to the app's loopback
bridge and authenticate through an app-private token. Only explicit Operator
mode enables Meta's experimental property and configures fixed host port 8720.
Static Doctor does not mutate the device. Before any live Quest mutation, QUAK
takes a host-local lease on the selected serial and fails if another QUAK
process on that host owns it. It does not coordinate separate hosts or bypass
developer-mode/USB approval, Guardian, or proximity focus requirements.

`prove APK TEST` accepts only a regular ZIP-valid `.apk` and a Quest test with
an exact `expected_application_id`. It records the source file SHA-256, size,
package/version/debug metadata from `aapt2`, `aapt`, or `apkanalyzer` and
optional signing metadata from `apksigner`. If the selected headset's sole
canonical `base.apk` already has the supplied file's SHA-256, QUAK reuses it and
records the skipped transfer. Otherwise it uses only the replace/downgrade
`adb install -r -d` command. It never uninstalls or clears app data to recover
from an install failure.
Before running the normal test path, it requires the manifest inspector to prove
the exact package and `debuggable=true`, a debuggable installed package, and a
byte-for-byte match between the supplied APK and the installed `base.apk`; an
executed install must also report ADB's exact `Success`. The receipt binds that
source/deployment metadata and the runner's independently captured installed
APK-set hash. A manifest `quest_preflight` remains separately gated by its own
`confirm: true` and `--allow-device-reset` requirements.
Android App Bundles and split-APK installs are rejected; this command proves one
monolithic APK against one installed `base.apk`.

`--build-source-project` records that Unity workspace's Git state and hashes its
manifest, lock file, and Unity version file beside the APK hash.
`--expected-source-commit` requires an exact 40-character HEAD and fails before
installation on mismatch. This is a local observation, not a signed CI
attestation or reproducible-build proof. Without the source flag, the receipt
marks build-source provenance unavailable. Top-level receipt Git provenance is
only the workspace orchestrating QUAK.

When a `prove` test requests visual evidence, QUAK also creates an offline review
bundle for passing or failing runs. `review-bundle RECEIPT [--output ZIP]` makes
the same deterministic bundle from an existing Editor, Simulator, or Quest
receipt. Bundle creation fails closed if the receipt or hash-bound visual
artifacts are missing, invalid, or changed. A visual run reports a passing
automated journey and capture as `PRODUCT PASSED; EVIDENCE
RECORDED_PENDING_REVIEW`. Product assertions, evidence capture, and overall
required-gate status are separate receipt outcomes. For example, a failed
required recording is `OVERALL FAILED; PRODUCT PASSED; EVIDENCE FAILED` and
returns nonzero. A decoded recording remains pending until human approval. JSON
retains the compatibility status fields and adds `outcomes`, `product_status`,
and `evidence_status`; `acceptance_status` is `evidence_failed` when a run's
optional capture failed even though its product result passed.

A test with no app-owned state value assertion reports `PRODUCT NOT_ASSESSED`.
Its declared diagnostic contract may still make `OVERALL PASSED` and return zero,
but visual JSON uses `acceptance_status: product_not_assessed` rather than
claiming that product acceptance is pending.

Control-provider command acceptance is not input-delivery proof. A semantic input with
no correlated application event or effect reports `OVERALL FAILED; PRODUCT
INCONCLUSIVE`; a correlated changed effect that violates the assertion reports
`PRODUCT FAILED`. Standard visual runs also emit one short, titled clip per
selected interaction under `artifacts/focus/`, with target crop/highlight and
the machine verdict burned in.

Use `quak evidence-settings TEST --mode off|standard|advanced` to apply the
same deterministic policy as the Control Panel. Standard fixes clip selection
to `marked-and-failures` and highlighting to `focused-clips`; Advanced accepts
`--focus-clips` and `--target-highlight` overrides.

Automatic failure diagnostics never request a composited image. The explicit
`--capture-failure-image` flag opts into that extra artifact and may open Meta's
media-capture consent UI, so use it only in an attended lane. Explicit
manifest/`--visual` evidence is separate and remains review-gated.
`setup --operator-standalone-archive <zip>` verifies and installs Meta's pinned,
user-supplied standalone Android AAR; it never downloads or redistributes the
vendor archive.
