# Test a supplied build

QUAK desktop runs reviewed Quest tests against a development APK, without Unity
Editor or a Unity project on the tester's computer. The developer still needs
to include QUAK's Unity integration and development-only direct bridge in the
APK. The Qt desktop app uses the same proof runner as the CLI.

## Install

Package targets are **macOS 15+ on Apple Silicon**, **Windows x64**, and
**Ubuntu 22.04 x64** as the Linux reference target. Python and Qt are bundled.
Intel Mac packages are not provided. Unsigned CI downloads are internal test
candidates; signing and customer onboarding remain separate publication gates.

- macOS: copy **QUAK.app** from the DMG into Applications, then open it.
- Windows: run the per-user installer, then open QUAK from the Start menu.
- Linux: extract the tar archive and launch `QUAK/QUAK` in a graphical session.
  Keep the complete folder, symlinks, and executable permissions together.
  The host supplies glibc, X11, EGL/OpenGL, and XCB libraries. Other distributions,
  ARM Linux, Alpine/musl, and Wayland-only sessions remain unvalidated.

For a Python installation, use Python 3.11–3.14 and the desktop extra:

```sh
python -m pip install 'quak[desktop]'
python -m quak desktop
```

When installing a supplied wheel, append `[desktop]` to its path in the quoted
pip argument. The ordinary CLI remains dependency-free and does not import Qt.

## Set up this computer

Open **Settings** in the sidebar. Install Android SDK Platform-Tools and
Build-Tools from the official Android SDK download, plus FFmpeg/FFprobe if tests
request video. The page links to official downloads and reports available tools.

Choose the SDK root containing `platform-tools` and `build-tools`, optionally a
separate ADB folder, and the folder containing `ffmpeg` and `ffprobe`. QUAK also
checks standard SDK locations and macOS Homebrew folders. No terminal PATH edits
are needed. Choose an **Evidence location**, then click **Save settings**.

Settings use your profile: `~/Library/Application Support/QUAK/desktop.json`
on macOS, `%LOCALAPPDATA%\QUAK\desktop.json` on Windows, and
`$XDG_CONFIG_HOME/QUAK/desktop.json` on Linux (default `~/.config/QUAK/desktop.json`).
Linux discovers `~/Android/Sdk`; empty or relative XDG paths use the default.
QUAK does not install third-party tools, change global PATH, or contact a headset
when saving settings.

## Create a run

1. Open **New run** and choose a development APK. You can also drop an APK into
   the window or use Cmd+O / Ctrl+O.
2. **Add tests** supplied with that build. These are individual reviewed JSON
   test definitions. Select a test to **Move up**, **Move down**, or **Remove**
   it. The displayed order is the execution order; duplicate paths are ignored.
   All tests must specify the same exact application ID as the APK.
3. Connect your development Quest by USB, accept USB debugging in the headset,
   then click **Find headsets**. Explicitly choose the intended device. Discovery
   never selects a headset for you. Keep it awake and complete Guardian setup.
4. Optionally use **Check setup** to validate local tests, tools, and APK identity.
   This does not install, launch, or prove live bridge readiness.
5. Click **Run tests**. The app moves to Results and checks the entire queue before
   installing/reusing the supplied APK. It then checks exact installed APK bytes,
   leases the selected device, and runs the tests. Existing app data is preserved.

The footer tells you what is missing, and Run tests stays disabled until a build,
tests, and an explicit headset are selected. Settings and input changes are
unavailable during work. Privileged preflight, project mutation, and eval are
rejected by the desktop; those workflows need explicit CLI permissions.
Parameterized suite manifests remain available through `quak suite`.

## Review results

Results show queued, running, completed, and **Not run** tests. The queue stops
at its first failure or runner error. Unexecuted tests are never counted as
passes. Overall result, product outcome, and evidence outcome remain distinct;
**Review needed** means a recording is pending human review.

Select a completed test to see its first failure and, where available, expected
and observed values. **Open report** opens its HTML report. **Review recording**
opens the review ZIP's folder: extract it and open `review.html` to review or
request changes. That action is available only when a hash-bound recording and
review bundle exist. **Evidence folder** opens retained files. **Show details**
reveals step counts and receipt location.

**Stop after current test**, closing the window, or quitting during work requests
an orderly stop. The current operation completes and releases its inputs; later
tests do not run. Close or quit again once cleanup has finished. These actions
do not forcibly kill a test or interrupt an APK installation.

Each run creates a unique `desktop-<id>` folder. Earlier evidence stays intact.
The app uses an isolated working directory so an unrelated project's config
cannot redirect a run. Supplied/installed APK hashes remain available; source
provenance is unavailable without an explicit build-source checkout. A passing
machine result is not visual approval. Inspect raw logs and media privately
before sharing. See [evidence and reviews](evidence-and-reviews.md).

Uninstalling the desktop leaves settings and evidence intact. On Linux, delete
the extracted application folder; on macOS remove the app from Applications;
on Windows use the installed uninstaller.

## First-computer pilot

Use a signed artifact and a computer without QUAK or Python installed. Record
OS/CPU, artifact SHA-256, existing prerequisites, elapsed time, trust prompts,
and every support intervention. Follow this page to reach a first meaningful
positive receipt, then run a rejection test and deliberate assertion-failure
control followed by a fourth sentinel test. Verify the queue stops, input is
released, and video/report/review ZIP remain available. A person must review
visual evidence. Uninstall/reinstall and confirm evidence is still usable.

Complete this hardware sequence separately on Windows and Linux before claiming
those platforms' Quest validation. Automated GUI/install checks and fake-provider
UI fixtures do not replace a hardware run or an unfamiliar person's pilot.
