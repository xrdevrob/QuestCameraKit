# QUAK Evaluation and Commercial License Agreement

Version 1.0 — 12 August 2026

Copyright © 2026 XR Dev Rob. All rights reserved.

This agreement governs the QUAK software, Unity package, command-line tools,
samples, documentation, and updates supplied with them (collectively, the
“Software”). “Licensor” means XR Dev Rob or the legal entity identified as the
seller in an applicable quote, invoice, or order. “Customer” means the person
or entity accepting this agreement.

## 1. Acceptance

By installing, copying, or using the Software, Customer accepts this agreement.
If Customer does not accept it, Customer must not use the Software and must
delete all copies. The Software is offered for business and professional use,
not consumer use.

## 2. Orders and evaluation

An “Order” is a quote, invoice, checkout record, or other written confirmation
from Licensor that identifies the licensed customer, term, authorized users,
projects, and any support or services.

If Customer receives the Software without a paid Order, Licensor grants a
non-exclusive, non-transferable 30-day evaluation license for one internal
project and up to three users. Evaluation use is limited to internal testing
and purchasing assessment and may not be used for production release gates.

## 3. Paid license grant

During the term stated in an Order, Licensor grants Customer a non-exclusive,
non-transferable license to install, use, and internally modify the Software
solely for the authorized users and projects stated in that Order. Customer may
make reasonable backup and CI-worker copies for those authorized projects.
Contractors may use the Software only while working for Customer on an
authorized project, and Customer remains responsible for their compliance.

## 4. Restrictions

Except where mandatory law expressly permits otherwise, Customer may not:

- publish, distribute, sublicense, rent, lease, sell, or provide the Software
  or any substantial portion of it to a third party;
- use the Software to provide a competing testing product or hosted service;
- remove or obscure copyright, license, or proprietary notices; or
- disclose credentials, download links, or license keys supplied by Licensor.

Nothing in this agreement limits rights that cannot lawfully be excluded,
including applicable rights to observe, study, test, back up, or obtain
information necessary for interoperability.

## 5. Ownership and feedback

Licensor retains all right, title, and interest in the Software. Customer owns
its applications, project-specific tests, adapters, configuration, and evidence.
Customer may provide feedback voluntarily; Licensor may use that feedback
without restriction or payment, without identifying Customer publicly.

## 6. Third-party products

Unity, Meta, OpenXR, and other third-party products are not included in the
license grant and remain governed by their own terms. Licensor is not
responsible for their availability, licensing, or breaking changes.

## 7. Updates, support, and services

Updates, support, onboarding, and professional services are provided only as
stated in an Order. A license to one version does not promise compatibility
with future versions of third-party products.

## 8. Confidentiality

Non-public Software, credentials, pricing, and technical information marked or
reasonably understood as confidential must be protected with reasonable care
and used only to exercise rights under this agreement. This does not cover
information that is public without breach, independently developed, or
rightfully received without confidentiality obligations.

## 9. Warranty disclaimer

TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SOFTWARE IS PROVIDED “AS IS” AND
WITHOUT WARRANTIES, INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT. XR testing depends on
third-party experimental tools and does not guarantee defect-free releases.

## 10. Limitation of liability

TO THE MAXIMUM EXTENT PERMITTED BY LAW, NEITHER PARTY IS LIABLE FOR INDIRECT,
INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR FOR LOST PROFITS,
REVENUE, DATA, OR BUSINESS INTERRUPTION. EACH PARTY’S TOTAL LIABILITY ARISING
FROM THE SOFTWARE WILL NOT EXCEED THE FEES CUSTOMER PAID FOR THE SOFTWARE IN
THE 12 MONTHS BEFORE THE EVENT GIVING RISE TO THE CLAIM. THESE LIMITS DO NOT
APPLY WHERE LIABILITY CANNOT LAWFULLY BE LIMITED.

## 11. Termination

This agreement ends when the evaluation or paid term expires. Either party may
terminate for a material breach that is not cured within 30 days after written
notice. On termination, Customer must stop using and delete the Software,
except archival copies required by law. Sections intended by their nature to
survive termination remain effective.

## 12. General

Customer may not assign this agreement without Licensor’s written consent,
except with substantially all assets involved in a merger or sale, provided the
successor accepts this agreement. If an Order conflicts with this agreement,
the Order controls for that transaction. If any provision is unenforceable, it
will be narrowed to the minimum extent necessary and the remainder stays in
effect. This agreement and applicable Orders are the complete agreement about
the Software.

Unless an Order states otherwise, Swiss law governs without regard to conflict
of law rules, and the courts of Zurich, Switzerland have exclusive jurisdiction.
