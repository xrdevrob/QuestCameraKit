# Changelog

## 0.4.0-alpha.1 - 2026-09-07

- Rename the product, CLI, Python imports, Unity package/types, native layer,
  bridge tools, skills, firmware, desktop packaging, and repository to Quak.
- This is a breaking rename: install the matching CLI and Unity package, update
  project-owned adapters and tests, then rebuild development APKs. See
  [migration](Documentation~/migration.md). Existing evidence stays untouched.
- Include the Qt desktop source and packaging work; signed desktop installers
  remain subject to the separate distribution gates.

## 0.3.1-alpha.23 - 2026-09-05

- Keep the Block Assembly sample's controller pose through grip release so
  simultaneous hand tracking cannot move the piece before socket validation;
  cancel the held piece safely if its pose device disappears.
- Add an optional local desktop QA window for supplied Quest development APKs,
  with explicit device selection, static readiness checks, a sequential test
  queue, and existing report/review-bundle handoff without Unity Editor.
- Reuse the exact APK proof runner and its cleanup/identity gates; expose
  structured progress separately from the final machine result.
- Add desktop host and native Tk regression checks, plus tester onboarding and
  architecture documentation. The desktop still requires Python with Tk and
  Android/media tools; standalone installer packaging remains future work.

## 0.3.1-alpha.22 - 2026-09-04

- Reject incomplete, duplicate, malformed, or wrong-shard distributed reports;
  require exact protected-test coverage before reporting a pass.
- Bind suite child receipts to the effective target and identity overrides while
  preserving the original test source hash.
- Return validation errors for malformed JSON types, boolean schema versions,
  and non-finite test/experiment values.
- Align Unity human approval with product and evidence outcomes, including
  legacy receipts; retain Quest supervisor logs inside portable review bundles.
- Verify release wheel modules/resources against source, run tests against the
  installed wheel, enable native sanitizer checks, and retain Unity test XML.
- Add repository agent instructions and a maintainer wiki; reconcile evidence
  layout, runner status, and historical Simulator compatibility claims.

## 0.3.1-alpha.21 - 2026-09-04

- Add explicit compositor-frame recording for layer-sensitive visual evidence,
  bypassing native display recorders that may omit virtual/OpenXR layers.

## 0.3.1-alpha.20 - 2026-09-03

- Add opt-in native Quest passthrough control with bounded teardown through the
  direct OpenXR bridge.
- Add a reachable tabletop MR showcase with product-state assertions and an
  Android build gate.
- Add a minimal Python lint gate while preserving Alpha 19's Quest evidence and
  release-integrity checks.

## 0.3.1-alpha.19 - 2026-09-03

- Distinguish diagnostic success from product acceptance, add parameterized
  suites with hash-linked child receipts, and reject effect claims against
  XRQA's own runtime state.
- Add bounded Quest lifecycle, process, and system-log supervision that remains
  available across app bridge loss and verifies device, PID, session, focus,
  wake, and boot continuity.
- Add a counterbalanced observer experiment for uninstrumented APKs with
  hash-bound Perfetto, PID-bound live XR frame-rate evidence, Quest GPU/process,
  optional gfxinfo evidence, declared metric semantics, thermal/cache controls,
  and fail-closed outcomes.
- Install the direct OpenXR layer through Unity's API-layer path without
  globally disabling native-library compression; make setup idempotent and
  fail closed when readiness is incomplete.
- Require byte-reproducible wheel, UPM, and native-layer builds under pinned
  release toolchains before publication.

## 0.3.1-alpha.18 - 2026-09-01

- Report exact runtime extensions, haptic output, display/performance metrics,
  and runtime-confirmed passthrough resume events through the direct bridge;
  retain hash-bound Quest POV recording as separate visual evidence.
- Package the tracked, reviewed Android layer without rebuilding it in place
  during release assembly.

## 0.3.1-alpha.17 - 2026-09-01

- Wait for the OpenXR action-sync boundary before acknowledging raw direct
  controller mutations.
- Require live bound actions for direct readiness so connection verification
  cannot pass on transport alone.
- Keep pointer position and rotation on the same active input device so live
  hand tracking cannot corrupt a direct controller grab.
- Scope the Horizon hand-tracking permission rewrite to direct Android
  Development Builds instead of changing unrelated or release builds.
- Require a clean, commit-bound Quest journey and retained receipt before the
  release candidate is tagged.

## 0.3.1-alpha.16 - 2026-08-31

- Add the primary Operator-free Quest lane: an authenticated app-private bridge,
  dynamic per-device ADB forwarding, a development-only explicit OpenXR layer,
  and a generic Unity Input System controller with fail-closed teardown.
- Complete direct Quest parity with Meta Operator's mutable Touch-controller
  surface: X/Y/Menu, A/B/System, thumbstick click and axes, Trigger/Grip, and
  aim/grip poses while physical hand tracking remains active.
- Add direct instance, system, session, frame, composition-layer, and active
  interaction-profile diagnostics, plus host-local bounded math and Unity/OpenXR
  pose utilities that avoid device round trips.
- Validate those diagnostics and a real controller-driven UI effect in a
  13/13-step Quest 3 run while the Operator process remains untouched.
- Reject stale Android bridge credentials unless they authenticate against the
  live forwarded player, eliminating a force-stop/relaunch startup race.
- Validate the Operator-free path on Quest 3 with the full Block Assembly
  journey and a Meta MR Motifs passthrough on/off round trip.
- Gate publication on pinned native Android/host builds, clean Unity compile and
  EditMode tests, paired development/release APK inspection, and exact packaged
  payload identity; pin third-party GitHub Actions and release build tools.
- Make project-local launchers, device leases, proxy execution, and path/receipt
  validation portable across Windows, macOS, and Linux.
- Add the optional `xrqa-head` USB status display and hash-pinned Waveshare
  firmware preparation without adding a Python runtime dependency.

## 0.3.1-alpha.15 - 2026-08-28

- Reuse an installed monolithic APK when its `base.apk` SHA-256 already matches
  the supplied build, avoiding repeat transfers while retaining exact identity
  verification in the receipt.
- Add explicit Quest runtime-permission preflight: verify each permission is
  requested and runtime-grantable before mutation, grant after any reset, and
  verify the result before launch.
- Fail quickly with actionable guidance for blocking permission prompts and
  headset focus placeholders instead of consuming the full readiness timeout.
- Poll application-effect closures for up to three seconds by default and
  recover conservatively from known Operator backend disconnects by observing
  the declared effect before any author-enabled replay; retry only reads,
  context, and releases at the transport layer.
- Surface provider preparation failures directly in terminal output when no
  test step could run.

## 0.3.1-alpha.14 - 2026-08-25

- Add explicit Off, Standard, and Advanced visual-evidence settings in the
  Control Panel and deterministic test JSON.
- Retain the unprocessed source and full captioned journey while producing one
  short, titled, target-cropped proof clip per selected interaction or failure,
  with explicit full-frame fallback metadata and red-to-green verdict focus.
- Deliver Operator controller input through Meta Interaction SDK on Quest when
  its OVR source is disconnected, without replacing connected OVR controllers.
- Release click Trigger input explicitly instead of relying on Operator's
  scheduled auto-release.

## 0.3.1-alpha.13 - 2026-08-25

- Distinguish an accepted Operator command from confirmed input delivery. When
  the app reports no correlated event or state change, report `PRODUCT
  INCONCLUSIVE` instead of blaming the product.
- Outline the exact runtime target during semantic input and emit a short
  `interaction-focus.mp4` with the input status and verdict burned into the
  picture for review and issue sharing.
- Separate overall, product, and evidence outcomes in receipts, terminal output,
  run reports, and offline reviews.
- Add host-local Quest serial leases before Operator, forwarding, app, or
  recording mutations; release any latched raw controller inputs during cleanup.
- Make Quest proof wait for the real Operator action session, recover once from
  a late non-system app takeover or dropped ADB install transport, and retain a
  useful final-state recording tail.
- Let `prove` record an explicit build-source workspace observation and require
  an exact source commit without mislabeling it as signed build attestation.
- Report locked Input System, OpenXR, optional XRI/Meta Core baselines, and exact
  FFmpeg paths in Doctor; enrich live UI Toolkit semantics and target counts.

## 0.3.1-alpha.12 - 2026-08-23

- Make unattended runs consent-safe: failure images are explicit opt-in,
  diagnostics are globally bounded, and child processes cannot consume stdin.
- Add idempotent final-state input, held-trigger pointer drag, step-scoped live
  target validation, and Unity 6.2+ world-space UI Toolkit targets.
- Add shared interactive/headless Unity setup, automatic Quest Operator
  bootstrap, safely quoted product startup routes, and clearer installer versus
  readiness outcomes.
- Add `prove APK TEST` for exact, data-preserving Quest deployment-to-receipt
  proof and deterministic offline review bundles with hash-bound approvals or
  timestamped change requests.
- Make visual capture policy explicit: unattended native Quest/Simulator lanes
  fail closed, while consent-gated Operator snapshots require attended opt-in;
  preserve remote Quest recordings until local evidence is verified.
- Gate release publication on the Python matrix, static Unity/package integrity,
  and rebuilt release artifacts.
- State receipt/report proof boundaries explicitly and document Python/SSH,
  Git LFS, Guardian/focus, and APK downgrade recovery without overstating XRQA.

## 0.3.1-alpha.11 - 2026-08-19

- Make static Doctor report `integrated-editor` versus `standalone-player` and
  fail closed when the no-Core desktop Operator layer/launch environment is
  missing; live Doctor and direct runs require the matching desktop player
  runtime rather than an Editor or Quest connection.
- Distinguish the MCP proxy from the Operator native API layer throughout
  setup, troubleshooting, installer output, and sample instructions.
- Make the release installer reject pairing its Android-only archive option
  with `--target simulator`.

## 0.3.1-alpha.10 - 2026-08-18

- Stop scheduling the Operator bridge every frame after its one-time tool
  registration. Focus stability now comes directly from OpenXR session-state
  transitions; the six-tool live Quest surface remains unchanged.
- Add a built-in `xrqa-runtime` smoke-readiness provider, expose Unity
  Development Build status, and make live Doctor inspect the real app contract.
- Verify and install the user-supplied Meta XR Operator Standalone 205.1
  Android AAR for Quest, while preserving existing or Core-provided layers;
  desktop setup remains manual.
- Add confirmed, development-build-only Quest fixture cleanup with deterministic
  force-stop/relaunch and bounded readiness; bounded polling for read-only tools;
  and run-bounded chronological log assertions.
- Add opt-in visual connection verification and deduplicate shared-provider
  diagnostics, metadata, and cleanup.
- Point setup and Doctor remediation at **XRQA > Control Panel > Set up XRQA**.

## 0.3.1-alpha.9 - 2026-08-18

- Remove the mandatory Meta XR Core SDK 205, Unity OpenXR Meta, and Unity
  Pipeline package dependencies. Pipeline remains an optional Editor adapter.
- Register XRQA's state, target, fixture, status, correlation, and optional log
  tools directly through the documented
  `XR_METAX1_agentic_external_tool` OpenXR extension.
- Route no-Core Simulator tests entirely through a standalone development
  player's Operator bridge while preserving the Core-205 Editor lane.
- Add explicit OpenXR feature setup, standard OpenXR session-focus reporting,
  automatic runtime bridge creation, bounded two-call callback caching,
  ABI/contract checks, and a no-Meta-Core/Pipeline Doctor lane.
- Live-validate the SDK-independent Quest lane against Meta's Android native
  Operator layer: all six XRQA callbacks and Touch Plus Grip/state observation
  pass without Core, Pipeline, or Unity OpenXR Meta in the project. Doctor only
  requires Unity OpenXR Meta for the integrated Core-205 Quest lane. The exact
  separately downloadable bundle and desktop players remain validation gates.

## 0.3.1-alpha.8 - 2026-08-17

- Add a one-pass whole-video mechanical inspection and hashed 2 fps storyboard
  so reviewers can scan every run quickly and jump to flagged intervals while
  semantic acceptance remains explicit.

## 0.3.1-alpha.7 - 2026-08-17

- Install one executable project-root `./xrqa` launcher and reject newer global
  CLIs when a pinned project environment exists; retain CLI/package version and
  match status in each receipt and Doctor report.
- Accept native fixture-action argument objects while converting to the vendor's
  string transport only at the provider boundary.
- Add concise receipt summaries and a hash-bound static run report with step,
  failure, before/after effect, provenance, diagnostics, and visual links.
- Record Quest visual evidence through bounded ADB screen recording, synchronized
  to steps and correlation annotations, while explicitly leaving native-layer
  visibility pending human review.
- Retain headset model, runtime build, battery state, and installed APK hashes;
  fail performance experiments and protected regression runs on dirty worktrees
  unless explicitly allowed.

## 0.3.1-alpha.6 - 2026-08-17

- Require strict live callback readiness with app/session/focus/provider identity,
  state-closed input sequences, bounded polling, and automatic failure diagnostics.
- Retain the exact hashed test definition, correlation IDs and phase boundaries;
  add paired counterbalanced A/B experiments with raw samples, robust summary
  statistics, metric availability, and JSON plus static HTML reports.
- Retain and label raw visual sources and provenance; reconstructed or annotated
  presentations are never described as raw device footage.
- Add public target configuration and richer world-space introspection. Direct
  compositor ray mapping remains dependent on a vendor/project layer contract.
- Make the wrong-connection negative control pass only when the attempted action
  is independently observed and rejected.
- Explain the first failed step and expected/observed value in human CLI output;
  validate tests and experiment manifests through the same command and checks.
- Add native `changed`, `changed_to`, and `increased_by` effect assertions with
  retained before/after values.
- Recover safely from ambiguous semantic-input timeouts by observing the effect
  first and retrying once only after a bounded unchanged-state proof; retry
  read-only Operator calls once within the original timeout budget.
- Name mirrored and reconstructed recordings honestly, surface native-layer
  visibility limits, document compositor-backed UI Toolkit target authoring,
  and advance the package/CLI version to 0.3.1-alpha.6.

## 0.3.1-alpha.5 - 2026-08-13

- Add a checksum-verifying one-command installer that provisions a pinned
  project-local CLI, portable Unity package, project skill, smoke test, and
  static prerequisite check; the Control Panel discovers that local CLI.
- Add **Verify connection** to the Control Panel; it runs live Doctor followed
  by the connection smoke test, shows exact fixes inline, and reveals the first
  passing receipt.
- Discover Meta's standard local Operator proxy install when it is not on
  `PATH`, and warn when a project exposes no XRQA product test surface.
- Support Unity's project-relative `file:` package sources while rejecting
  missing local sources before setup changes the project.
- Keep the installer's package cache and virtual environment out of source
  control.
- Put latest execution and visual-evidence status on each Tests card, remove
  the separate Results tab, and add a natural-language **Add test with agent**
  handoff that can open the project in Codex.
- Make runtime state explicit with passed/failed/not-run totals, step and
  assertion counts, inline failure details, and browser-friendly recording and
  visual-report actions instead of opening raw receipts.
- Add **Fix with agent** for failed runs; it packages the definition, receipt,
  failed steps and assertions, visual evidence, and rerun requirements into a
  ready-to-send repair task and opens Codex when available.
- Add an automatic validation-device selector ordered as connected ADB Quest,
  Unity Editor, then optional Meta XR Simulator; selected headsets are forwarded
  and addressed by serial by the CLI.
- Add hash-bound human recording approval and timestamped change annotations.
  Visually rejected machine passes stay red and can be handed to the agent; the
  corrective receipt links back to the prior run.

## 0.3.1-alpha.4 - 2026-08-13

- Reject malformed assertion paths instead of silently interpreting a valid
  subset, preventing typo-driven false passes.
- Keep booleans distinct from numbers in equality assertions, and reject
  non-finite Operator poses and click parameters before they reach settle
  checks.
- Reject boolean, negative, or internally inconsistent distributed worker
  counts as malformed reports.
- Reject a blocked Codex skill `agents` path before setup writes any project
  files.
- Reject a missing or relative local UPM package source before setup changes
  the project.
- Reject invalid config versions, paths, executables, and timeouts with a
  concise CLI error.
- Redact `api_key` and `apiKey` receipt fields alongside tokens and secrets.

## 0.3.1-alpha.3 - 2026-08-12

- Keep the installed CLI, Python package, and Unity package versions in sync,
  with a release test preventing future drift.
- Add Unity OpenXR Meta 2.4.0 as an explicit package prerequisite so Quest
  builds retain Unity head/controller tracking and Meta XR Operator together.
- Close the physical Quest 3 controller lane with a successful human puzzle
  solve and an automated Grip-to-socket journey with independent app-state
  assertions.
- Make Doctor fail early when the supported Unity OpenXR Meta package is
  missing from Simulator or Quest projects.

## 0.3.1-alpha.2 - 2026-08-12

- Fail live Doctor when Unity has no XR controller device and report the
  matching OpenXR interaction-profile fix.
- Move both OpenXR aim and grip poses during grab automation so direct Input
  System, XRI, and Meta Interaction SDK controller paths receive the same pose.
- Route `target: quest` app actions and state through the headset Operator
  bridge, fail closed on textual Operator errors, and fall back to an
  instantaneous pose when the device cannot provide an animation start pose.
- Fix the optional XRI UI Toolkit gate to use XRI's supported
  `NearFarInteractor` path and generate the Meta controller sample through
  Meta's public auto-wired rig builder.
- Close the live Simulator gates for Block Assembly, XRI grab, XRI world-space
  UI Toolkit, and Meta Interaction SDK controller grab.

## 0.3.1-alpha.1 - 2026-08-12

- Added customer release artifacts, integrity checksums, source-free install
  instructions, and evaluation/commercial license terms.

- Added explicit regression baselines, target-scoped deterministic CI sharding,
  protected-suite exit codes, a machine-pool editor backed by local SSH aliases,
  concurrent connection checks and suite runs, merged evidence, and a compact
  regression summary in the Unity Control Panel. Distributed runs fail closed
  when a protected target lane, test, report field, or catalog revision is
  missing or inconsistent.
- Delay Meta XR Operator tool registration until its OpenXR function is ready,
  so a late-starting Operator layer cannot leave XRQA tools missing.
- Redesigned the Unity Control Panel around safe one-click setup, connected
  milestone progress, Unity's native progress and ETA display, compact status
  cards, and an optional Codex integration.
- Added optional XRI/UI Toolkit and Meta Interaction SDK controller samples;
  neither SDK is added to XRQA's core dependencies.
- Redesigned the Block Assembly Lab as a selectable square-packing puzzle with
  Easy 4 x 4, Medium 5 x 5, and Hard 6 x 6 modes. A stepped slider and large
  minus/plus buttons choose the size; **New Puzzle** applies and rerolls it,
  while **Reset Pieces** preserves the active seed and layout.
- Generate exactly five connected, uniquely shaped and colored pieces that
  cover the selected square without overlap. Each piece renders as one smooth,
  continuous mesh without visible cell gaps or internal faces.
- Stage generated pieces with bounded assignment and rotation backtracking so
  a valid square cannot fail merely because a greedy tray order overlaps.
- Expanded the success and negative-control tests to cover the five connection
  targets and the independent five-piece product state.
- Generate a fresh runtime-random square partition on every scene load and
  record its size, difficulty, coverage, seed, stable signature, and generator
  validity flags in XRQA state and receipts.
- Require pieces to be within both the socket's positional range and a
  30-degree full-orientation allowance before they can connect, preventing
  upside-down or quarter-turned pieces from snapping into place.
- Add magnetic guide feedback that brightens on approach and pulses when a
  held piece is safe to release, plus a short spatial click after each
  successful placement.
- Rotate Operator-driven pieces smoothly from their live source orientation
  toward the destination orientation during grab-to-target automation.
- Let grab-to-target tests specify a destination-local release position and
  yaw offset, and make the Block Assembly success path deliberately release
  every piece slightly off-pose before Unity performs the magnetic snap.
- Add a placement-margin boundary test covering accepted imperfect placement,
  excessive position error, excessive angle error, and click dispatch.

## 0.3.0 - 2026-08-03

- Renamed the public workflow from journeys to tests while retaining legacy
  compatibility in the CLI and receipts.
- Added the **XRQA > Control Panel** setup, test, and result dashboard.
- Added idempotent project setup and the `xrqa-test` Codex/ChatGPT skill.
- Added explicit false-positive guidance and kept the Cube Assembly sample as
  the generic reference test.

## 0.2.0 - 2026-08-02

- Added the Block Assembly Lab as an importable Unity Package Manager sample.
- Added repeatable block-to-socket and intentional wrong-socket tests.
- Added real OpenXR Grip sequencing with independent Unity state assertions.
- Documented the sample's direct Input System coverage and XRI/Meta Interaction
  SDK boundaries.

## 0.1.0 - 2026-08-02

- Initial alpha.
- Added stable target, app state, and fixture action contracts.
- Added Unity Pipeline commands and Meta XR Operator custom tools.
