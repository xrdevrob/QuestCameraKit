# QUAK Unity package

User documentation: [QUAK documentation](https://xrdevrob.github.io/quak/).

QUAK turns Unity CLI and QUAK-owned direct OpenXR commands into repeatable
product tests. Meta XR Operator remains an optional Simulator/rollback provider:

- World-space Unity UI controls are discovered automatically; optional
  `QuakTarget` aliases cover durable IDs, custom interactions, and destinations.
- `IQuakStateProvider` exposes independent, read-only product facts.
- `IQuakActionHandler` provides deterministic setup and reset fixtures.
- `QuakDirectBridge` exposes that contract over an authenticated, app-private
  development-build channel and drives the packaged QUAK OpenXR API layer. No
  Meta XR package or Operator process is required on Quest.
- `QuakOperatorBridge` preserves the optional Operator rollback path.
- `QuakTarget.Configure` registers public semantic aliases; capability output
  identifies `coordinateSpace: world` and exposes active state, bounds, source,
  owner, and raycast eligibility. Generic rendered visibility and compositor
  layer are explicitly `unavailable` until a project/vendor integration can
  report them.
- **QUAK > Control Panel** performs safe one-click project setup, verifies the
  live connection through the first smoke-test receipt, and shows each test's
  latest pass/fail/not-run result, assertion summary, failures, and
  browser-friendly visual-evidence review actions in place. Its device selector
  prefers an authorized ADB Quest, then Unity Editor, then the optional Meta XR
  Simulator. Human approval or timestamped requested changes are bound to the
  receipt and video hashes. The panel also runs
  target-specific test-machine shards, and turns a natural-language behavior
  or failed receipt into a ready-to-paste task for the developer's existing
  agent.

Import **MR Block Assembly Showcase** for reachable tabletop hand or controller
interaction. In the sample, the selected XR control provider
grabs five differently shaped and colored pieces through OpenXR and packs them
into one square; the sample app
independently decides
whether each connection is correct and whether Validate should pass. A stepped
slider and large minus/plus buttons select Easy 4 x 4, Medium 5 x 5, or Hard
6 x 6. **New Puzzle** applies the size and generates a fresh runtime-random
five-piece partition; **Reset Pieces** preserves the active seed and layout.
Each piece is a smooth continuous mesh and has a unique shape under rotation or
reflection. The receipt records the exercised size, coverage, seed, signature,
and validity flags. The success path releases every piece slightly off-pose so
Unity performs the final magnetic snap. Companion placement-margin and
wrong-connection tests prove the acceptance boundary and demonstrate why
successful input alone is not a product pass.

The wrong-connection sample passes by proving the wrong placement was attempted
and rejected. Every input sequence closes with independent `quak_get_state`
assertions, including an `effect: true` app-state value that must differ from its
pre-input baseline. `changed`, `changed_to`, and `increased_by` retain the exact
before/after values. Application-effect closures poll for up to three seconds by
default and may override that bound; after an ambiguous input timeout or known
backend disconnect, effect observation decides whether QUAK continues, performs
an explicitly authorized retry, or fails without another input. Receipts retain
a redacted test snapshot plus an exact execution hash, action-context correlation/phase evidence,
and bounded automatic failure diagnostics. Recent Unity logs are included only
when their dedicated tool is available.

The release installer creates a project-root `./quak` launcher so terminal and
agent runs use the same pinned CLI as the Control Panel. Receipts retain the CLI
and Unity package identities, a compact run summary, and a hash-bound static
HTML report. Fixture actions accept native argument objects; QUAK performs the
legacy string encoding only at the provider boundary.

Required visual evidence is synchronized to the run. On a selected Quest QUAK
owns bounded ADB screen recording and labels it `device_screenrecord`; Simulator
uses a pre-authorized mirrored window capture. Operator composition snapshots
are reconstructed under explicit `capture_source: compositor`; Quest also
requires `capture_policy: attended`. They are never an automatic fallback. This
explicit source bypasses ADB/window recording for layer-sensitive proof. Device
recording is not a raw per-eye compositor dump and does not prove native-layer
visibility, so visual review remains a separate human gate.
The finished review uses one low-resolution FFmpeg pass to check every decodable
frame for mechanical timing/black/freeze problems and build a clickable 2 fps
timeline. It speeds review without claiming automatic semantic approval.

Install the matching QUAK Python wheel before using the Control Panel. The
customer release includes `QUAK-CUSTOMER-GUIDE.md`, checksums, and the complete
license terms in this package's `LICENSE.md`. The direct Quest lane requires
Unity OpenXR `1.17.1` and ADB, but not Meta XR Core, Unity Pipeline, Unity
OpenXR Meta, the Operator layer, or its MCP proxy. The QUAK layer and
authenticated bridge are development-only. QUAK contributes Android `INTERNET`
only to a direct Development Build; disable the layer before a release build.
Meta XR Core 205+, Unity Pipeline, Unity OpenXR Meta, and Operator 205.1 are
optional dependencies for Simulator or explicit Operator rollback.
Install the release tarball or an exact Git commit, never `#main`. A test or
harness build and test-only navigation do not establish shipping-app behavior.
Quest tests must declare the intended Android package as
`expected_application_id`; add `expected_scene` when scene identity is part of
the proof. Direct mode receives a dynamic per-device ADB forward, so multiple
headsets can run concurrently on one host; a host-local serial lease protects
each device's mutations. Multi-host labs still need an external scheduler.

Quest 3 has successful live direct receipts for the complete 23-step Block
Assembly journey, every Operator-mutable Touch control, and a Meta MR Motifs
passthrough round trip with simultaneous physical hand tracking and no Operator
executable. An earlier direct APK installed on Quest 3S, but that headset's
physical Sensor Lock still prevents app focus; do not generalize the Quest 3
result to that model yet.
