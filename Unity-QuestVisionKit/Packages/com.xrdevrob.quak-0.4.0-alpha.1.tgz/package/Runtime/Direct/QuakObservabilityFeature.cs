using UnityEngine.XR.OpenXR.Features;

#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.XR.OpenXR.Features;
#endif

namespace XRDevRob.QUAK.Direct
{
#if UNITY_EDITOR
    [OpenXRFeature(
        UiName = "QUAK Runtime Observability",
        Desc = "Enables optional Quest performance, refresh-rate, and passthrough resume telemetry.",
        Company = "XR Dev Rob",
        Version = "0.3.1",
        FeatureId = FeatureId,
        OpenxrExtensionStrings = ExtensionNames,
        BuildTargetGroups = new[] { BuildTargetGroup.Android })]
#endif
    public sealed class QuakObservabilityFeature : OpenXRFeature
    {
        public const string FeatureId = "com.xrdevrob.quak.observability";
        public const string ExtensionNames =
            "XR_META_performance_metrics XR_FB_display_refresh_rate " +
            "XR_FB_passthrough XR_META_passthrough_layer_resumed_event";
    }
}
