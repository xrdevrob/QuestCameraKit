using System;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.Features;

#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.XR.OpenXR.Features;
#endif

namespace XRDevRob.QUAK.Direct
{
#if UNITY_EDITOR
    [OpenXRFeature(
        UiName = "QUAK Simultaneous Hands and Controllers",
        Desc = "Enables Meta Quest simultaneous hand and controller tracking.",
        Company = "XR Dev Rob",
        Version = "0.3.1",
        FeatureId = FeatureId,
        OpenxrExtensionStrings = ExtensionName,
        BuildTargetGroups = new[] { BuildTargetGroup.Android })]
#endif
    public sealed class QuakSimultaneousInputFeature : OpenXRFeature
    {
        public const string FeatureId = "com.xrdevrob.quak.simultaneous-input";
        public const string ExtensionName =
            "XR_META_simultaneous_hands_and_controllers";
        private const string ResumeFunctionName =
            "xrResumeSimultaneousHandsAndControllersTrackingMETA";
        private const int ResumeInfoType = 1000532002;

        private ResumeTracking resumeTracking;

        protected override bool OnInstanceCreate(ulong xrInstance)
        {
            resumeTracking = null;
            if (!OpenXRRuntime.IsExtensionEnabled(ExtensionName))
            {
                Debug.LogWarning($"[QUAK] {ExtensionName} is unavailable.");
                return true;
            }

            var getInstanceProcAddr = Marshal.GetDelegateForFunctionPointer<GetInstanceProcAddr>(
                xrGetInstanceProcAddr);
            var result = getInstanceProcAddr(
                xrInstance,
                ResumeFunctionName,
                out var functionPointer);
            if (result != 0 || functionPointer == IntPtr.Zero)
            {
                Debug.LogError($"[QUAK] Could not resolve {ResumeFunctionName}: {result}.");
                return true;
            }

            resumeTracking = Marshal.GetDelegateForFunctionPointer<ResumeTracking>(
                functionPointer);
            return true;
        }

        protected override void OnSessionCreate(ulong xrSession)
        {
            if (resumeTracking == null)
                return;
            var info = new ResumeInfo { Type = ResumeInfoType };
            var result = resumeTracking(xrSession, in info);
            if (result != 0)
                Debug.LogError(
                    $"[QUAK] Simultaneous hand/controller tracking failed: {result}.");
            else
                Debug.Log("[QUAK] Simultaneous hand/controller tracking enabled.");
        }

        protected override void OnInstanceDestroy(ulong xrInstance)
        {
            resumeTracking = null;
        }

        [UnmanagedFunctionPointer(CallingConvention.Winapi)]
        private delegate int GetInstanceProcAddr(
            ulong xrInstance,
            [MarshalAs(UnmanagedType.LPStr)] string name,
            out IntPtr function);

        [UnmanagedFunctionPointer(CallingConvention.Winapi)]
        private delegate int ResumeTracking(ulong xrSession, in ResumeInfo resumeInfo);

        [StructLayout(LayoutKind.Sequential)]
        private struct ResumeInfo
        {
            internal int Type;
            internal IntPtr Next;
        }
    }
}
