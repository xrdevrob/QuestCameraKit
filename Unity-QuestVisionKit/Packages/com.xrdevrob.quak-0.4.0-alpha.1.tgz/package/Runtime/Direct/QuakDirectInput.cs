using System;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;
using UnityEngine.InputSystem.LowLevel;

namespace XRDevRob.QUAK.Direct
{
    internal static class QuakDirectInput
    {
        private const string LayoutName = "QUAKDirectController";
        private const string LayoutJson = @"{
            ""name"": ""QUAKDirectController"",
            ""extend"": ""XRController"",
            ""controls"": [
                { ""name"": ""pointerPosition"", ""layout"": ""Vector3"", ""noisy"": true },
                { ""name"": ""pointerRotation"", ""layout"": ""Quaternion"", ""noisy"": true },
                { ""name"": ""isTracked"", ""layout"": ""Button"", ""format"": ""FLT"" },
                { ""name"": ""grip"", ""layout"": ""Axis"", ""usages"": [""Grip""] },
                { ""name"": ""gripPressed"", ""layout"": ""Button"", ""format"": ""FLT"", ""usages"": [""GripButton""] },
                { ""name"": ""trigger"", ""layout"": ""Axis"", ""usages"": [""Trigger""] },
                { ""name"": ""triggerPressed"", ""layout"": ""Button"", ""format"": ""FLT"", ""usages"": [""TriggerButton""] },
                { ""name"": ""primaryButton"", ""layout"": ""Button"", ""format"": ""FLT"", ""usages"": [""PrimaryButton""] },
                { ""name"": ""secondaryButton"", ""layout"": ""Button"", ""format"": ""FLT"", ""usages"": [""SecondaryButton""] },
                { ""name"": ""menu"", ""layout"": ""Button"", ""format"": ""FLT"", ""usages"": [""MenuButton""] },
                { ""name"": ""thumbstick"", ""layout"": ""Vector2"", ""usages"": [""Primary2DAxis""] },
                { ""name"": ""thumbstickClicked"", ""layout"": ""Button"", ""format"": ""FLT"", ""usages"": [""Primary2DAxisClick""] }
            ]
        }";
        private static readonly InputDevice[] Devices = new InputDevice[2];
        private static readonly Vector2[] Thumbsticks = new Vector2[2];

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void Reset()
        {
            foreach (var device in Devices)
                if (device?.added == true)
                    InputSystem.RemoveDevice(device);
            Array.Clear(Devices, 0, Devices.Length);
            Array.Clear(Thumbsticks, 0, Thumbsticks.Length);
        }

        internal static void SetInput(uint hand, uint component, float value)
        {
            var device = Device(hand);
            var scalar = component switch
            {
                0 => "trigger",
                1 => "grip",
                2 => "primaryButton",
                3 => "secondaryButton",
                4 => "menu",
                5 => "thumbstickClicked",
                6 or 7 => null,
                _ => throw new ArgumentOutOfRangeException(nameof(component))
            };
            if (component is 6 or 7)
            {
                var thumbstick = Thumbsticks[hand];
                if (component == 6)
                    thumbstick.x = value;
                else
                    thumbstick.y = value;
                Thumbsticks[hand] = thumbstick;
                InputState.Change(Required<Vector2Control>(device, "thumbstick"), thumbstick);
            }
            else if (component <= 1)
            {
                InputState.Change(Required<AxisControl>(device, scalar), value);
                InputState.Change(Required<ButtonControl>(device, scalar + "Pressed"), value);
            }
            else
            {
                InputState.Change(Required<ButtonControl>(device, scalar), value);
            }
        }

        internal static void SetPose(
            uint hand,
            uint kind,
            Vector3 position,
            Quaternion rotation)
        {
            var device = Device(hand);
            var prefix = kind switch
            {
                0 => "pointer",
                1 => "device",
                _ => throw new ArgumentOutOfRangeException(nameof(kind))
            };
            InputState.Change(
                Required<Vector3Control>(device, prefix + "Position"),
                new Vector3(position.x, position.y, -position.z));
            InputState.Change(
                Required<QuaternionControl>(device, prefix + "Rotation"),
                new Quaternion(-rotation.x, -rotation.y, rotation.z, rotation.w));
            InputState.Change(Required<ButtonControl>(device, "isTracked"), 1f);
            InputState.Change(
                Required<IntegerControl>(device, "trackingState"),
                (int)(UnityEngine.XR.InputTrackingState.Position |
                      UnityEngine.XR.InputTrackingState.Rotation));
        }

        internal static void SetPoses(
            uint hand,
            Vector3 aimPosition,
            Quaternion aimRotation,
            Vector3 gripPosition,
            Quaternion gripRotation)
        {
            SetPose(hand, 0, aimPosition, aimRotation);
            SetPose(hand, 1, gripPosition, gripRotation);
        }

        internal static void ReleaseAll()
        {
            for (var hand = 0; hand < Devices.Length; hand++)
            {
                var device = Devices[hand];
                if (device?.added != true)
                    continue;
                ChangeIfPresent<AxisControl, float>(device, "trigger", 0f);
                ChangeIfPresent<ButtonControl, float>(device, "triggerPressed", 0f);
                ChangeIfPresent<AxisControl, float>(device, "grip", 0f);
                ChangeIfPresent<ButtonControl, float>(device, "gripPressed", 0f);
                ChangeIfPresent<ButtonControl, float>(device, "isTracked", 0f);
                ChangeIfPresent<IntegerControl, int>(device, "trackingState", 0);
                ChangeIfPresent<ButtonControl, float>(device, "primaryButton", 0f);
                ChangeIfPresent<ButtonControl, float>(device, "secondaryButton", 0f);
                ChangeIfPresent<ButtonControl, float>(device, "menu", 0f);
                ChangeIfPresent<ButtonControl, float>(device, "thumbstickClicked", 0f);
                ChangeIfPresent<Vector2Control, Vector2>(device, "thumbstick", Vector2.zero);
                Thumbsticks[hand] = Vector2.zero;
            }
        }

        private static InputDevice Device(uint hand)
        {
            if (hand >= Devices.Length)
                throw new ArgumentOutOfRangeException(nameof(hand));
            var existing = Devices[hand];
            if (existing?.added == true)
                return existing;

            if (InputSystem.LoadLayout(LayoutName) == null)
                InputSystem.RegisterLayout(LayoutJson);
            var side = hand == 0 ? "Left" : "Right";
            var device = InputSystem.AddDevice(LayoutName, $"QUAK_Virtual_{side}_Controller");
            InputSystem.SetDeviceUsage(
                device, hand == 0 ? CommonUsages.LeftHand : CommonUsages.RightHand);
            Devices[hand] = device;
            return device;
        }

        private static T Required<T>(InputDevice device, string path) where T : InputControl =>
            device.TryGetChildControl<T>(path) ?? throw new InvalidOperationException(
                $"QUAK virtual controller layout has no {path} control.");

        private static void ChangeIfPresent<TControl, TValue>(
            InputDevice device, string path, TValue value)
            where TControl : InputControl
            where TValue : struct
        {
            var control = device.TryGetChildControl<TControl>(path);
            if (control != null)
                InputState.Change(control, value);
        }
    }
}
