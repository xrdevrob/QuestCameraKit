# Third-party notices

QUAK's native OpenXR API layer is compiled against official Khronos OpenXR
headers obtained from the pinned Unity OpenXR Plugin `1.17.1` package. The
headers are build inputs and are not redistributed in this Unity package.

The generated Khronos OpenXR headers state:

> Copyright 2017-2025 The Khronos Group Inc.
> SPDX-License-Identifier: Apache-2.0 OR MIT

The Unity OpenXR Plugin is copyright Unity Technologies ApS and is distributed
under Unity's package licensing terms. The OpenXR specification and loader
documentation are copyright The Khronos Group Inc. and published under the
Creative Commons Attribution 4.0 International License.

- https://www.apache.org/licenses/LICENSE-2.0
- https://opensource.org/license/mit
- https://unity.com/legal/licenses/unity-companion-license
- https://unity.com/legal/terms-of-service/software-legacy
- https://registry.khronos.org/OpenXR/specs/1.1-khr/html/xrspec.html
- https://registry.khronos.org/OpenXR/specs/1.1/loader.html
- https://github.com/KhronosGroup/OpenXR-SDK
