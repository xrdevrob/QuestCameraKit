# QUAK direct OpenXR layer

`Android/arm64/XrApiLayer_QUAK_injection.json` and its adjacent `.so` are the
source pair passed to Unity OpenXR 1.17.1 `ApiLayers.TryAdd` with
`Architecture.Arm64`. Project setup restores the bare `library_path`, so Unity
packages the manifest under `assets/openxr/1/api_layers/explicit.d/` and the
library once under `lib/arm64-v8a/`.

Build the library from the repository root with:

```sh
native/quak_openxr_injection/build-android.sh
```

By default the build downloads the exact Unity OpenXR `1.17.1` archive and
verifies its pinned SHA-256 before extracting `openxr_loader.aar`. It uses
Unity's installed Android NDK. Override `OPENXR_LOADER_AAR` only to supply a
reviewed matching AAR; use `UNITY_ROOT` or `ANDROID_NDK_ROOT` when those tools
live elsewhere. The committed release binary is produced on Linux x86_64 with
NDK 27.2.12479018; other hosts produce local validation builds.

QUAK project setup imports and enables this layer. Android builds only validate
that durable setup state; they do not modify the project. QUAK contributes
Android `INTERNET` permission and the required Quest passthrough declaration only
to a direct Development Build. The import persists in project OpenXR settings,
and a non-development build fails until the QUAK layer is disabled.
