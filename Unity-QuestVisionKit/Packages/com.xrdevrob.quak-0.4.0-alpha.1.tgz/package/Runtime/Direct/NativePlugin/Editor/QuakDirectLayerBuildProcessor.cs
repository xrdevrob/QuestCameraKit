using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.Features;

[assembly: InternalsVisibleTo("XRDevRob.QUAK.Editor.ControlPanel")]
[assembly: InternalsVisibleTo("XRDevRob.QUAK.Tests.Editor")]

namespace XRDevRob.QUAK.Direct.Editor
{
    internal sealed class QuakDirectLayerBuildProcessor : BuildPlayerProcessor
    {
        internal const string LayerName = "XR_APILAYER_XRDEVROB_quak_injection";
        internal const string LibraryFileName = "libXrApiLayer_QUAK_injection.so";
        private const string ManifestFileName = "XrApiLayer_QUAK_injection.json";
        private const string LegacyNativeLibraryAssetPath =
            "Assets/Plugins/Android/arm64-v8a/libXrApiLayer_XRQA_injection.so";
        private const string LegacyNativeDirectoryAssetPath =
            "Assets/Plugins/Android/arm64-v8a";
        private const string Alpha18LegacyNativeLibrarySha256 =
            "f0c27cb22c451f5da375719b1cb6b0c296efa45ffc9e5cf0868c664fd1fb63f4";
        private const string OperatorLayerName = "XR_APILAYER_METAX_operator";
        private const string OperatorFeatureType =
            "XRDevRob.QUAK.MetaOperator.QuakOperatorFeature";
        internal static bool IncludeInternetPermission { get; set; }

        public override int callbackOrder => -10;

        public override void PrepareForBuild(BuildPlayerContext context)
        {
            if (context.BuildPlayerOptions.target != BuildTarget.Android)
                return;

            IncludeInternetPermission = false;

            var settings = OpenXRSettings.GetSettingsForBuildTargetGroup(
                BuildTargetGroup.Android);
            var feature = settings?.GetFeature<ApiLayersFeature>() ??
                throw new BuildFailedException(
                    "Unity OpenXR API Layers feature is unavailable for Android.");
            var development =
                (context.BuildPlayerOptions.options & BuildOptions.Development) != 0;
            var installed = feature.apiLayers.collection.Any(layer =>
                layer.name == LayerName && layer.libraryArchitecture == Architecture.Arm64);
            var operatorEnabled = feature.apiLayers.collection.Any(
                layer => layer.name == OperatorLayerName && layer.isEnabled);
            var operatorFeatureEnabled = settings.GetFeatures().Any(candidate =>
                candidate != null && candidate.enabled &&
                candidate.GetType().FullName == OperatorFeatureType);
            if (!development && (operatorEnabled || operatorFeatureEnabled))
                throw new BuildFailedException(
                    "QUAK Meta XR Operator is debug-only. Disable its OpenXR feature " +
                    "and API layer before making a non-development build.");
            if (development && (operatorEnabled || operatorFeatureEnabled))
            {
                if (installed && feature.apiLayers.IsEnabled(LayerName, Architecture.Arm64))
                    throw new BuildFailedException(
                        "QUAK direct injection cannot be packaged while the Meta XR Operator rollback feature or API layer is enabled.");
                return;
            }

            if (development)
            {
                var error = LayerValidationError(feature);
                if (error != null)
                    throw new BuildFailedException(
                        $"{error} Run QUAK project setup before building.");
                IncludeInternetPermission = true;
            }
            else if (installed && feature.apiLayers.IsEnabled(LayerName, Architecture.Arm64))
                throw new BuildFailedException(
                    "QUAK direct injection is debug-only. Disable the QUAK API layer " +
                    "before making a non-development Android build.");

        }

        internal static bool IsLayerReady(ApiLayersFeature feature) =>
            LayerValidationError(feature) == null;

        internal static void EnsureLayerInstalled(ApiLayersFeature feature)
        {
            var sourceDirectory = SourceDirectory();
            var sourceManifest = Path.Combine(sourceDirectory, ManifestFileName);
            var sourceLibrary = Path.Combine(sourceDirectory, LibraryFileName);
            RemoveLegacyNativePlugin(sourceLibrary);
            var installed = feature.apiLayers.collection.Any(layer =>
                layer.name == LayerName && layer.libraryArchitecture == Architecture.Arm64);
            if (!installed && !feature.apiLayers.TryAdd(
                    sourceManifest, Architecture.Arm64, BuildTargetGroup.Android, out _))
                throw new InvalidOperationException(
                    $"Could not import QUAK API layer from {sourceManifest}.");

            var importedDirectory = ImportedDirectory();
            CopyIfChanged(sourceManifest, Path.Combine(importedDirectory, ManifestFileName));
            CopyIfChanged(
                sourceLibrary,
                Path.Combine(importedDirectory, LibraryFileName));
            NormalizeSerializedLibraryPath(feature);
            feature.apiLayers.SetEnabled(LayerName, Architecture.Arm64, true);
            EditorUtility.SetDirty(feature);
        }

        private static string LayerValidationError(ApiLayersFeature feature)
        {
            if (feature == null || !feature.enabled)
                return "Unity OpenXR API Layers is not enabled for Android.";
            var installed = feature.apiLayers.collection.Any(layer =>
                layer.name == LayerName &&
                layer.libraryArchitecture == Architecture.Arm64);
            if (!installed)
                return "QUAK Android API layer is not imported.";
            if (!feature.apiLayers.collection.Any(layer =>
                    layer.name == LayerName &&
                    layer.libraryArchitecture == Architecture.Arm64 &&
                    layer.libraryPath == LibraryFileName))
                return "QUAK Android API layer must use a filename-only library_path.";
            if (!feature.apiLayers.IsEnabled(LayerName, Architecture.Arm64))
                return "QUAK Android API layer is not enabled.";

            try
            {
                var sourceDirectory = SourceDirectory();
                var importedDirectory = ImportedDirectory();
                if (!FilesEqual(
                        Path.Combine(sourceDirectory, ManifestFileName),
                        Path.Combine(importedDirectory, ManifestFileName)) ||
                    !FilesEqual(
                        Path.Combine(sourceDirectory, LibraryFileName),
                        Path.Combine(importedDirectory, LibraryFileName)))
                    return "QUAK Android API-layer files are missing or stale.";
            }
            catch (Exception exception)
            {
                return $"QUAK Android API-layer files could not be verified: {exception.Message}";
            }
            return null;
        }

        private static string SourceDirectory()
        {
            var package = UnityEditor.PackageManager.PackageInfo.FindForAssembly(
                typeof(QuakDirectLayerBuildProcessor).Assembly);
            if (package == null)
                throw new InvalidOperationException("QUAK package metadata is unavailable.");
            return Path.Combine(
                package.resolvedPath,
                "Runtime", "Direct", "NativePlugin~", "Android", "arm64");
        }

        private static string ImportedDirectory() => Path.Combine(
            Application.dataPath, "XR", "APILayers~", "AndroidLayers", "arm64");

        private static bool FilesEqual(string left, string right) =>
            File.Exists(left) && File.Exists(right) &&
            File.ReadAllBytes(left).SequenceEqual(File.ReadAllBytes(right));

        private static void CopyIfChanged(string source, string destination)
        {
            if (FilesEqual(source, destination))
                return;
            Directory.CreateDirectory(Path.GetDirectoryName(destination) ?? Application.dataPath);
            File.Copy(source, destination, true);
        }

        private static void RemoveLegacyNativePlugin(string sourceLibrary)
        {
            var legacyLibrary = Path.Combine(
                Application.dataPath, "Plugins", "Android", "arm64-v8a", "libXrApiLayer_XRQA_injection.so");
            if (File.Exists(legacyLibrary))
            {
                if (!FilesEqual(sourceLibrary, legacyLibrary) &&
                    FileSha256(legacyLibrary) != Alpha18LegacyNativeLibrarySha256)
                    throw new InvalidOperationException(
                        $"Legacy QUAK native plugin at {legacyLibrary} differs from the " +
                        "installed package. It was preserved; remove or relocate it, then " +
                        "rerun QUAK project setup.");
                if (!AssetDatabase.DeleteAsset(LegacyNativeLibraryAssetPath) ||
                    File.Exists(legacyLibrary))
                    throw new InvalidOperationException(
                        $"Could not remove legacy generated QUAK plugin {legacyLibrary}. " +
                        "Remove it, then rerun QUAK project setup.");
            }

            var legacyDirectory = Path.GetDirectoryName(legacyLibrary);
            if (legacyDirectory != null && Directory.Exists(legacyDirectory) &&
                !Directory.EnumerateFileSystemEntries(legacyDirectory).Any())
                AssetDatabase.DeleteAsset(LegacyNativeDirectoryAssetPath);
        }

        private static string FileSha256(string path)
        {
            using var stream = File.OpenRead(path);
            using var algorithm = SHA256.Create();
            return string.Concat(algorithm.ComputeHash(stream)
                .Select(value => value.ToString("x2")));
        }

        private static void NormalizeSerializedLibraryPath(ApiLayersFeature feature)
        {
            var serialized = new SerializedObject(feature);
            var collection = serialized.FindProperty("m_ApiLayers")?
                .FindPropertyRelative("m_Collection");
            if (collection == null || !collection.isArray)
                throw new InvalidOperationException(
                    "Unity OpenXR API Layers serialization layout is unsupported.");

            for (var index = 0; index < collection.arraySize; index++)
            {
                var layer = collection.GetArrayElementAtIndex(index);
                var json = layer.FindPropertyRelative("m_Json");
                var name = json?.FindPropertyRelative("name");
                var architecture = layer.FindPropertyRelative("m_LibraryArchitecture");
                if (name?.stringValue != LayerName ||
                    architecture?.intValue != (int)Architecture.Arm64)
                    continue;

                var libraryPath = json.FindPropertyRelative("library_path");
                if (libraryPath == null)
                    break;
                libraryPath.stringValue = LibraryFileName;
                serialized.ApplyModifiedPropertiesWithoutUndo();
                return;
            }
            throw new InvalidOperationException(
                "Could not normalize the QUAK Android API-layer library path.");
        }
    }
}
