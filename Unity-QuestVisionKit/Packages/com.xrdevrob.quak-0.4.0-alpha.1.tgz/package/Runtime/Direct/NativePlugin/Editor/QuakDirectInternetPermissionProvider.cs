using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor.Android;
using Unity.XR.Management.AndroidManifest.Editor;
using UnityEngine.XR.OpenXR;

namespace XRDevRob.QUAK.Direct.Editor
{
    public sealed class QuakDirectInternetPermissionProvider :
        IAndroidManifestRequirementProvider
    {
        public ManifestRequirement ProvideManifestRequirement()
        {
            if (!QuakDirectLayerBuildProcessor.IncludeInternetPermission)
                return null;

            return new ManifestRequirement
            {
                SupportedXRLoaders = new HashSet<Type> { typeof(OpenXRLoader) },
                NewElements = new List<ManifestElement>
                {
                    new ManifestElement
                    {
                        ElementPath = new List<string> { "manifest", "uses-permission" },
                        Attributes = new Dictionary<string, string>
                        {
                            { "name", "android.permission.INTERNET" }
                        }
                    },
                    new ManifestElement
                    {
                        ElementPath = new List<string> { "manifest", "uses-feature" },
                        Attributes = new Dictionary<string, string>
                        {
                            { "name", "com.oculus.feature.PASSTHROUGH" },
                            { "required", "true" }
                        }
                    }
                }
            };
        }
    }

    internal sealed class QuakHorizonHandTrackingPermissionProcessor :
        IPostGenerateGradleAndroidProject
    {
        private const string DeprecatedPermission =
            "com.oculus.permission.HAND_TRACKING";
        private const string HorizonPermission =
            "horizonos.permission.HAND_TRACKING";

        public int callbackOrder => 20;

        public void OnPostGenerateGradleAndroidProject(string path)
        {
            if (!QuakDirectLayerBuildProcessor.IncludeInternetPermission)
                return;

            var manifestPath = Path.Combine(
                path, "src", "main", "AndroidManifest.xml");
            var manifest = File.ReadAllText(manifestPath);
            if (manifest.Contains(DeprecatedPermission))
                File.WriteAllText(
                    manifestPath,
                    manifest.Replace(DeprecatedPermission, HorizonPermission));
        }
    }
}
