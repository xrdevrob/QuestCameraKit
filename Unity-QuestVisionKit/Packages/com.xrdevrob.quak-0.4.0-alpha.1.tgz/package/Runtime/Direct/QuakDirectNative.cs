using System;
using System.Runtime.InteropServices;
using UnityEngine;

namespace XRDevRob.QUAK.Direct
{
    internal enum QuakDirectResult
    {
        Success = 0,
        NotReady = 1,
        InvalidArgument = 2,
        NoData = 3,
        Internal = 4
    }

    [StructLayout(LayoutKind.Sequential)]
    internal struct QuakDirectPose
    {
        public float px;
        public float py;
        public float pz;
        public float qx;
        public float qy;
        public float qz;
        public float qw;

        public static QuakDirectPose FromOpenXr(Vector3 position, Quaternion rotation) => new()
        {
            px = position.x,
            py = position.y,
            pz = position.z,
            qx = rotation.x,
            qy = rotation.y,
            qz = rotation.z,
            qw = rotation.w
        };

        public Vector3 Position => new(px, py, pz);
        public Quaternion Rotation => new(qx, qy, qz, qw);
    }

    [StructLayout(LayoutKind.Sequential)]
    internal struct QuakDirectNativeStatus
    {
        public uint abi_version;
        public uint ready;
        public uint session_focused;
        public uint owns_inputs;
        public uint reference_space;
        public uint bound_action_count;
        public ulong sync_epoch;
        public ulong command_serial;
        public ulong applied_serial;
        public long focus_changed_monotonic_ns;
        public long monotonic_now_ns;
        public float focus_stable_seconds;
        public uint injected_read_count;
        public uint session_state;
        public long predicted_display_time;
        public long predicted_display_period;
        public uint should_render;
        public long display_time;
        public uint environment_blend_mode;
        public uint layer_count;
        public uint projection_layer_count;
        public uint quad_layer_count;
        public uint cylinder_layer_count;
        public uint cube_layer_count;
        public uint equirect_layer_count;
        public uint other_layer_count;
        public ulong frame_serial;
        public ulong system_id;
        public uint vendor_id;
        public uint max_swapchain_image_width;
        public uint max_swapchain_image_height;
        public uint max_layer_count;
        public uint orientation_tracking;
        public uint position_tracking;
        public uint enabled_api_layer_count;
        public uint enabled_extension_count;
        public ulong passthrough_resumed_serial;
        public ulong passthrough_resumed_layer;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    internal struct QuakDirectHapticEvent
    {
        public ulong serial;
        public long duration_ns;
        public int result;
        public uint operation;
        public int feedback_type;
        public float frequency;
        public float amplitude;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)] public string action_name;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string subaction_path;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    internal struct QuakDirectPerformanceMetric
    {
        public ulong counter_flags;
        public int counter_unit;
        public uint uint_value;
        public float float_value;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string counter_path;
    }

    [StructLayout(LayoutKind.Sequential)]
    internal struct QuakDirectPassthroughState
    {
        public uint supported;
        public uint enabled;
    }

    internal static class QuakDirectNative
    {
        internal const uint AbiVersion = 4;
        internal const int HapticEventCapacity = 64;
        internal const int PerformanceMetricCapacity = 64;
        private const string Library = "XrApiLayer_QUAK_injection";

#if UNITY_ANDROID && !UNITY_EDITOR
        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        private static extern QuakDirectResult quak_direct_get_status(
            out QuakDirectNativeStatus status);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        private static extern QuakDirectResult quak_direct_set_input(
            uint hand, uint component, float value, uint active, long changeTimeNs);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        private static extern QuakDirectResult quak_direct_set_pose(
            uint hand, uint kind, ref QuakDirectPose pose, uint active, long sampleTimeNs);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        private static extern QuakDirectResult quak_direct_set_poses(
            uint hand,
            ref QuakDirectPose aimPose,
            ref QuakDirectPose gripPose,
            uint active,
            long sampleTimeNs);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        private static extern QuakDirectResult quak_direct_get_pose(
            uint hand, uint kind, out QuakDirectPose pose, out uint active);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        private static extern QuakDirectResult quak_direct_get_head_pose(
            out QuakDirectPose pose, out uint valid, out long sampleTimeNs);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        private static extern QuakDirectResult quak_direct_get_interaction_profile(
            uint hand,
            [Out] byte[] path,
            uint pathCapacity,
            out uint pathCount);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        private static extern QuakDirectResult quak_direct_release_all(long changeTimeNs);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        private static extern QuakDirectResult quak_direct_set_passthrough(
            uint enabled, out QuakDirectPassthroughState state);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        private static extern QuakDirectResult quak_direct_get_haptic_events(
            ulong afterSerial,
            IntPtr events,
            uint eventCapacity,
            out uint eventCount,
            out ulong latestSerial);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        private static extern QuakDirectResult quak_direct_get_performance_metrics(
            IntPtr metrics,
            uint metricCapacity,
            out uint metricCount);
#endif

        internal static QuakDirectResult GetStatus(out QuakDirectNativeStatus status)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            try { return quak_direct_get_status(out status); }
            catch (DllNotFoundException) { }
            catch (EntryPointNotFoundException) { }
#endif
            status = default;
            return QuakDirectResult.NotReady;
        }

        internal static QuakDirectResult SetInput(uint hand, uint component, float value)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            return quak_direct_set_input(
                hand, component, value, 1, 0);
#else
            return QuakDirectResult.NotReady;
#endif
        }

        internal static QuakDirectResult SetPose(
            uint hand, uint kind, Vector3 position, Quaternion rotation)
        {
            var pose = QuakDirectPose.FromOpenXr(position, rotation);
#if UNITY_ANDROID && !UNITY_EDITOR
            return quak_direct_set_pose(
                hand, kind, ref pose, 1, 0);
#else
            return QuakDirectResult.NotReady;
#endif
        }

        internal static QuakDirectResult SetPoses(
            uint hand,
            Vector3 aimPosition,
            Quaternion aimRotation,
            Vector3 gripPosition,
            Quaternion gripRotation)
        {
            var aimPose = QuakDirectPose.FromOpenXr(aimPosition, aimRotation);
            var gripPose = QuakDirectPose.FromOpenXr(gripPosition, gripRotation);
#if UNITY_ANDROID && !UNITY_EDITOR
            return quak_direct_set_poses(
                hand, ref aimPose, ref gripPose, 1, 0);
#else
            return QuakDirectResult.NotReady;
#endif
        }

        internal static QuakDirectResult GetPose(
            uint hand, uint kind, out QuakDirectPose pose, out bool active)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            var result = quak_direct_get_pose(hand, kind, out pose, out var nativeActive);
            active = nativeActive != 0;
            return result;
#else
            pose = default;
            active = false;
            return QuakDirectResult.NotReady;
#endif
        }

        internal static QuakDirectResult GetHeadPose(
            out QuakDirectPose pose, out bool valid, out long sampleTimeNs)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            var result = quak_direct_get_head_pose(out pose, out var nativeValid, out sampleTimeNs);
            valid = nativeValid != 0;
            return result;
#else
            pose = default;
            valid = false;
            sampleTimeNs = 0;
            return QuakDirectResult.NotReady;
#endif
        }

        internal static QuakDirectResult GetInteractionProfile(uint hand, out string profile)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            var buffer = new byte[256];
            var result = quak_direct_get_interaction_profile(
                hand, buffer, (uint)buffer.Length, out var count);
            if (result == QuakDirectResult.Success && count > 0 && count <= buffer.Length)
                profile = System.Text.Encoding.UTF8.GetString(buffer, 0, (int)count - 1);
            else
                profile = null;
            return result;
#else
            profile = null;
            return QuakDirectResult.NotReady;
#endif
        }

        internal static void ReleaseAll()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            try { quak_direct_release_all(0); }
            catch (DllNotFoundException) { }
            catch (EntryPointNotFoundException) { }
#endif
        }

        internal static QuakDirectResult SetPassthrough(
            bool enabled, out QuakDirectPassthroughState state)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            return quak_direct_set_passthrough(enabled ? 1U : 0U, out state);
#else
            state = default;
            return QuakDirectResult.NotReady;
#endif
        }

        internal static QuakDirectResult GetHapticEvents(
            ulong afterSerial,
            int capacity,
            out QuakDirectHapticEvent[] events,
            out ulong latestSerial)
        {
            events = Array.Empty<QuakDirectHapticEvent>();
            latestSerial = 0;
            if (capacity < 0 || capacity > HapticEventCapacity)
                return QuakDirectResult.InvalidArgument;
#if UNITY_ANDROID && !UNITY_EDITOR
            var size = Marshal.SizeOf<QuakDirectHapticEvent>();
            var buffer = capacity == 0 ? IntPtr.Zero : Marshal.AllocHGlobal(size * capacity);
            try
            {
                var result = quak_direct_get_haptic_events(
                    afterSerial, buffer, (uint)capacity, out var count, out latestSerial);
                if (result != QuakDirectResult.Success || count > capacity)
                    return count > capacity ? QuakDirectResult.Internal : result;
                var copiedCount = (int)count;
                events = new QuakDirectHapticEvent[copiedCount];
                for (var index = 0; index < copiedCount; index++)
                    events[index] = Marshal.PtrToStructure<QuakDirectHapticEvent>(
                        IntPtr.Add(buffer, index * size));
                return result;
            }
            catch (DllNotFoundException) { }
            catch (EntryPointNotFoundException) { }
            finally
            {
                if (buffer != IntPtr.Zero)
                    Marshal.FreeHGlobal(buffer);
            }
#endif
            return QuakDirectResult.NotReady;
        }

        internal static QuakDirectResult GetPerformanceMetrics(
            out QuakDirectPerformanceMetric[] metrics)
        {
            metrics = Array.Empty<QuakDirectPerformanceMetric>();
#if UNITY_ANDROID && !UNITY_EDITOR
            var size = Marshal.SizeOf<QuakDirectPerformanceMetric>();
            var buffer = Marshal.AllocHGlobal(size * PerformanceMetricCapacity);
            try
            {
                var result = quak_direct_get_performance_metrics(
                    buffer, PerformanceMetricCapacity, out var count);
                if (result != QuakDirectResult.Success || count > PerformanceMetricCapacity)
                    return count > PerformanceMetricCapacity ? QuakDirectResult.Internal : result;
                metrics = new QuakDirectPerformanceMetric[count];
                for (var index = 0; index < count; index++)
                    metrics[index] = Marshal.PtrToStructure<QuakDirectPerformanceMetric>(
                        IntPtr.Add(buffer, index * size));
                return result;
            }
            catch (DllNotFoundException) { }
            catch (EntryPointNotFoundException) { }
            finally
            {
                Marshal.FreeHGlobal(buffer);
            }
#endif
            return QuakDirectResult.NotReady;
        }
    }
}
