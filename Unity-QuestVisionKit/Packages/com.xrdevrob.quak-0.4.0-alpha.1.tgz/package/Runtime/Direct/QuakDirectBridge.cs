using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Cryptography;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using UnityEngine;
using UnityEngine.Scripting;
using UnityEngine.XR;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.Features;

[assembly: AlwaysLinkAssembly]
[assembly: InternalsVisibleTo("XRDevRob.QUAK.Tests.Editor")]

namespace XRDevRob.QUAK.Direct
{
    [DefaultExecutionOrder(10000)]
    [AddComponentMenu("QUAK/Direct Bridge")]
    public sealed class QuakDirectBridge : MonoBehaviour
    {
        internal const int Port = 8720;
        internal const int MaxMessageBytes = 1024 * 1024;
        private const int RequestTimeoutMilliseconds = 30000;
        private const string TokenFileName = "quak-direct-token";

        private readonly ConcurrentQueue<PendingRequest> pending = new();
        private readonly object clientLock = new();
        private readonly ManualResetEventSlim stopping = new(false);
        private static QuakDirectBridge instance;
        private TcpListener listener;
        private Thread listenerThread;
        private TcpClient activeClient;
        private int releaseManagedInputs;
        private volatile bool running;
        private string token;
        private string tokenPath;

        public static bool IsSupported
        {
            get
            {
#if UNITY_ANDROID && !UNITY_EDITOR
                return Debug.isDebugBuild;
#else
                return false;
#endif
            }
        }

        public static bool IsNativeReady =>
            QuakDirectNative.GetStatus(out var status) == QuakDirectResult.Success &&
            status.ready != 0 && status.session_focused != 0;

        private static void DisableBrokenAndroidApiLayerLogging()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            if (!Debug.isDebugBuild)
                return;

            var field = typeof(ApiLayersFeature).GetField(
                "s_ApiLayersSupport", BindingFlags.Static | BindingFlags.NonPublic);
            if (field?.GetValue(null) is not IList supports)
            {
                Debug.LogWarning("[QUAK] Unity OpenXR API-layer logging compatibility shim could not initialize.");
                return;
            }

            for (var index = supports.Count - 1; index >= 0; index--)
            {
                var type = supports[index]?.GetType().FullName;
                if (type == "UnityEngine.XR.OpenXR.ApiLayers+CoreValidationLogSupport" ||
                    type == "UnityEngine.XR.OpenXR.ApiLayers+ApiDumpLogSupport")
                    supports.RemoveAt(index);
            }
#endif
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void EnsureBridge()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            if (Debug.isDebugBuild && FindAnyObjectByType<QuakDirectBridge>() == null)
                new GameObject("QUAK Direct Bridge").AddComponent<QuakDirectBridge>();
#endif
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStatics()
        {
            instance = null;
            DisableBrokenAndroidApiLayerLogging();
        }

        private void Awake()
        {
            if (!IsSupported || (instance != null && instance != this))
            {
                enabled = false;
                return;
            }
            instance = this;
            try
            {
                DontDestroyOnLoad(gameObject);
                tokenPath = PrivateTokenPath();
                token = NewToken();
                File.WriteAllText(tokenPath, token, new UTF8Encoding(false));
                stopping.Reset();
                listener = new TcpListener(IPAddress.Loopback, Port);
                listener.Start(1);
                running = true;
                listenerThread = new Thread(Listen) { IsBackground = true };
                listenerThread.Start();
                Debug.Log($"[QUAK] Direct bridge listening on 127.0.0.1:{Port}.");
            }
            catch (Exception exception)
            {
                StopBridge();
                instance = null;
                enabled = false;
                Debug.LogError($"[QUAK] Direct bridge could not start: {exception.Message}");
            }
        }

        private void Update()
        {
            if (Interlocked.Exchange(ref releaseManagedInputs, 0) != 0)
                QuakDirectInput.ReleaseAll();
            while (pending.TryDequeue(out var request))
            {
                if (!request.TryBeginDispatch())
                {
                    request.Done.Set();
                    request.Release();
                    continue;
                }
                try
                {
                    request.ResultJson = QuakDirectDispatcher.Invoke(
                        request.Method, request.ArgumentsJson);
                }
                catch (Exception exception)
                {
                    request.Error = exception.Message;
                }
                finally
                {
                    var canceledWhileDispatching = request.CompleteDispatch();
                    request.Done.Set();
                    if (canceledWhileDispatching)
                    {
                        QuakDirectNative.ReleaseAll();
                        QuakDirectInput.ReleaseAll();
                    }
                    request.Release();
                }
            }
        }

        private void OnDestroy()
        {
            if (instance != this)
                return;
            instance = null;
            StopBridge();
        }

        private void StopBridge()
        {
            running = false;
            stopping.Set();
            listener?.Stop();
            lock (clientLock)
                activeClient?.Close();
            listenerThread?.Join(1000);
            while (pending.TryDequeue(out var request))
            {
                request.Cancel();
                request.Error = "QUAK direct bridge stopped";
                request.Done.Set();
                request.Release();
            }
            QuakDirectNative.ReleaseAll();
            QuakDirectInput.ReleaseAll();
            if (!string.IsNullOrEmpty(tokenPath))
            {
                try { File.Delete(tokenPath); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
            listener = null;
            listenerThread = null;
            token = null;
            tokenPath = null;
        }

        private void Listen()
        {
            while (running)
            {
                try
                {
                    using var client = listener.AcceptTcpClient();
                    lock (clientLock)
                    {
                        if (!running)
                            return;
                        activeClient = client;
                    }
                    try
                    {
                        client.ReceiveTimeout = RequestTimeoutMilliseconds;
                        client.SendTimeout = RequestTimeoutMilliseconds;
                        HandleClient(client);
                    }
                    finally
                    {
                        lock (clientLock)
                            if (ReferenceEquals(activeClient, client))
                                activeClient = null;
                    }
                }
                catch (SocketException)
                {
                    if (running)
                        Thread.Sleep(50);
                }
                catch (IOException)
                {
                    if (running)
                        Thread.Sleep(10);
                }
                catch (ObjectDisposedException) { }
                catch (Exception)
                {
                    if (running)
                        Thread.Sleep(10);
                }
            }
        }

        private void HandleClient(TcpClient client)
        {
            try
            {
                using var stream = client.GetStream();
                while (running)
                {
                    var line = ReadBoundedLine(stream);
                    if (line == null)
                        return;
                    DirectRequest envelope;
                    try
                    {
                        envelope = JsonUtility.FromJson<DirectRequest>(line);
                    }
                    catch (ArgumentException)
                    {
                        Write(stream, DirectResponse.Fail(0, "malformed request JSON"));
                        return;
                    }
                    if (envelope == null || envelope.v != 1 || envelope.id <= 0 ||
                        string.IsNullOrWhiteSpace(envelope.method))
                    {
                        Write(stream, DirectResponse.Fail(envelope?.id ?? 0, "invalid request envelope"));
                        return;
                    }
                    if (!TokenEquals(token, envelope.token))
                    {
                        Write(stream, DirectResponse.Fail(envelope.id, "authentication failed"));
                        return;
                    }

                    var request = new PendingRequest(
                        envelope.method,
                        string.IsNullOrWhiteSpace(envelope.arguments_json)
                            ? "{}"
                            : envelope.arguments_json);
                    pending.Enqueue(request);
                    try
                    {
                        var waitResult = WaitHandle.WaitAny(
                            new[] { request.Done.WaitHandle, stopping.WaitHandle },
                            RequestTimeoutMilliseconds);
                        if (waitResult != 0)
                        {
                            request.Cancel();
                            if (waitResult == WaitHandle.WaitTimeout)
                                Write(stream, DirectResponse.Fail(envelope.id, "request timed out"));
                            return;
                        }
                        Write(
                            stream,
                            request.Error == null
                                ? DirectResponse.Pass(envelope.id, request.ResultJson)
                                : DirectResponse.Fail(envelope.id, request.Error));
                    }
                    finally
                    {
                        request.Release();
                    }
                }
            }
            finally
            {
                QuakDirectNative.ReleaseAll();
                Interlocked.Exchange(ref releaseManagedInputs, 1);
            }
        }

        internal static string ReadBoundedLine(Stream stream)
        {
            using var buffer = new MemoryStream();
            while (buffer.Length <= MaxMessageBytes)
            {
                var value = stream.ReadByte();
                if (value < 0)
                    return buffer.Length == 0 ? null : throw new IOException("truncated request");
                if (value == '\n')
                    return Encoding.UTF8.GetString(buffer.ToArray());
                buffer.WriteByte((byte)value);
            }
            throw new IOException("request exceeds 1 MiB");
        }

        private static void Write(Stream stream, DirectResponse response)
        {
            var bytes = Encoding.UTF8.GetBytes(JsonUtility.ToJson(response) + "\n");
            if (bytes.Length > MaxMessageBytes)
                bytes = Encoding.UTF8.GetBytes(
                    JsonUtility.ToJson(DirectResponse.Fail(
                        response.id, "response exceeds 1 MiB")) + "\n");
            stream.Write(bytes, 0, bytes.Length);
            stream.Flush();
        }

        internal static bool TokenEquals(string expected, string actual)
        {
            if (expected == null || actual == null || expected.Length != actual.Length)
                return false;
            var difference = 0;
            for (var index = 0; index < expected.Length; index++)
                difference |= expected[index] ^ actual[index];
            return difference == 0;
        }

        private static string NewToken()
        {
            var bytes = new byte[32];
            using (var random = RandomNumberGenerator.Create())
                random.GetBytes(bytes);
            var result = new StringBuilder(64);
            foreach (var value in bytes)
                result.Append(value.ToString("x2"));
            return result.ToString();
        }

        private static string PrivateTokenPath()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            using var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            using var activity = player.GetStatic<AndroidJavaObject>("currentActivity");
            using var files = activity.Call<AndroidJavaObject>("getFilesDir");
            return Path.Combine(files.Call<string>("getAbsolutePath"), TokenFileName);
#else
            return Path.Combine(Application.temporaryCachePath, TokenFileName);
#endif
        }

        [Serializable]
        private sealed class DirectRequest
        {
            public int v;
            public int id;
            public string token;
            public string method;
            public string arguments_json;
        }

        [Serializable]
        private sealed class DirectResponse
        {
            public int v = 1;
            public int id;
            public bool success;
            public string result_json;
            public string error;

            public static DirectResponse Pass(int id, string result) => new()
            {
                id = id,
                success = true,
                result_json = result ?? "{}"
            };

            public static DirectResponse Fail(int id, string error) => new()
            {
                id = id,
                error = error
            };
        }

        private sealed class PendingRequest
        {
            private const int Queued = 0;
            private const int Dispatching = 1;
            private const int Completed = 2;
            private const int Canceled = 3;
            private const int CanceledWhileDispatching = 4;
            private int owners = 2;
            private int state = Queued;

            public PendingRequest(string method, string argumentsJson)
            {
                Method = method;
                ArgumentsJson = argumentsJson;
            }

            public string Method { get; }
            public string ArgumentsJson { get; }
            public ManualResetEventSlim Done { get; } = new(false);
            public string ResultJson { get; set; }
            public string Error { get; set; }

            public bool TryBeginDispatch() =>
                Interlocked.CompareExchange(ref state, Dispatching, Queued) == Queued;

            public void Cancel()
            {
                while (true)
                {
                    var current = Volatile.Read(ref state);
                    var canceled = current == Queued
                        ? Canceled
                        : current == Dispatching
                            ? CanceledWhileDispatching
                            : current;
                    if (canceled == current ||
                        Interlocked.CompareExchange(ref state, canceled, current) == current)
                        return;
                }
            }

            public bool CompleteDispatch()
            {
                if (Interlocked.CompareExchange(
                        ref state, Completed, Dispatching) == Dispatching)
                    return false;
                return Volatile.Read(ref state) == CanceledWhileDispatching;
            }

            public void Release()
            {
                if (Interlocked.Decrement(ref owners) == 0)
                    Done.Dispose();
            }
        }
    }

    internal static class QuakDirectDispatcher
    {
        internal const int BridgeProtocolVersion = 1;
        internal static readonly string[] BridgeTools =
        {
            "convert_unity_pose_to_openxr",
            "math_build_quat",
            "openxr_get_active_interaction_profile",
            "openxr_get_controller_pose",
            "openxr_get_frame_info",
            "openxr_get_head_pose",
            "openxr_get_haptic_events",
            "openxr_get_instance_info",
            "openxr_get_performance_metrics",
            "openxr_get_session_info",
            "openxr_get_session_state",
            "openxr_get_system_info",
            "openxr_set_controller_input",
            "openxr_set_controller_pose",
            "openxr_set_controller_poses",
            "openxr_set_passthrough",
            "quak_get_capabilities",
            "quak_get_layer_inventory",
            "quak_get_recent_logs",
            "quak_get_state",
            "quak_invoke_action",
            "quak_mark_evidence_target",
            "quak_set_context",
            "quak_status"
        };

        internal static string Invoke(string method, string argumentsJson)
        {
            return method switch
            {
                "quak_status" => StatusJson(),
                "quak_get_capabilities" => QuakRegistry.CapabilitiesJson(),
                "quak_get_layer_inventory" => LayerInventory(),
                "quak_get_state" => QuakRegistry.StateJson(),
                "quak_invoke_action" => InvokeAction(argumentsJson),
                "quak_set_context" => SetContext(argumentsJson),
                "quak_mark_evidence_target" => MarkEvidenceTarget(argumentsJson),
                "quak_get_recent_logs" => RecentLogs(argumentsJson),
                "convert_unity_pose_to_openxr" => ConvertPose(argumentsJson),
                "math_build_quat" => BuildQuaternion(argumentsJson),
                "openxr_get_head_pose" => GetHeadPose(argumentsJson),
                "openxr_get_active_interaction_profile" => GetInteractionProfile(argumentsJson),
                "openxr_get_frame_info" => GetFrameInfo(),
                "openxr_get_haptic_events" => GetHapticEvents(argumentsJson),
                "openxr_get_instance_info" => GetInstanceInfo(),
                "openxr_get_performance_metrics" => GetPerformanceMetrics(),
                "openxr_get_session_info" => GetSessionInfo(),
                "openxr_get_session_state" => GetSessionState(),
                "openxr_get_system_info" => GetSystemInfo(),
                "openxr_set_controller_pose" => SetControllerPose(argumentsJson),
                "openxr_set_controller_poses" => SetControllerPoses(argumentsJson),
                "openxr_get_controller_pose" => GetControllerPose(argumentsJson),
                "openxr_set_controller_input" => SetControllerInput(argumentsJson),
                "openxr_set_passthrough" => SetPassthrough(argumentsJson),
                _ => throw new InvalidOperationException($"Unknown QUAK direct method: {method}")
            };
        }

        private static string StatusJson()
        {
            var runtime = QuakRegistry.CaptureRuntimeStatus();
            var nativeResult = QuakDirectNative.GetStatus(out var native);
            var focused = nativeResult == QuakDirectResult.Success && native.session_focused != 0;
            var focusSeconds = focused ? Mathf.Max(0f, native.focus_stable_seconds) : 0f;
            var errors = runtime.errors.ToList();
            if (nativeResult != QuakDirectResult.Success)
                errors.Add($"QUAK direct native adapter is not ready: {nativeResult}.");
            else if (native.abi_version != QuakDirectNative.AbiVersion)
                errors.Add($"QUAK direct ABI mismatch: expected {QuakDirectNative.AbiVersion}, got {native.abi_version}.");
            else if (native.reference_space != 1)
                errors.Add("QUAK direct native adapter has no local-floor reference space.");
            else if (native.bound_action_count == 0)
                errors.Add("QUAK direct native adapter observed no bound OpenXR actions.");
            return JsonUtility.ToJson(new DirectStatus
            {
                bridgeTools = BridgeTools,
                nativeAbiVersion = native.abi_version,
                ready = runtime.ready && Debug.isDebugBuild && native.ready != 0 && focused &&
                    focusSeconds >= 1f && errors.Count == 0,
                playing = true,
                runtime = runtime,
                sessionId = runtime.sessionId,
                sessionAgeSeconds = runtime.sessionAgeSeconds,
                applicationId = runtime.applicationId,
                applicationVersion = runtime.applicationVersion,
                unityVersion = runtime.unityVersion,
                activeScene = runtime.activeScene,
                isEditor = runtime.isEditor,
                runtimePlatform = runtime.runtimePlatform,
                developmentBuild = runtime.developmentBuild,
                correlationId = runtime.correlationId,
                stateProviders = runtime.stateProviders.ToArray(),
                applicationFocused = runtime.applicationFocused,
                inputFocused = focused,
                vrFocused = focused,
                focusStableSeconds = focusSeconds,
                syncEpoch = native.sync_epoch,
                commandSerial = native.command_serial,
                appliedSerial = native.applied_serial,
                boundActionCount = native.bound_action_count,
                injectedReadCount = native.injected_read_count,
                ownsInputs = native.owns_inputs != 0,
                errors = errors.ToArray()
            });
        }

        private static string InvokeAction(string json)
        {
            var input = Parse<InvokeInput>(json);
            return JsonUtility.ToJson(QuakRegistry.InvokeAction(
                input.action_id, input.arguments_json, input.confirm));
        }

        private static string SetContext(string json)
        {
            var input = Parse<ContextInput>(json);
            return JsonUtility.ToJson(new ContextResult
            {
                success = true,
                correlationId = QuakRegistry.SetCorrelationId(input.correlation_id)
            });
        }

        private static string MarkEvidenceTarget(string json)
        {
            var input = Parse<EvidenceInput>(json);
            return JsonUtility.ToJson(QuakRegistry.MarkEvidenceTarget(
                input.target_id,
                input.status,
                string.IsNullOrWhiteSpace(input.eye) ? "mono" : input.eye,
                input.hide_outline));
        }

        private static string RecentLogs(string json)
        {
            var input = Parse<RecentLogsInput>(json);
            return QuakRegistry.RecentLogsJson(
                input.limit > 0 ? Mathf.RoundToInt(input.limit) : QuakRegistry.DefaultRecentLogLimit);
        }

        private static QuakDirectNativeStatus NativeStatus()
        {
            RequireSuccess(QuakDirectNative.GetStatus(out var status));
            if (status.abi_version != QuakDirectNative.AbiVersion)
                throw new InvalidOperationException(
                    $"QUAK direct ABI mismatch: expected {QuakDirectNative.AbiVersion}, got {status.abi_version}.");
            return status;
        }

        private static string GetInstanceInfo()
        {
            var status = NativeStatus();
            var availableExtensions = OpenXRRuntime.GetAvailableExtensions();
            var enabledExtensions = OpenXRRuntime.GetEnabledExtensions();
            Array.Sort(availableExtensions, StringComparer.Ordinal);
            Array.Sort(enabledExtensions, StringComparer.Ordinal);
            return JsonUtility.ToJson(new InstanceInfoOutput
            {
                applicationName = Application.productName,
                applicationVersion = Application.version,
                engineName = "Unity",
                engineVersion = Application.unityVersion,
                runtimeName = OpenXRRuntime.name,
                runtimeVersion = OpenXRRuntime.version,
                openXrApiVersion = OpenXRRuntime.apiVersion,
                enabledApiLayerCount = status.enabled_api_layer_count,
                enabledExtensionCount = status.enabled_extension_count,
                observedApiLayers = new[] { "XR_APILAYER_XRDEVROB_quak_injection" },
                availableExtensions = availableExtensions,
                enabledExtensions = enabledExtensions
            });
        }

        private static string GetPerformanceMetrics()
        {
            var status = NativeStatus();
            var displays = new List<XRDisplaySubsystem>();
            SubsystemManager.GetSubsystems(displays);
            var display = displays.FirstOrDefault(item => item.running) ?? displays.FirstOrDefault();
            var metricsResult = QuakDirectNative.GetPerformanceMetrics(out var nativeMetrics);
            var refreshRateHz = 0f;
            var refreshRateAvailable = display != null &&
                display.TryGetDisplayRefreshRate(out refreshRateHz);
            return JsonUtility.ToJson(new PerformanceMetricsOutput
            {
                extensionEnabled = OpenXRRuntime.IsExtensionEnabled(
                    "XR_META_performance_metrics"),
                refreshRateExtensionEnabled = OpenXRRuntime.IsExtensionEnabled(
                    "XR_FB_display_refresh_rate"),
                metricsResult = metricsResult.ToString(),
                metricsAvailable = metricsResult == QuakDirectResult.Success,
                refreshRateAvailable = refreshRateAvailable,
                currentRefreshRateHz = refreshRateAvailable ? refreshRateHz : 0f,
                predictedRefreshRateHz = status.predicted_display_period > 0
                    ? 1_000_000_000f / status.predicted_display_period
                    : 0f,
                metrics = nativeMetrics
                    .OrderBy(item => item.counter_path, StringComparer.Ordinal)
                    .Select(item => new PerformanceMetric
                    {
                        path = item.counter_path ?? string.Empty,
                        counterFlags = item.counter_flags,
                        unitCode = item.counter_unit,
                        unit = PerformanceMetricUnit(item.counter_unit),
                        uintValue = item.uint_value,
                        floatValue = item.float_value
                    }).ToArray()
            });
        }

        private static string GetHapticEvents(string json)
        {
            var input = Parse<HapticEventsInput>(json);
            if (input.after_serial < 0)
                throw new ArgumentException("after_serial must be non-negative");
            if (input.limit < 0 || input.limit > QuakDirectNative.HapticEventCapacity)
                throw new ArgumentException(
                    $"limit must be between 0 and {QuakDirectNative.HapticEventCapacity}");
            var limit = input.limit == 0 ? 32 : input.limit;
            RequireSuccess(QuakDirectNative.GetHapticEvents(
                (ulong)input.after_serial, limit, out var nativeEvents, out var latestSerial));
            var events = nativeEvents.Select(item => new HapticEventOutput
            {
                serial = item.serial,
                operation = item.operation switch { 1 => "apply", 2 => "stop", _ => "unknown" },
                result = item.result,
                feedbackType = item.feedback_type,
                durationNanoseconds = item.duration_ns,
                frequency = item.frequency,
                amplitude = item.amplitude,
                actionName = item.action_name ?? string.Empty,
                subactionPath = item.subaction_path ?? string.Empty
            }).ToArray();
            return JsonUtility.ToJson(new HapticEventsOutput
            {
                latestSerial = latestSerial,
                truncated = latestSerial > (ulong)input.after_serial &&
                    (events.Length == 0 ||
                     events[0].serial > (ulong)input.after_serial + 1 ||
                     events[^1].serial < latestSerial),
                events = events
            });
        }

        private static string PerformanceMetricUnit(int unit) => unit switch
        {
            0 => "generic",
            1 => "percentage",
            2 => "milliseconds",
            3 => "bytes",
            4 => "hertz",
            _ => "unknown"
        };

        private static string GetSessionInfo()
        {
            var status = NativeStatus();
            return JsonUtility.ToJson(new SessionInfoOutput
            {
                state = SessionStateName(status.session_state),
                stateCode = status.session_state,
                focused = status.session_focused != 0,
                ready = status.ready != 0,
                systemId = status.system_id,
                referenceSpace = status.reference_space == 1 ? "local_floor" : "local"
            });
        }

        private static string GetSessionState()
        {
            var status = NativeStatus();
            return JsonUtility.ToJson(new SessionStateOutput
            {
                state = SessionStateName(status.session_state),
                stateCode = status.session_state
            });
        }

        private static string GetFrameInfo()
        {
            var status = NativeStatus();
            return JsonUtility.ToJson(new FrameInfoOutput
            {
                frameSerial = status.frame_serial,
                predictedDisplayTime = status.predicted_display_time,
                predictedDisplayPeriod = status.predicted_display_period,
                shouldRender = status.should_render != 0,
                displayTime = status.display_time,
                environmentBlendMode = BlendModeName(status.environment_blend_mode),
                compositionLayers = LayerSummary(status)
            });
        }

        private static string LayerInventory()
        {
            var status = NativeStatus();
            var layers = new List<LayerInventoryEntry>();
            AddLayer(layers, "projection", status.projection_layer_count);
            AddLayer(layers, "quad", status.quad_layer_count);
            AddLayer(layers, "cylinder", status.cylinder_layer_count);
            AddLayer(layers, "cube", status.cube_layer_count);
            AddLayer(layers, "equirect", status.equirect_layer_count);
            AddLayer(layers, "other", status.other_layer_count);
            return JsonUtility.ToJson(new LayerInventoryOutput
            {
                frameSerial = status.frame_serial,
                displayTime = status.display_time,
                environmentBlendMode = BlendModeName(status.environment_blend_mode),
                layerCount = status.layer_count,
                passthroughEventSupported = OpenXRRuntime.IsExtensionEnabled(
                    "XR_META_passthrough_layer_resumed_event"),
                passthroughResumedObserved = status.passthrough_resumed_serial != 0,
                passthroughResumedSerial = status.passthrough_resumed_serial,
                passthroughLayer = status.passthrough_resumed_layer,
                layers = layers.ToArray()
            });
        }

        private static string GetSystemInfo()
        {
            var status = NativeStatus();
            return JsonUtility.ToJson(new SystemInfoOutput
            {
                systemId = status.system_id,
                vendorId = status.vendor_id,
                systemName = SystemInfo.deviceModel,
                runtimeName = OpenXRRuntime.name,
                maxSwapchainImageWidth = status.max_swapchain_image_width,
                maxSwapchainImageHeight = status.max_swapchain_image_height,
                maxLayerCount = status.max_layer_count,
                orientationTracking = status.orientation_tracking != 0,
                positionTracking = status.position_tracking != 0,
                graphicsDeviceName = SystemInfo.graphicsDeviceName,
                graphicsDeviceType = SystemInfo.graphicsDeviceType.ToString()
            });
        }

        private static string GetInteractionProfile(string json)
        {
            var input = Parse<InteractionProfileInput>(json);
            if (!string.IsNullOrEmpty(input.hand) &&
                input.hand != "left" && input.hand != "right" && input.hand != "both")
                throw new ArgumentException("hand must be left, right, or both");
            var both = string.IsNullOrEmpty(input.hand) || input.hand == "both";
            var output = new InteractionProfilesOutput();
            if (both || input.hand == "left")
                output.left = InteractionProfile(0);
            if (both || input.hand == "right")
                output.right = InteractionProfile(1);
            return JsonUtility.ToJson(output);
        }

        private static InteractionProfileOutput InteractionProfile(uint hand)
        {
            RequireSuccess(QuakDirectNative.GetInteractionProfile(hand, out var profile));
            return new InteractionProfileOutput { profile = profile };
        }

        private static LayerSummaryOutput LayerSummary(QuakDirectNativeStatus status) => new()
        {
            total = status.layer_count,
            projection = status.projection_layer_count,
            quad = status.quad_layer_count,
            cylinder = status.cylinder_layer_count,
            cube = status.cube_layer_count,
            equirect = status.equirect_layer_count,
            other = status.other_layer_count
        };

        private static void AddLayer(List<LayerInventoryEntry> layers, string type, uint count)
        {
            if (count != 0)
                layers.Add(new LayerInventoryEntry { type = type, count = count });
        }

        private static string SessionStateName(uint state) => state switch
        {
            1 => "IDLE",
            2 => "READY",
            3 => "SYNCHRONIZED",
            4 => "VISIBLE",
            5 => "FOCUSED",
            6 => "STOPPING",
            7 => "LOSS_PENDING",
            8 => "EXITING",
            _ => "UNKNOWN"
        };

        private static string BlendModeName(uint mode) => mode switch
        {
            1 => "OPAQUE",
            2 => "ADDITIVE",
            3 => "ALPHA_BLEND",
            _ => "UNKNOWN"
        };

        private static string ConvertPose(string json)
        {
            var input = Parse<PoseInput>(json);
            RequireVector(input.position, "position", 3);
            var result = new PoseOutput
            {
                position = new[] { input.position[0], input.position[1], -input.position[2] }
            };
            if (input.orientation != null && input.orientation.Length > 0)
            {
                RequireQuaternion(input.orientation, "orientation");
                result.orientation = new[]
                {
                    -input.orientation[0], -input.orientation[1],
                    input.orientation[2], input.orientation[3]
                };
            }
            return JsonUtility.ToJson(result);
        }

        private static string BuildQuaternion(string json)
        {
            var input = Parse<QuaternionInput>(json);
            RequireVector(input.front_direction, "front_direction", 3);
            var unityDirection = new Vector3(
                input.front_direction[0], input.front_direction[1], -input.front_direction[2]);
            if (unityDirection.sqrMagnitude < 1e-12f)
                throw new ArgumentException("front_direction must not be zero");
            var rotation = Quaternion.LookRotation(unityDirection.normalized);
            return JsonUtility.ToJson(new QuaternionOutput
            {
                quaternion = new[] { -rotation.x, -rotation.y, rotation.z, rotation.w }
            });
        }

        private static string SetControllerInput(string json)
        {
            var input = Parse<ControllerInput>(json);
            var hand = Hand(input.hand);
            var component = Component(input.hand, input.component, input.sub_component);
            var thumbstick = component is 6 or 7;
            if (!Finite(input.value) || (thumbstick
                    ? input.value < -1f || input.value > 1f
                    : input.value < 0f || input.value > 1f))
                throw new ArgumentException(
                    thumbstick ? "Thumbstick value must be between -1 and 1" :
                    "value must be between 0 and 1");
            RequireSuccess(QuakDirectNative.SetInput(hand, component, input.value));
            QuakDirectInput.SetInput(hand, component, input.value);
            return "{}";
        }

        private static string SetPassthrough(string json)
        {
            if (string.IsNullOrWhiteSpace(json) ||
                !System.Text.RegularExpressions.Regex.IsMatch(
                    json,
                    "^\\s*\\{\\s*\\\"enabled\\\"\\s*:\\s*(?:true|false)\\s*\\}\\s*$",
                    System.Text.RegularExpressions.RegexOptions.CultureInvariant))
                throw new ArgumentException("enabled must be a boolean");
            var input = Parse<PassthroughInput>(json);
            RequireSuccess(QuakDirectNative.SetPassthrough(input.enabled, out var state));
            return JsonUtility.ToJson(new PassthroughOutput
            {
                supported = state.supported != 0,
                enabled = state.enabled != 0
            });
        }

        private static string SetControllerPose(string json)
        {
            var input = Parse<ControllerPoseInput>(json);
            if (!string.IsNullOrWhiteSpace(input.base_space) && input.base_space != "local_floor")
                throw new ArgumentException("base_space must be local_floor");
            RequireVector(input.position, "position", 3);
            RequireQuaternion(input.orientation, "orientation");
            var hand = Hand(input.hand);
            var kind = PoseKind(input.pose_type);
            var position = new Vector3(input.position[0], input.position[1], input.position[2]);
            var rotation = new Quaternion(
                input.orientation[0], input.orientation[1],
                input.orientation[2], input.orientation[3]);
            RequireSuccess(QuakDirectNative.SetPose(hand, kind, position, rotation));
            QuakDirectInput.SetPose(hand, kind, position, rotation);
            return "{}";
        }

        private static string SetControllerPoses(string json)
        {
            var input = Parse<ControllerPosesInput>(json);
            if (!string.IsNullOrWhiteSpace(input.base_space) && input.base_space != "local_floor")
                throw new ArgumentException("base_space must be local_floor");
            RequireVector(input.aim_position, "aim_position", 3);
            RequireQuaternion(input.aim_orientation, "aim_orientation");
            RequireVector(input.grip_position, "grip_position", 3);
            RequireQuaternion(input.grip_orientation, "grip_orientation");
            var hand = Hand(input.hand);
            var aimPosition = new Vector3(
                input.aim_position[0], input.aim_position[1], input.aim_position[2]);
            var aimRotation = new Quaternion(
                input.aim_orientation[0], input.aim_orientation[1],
                input.aim_orientation[2], input.aim_orientation[3]);
            var gripPosition = new Vector3(
                input.grip_position[0], input.grip_position[1], input.grip_position[2]);
            var gripRotation = new Quaternion(
                input.grip_orientation[0], input.grip_orientation[1],
                input.grip_orientation[2], input.grip_orientation[3]);
            RequireSuccess(QuakDirectNative.SetPoses(
                hand,
                aimPosition, aimRotation, gripPosition, gripRotation));
            QuakDirectInput.SetPoses(
                hand, aimPosition, aimRotation, gripPosition, gripRotation);
            return "{}";
        }

        private static string GetControllerPose(string json)
        {
            var input = Parse<ControllerPoseQuery>(json);
            if (!string.IsNullOrWhiteSpace(input.base_space) && input.base_space != "local_floor")
                throw new ArgumentException("base_space must be local_floor");
            RequireSuccess(QuakDirectNative.GetPose(
                Hand(input.hand), PoseKind(input.pose_type), out var pose, out var active));
            if (!active)
                throw new InvalidOperationException("controller pose is inactive");
            RequireApplied();
            return PoseResult(pose);
        }

        private static string GetHeadPose(string json)
        {
            var input = Parse<HeadPoseInput>(json);
            if (!string.IsNullOrWhiteSpace(input.base_space) && input.base_space != "local_floor")
                throw new ArgumentException("base_space must be local_floor");
            RequireSuccess(QuakDirectNative.GetHeadPose(out var pose, out var valid, out _));
            if (!valid)
                throw new InvalidOperationException("head pose is invalid");
            return PoseResult(pose);
        }

        private static string PoseResult(QuakDirectPose openXrPose)
        {
            return JsonUtility.ToJson(new PoseResultOutput
            {
                pose = new PoseOutput
                {
                    position = new[] { openXrPose.px, openXrPose.py, openXrPose.pz },
                    orientation = new[]
                    {
                        openXrPose.qx, openXrPose.qy, openXrPose.qz, openXrPose.qw
                    }
                }
            });
        }

        private static void RequireApplied()
        {
            RequireSuccess(QuakDirectNative.GetStatus(out var status));
            if (status.applied_serial < status.command_serial)
                throw new InvalidOperationException(
                    $"QUAK direct command is pending OpenXR sync: {status.applied_serial} < {status.command_serial}");
        }

        private static T Parse<T>(string json) where T : class, new() =>
            JsonUtility.FromJson<T>(string.IsNullOrWhiteSpace(json) ? "{}" : json) ?? new T();

        private static void RequireSuccess(QuakDirectResult result)
        {
            if (result != QuakDirectResult.Success)
                throw new InvalidOperationException($"QUAK direct native call failed: {result}");
        }

        private static uint Hand(string value) => value switch
        {
            "left" => 0,
            "right" => 1,
            _ => throw new ArgumentException("hand must be left or right")
        };

        private static uint Component(string hand, string value, string subComponent) =>
            (hand, value, subComponent) switch
        {
            (_, "Trigger", null or "") => 0,
            (_, "Grip", null or "") => 1,
            ("left", "X", null or "") or ("right", "A", null or "") => 2,
            ("left", "Y", null or "") or ("right", "B", null or "") => 3,
            ("left", "Menu", null or "") or ("right", "System", null or "") => 4,
            (_, "ThumbstickClick", null or "") => 5,
            (_, "Thumbstick", "X") => 6,
            (_, "Thumbstick", "Y") => 7,
            (_, "Thumbstick", _) => throw new ArgumentException(
                "Thumbstick sub_component must be X or Y"),
            _ => throw new ArgumentException(
                hand == "left"
                    ? "left component must be X, Y, Menu, Thumbstick, ThumbstickClick, Trigger, or Grip"
                    : "right component must be A, B, System, Thumbstick, ThumbstickClick, Trigger, or Grip")
        };

        private static uint PoseKind(string value) => value switch
        {
            "aim" => 0,
            "grip" => 1,
            _ => throw new ArgumentException("pose_type must be aim or grip")
        };

        private static void RequireVector(float[] value, string name, int length)
        {
            if (value == null || value.Length != length || value.Any(item => !Finite(item)))
                throw new ArgumentException($"{name} must contain {length} finite numbers");
        }

        private static void RequireQuaternion(float[] value, string name)
        {
            RequireVector(value, name, 4);
            var magnitude = value.Sum(item => item * item);
            if (Mathf.Abs(magnitude - 1f) > 0.001f)
                throw new ArgumentException($"{name} must be a unit quaternion");
        }

        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);

        [Serializable] private sealed class InvokeInput { public string action_id; public string arguments_json = "{}"; public bool confirm; }
        [Serializable] private sealed class ContextInput { public string correlation_id; }
        [Serializable] private sealed class ContextResult { public bool success; public string correlationId; }
        [Serializable] private sealed class EvidenceInput { public string target_id; public string status; public string eye; public bool hide_outline; }
        [Serializable] private sealed class RecentLogsInput { public float limit; }
        [Serializable] private sealed class PoseInput { public float[] position; public float[] orientation; }
        [Serializable] private sealed class PoseOutput { public float[] position; public float[] orientation; }
        [Serializable] private sealed class QuaternionInput { public float[] front_direction; }
        [Serializable] private sealed class QuaternionOutput { public float[] quaternion; }
        [Serializable] private sealed class ControllerInput { public string hand; public string component; public string sub_component; public float value; }
        [Serializable] private sealed class PassthroughInput { public bool enabled; }
        [Serializable] private sealed class PassthroughOutput { public bool supported; public bool enabled; }
        [Serializable] private sealed class ControllerPoseInput { public string hand; public string pose_type; public float[] position; public float[] orientation; public string base_space; }
        [Serializable] private sealed class ControllerPosesInput { public string hand; public float[] aim_position; public float[] aim_orientation; public float[] grip_position; public float[] grip_orientation; public string base_space; }
        [Serializable] private sealed class ControllerPoseQuery { public string hand; public string pose_type; public string base_space; }
        [Serializable] private sealed class HeadPoseInput { public string base_space; }
        [Serializable] private sealed class PoseResultOutput { public PoseOutput pose; }
        [Serializable] private sealed class InteractionProfileInput { public string hand; }
        [Serializable] private sealed class InteractionProfilesOutput { public InteractionProfileOutput left; public InteractionProfileOutput right; }
        [Serializable] private sealed class InteractionProfileOutput { public string profile; }
        [Serializable] private sealed class InstanceInfoOutput { public string applicationName; public string applicationVersion; public string engineName; public string engineVersion; public string runtimeName; public string runtimeVersion; public string openXrApiVersion; public uint enabledApiLayerCount; public uint enabledExtensionCount; public string[] observedApiLayers; public string[] availableExtensions; public string[] enabledExtensions; }
        [Serializable] private sealed class PerformanceMetricsOutput { public bool extensionEnabled; public bool refreshRateExtensionEnabled; public string metricsResult; public bool metricsAvailable; public bool refreshRateAvailable; public float currentRefreshRateHz; public float predictedRefreshRateHz; public PerformanceMetric[] metrics; }
        [Serializable] private sealed class PerformanceMetric { public string path; public ulong counterFlags; public int unitCode; public string unit; public uint uintValue; public float floatValue; }
        [Serializable] private sealed class HapticEventsInput { public long after_serial; public int limit; }
        [Serializable] private sealed class HapticEventsOutput { public ulong latestSerial; public bool truncated; public HapticEventOutput[] events; }
        [Serializable] private sealed class HapticEventOutput { public ulong serial; public string operation; public int result; public int feedbackType; public long durationNanoseconds; public float frequency; public float amplitude; public string actionName; public string subactionPath; }
        [Serializable] private sealed class SessionInfoOutput { public string state; public uint stateCode; public bool focused; public bool ready; public ulong systemId; public string referenceSpace; }
        [Serializable] private sealed class SessionStateOutput { public string state; public uint stateCode; }
        [Serializable] private sealed class FrameInfoOutput { public ulong frameSerial; public long predictedDisplayTime; public long predictedDisplayPeriod; public bool shouldRender; public long displayTime; public string environmentBlendMode; public LayerSummaryOutput compositionLayers; }
        [Serializable] private sealed class LayerSummaryOutput { public uint total; public uint projection; public uint quad; public uint cylinder; public uint cube; public uint equirect; public uint other; }
        [Serializable] private sealed class LayerInventoryOutput { public ulong frameSerial; public long displayTime; public string environmentBlendMode; public uint layerCount; public bool passthroughEventSupported; public bool passthroughResumedObserved; public ulong passthroughResumedSerial; public ulong passthroughLayer; public LayerInventoryEntry[] layers; }
        [Serializable] private sealed class LayerInventoryEntry { public string type; public uint count; }
        [Serializable] private sealed class SystemInfoOutput { public ulong systemId; public uint vendorId; public string systemName; public string runtimeName; public uint maxSwapchainImageWidth; public uint maxSwapchainImageHeight; public uint maxLayerCount; public bool orientationTracking; public bool positionTracking; public string graphicsDeviceName; public string graphicsDeviceType; }

        [Serializable]
        private sealed class DirectStatus
        {
            public int schemaVersion = 1;
            public int bridgeProtocolVersion = BridgeProtocolVersion;
            public uint nativeAbiVersion;
            public string[] bridgeTools;
            public bool ready;
            public bool playing;
            public string backendSource = "live";
            public string bridgeId = "quak-direct";
            public string providerId = "quak-direct-openxr";
            public QuakRuntimeStatus runtime;
            public string sessionId;
            public float sessionAgeSeconds;
            public string applicationId;
            public string applicationVersion;
            public string unityVersion;
            public string activeScene;
            public bool isEditor;
            public string runtimePlatform;
            public bool developmentBuild;
            public string correlationId;
            public string[] stateProviders;
            public bool applicationFocused;
            public bool inputFocused;
            public bool vrFocused;
            public float focusStableSeconds;
            public ulong syncEpoch;
            public ulong commandSerial;
            public ulong appliedSerial;
            public uint boundActionCount;
            public uint injectedReadCount;
            public bool ownsInputs;
            public string[] errors;
        }
    }
}
