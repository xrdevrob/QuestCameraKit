using System;
using UnityEngine;

namespace XRDevRob.QUAK
{
    /// <summary>
    /// Gives an important interaction surface a stable automation identity.
    /// The ID is product-facing API and should survive hierarchy/name changes.
    /// </summary>
    [DisallowMultipleComponent]
    [AddComponentMenu("QUAK/Stable Target")]
    public sealed class QuakTarget : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("Stable ID such as assembly.block.red or menu.settings.")]
        private string id;

        [SerializeField]
        [TextArea]
        private string description;

        public string Id => id;
        public string Description => description;

        public void Configure(string targetId, string targetDescription = null)
        {
            if (string.IsNullOrWhiteSpace(targetId))
                throw new ArgumentException("QUAK target ID must not be empty.", nameof(targetId));
            id = targetId.Trim();
            description = targetDescription?.Trim();
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            id = id?.Trim();
        }
#endif
    }
}
