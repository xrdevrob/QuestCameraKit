using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.UIElements;

[assembly: InternalsVisibleTo("XRDevRob.QUAK.Tests.Editor")]

namespace XRDevRob.QUAK
{
    /// <summary>Read-only product state exposed to QUAK tests.</summary>
    public interface IQuakStateProvider
    {
        string ProviderId { get; }
        string CaptureStateJson();
    }

    /// <summary>
    /// Deterministic setup/reset hook. It must not replace the XR interaction
    /// under test.
    /// </summary>
    public interface IQuakActionHandler
    {
        string ActionId { get; }
        string Description { get; }
        bool IsProjectMutation { get; }
        string Invoke(string argumentsJson);
    }

    [Serializable]
    public sealed class QuakTargetInfo
    {
        public string id;
        public string label;
        public string description;
        public string hierarchyPath;
        public string source;
        public string owner;
        public string componentType;
        public string uiSystem;
        public string coordinateSpace = "unavailable";
        public string compositorLayer = "unavailable";
        public string visibility = "unavailable";
        public string enabledState = "unavailable";
        public string focusState = "unavailable";
        public string semanticRole = "unavailable";
        public bool stable;
        public bool active;
        public bool raycastEligible;
        public Vector3 worldPosition;
        public Quaternion worldRotation;
        public Vector3 worldBoundsCenter;
        public Vector3 worldBoundsSize;
    }

    [Serializable]
    public sealed class QuakActionInfo
    {
        public string id;
        public string description;
        public bool projectMutation;
    }

    [Serializable]
    public sealed class QuakCapabilities
    {
        public int schemaVersion = 1;
        public bool ready;
        public int targetCount;
        public int activeTargetCount;
        public int raycastEligibleTargetCount;
        public List<QuakTargetInfo> targets = new();
        public List<string> stateProviders = new();
        public List<QuakActionInfo> actions = new();
        public List<string> errors = new();
    }

    [Serializable]
    public sealed class QuakProviderState
    {
        public string providerId;
        public string json;
        public string error;
    }

    [Serializable]
    public sealed class QuakStateSnapshot
    {
        public int schemaVersion = 1;
        public bool ready;
        public int frame;
        public float realtimeSinceStartup;
        public string correlationId;
        public List<QuakProviderState> providers = new();
        public List<string> errors = new();
    }

    [Serializable]
    public sealed class QuakRuntimeState
    {
        public int schemaVersion = 1;
        public bool ready;
        public string activeScene;
        public bool applicationFocused;
    }

    [Serializable]
    public sealed class QuakRuntimeStatus
    {
        public int schemaVersion = 1;
        public bool ready;
        public string sessionId;
        public float sessionAgeSeconds;
        public string applicationId;
        public string applicationVersion;
        public string unityVersion;
        public string activeScene;
        public bool isEditor;
        public string runtimePlatform;
        public bool developmentBuild;
        public bool applicationFocused;
        public int frame;
        public List<string> stateProviders = new();
        public string correlationId;
        public List<string> errors = new();
    }

    [Serializable]
    public sealed class QuakLogEntry
    {
        public long sequence;
        public string timestampUtc;
        public string type;
        public string message;
        public bool truncated;
    }

    [Serializable]
    public sealed class QuakRecentLogs
    {
        public int schemaVersion = 1;
        public int capacity;
        public int returned;
        public bool newestFirst = true;
        public List<QuakLogEntry> entries = new();
    }

    [Serializable]
    public sealed class QuakActionResult
    {
        public bool success;
        public string actionId;
        public string resultJson;
        public string error;

        public static QuakActionResult Fail(string actionId, string error)
        {
            return new QuakActionResult
            {
                success = false,
                actionId = actionId,
                error = error
            };
        }
    }

    [Serializable]
    public sealed class QuakEvidenceMarkerResult
    {
        public bool success;
        public string targetId;
        public string status;
        public bool outlineVisible;
        public string screenBoundsSource;
        public QuakNormalizedRect screenBoundsNormalized;
        public string error;
    }

    [Serializable]
    public sealed class QuakNormalizedRect
    {
        public float x;
        public float y;
        public float width;
        public float height;
    }

    public static class QuakRegistry
    {
        public const string ExplicitTargetSource = "explicit";
        public const string RuntimeStateProviderId = "quak-runtime";
        public const int DefaultRecentLogLimit = 50;
        public const int MaxRecentLogEntries = 200;
        public const int MaxRecentLogMessageCharacters = 2048;

        private const string UgUiTargetSource = "ugui";
        private const string UiToolkitTargetSource = "ui-toolkit-live";

        private static readonly Dictionary<string, IQuakStateProvider> StateProviders = new();
        private static readonly Dictionary<string, IQuakActionHandler> Actions = new();
        private static readonly List<string> RegistrationErrors = new();
        private static readonly object RecentLogLock = new();
        private static readonly Queue<QuakLogEntry> RecentLogs = new(MaxRecentLogEntries);
        private static long recentLogSequence;
        private static string sessionId;
        private static float sessionStartedAt;
        private static string correlationId;
        private static bool recentLogCaptureInitialized;
        private static QuakEvidenceMarker evidenceMarker;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStatics()
        {
            StateProviders.Clear();
            Actions.Clear();
            RegistrationErrors.Clear();
            sessionId = Guid.NewGuid().ToString("N");
            sessionStartedAt = Time.realtimeSinceStartup;
            correlationId = string.Empty;
            lock (RecentLogLock)
            {
                RecentLogs.Clear();
                recentLogSequence = 0;
            }
            Application.logMessageReceived -= CaptureLog;
            Application.logMessageReceivedThreaded -= CaptureLog;
            recentLogCaptureInitialized = false;
            if (evidenceMarker != null)
                UnityEngine.Object.Destroy(evidenceMarker.gameObject);
            evidenceMarker = null;
            EnsureRecentLogCapture();
        }

        public static bool Register(IQuakStateProvider provider)
        {
            if (provider == null || string.IsNullOrWhiteSpace(provider.ProviderId))
                return false;
            var id = provider.ProviderId.Trim();
            if (string.Equals(id, RuntimeStateProviderId, StringComparison.Ordinal))
                return false;
            if (StateProviders.TryGetValue(id, out var existing) && !ReferenceEquals(existing, provider))
            {
                AddRegistrationError($"Duplicate QUAK state provider ID: {id}");
                return false;
            }
            StateProviders[id] = provider;
            ClearRegistrationError($"Duplicate QUAK state provider ID: {id}");
            return true;
        }

        public static bool Unregister(IQuakStateProvider provider)
        {
            if (provider == null || string.IsNullOrWhiteSpace(provider.ProviderId))
                return false;
            var id = provider.ProviderId.Trim();
            if (!StateProviders.TryGetValue(id, out var existing) ||
                !ReferenceEquals(existing, provider) || !StateProviders.Remove(id))
                return false;
            ClearRegistrationError($"Duplicate QUAK state provider ID: {id}");
            return true;
        }

        public static bool Register(IQuakActionHandler action)
        {
            if (action == null || string.IsNullOrWhiteSpace(action.ActionId))
                return false;
            var id = action.ActionId.Trim();
            if (Actions.TryGetValue(id, out var existing) && !ReferenceEquals(existing, action))
            {
                AddRegistrationError($"Duplicate QUAK action ID: {id}");
                return false;
            }
            Actions[id] = action;
            ClearRegistrationError($"Duplicate QUAK action ID: {id}");
            return true;
        }

        public static bool Unregister(IQuakActionHandler action)
        {
            if (action == null || string.IsNullOrWhiteSpace(action.ActionId))
                return false;
            var id = action.ActionId.Trim();
            if (!Actions.TryGetValue(id, out var existing) ||
                !ReferenceEquals(existing, action) || !Actions.Remove(id))
                return false;
            ClearRegistrationError($"Duplicate QUAK action ID: {id}");
            return true;
        }

        private static void AddRegistrationError(string error)
        {
            if (!RegistrationErrors.Contains(error))
                RegistrationErrors.Add(error);
        }

        private static void ClearRegistrationError(string error)
        {
            RegistrationErrors.Remove(error);
        }

        public static string SetCorrelationId(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("correlation_id must not be empty.", nameof(value));
            correlationId = value.Trim();
            return correlationId;
        }

        public static string CurrentCorrelationId => correlationId ?? string.Empty;

        public static QuakRecentLogs CaptureRecentLogs(int limit = DefaultRecentLogLimit)
        {
            EnsureRecentLogCapture();
            limit = Mathf.Clamp(limit, 1, MaxRecentLogEntries);
            lock (RecentLogLock)
            {
                var snapshot = RecentLogs.ToArray();
                var result = new QuakRecentLogs
                {
                    capacity = MaxRecentLogEntries,
                    returned = Math.Min(limit, snapshot.Length)
                };
                for (var index = snapshot.Length - 1;
                     index >= 0 && result.entries.Count < limit;
                     index--)
                    result.entries.Add(snapshot[index]);
                return result;
            }
        }

        public static string RecentLogsJson(int limit = DefaultRecentLogLimit)
        {
            return JsonUtility.ToJson(CaptureRecentLogs(limit));
        }

        public static QuakRuntimeStatus CaptureRuntimeStatus()
        {
            return CaptureRuntimeStatus(CaptureCapabilities(), CaptureState());
        }

        public static QuakRuntimeStatus CaptureRuntimeStatus(
            QuakCapabilities capabilities,
            QuakStateSnapshot state)
        {
            if (string.IsNullOrEmpty(sessionId))
            {
                sessionId = Guid.NewGuid().ToString("N");
                sessionStartedAt = Time.realtimeSinceStartup;
            }
            var providers = (capabilities.stateProviders ?? new List<string>())
                .Where(id => !string.IsNullOrWhiteSpace(id))
                .OrderBy(id => id, StringComparer.Ordinal)
                .ToList();
            var result = new QuakRuntimeStatus
            {
                ready = capabilities.ready && state.ready && providers.Count > 0,
                sessionId = sessionId,
                sessionAgeSeconds = Mathf.Max(0f, Time.realtimeSinceStartup - sessionStartedAt),
                applicationId = Application.identifier,
                applicationVersion = Application.version,
                unityVersion = Application.unityVersion,
                activeScene = SceneManager.GetActiveScene().name,
                isEditor = Application.isEditor,
                runtimePlatform = Application.platform.ToString(),
                developmentBuild = Debug.isDebugBuild,
                applicationFocused = Application.isFocused,
                frame = Time.frameCount,
                stateProviders = providers,
                correlationId = correlationId
            };
            result.errors.AddRange(capabilities.errors);
            result.errors.AddRange(state.errors);
            if (providers.Count == 0)
                result.errors.Add("No QUAK state provider is registered.");
            return result;
        }

        public static QuakCapabilities CaptureCapabilities()
        {
            var result = new QuakCapabilities();
            result.errors.AddRange(RegistrationErrors);

            foreach (var target in DiscoverTargets(result.errors)
                         .OrderBy(item => item.Info.id, StringComparer.Ordinal))
            {
                if (string.IsNullOrWhiteSpace(target.Info.id))
                {
                    result.errors.Add(
                        $"QuakTarget at {target.Info.hierarchyPath} has no ID.");
                    continue;
                }
                result.targets.Add(target.Info);
            }

            foreach (var duplicate in result.targets
                         .GroupBy(item => item.id, StringComparer.Ordinal)
                         .Where(group => group.Count() > 1))
            {
                result.errors.Add($"Duplicate QuakTarget ID: {duplicate.Key}");
            }

            result.stateProviders.Add(RuntimeStateProviderId);
            result.stateProviders.AddRange(StateProviders.Keys.OrderBy(id => id, StringComparer.Ordinal));
            result.actions.AddRange(Actions.Values
                .OrderBy(action => action.ActionId, StringComparer.Ordinal)
                .Select(action => new QuakActionInfo
                {
                    id = action.ActionId,
                    description = action.Description,
                    projectMutation = action.IsProjectMutation
                }));
            result.targetCount = result.targets.Count;
            result.activeTargetCount = result.targets.Count(target => target.active);
            result.raycastEligibleTargetCount = result.targets.Count(
                target => target.raycastEligible);
            result.ready = result.errors.Count == 0;
            return result;
        }

        public static QuakStateSnapshot CaptureState()
        {
            var scene = SceneManager.GetActiveScene();
            var runtime = new QuakRuntimeState
            {
                ready = scene.IsValid() && scene.isLoaded,
                activeScene = scene.name,
                applicationFocused = Application.isFocused
            };
            var result = new QuakStateSnapshot
            {
                frame = Time.frameCount,
                realtimeSinceStartup = Time.realtimeSinceStartup,
                correlationId = CurrentCorrelationId
            };
            result.providers.Add(new QuakProviderState
            {
                providerId = RuntimeStateProviderId,
                json = JsonUtility.ToJson(runtime)
            });
            if (!runtime.ready)
                result.errors.Add($"{RuntimeStateProviderId}: active Unity scene is not loaded.");

            foreach (var pair in StateProviders.OrderBy(pair => pair.Key, StringComparer.Ordinal))
            {
                try
                {
                    var json = pair.Value.CaptureStateJson();
                    if (string.IsNullOrWhiteSpace(json))
                        throw new InvalidOperationException("Provider returned empty JSON.");
                    if (!json.TrimStart().StartsWith("{", StringComparison.Ordinal))
                        throw new InvalidOperationException("Provider JSON must be an object.");
                    try
                    {
                        JsonUtility.FromJson<QuakProviderState>(json);
                    }
                    catch (ArgumentException exception)
                    {
                        throw new InvalidOperationException("Provider returned malformed JSON.", exception);
                    }
                    result.providers.Add(new QuakProviderState
                    {
                        providerId = pair.Key,
                        json = json
                    });
                }
                catch (Exception exception)
                {
                    var message = $"{pair.Key}: {exception.Message}";
                    result.errors.Add(message);
                    result.providers.Add(new QuakProviderState
                    {
                        providerId = pair.Key,
                        error = exception.Message
                    });
                }
            }

            result.ready = result.errors.Count == 0;
            return result;
        }

        public static QuakActionResult InvokeAction(
            string actionId,
            string argumentsJson,
            bool confirmProjectMutation)
        {
            if (string.IsNullOrWhiteSpace(actionId))
                return QuakActionResult.Fail(actionId, "actionId is required.");
            if (!Actions.TryGetValue(actionId, out var action))
                return QuakActionResult.Fail(actionId, $"Unknown QUAK action: {actionId}");
            if (action.IsProjectMutation && !confirmProjectMutation)
                return QuakActionResult.Fail(
                    actionId,
                    "This action changes project state and requires confirm=true.");

            try
            {
                return new QuakActionResult
                {
                    success = true,
                    actionId = actionId,
                    resultJson = action.Invoke(
                        string.IsNullOrWhiteSpace(argumentsJson) ? "{}" : argumentsJson)
                };
            }
            catch (Exception exception)
            {
                return QuakActionResult.Fail(actionId, exception.Message);
            }
        }

        public static QuakEvidenceMarkerResult MarkEvidenceTarget(
            string targetId,
            string status,
            string eye = "mono",
            bool hideOutline = false)
        {
            if (string.Equals(status, "clear", StringComparison.Ordinal))
            {
                if (evidenceMarker != null)
                    evidenceMarker.Clear();
                return new QuakEvidenceMarkerResult
                {
                    success = true,
                    targetId = targetId,
                    status = status
                };
            }
            if (status != "targeted" && status != "attempted" &&
                status != "passed" && status != "failed" && status != "inconclusive")
            {
                return new QuakEvidenceMarkerResult
                {
                    targetId = targetId,
                    status = status,
                    error = "status must be targeted, attempted, passed, failed, inconclusive, or clear."
                };
            }
            if (string.IsNullOrWhiteSpace(targetId))
            {
                return new QuakEvidenceMarkerResult
                {
                    status = status,
                    error = "targetId is required."
                };
            }

            var matches = DiscoverTargets(new List<string>(), targetId);
            if (matches.Count != 1)
            {
                return new QuakEvidenceMarkerResult
                {
                    targetId = targetId,
                    status = status,
                    error = matches.Count == 0
                        ? $"Unknown QUAK target: {targetId}"
                        : $"Duplicate QUAK target: {targetId}"
                };
            }

            if (evidenceMarker == null)
            {
                var markerObject = new GameObject("QUAK Evidence Target Marker");
                evidenceMarker = markerObject.AddComponent<QuakEvidenceMarker>();
                if (Application.isPlaying)
                    UnityEngine.Object.DontDestroyOnLoad(markerObject);
            }
            evidenceMarker.Show(matches[0].Component, status, !hideOutline);
            return new QuakEvidenceMarkerResult
            {
                success = true,
                targetId = targetId,
                status = status,
                outlineVisible = !hideOutline,
                screenBoundsSource = $"{eye}-eye-main-camera-viewport",
                screenBoundsNormalized = evidenceMarker.ScreenBounds(eye)
            };
        }

        public static string CapabilitiesJson()
        {
            return JsonUtility.ToJson(CaptureCapabilities());
        }

        public static string StateJson()
        {
            return JsonUtility.ToJson(CaptureState());
        }

        private static void EnsureRecentLogCapture()
        {
            if (recentLogCaptureInitialized)
                return;
            Application.logMessageReceived -= CaptureLog;
            Application.logMessageReceivedThreaded -= CaptureLog;
            Application.logMessageReceivedThreaded += CaptureLog;
            recentLogCaptureInitialized = true;
        }

        private static void CaptureLog(string condition, string stackTrace, LogType type)
        {
            var message = condition ?? string.Empty;
            var truncated = message.Length > MaxRecentLogMessageCharacters;
            var entry = new QuakLogEntry
            {
                timestampUtc = DateTime.UtcNow.ToString("o"),
                type = type.ToString(),
                message = truncated ? message.Substring(0, MaxRecentLogMessageCharacters) : message,
                truncated = truncated
            };
            lock (RecentLogLock)
            {
                entry.sequence = ++recentLogSequence;
                if (RecentLogs.Count >= MaxRecentLogEntries)
                    RecentLogs.Dequeue();
                RecentLogs.Enqueue(entry);
            }
        }

        private static string HierarchyPath(Transform transform)
        {
            var names = new Stack<string>();
            var current = transform;
            while (current != null)
            {
                names.Push(current.name);
                current = current.parent;
            }
            return string.Join("/", names);
        }

        internal static bool IsDiscoverableExplicitTarget(Component target)
        {
            var scene = target.gameObject.scene;
            return scene.IsValid() && scene.isLoaded;
        }

        private static List<TargetCandidate> DiscoverTargets(
            List<string> errors,
            string targetId = null)
        {
            var result = new List<TargetCandidate>();
            var claimedObjects = new HashSet<GameObject>();
            var filterById = targetId != null;

            foreach (var target in Resources.FindObjectsOfTypeAll<QuakTarget>()
                     .Where(IsDiscoverableExplicitTarget))
            {
                claimedObjects.Add(target.gameObject);
                if (filterById && !string.Equals(target.Id, targetId, StringComparison.Ordinal))
                    continue;
                result.Add(CreateCandidate(
                    target,
                    target.Id,
                    target.gameObject.name,
                    target.Description,
                    ExplicitTargetSource,
                    true,
                    target.isActiveAndEnabled && target.gameObject.activeInHierarchy,
                    target.transform is RectTransform rect
                        ? rect.TransformPoint(rect.rect.center)
                        : target.transform.position,
                    RaycastEligible(target)));
            }

            foreach (var target in Resources.FindObjectsOfTypeAll<QuakUiToolkitTarget>()
                     .Where(IsDiscoverableExplicitTarget)
                     .Where(item => !filterById ||
                         string.Equals(item.Id, targetId, StringComparison.Ordinal))
                     .OrderBy(item => IndexedHierarchyPath(item.transform), StringComparer.Ordinal)
                     .ThenBy(item => item.Id, StringComparer.Ordinal))
            {
                if (TryCreateUiToolkitCandidate(target, out var candidate, out var error))
                    result.Add(candidate);
                else if (!string.IsNullOrEmpty(error))
                    errors.Add(error);
            }

            if (filterById &&
                !targetId.StartsWith($"auto:{UgUiTargetSource}:", StringComparison.Ordinal))
                return result;

            IEnumerable<Selectable> selectables = UnityEngine.Object.FindObjectsByType<Selectable>(
                FindObjectsInactive.Include,
                FindObjectsSortMode.None);
            if (!filterById)
                selectables = selectables.OrderBy(
                    item => IndexedHierarchyPath(item.transform),
                    StringComparer.Ordinal);
            foreach (var selectable in selectables)
            {
                var canvas = selectable.GetComponentInParent<Canvas>(true);
                if (canvas == null || canvas.renderMode != RenderMode.WorldSpace ||
                    !claimedObjects.Add(selectable.gameObject))
                    continue;
                if (filterById &&
                    !string.Equals(AutomaticId(selectable), targetId, StringComparison.Ordinal))
                    continue;
                var rect = selectable.targetGraphic?.rectTransform ??
                           selectable.transform as RectTransform;
                result.Add(CreateAutomaticCandidate(
                    selectable,
                    selectable.gameObject.name,
                    selectable.isActiveAndEnabled && selectable.gameObject.activeInHierarchy &&
                    selectable.IsInteractable(),
                    rect != null
                        ? rect.TransformPoint(rect.rect.center)
                        : selectable.transform.position,
                    RaycastEligible(selectable)));
            }

            return result;
        }

        private static bool TryCreateUiToolkitCandidate(
            QuakUiToolkitTarget target,
            out TargetCandidate candidate,
            out string error)
        {
            candidate = null;
            var path = HierarchyPath(target.transform);
            if (string.IsNullOrWhiteSpace(target.Id))
                return FailUiToolkitTarget(path, "target ID is empty.", out error);
            if (string.IsNullOrWhiteSpace(target.ElementName))
                return FailUiToolkitTarget(path, "element name is empty.", out error);

            var document = target.GetComponent<UIDocument>();
            var collider = target.GetComponent<BoxCollider>();
            if (document == null || collider == null)
                return FailUiToolkitTarget(
                    path,
                    "requires a UIDocument and BoxCollider on the same GameObject.",
                    out error);

#if UNITY_6000_2_OR_NEWER
            if (document.panelSettings == null ||
                document.panelSettings.renderMode != PanelRenderMode.WorldSpace)
                return FailUiToolkitTarget(path, "UIDocument is not world-space.", out error);
#else
            return FailUiToolkitTarget(
                path,
                "live world-space UI Toolkit targets require Unity 6.2 or newer.",
                out error);
#endif

            var root = document.rootVisualElement;
            if (!TryFindLiveUiToolkitElement(
                    root,
                    target.ElementName,
                    out var element,
                    out var reason,
                    out var unavailable))
            {
                if (unavailable)
                {
                    error = null;
                    return false;
                }
                return FailUiToolkitTarget(path, reason, out error);
            }
            if (!ValidUiToolkitRect(root.worldBound) || root.worldBound.width <= 0f ||
                root.worldBound.height <= 0f)
            {
                error = null;
                return false;
            }
            if (!ValidUiToolkitRect(element.worldBound))
            {
                error = null;
                return false;
            }
            if (!ValidBox(collider))
                return FailUiToolkitTarget(path, "BoxCollider must have a finite, positive size.", out error);

            var clipped = ClipUiToolkitBounds(root.worldBound, element.worldBound);
            var bounds = MapUiToolkitBounds(collider, root.worldBound, element.worldBound, out var worldPosition);
            var visible = document.isActiveAndEnabled && UiToolkitElementDisplayed(element, root) &&
                          clipped.width > 0f && clipped.height > 0f;
            var active = target.isActiveAndEnabled && visible && element.enabledInHierarchy;
            var focusedElement = element.panel?.focusController?.focusedElement as VisualElement;
            var focused = focusedElement != null &&
                          (ReferenceEquals(focusedElement, element) || element.Contains(focusedElement));
            var picked = active ? root.panel.Pick(clipped.center) : null;
            var raycastEligible = active && collider.enabled && picked != null &&
                                  (ReferenceEquals(picked, element) || element.Contains(picked));
            candidate = new TargetCandidate
            {
                Info = new QuakTargetInfo
                {
                    id = target.Id,
                    label = element.name,
                    description = target.Description,
                    hierarchyPath = $"{path}#{target.ElementName}",
                    source = UiToolkitTargetSource,
                    owner = document.gameObject.name,
                    componentType = element.GetType().FullName,
                    uiSystem = "ui-toolkit",
                    coordinateSpace = "world",
                    visibility = visible ? "visible" : "hidden",
                    enabledState = element.enabledInHierarchy ? "enabled" : "disabled",
                    focusState = focused ? "focused" : "not_focused",
                    semanticRole = string.IsNullOrWhiteSpace(target.SemanticRole)
                        ? element.GetType().Name
                        : target.SemanticRole,
                    stable = true,
                    active = active,
                    raycastEligible = raycastEligible,
                    worldPosition = worldPosition,
                    worldRotation = collider.transform.rotation,
                    worldBoundsCenter = bounds.center,
                    worldBoundsSize = bounds.size
                }
            };
            error = null;
            return true;
        }

        internal static bool TryFindLiveUiToolkitElement(
            VisualElement root,
            string elementName,
            out VisualElement element,
            out string error,
            out bool unavailable)
        {
            element = null;
            unavailable = false;
            if (root == null)
            {
                error = "UIDocument has no live rootVisualElement.";
                unavailable = true;
                return false;
            }

            var matches = root.Query<VisualElement>(name: elementName).ToList();
            if (matches.Count == 0)
            {
                error = $"live UIDocument contains no element named '{elementName}'.";
                unavailable = true;
                return false;
            }
            if (matches.Count > 1)
            {
                error = $"live UIDocument contains {matches.Count} elements named '{elementName}'.";
                return false;
            }

            element = matches[0];
            if (root.panel == null || element.panel == null ||
                !ReferenceEquals(root.panel, element.panel) ||
                !ReferenceEquals(root, element) && !root.Contains(element))
            {
                element = null;
                error = $"element '{elementName}' is detached from the live UIDocument.";
                unavailable = true;
                return false;
            }

            error = null;
            return true;
        }

        internal static Bounds MapUiToolkitBounds(
            BoxCollider collider,
            Rect rootBounds,
            Rect elementBounds,
            out Vector3 worldCenter)
        {
            var clipped = ClipUiToolkitBounds(rootBounds, elementBounds);
            var xMin = collider.center.x +
                       (clipped.xMin - rootBounds.xMin) / rootBounds.width * collider.size.x -
                       collider.size.x * 0.5f;
            var xMax = collider.center.x +
                       (clipped.xMax - rootBounds.xMin) / rootBounds.width * collider.size.x -
                       collider.size.x * 0.5f;
            var yMin = collider.center.y + collider.size.y * 0.5f -
                       (clipped.yMax - rootBounds.yMin) / rootBounds.height * collider.size.y;
            var yMax = collider.center.y + collider.size.y * 0.5f -
                       (clipped.yMin - rootBounds.yMin) / rootBounds.height * collider.size.y;
            var zMin = collider.center.z - collider.size.z * 0.5f;
            var zMax = collider.center.z + collider.size.z * 0.5f;
            var localCenter = new Vector3(
                (xMin + xMax) * 0.5f,
                (yMin + yMax) * 0.5f,
                collider.center.z);
            worldCenter = collider.transform.TransformPoint(localCenter);

            var first = collider.transform.TransformPoint(new Vector3(xMin, yMin, zMin));
            var result = new Bounds(first, Vector3.zero);
            for (var xIndex = 0; xIndex < 2; xIndex++)
            for (var yIndex = 0; yIndex < 2; yIndex++)
            for (var zIndex = 0; zIndex < 2; zIndex++)
            {
                var x = xIndex == 0 ? xMin : xMax;
                var y = yIndex == 0 ? yMin : yMax;
                var z = zIndex == 0 ? zMin : zMax;
                result.Encapsulate(collider.transform.TransformPoint(new Vector3(x, y, z)));
            }
            return result;
        }

        private static Rect ClipUiToolkitBounds(Rect root, Rect element)
        {
            var xMin = Mathf.Max(root.xMin, element.xMin);
            var xMax = Mathf.Min(root.xMax, element.xMax);
            var yMin = Mathf.Max(root.yMin, element.yMin);
            var yMax = Mathf.Min(root.yMax, element.yMax);
            if (xMax < xMin)
                xMin = xMax = Mathf.Clamp(element.center.x, root.xMin, root.xMax);
            if (yMax < yMin)
                yMin = yMax = Mathf.Clamp(element.center.y, root.yMin, root.yMax);
            return Rect.MinMaxRect(xMin, yMin, xMax, yMax);
        }

        private static bool UiToolkitElementDisplayed(VisualElement element, VisualElement root)
        {
            for (var current = element; current != null; current = current.parent)
            {
                if (current.resolvedStyle.display == DisplayStyle.None ||
                    current.resolvedStyle.visibility == Visibility.Hidden)
                    return false;
                if (ReferenceEquals(current, root))
                    return true;
            }
            return false;
        }

        private static bool ValidUiToolkitRect(Rect rect)
        {
            return IsFinite(rect.x) && IsFinite(rect.y) &&
                   IsFinite(rect.width) && IsFinite(rect.height);
        }

        private static bool ValidBox(BoxCollider collider)
        {
            var size = collider.size;
            var center = collider.center;
            var scale = collider.transform.lossyScale;
            return size.x > 0f && size.y > 0f && size.z > 0f &&
                   IsFinite(size.x) && IsFinite(size.y) && IsFinite(size.z) &&
                   IsFinite(center.x) && IsFinite(center.y) && IsFinite(center.z) &&
                   Mathf.Abs(scale.x) > 0f && Mathf.Abs(scale.y) > 0f && Mathf.Abs(scale.z) > 0f &&
                   IsFinite(scale.x) && IsFinite(scale.y) && IsFinite(scale.z);
        }

        private static bool IsFinite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }

        private static bool FailUiToolkitTarget(string path, string reason, out string error)
        {
            error = $"QuakUiToolkitTarget at {path}: {reason}";
            return false;
        }

        private static TargetCandidate CreateAutomaticCandidate(
            Component component,
            string label,
            bool active,
            Vector3 worldPosition,
            bool raycastEligible)
        {
            return CreateCandidate(
                component,
                AutomaticId(component),
                label,
                $"Automatically discovered Unity UI {component.GetType().Name}.",
                UgUiTargetSource,
                false,
                active,
                worldPosition,
                raycastEligible);
        }

        private static TargetCandidate CreateCandidate(
            Component component,
            string id,
            string label,
            string description,
            string source,
            bool stable,
            bool active,
            Vector3 worldPosition,
            bool raycastEligible)
        {
            var bounds = WorldBounds(component);
            var selectable = component.GetComponent<Selectable>();
            var uiDocument = component.GetComponent("UIDocument") ??
                             component.GetComponent("UnityEngine.UIElements.UIDocument");
            Component inspectedComponent = selectable;
            inspectedComponent ??= uiDocument;
            inspectedComponent ??= component.GetComponent<Collider>();
            inspectedComponent ??= component.GetComponent<Renderer>();
            inspectedComponent ??= component;
            return new TargetCandidate
            {
                Component = component,
                Info = new QuakTargetInfo
                {
                    id = id,
                    label = label,
                    description = description,
                    hierarchyPath = HierarchyPath(component.transform),
                    source = source,
                    owner = component.gameObject.name,
                    componentType = inspectedComponent.GetType().FullName,
                    uiSystem = selectable != null
                        ? "ugui"
                        : uiDocument != null ? "ui-toolkit" : "none",
                    coordinateSpace = CoordinateSpace(component, uiDocument),
                    stable = stable,
                    active = active,
                    raycastEligible = raycastEligible,
                    worldPosition = worldPosition,
                    worldRotation = component.transform.rotation,
                    worldBoundsCenter = bounds.center,
                    worldBoundsSize = bounds.size
                }
            };
        }

        private static bool RaycastEligible(Component component)
        {
            if (!component.gameObject.activeInHierarchy ||
                component is Behaviour behaviour && !behaviour.isActiveAndEnabled)
                return false;
            var selectable = component.GetComponent<Selectable>();
            if (selectable != null)
            {
                var canvas = selectable.GetComponentInParent<Canvas>(true);
                var raycaster = selectable.GetComponentInParent<GraphicRaycaster>(true);
                return canvas != null && canvas.renderMode == RenderMode.WorldSpace &&
                    canvas.isActiveAndEnabled && selectable.IsInteractable() &&
                    selectable.GetComponentsInChildren<Graphic>(false).Any(graphic =>
                        graphic.isActiveAndEnabled && graphic.raycastTarget &&
                        graphic.GetComponentInParent<Selectable>() == selectable) &&
                    raycaster != null && raycaster.isActiveAndEnabled &&
                    CanvasGroupsAllowRaycasts(selectable.transform);
            }
            var collider = component.GetComponent<Collider>();
            return collider != null && collider.enabled && collider.gameObject.activeInHierarchy;
        }

        private static bool CanvasGroupsAllowRaycasts(Transform transform)
        {
            var groups = new List<CanvasGroup>();
            for (var current = transform; current != null; current = current.parent)
            {
                current.GetComponents(groups);
                foreach (var group in groups.Where(group => group.enabled))
                {
                    if (!group.blocksRaycasts)
                        return false;
                    if (group.ignoreParentGroups)
                        return true;
                }
            }
            return true;
        }

        private static string CoordinateSpace(Component component, Component uiDocument)
        {
            var canvas = component.GetComponentInParent<Canvas>(true);
            if (canvas != null)
                return canvas.renderMode == RenderMode.WorldSpace ? "world" : "unavailable";
            if (uiDocument != null && component.GetComponent<Collider>() == null)
                return "unavailable";
            return "world";
        }

        private static Bounds WorldBounds(Component component)
        {
            if (component.transform is RectTransform rect)
            {
                var corners = new Vector3[4];
                rect.GetWorldCorners(corners);
                var bounds = new Bounds(corners[0], Vector3.zero);
                for (var index = 1; index < corners.Length; index++)
                    bounds.Encapsulate(corners[index]);
                return bounds;
            }
            var collider = component.GetComponent<Collider>();
            if (collider != null)
                return collider.bounds;
            var renderer = component.GetComponent<Renderer>();
            return renderer != null
                ? renderer.bounds
                : new Bounds(component.transform.position, Vector3.zero);
        }

        private static string AutomaticId(Component component)
        {
            var scene = component.gameObject.scene;
            var sceneId = string.IsNullOrWhiteSpace(scene.path) ? scene.name : scene.path;
            return $"auto:{UgUiTargetSource}:{sceneId}:{IndexedHierarchyPath(component.transform)}";
        }

        private static string IndexedHierarchyPath(Transform transform)
        {
            var names = new Stack<string>();
            for (var current = transform; current != null; current = current.parent)
                names.Push($"{current.name}[{current.GetSiblingIndex()}]");
            return string.Join("/", names);
        }

        private sealed class TargetCandidate
        {
            public Component Component;
            public QuakTargetInfo Info;
        }
    }

    [DisallowMultipleComponent]
    internal sealed class QuakEvidenceMarker : MonoBehaviour
    {
        private readonly Vector3[] corners = new Vector3[4];
        private Component target;
        private LineRenderer outline;
        private Material material;
        private string status;
        private bool showOutline;

        internal void Show(Component value, string markerStatus, bool visible = true)
        {
            target = value;
            status = markerStatus;
            showOutline = visible;
            EnsureOutline();
            outline.enabled = target != null && showOutline;
            enabled = outline.enabled;
            if (showOutline)
                UpdateGeometry();
        }

        internal void Clear()
        {
            target = null;
            showOutline = false;
            enabled = false;
            if (outline != null)
                outline.enabled = false;
        }

        private void LateUpdate()
        {
            if (!showOutline)
            {
                enabled = false;
                return;
            }
            if (target == null)
            {
                Clear();
                return;
            }
            UpdateGeometry();
        }

        private void EnsureOutline()
        {
            if (outline != null)
                return;
            outline = gameObject.AddComponent<LineRenderer>();
            outline.useWorldSpace = true;
            outline.loop = true;
            outline.positionCount = 4;
            outline.numCornerVertices = 2;
            outline.numCapVertices = 2;
            outline.alignment = LineAlignment.View;
            outline.textureMode = LineTextureMode.Stretch;
            outline.sortingOrder = short.MaxValue;
            var shader = Shader.Find("Sprites/Default") ?? Shader.Find("Unlit/Color");
            if (shader == null)
                return;
            material = new Material(shader) { hideFlags = HideFlags.HideAndDontSave };
            material.SetInt("_ZTest", (int)UnityEngine.Rendering.CompareFunction.Always);
            material.renderQueue = 5000;
            outline.sharedMaterial = material;
        }

        private void UpdateGeometry()
        {
            if (outline == null || target == null)
                return;
            var center = target.transform.position;
            if (target.transform is RectTransform rect)
            {
                rect.GetWorldCorners(corners);
                center = (corners[0] + corners[2]) * 0.5f;
            }
            else
            {
                var bounds = BoundsFor(target);
                center = bounds.center;
                corners[0] = new Vector3(bounds.min.x, bounds.min.y, center.z);
                corners[1] = new Vector3(bounds.min.x, bounds.max.y, center.z);
                corners[2] = new Vector3(bounds.max.x, bounds.max.y, center.z);
                corners[3] = new Vector3(bounds.max.x, bounds.min.y, center.z);
            }

            var camera = Camera.main;
            var offset = camera != null
                ? (camera.transform.position - center).normalized * 0.004f
                : target.transform.forward * -0.004f;
            var maximumExtent = 0f;
            for (var index = 0; index < corners.Length; index++)
            {
                var expanded = center + (corners[index] - center) * 1.12f + offset;
                maximumExtent = Mathf.Max(maximumExtent, Vector3.Distance(center, expanded));
                outline.SetPosition(index, expanded);
            }

            var color = status == "passed"
                ? new Color(0.1f, 1f, 0.25f, 1f)
                : new Color(1f, 0.05f, 0.02f, 1f);
            outline.startColor = color;
            outline.endColor = color;
            var pulse = status == "attempted" || status == "inconclusive"
                ? 0.8f + 0.25f * Mathf.Sin(Time.unscaledTime * 8f)
                : 1f;
            var width = Mathf.Max(0.004f, maximumExtent * 0.025f) * pulse;
            outline.startWidth = width;
            outline.endWidth = width;
        }

        internal QuakNormalizedRect ScreenBounds(string eye)
        {
            var camera = Camera.main;
            if (camera == null || target == null)
                return null;

            if (!showOutline)
                UpdateGeometry();
            var stereoEye = string.Equals(eye, "left", StringComparison.Ordinal)
                ? Camera.MonoOrStereoscopicEye.Left
                : string.Equals(eye, "right", StringComparison.Ordinal)
                    ? Camera.MonoOrStereoscopicEye.Right
                    : Camera.MonoOrStereoscopicEye.Mono;
            var minimum = new Vector2(float.PositiveInfinity, float.PositiveInfinity);
            var maximum = new Vector2(float.NegativeInfinity, float.NegativeInfinity);
            foreach (var corner in corners)
            {
                var viewport = camera.WorldToViewportPoint(corner, stereoEye);
                if (viewport.z <= 0f)
                    return null;
                minimum = Vector2.Min(minimum, viewport);
                maximum = Vector2.Max(maximum, viewport);
            }
            if (maximum.x <= 0f || maximum.y <= 0f || minimum.x >= 1f || minimum.y >= 1f)
                return null;

            minimum = Vector2.Max(Vector2.zero, minimum);
            maximum = Vector2.Min(Vector2.one, maximum);
            return new QuakNormalizedRect
            {
                x = minimum.x,
                y = minimum.y,
                width = maximum.x - minimum.x,
                height = maximum.y - minimum.y
            };
        }

        private static Bounds BoundsFor(Component component)
        {
            var collider = component.GetComponent<Collider>();
            if (collider != null)
                return collider.bounds;
            var renderer = component.GetComponent<Renderer>();
            return renderer != null
                ? renderer.bounds
                : new Bounds(component.transform.position, Vector3.one * 0.08f);
        }

        private void OnDestroy()
        {
            if (material != null)
                UnityEngine.Object.Destroy(material);
        }
    }
}
