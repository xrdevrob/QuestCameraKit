using System;
using UnityEngine;
using UnityEngine.UIElements;

namespace XRDevRob.QUAK
{
    /// <summary>
    /// Maps one named element from a live world-space UI Toolkit document to a
    /// stable QUAK target. Add one component per element that a test must use.
    /// </summary>
    [RequireComponent(typeof(UIDocument), typeof(BoxCollider))]
    [AddComponentMenu("QUAK/UI Toolkit Target")]
    public sealed class QuakUiToolkitTarget : MonoBehaviour
    {
        [SerializeField]
        [Tooltip("Stable ID such as playback.seek or menu.episodes.")]
        private string id;

        [SerializeField]
        [Tooltip("Exact name of one element under this UIDocument's live root.")]
        private string elementName;

        [SerializeField]
        [TextArea]
        private string description;

        [SerializeField]
        [Tooltip("Optional semantic role such as button, toggle, slider, or list item.")]
        private string semanticRole;

        public string Id => id;
        public string ElementName => elementName;
        public string Description => description;
        public string SemanticRole => semanticRole;

        public void Configure(
            string targetId,
            string liveElementName,
            string targetDescription = null,
            string targetSemanticRole = null)
        {
            if (string.IsNullOrWhiteSpace(targetId))
                throw new ArgumentException("QUAK target ID must not be empty.", nameof(targetId));
            if (string.IsNullOrWhiteSpace(liveElementName))
                throw new ArgumentException(
                    "QUAK UI Toolkit element name must not be empty.",
                    nameof(liveElementName));
            id = targetId.Trim();
            elementName = liveElementName.Trim();
            description = targetDescription?.Trim();
            semanticRole = targetSemanticRole?.Trim();
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            id = id?.Trim();
            elementName = elementName?.Trim();
            semanticRole = semanticRole?.Trim();
        }
#endif
    }
}
