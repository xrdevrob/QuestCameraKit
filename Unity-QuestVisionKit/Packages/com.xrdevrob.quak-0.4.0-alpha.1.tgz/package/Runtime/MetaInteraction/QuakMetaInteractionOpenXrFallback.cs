#if QUAK_META_INTERACTION_SDK && USING_XR_SDK_OPENXR
using Oculus.Interaction.Input;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;
using UnityEngine.InputSystem.XR;
using UnityEngine.SceneManagement;
using UnityEngine.Scripting;
using UnityEngine.XR;
using UnityEngine.XR.OpenXR;
using XRDevRob.QUAK.Direct;
using XRDevRob.QUAK.MetaOperator;
using InputDevice = UnityEngine.InputSystem.InputDevice;
using InputUsages = UnityEngine.InputSystem.CommonUsages;

[assembly: AlwaysLinkAssembly]

namespace XRDevRob.QUAK.MetaInteraction
{
    /// <summary>
    /// Keeps Meta Interaction SDK on its normal OVR source, but substitutes the
    /// QUAK controller while direct injection is active or OVR is disconnected.
    /// </summary>
    internal static class QuakMetaInteractionOpenXrBootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void Install()
        {
            var operatorEnabled =
                OpenXRSettings.Instance?.GetFeature<QuakOperatorFeature>()?.enabled == true;
            if ((!Application.isEditor && !Debug.isDebugBuild) ||
                !operatorEnabled && !QuakDirectBridge.IsSupported)
                return;

            if (Object.FindAnyObjectByType<QuakMetaInteractionOpenXrInstaller>() == null)
                new GameObject("QUAK Meta Interaction OpenXR Fallback")
                    .AddComponent<QuakMetaInteractionOpenXrInstaller>();
        }

        internal static void PatchControllers()
        {
            var patched = 0;
            foreach (var controller in Object.FindObjectsByType<Controller>(
                         FindObjectsInactive.Include,
                         FindObjectsSortMode.None))
            {
                var source = controller.ModifyDataFromSource;
                if (source == null || source is QuakMetaInteractionOpenXrFallback)
                    continue;

                var fallback = controller.gameObject.AddComponent<QuakMetaInteractionOpenXrFallback>();
                fallback.InjectAllDataModifier(
                    DataSource<ControllerDataAsset>.UpdateModeFlags.UnityUpdate,
                    null,
                    source,
                    true);
                controller.ResetSources(
                    fallback,
                    fallback,
                    DataSource<ControllerDataAsset>.UpdateModeFlags.AfterPreviousStep);
                patched++;
            }

            if (patched > 0)
                Debug.Log($"[QUAK] Enabled native OpenXR fallback for {patched} Meta Interaction SDK controller(s).");
        }
    }

    [DefaultExecutionOrder(9999)]
    internal sealed class QuakMetaInteractionOpenXrInstaller : MonoBehaviour
    {
        private const float ScanIntervalSeconds = 1f;
        private float nextScanAt;

        private void Awake()
        {
            DontDestroyOnLoad(gameObject);
            SceneManager.sceneLoaded += HandleSceneLoaded;
        }

        private void OnDestroy()
        {
            SceneManager.sceneLoaded -= HandleSceneLoaded;
        }

        private void HandleSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            nextScanAt = 0f;
        }

        private void Update()
        {
            if (!OpenXRRuntime.IsExtensionEnabled(QuakOperatorFeature.ExtensionName) &&
                !QuakDirectBridge.IsNativeReady)
                return;
            if (!AdvanceScanSchedule(Time.unscaledTime, ref nextScanAt))
                return;

            QuakMetaInteractionOpenXrBootstrap.PatchControllers();
        }

        private static bool AdvanceScanSchedule(float now, ref float nextScan)
        {
            if (now < nextScan)
                return false;
            nextScan = now + ScanIntervalSeconds;
            return true;
        }
    }

    internal sealed class QuakMetaInteractionOpenXrFallback : DataModifier<ControllerDataAsset>
    {
        private const string DirectControllerLayout = "QUAKDirectController";
        private DeviceControls cachedControls;
        private Handedness cachedHandedness;

        protected override void Apply(ControllerDataAsset data)
        {
            if (data.Config == null)
                return;

            DeviceControls controls = null;
            var pointerPose = default(Pose);
            var hasDirectControls = QuakDirectBridge.IsNativeReady &&
                TryGetTrackedControls(
                    data.Config.Handedness,
                    true,
                    out controls,
                    out pointerPose);
            if (!hasDirectControls &&
                (data.IsConnected || !TryGetTrackedControls(
                    data.Config.Handedness,
                    false,
                    out controls,
                    out pointerPose)))
                return;

            if (!TryReadPose(controls.RootPose, out var root))
                root = pointerPose;

            data.IsDataValid = true;
            data.IsConnected = true;
            data.IsTracked = true;
            data.RootPose = root;
            data.RootPoseOrigin = PoseOrigin.RawTrackedPose;
            data.PointerPose = pointerPose;
            data.PointerPoseOrigin = PoseOrigin.RawTrackedPose;

            data.Input.Clear();
            SetButton(data, ControllerButtonUsage.PrimaryButton, controls.PrimaryButton);
            SetButton(data, ControllerButtonUsage.PrimaryTouch, controls.PrimaryTouched);
            SetButton(data, ControllerButtonUsage.SecondaryButton, controls.SecondaryButton);
            SetButton(data, ControllerButtonUsage.SecondaryTouch, controls.SecondaryTouched);
            SetButton(data, ControllerButtonUsage.MenuButton, controls.Menu);
            SetButton(data, ControllerButtonUsage.Primary2DAxisClick, controls.ThumbstickClicked);
            SetButton(data, ControllerButtonUsage.Primary2DAxisTouch, controls.ThumbstickTouched);
            SetButton(data, ControllerButtonUsage.Thumbrest, controls.ThumbrestTouched);

            var trigger = ReadAxis(controls.Trigger);
            var grip = ReadAxis(controls.Grip);
            data.Input.SetAxis1D(ControllerAxis1DUsage.Trigger, trigger);
            data.Input.SetAxis1D(ControllerAxis1DUsage.Grip, grip);
            data.Input.SetButton(
                ControllerButtonUsage.TriggerButton,
                ReadButton(controls.TriggerPressed) || trigger > 0.5f);
            data.Input.SetButton(
                ControllerButtonUsage.GripButton,
                ReadButton(controls.GripPressed) || grip > 0.5f);

            if (controls.Thumbstick != null)
                data.Input.SetAxis2D(
                    ControllerAxis2DUsage.Primary2DAxis,
                    controls.Thumbstick.ReadValue());
        }

        private bool TryGetTrackedControls(
            Handedness handedness,
            bool directOnly,
            out DeviceControls controls,
            out Pose pointerPose)
        {
            var cachedDeviceIsCurrent = cachedControls != null &&
                cachedHandedness == handedness && cachedControls.Device.added &&
                (!directOnly || cachedControls.Device.layout == DirectControllerLayout);
            if (cachedDeviceIsCurrent && TryReadPose(cachedControls.PointerPose, out pointerPose))
            {
                controls = cachedControls;
                return true;
            }

            var usage = handedness == Handedness.Left ? InputUsages.LeftHand : InputUsages.RightHand;
            foreach (var device in InputSystem.devices)
            {
                if (device is not XRController)
                    continue;
                if (directOnly && device.layout != DirectControllerLayout)
                    continue;
                if (cachedDeviceIsCurrent && object.ReferenceEquals(device, cachedControls.Device))
                    continue;
                var matchesHand = false;
                foreach (var deviceUsage in device.usages)
                {
                    if (deviceUsage != usage)
                        continue;
                    matchesHand = true;
                    break;
                }
                if (!matchesHand)
                    continue;

                var candidate = new DeviceControls(device);
                if (!TryReadPose(candidate.PointerPose, out pointerPose))
                    continue;
                cachedControls = candidate;
                cachedHandedness = handedness;
                controls = candidate;
                return true;
            }

            controls = null;
            pointerPose = default;
            return false;
        }

        private static bool TryReadPose(PoseControls controls, out Pose pose)
        {
            if (controls?.TrackingState == null || controls.Position == null ||
                controls.Rotation == null)
            {
                pose = default;
                return false;
            }

            var trackingState = (InputTrackingState)controls.TrackingState.ReadValue();
            if ((trackingState & (InputTrackingState.Position | InputTrackingState.Rotation)) !=
                (InputTrackingState.Position | InputTrackingState.Rotation))
            {
                pose = default;
                return false;
            }

            pose = new Pose(controls.Position.ReadValue(), controls.Rotation.ReadValue());
            return true;
        }

        private static void SetButton(
            ControllerDataAsset data,
            ControllerButtonUsage usage,
            ButtonControl control)
        {
            data.Input.SetButton(usage, ReadButton(control));
        }

        private static bool ReadButton(ButtonControl control)
        {
            return control?.isPressed == true;
        }

        private static float ReadAxis(AxisControl control)
        {
            return control?.ReadValue() ?? 0f;
        }

        private sealed class DeviceControls
        {
            public DeviceControls(InputDevice device)
            {
                Device = device;
                PointerPose = device.layout == DirectControllerLayout
                    ? new PoseControls(
                        device.TryGetChildControl<IntegerControl>("trackingState"),
                        device.TryGetChildControl<Vector3Control>("pointerPosition"),
                        device.TryGetChildControl<QuaternionControl>("pointerRotation"))
                    : new PoseControls(device.TryGetChildControl("pointer"));
                RootPose = new PoseControls(device.TryGetChildControl("devicePose"));
                PrimaryButton = device.TryGetChildControl<ButtonControl>("primaryButton");
                PrimaryTouched = device.TryGetChildControl<ButtonControl>("primaryTouched");
                SecondaryButton = device.TryGetChildControl<ButtonControl>("secondaryButton");
                SecondaryTouched = device.TryGetChildControl<ButtonControl>("secondaryTouched");
                Menu = device.TryGetChildControl<ButtonControl>("menu");
                ThumbstickClicked = device.TryGetChildControl<ButtonControl>("thumbstickClicked");
                ThumbstickTouched = device.TryGetChildControl<ButtonControl>("thumbstickTouched");
                ThumbrestTouched = device.TryGetChildControl<ButtonControl>("thumbrestTouched");
                TriggerPressed = device.TryGetChildControl<ButtonControl>("triggerPressed");
                GripPressed = device.TryGetChildControl<ButtonControl>("gripPressed");
                Trigger = device.TryGetChildControl<AxisControl>("trigger");
                Grip = device.TryGetChildControl<AxisControl>("grip");
                Thumbstick = device.TryGetChildControl<Vector2Control>("thumbstick");
            }

            public InputDevice Device { get; }
            public PoseControls PointerPose { get; }
            public PoseControls RootPose { get; }
            public ButtonControl PrimaryButton { get; }
            public ButtonControl PrimaryTouched { get; }
            public ButtonControl SecondaryButton { get; }
            public ButtonControl SecondaryTouched { get; }
            public ButtonControl Menu { get; }
            public ButtonControl ThumbstickClicked { get; }
            public ButtonControl ThumbstickTouched { get; }
            public ButtonControl ThumbrestTouched { get; }
            public ButtonControl TriggerPressed { get; }
            public ButtonControl GripPressed { get; }
            public AxisControl Trigger { get; }
            public AxisControl Grip { get; }
            public Vector2Control Thumbstick { get; }
        }

        private sealed class PoseControls
        {
            public PoseControls(InputControl control) : this(
                control?.TryGetChildControl<IntegerControl>("trackingState"),
                control?.TryGetChildControl<Vector3Control>("position"),
                control?.TryGetChildControl<QuaternionControl>("rotation"))
            {
            }

            public PoseControls(
                IntegerControl trackingState,
                Vector3Control position,
                QuaternionControl rotation)
            {
                TrackingState = trackingState;
                Position = position;
                Rotation = rotation;
            }

            public IntegerControl TrackingState { get; }
            public Vector3Control Position { get; }
            public QuaternionControl Rotation { get; }
        }
    }
}
#endif
