#if USING_XR_SDK_OPENXR
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.Features;

#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.XR.OpenXR.Features;
#endif

[assembly: InternalsVisibleTo("XRDevRob.QUAK.Tests.Editor")]

namespace XRDevRob.QUAK.MetaOperator
{
#if UNITY_EDITOR
    [OpenXRFeature(
        UiName = "QUAK Meta XR Operator Bridge",
        Desc = "Registers QUAK app-state and fixture tools through Meta XR Operator's OpenXR extension.",
        Company = "XR Dev Rob",
        Version = "0.3.1",
        FeatureId = FeatureId,
        OpenxrExtensionStrings = ExtensionName,
        BuildTargetGroups = new[] { BuildTargetGroup.Standalone, BuildTargetGroup.Android })]
#endif
    public sealed unsafe class QuakOperatorFeature : OpenXRFeature
    {
        public const string FeatureId = "com.xrdevrob.quak.operator-bridge";
        public const string ExtensionName = "XR_METAX1_agentic_external_tool";
        private const string RegisterFunctionName = "xrAgenticRegisterExternalToolMETAX1";
        private const int FocusedSessionState = 5;

        private static readonly NativeToolCallback NativeCallback = NativeCallbackTrampoline;
        private static readonly Dictionary<string, GCHandle> CallbackHandles =
            new(StringComparer.Ordinal);
        private static RegisterExternalTool registerExternalTool;
        private static ulong instance;
        private static float sessionFocusedAt = -1f;
        private static string availabilityError;

        internal static bool IsAvailable => instance != 0 && registerExternalTool != null;
        internal static bool SessionFocused { get; private set; }
        internal static float FocusStableSeconds => SessionFocused && sessionFocusedAt >= 0f
            ? Mathf.Max(0f, Time.unscaledTime - sessionFocusedAt)
            : 0f;

        protected override bool OnInstanceCreate(ulong xrInstance)
        {
            instance = xrInstance;
            SessionFocused = false;
            sessionFocusedAt = -1f;
            availabilityError = null;
            registerExternalTool = null;

            if (!OpenXRRuntime.IsExtensionEnabled(ExtensionName))
            {
                availabilityError =
                    $"OpenXR extension {ExtensionName} is unavailable. Enable the QUAK feature " +
                    "and activate Meta XR Operator before starting OpenXR.";
                Debug.LogWarning($"[QUAK] {availabilityError}");
                return true;
            }

            var getInstanceProcAddr = Marshal.GetDelegateForFunctionPointer<GetInstanceProcAddr>(
                xrGetInstanceProcAddr);
            var result = getInstanceProcAddr(
                xrInstance,
                RegisterFunctionName,
                out var functionPointer);
            if (result != XrResult.Success || functionPointer == IntPtr.Zero)
            {
                availabilityError =
                    $"OpenXR could not resolve {RegisterFunctionName}: {result}.";
                Debug.LogError($"[QUAK] {availabilityError}");
                return true;
            }

            registerExternalTool = Marshal.GetDelegateForFunctionPointer<RegisterExternalTool>(
                functionPointer);
            return true;
        }

        protected override void OnSessionStateChange(int oldState, int newState)
        {
            var focused = newState == FocusedSessionState;
            if (focused == SessionFocused)
                return;
            SessionFocused = focused;
            sessionFocusedAt = focused ? Time.unscaledTime : -1f;
        }

        protected override void OnInstanceDestroy(ulong xrInstance)
        {
            registerExternalTool = null;
            instance = 0;
            SessionFocused = false;
            sessionFocusedAt = -1f;
            availabilityError = null;
            foreach (var handle in CallbackHandles.Values)
                if (handle.IsAllocated)
                    handle.Free();
            CallbackHandles.Clear();
        }

        internal static unsafe XrResult RegisterAgenticTool(
            string toolName,
            string toolDescription,
            AgenticToolParameter[] parameters,
            Func<string, string> callback)
        {
            if (!IsAvailable)
            {
                Debug.LogError($"[QUAK] {availabilityError ?? "Operator OpenXR feature is unavailable."}");
                return XrResult.ErrorExtensionNotPresent;
            }
            if (CallbackHandles.ContainsKey(toolName))
                return XrResult.ErrorValidationFailure;

            var callbackData = new QuakOperatorToolCallback(toolName, callback);
            var callbackHandle = GCHandle.Alloc(callbackData);
            CallbackHandles.Add(toolName, callbackHandle);

            var parameterCount = parameters?.Length ?? 0;
            XrAgenticExternalToolParameter* nativeParameters =
                stackalloc XrAgenticExternalToolParameter[parameterCount];
            for (var index = 0; index < parameterCount; index++)
            {
                var nativeParameter = nativeParameters + index;
                *nativeParameter = default;
                nativeParameter->Type = XrAgenticExternalToolParameter.StructureType;
                nativeParameter->ParameterType = parameters[index].ParameterType;
                nativeParameter->IsRequired = parameters[index].IsRequired ? 1u : 0u;
                nativeParameter->ArrayItemType = parameters[index].ArrayItemType;
                CopyUtf8(
                    parameters[index].Name,
                    nativeParameter->ParameterName,
                    XrAgenticExternalToolParameter.MaxNameLength,
                    nameof(AgenticToolParameter.Name));
                CopyUtf8(
                    parameters[index].Description,
                    nativeParameter->ParameterDescription,
                    XrAgenticExternalToolParameter.MaxDescriptionLength,
                    nameof(AgenticToolParameter.Description));
                CopyUtf8(
                    parameters[index].ObjectProperties,
                    nativeParameter->ObjectProperties,
                    XrAgenticExternalToolParameter.MaxObjectPropertiesLength,
                    nameof(AgenticToolParameter.ObjectProperties));
            }

            var registerInfo = new XrAgenticExternalToolRegisterInfo
            {
                Type = XrAgenticExternalToolRegisterInfo.StructureType,
                ToolParameterCount = (uint)parameterCount,
                ToolParameters = nativeParameters,
                ToolCallback = Marshal.GetFunctionPointerForDelegate(NativeCallback),
                ToolCallbackInfoFlags = 1,
                ToolUserData = GCHandle.ToIntPtr(callbackHandle)
            };
            var registerInfoPointer = &registerInfo;
            CopyUtf8(
                toolName,
                registerInfoPointer->ToolName,
                XrAgenticExternalToolRegisterInfo.MaxNameLength,
                nameof(toolName));
            CopyUtf8(
                toolDescription,
                registerInfoPointer->ToolDescription,
                XrAgenticExternalToolRegisterInfo.MaxDescriptionLength,
                nameof(toolDescription));

            return registerExternalTool(instance, in registerInfo);
        }

        [AOT.MonoPInvokeCallback(typeof(NativeToolCallback))]
        internal static unsafe XrResult NativeCallbackTrampoline(
            byte* resultBuffer,
            uint resultBufferCapacityInput,
            uint* resultBufferCountOutput,
            byte* parameters,
            void* userData)
        {
            try
            {
                if (userData == null)
                    return XrResult.ErrorRuntimeFailure;
                var handle = GCHandle.FromIntPtr((IntPtr)userData);
                if (!handle.IsAllocated || handle.Target is not QuakOperatorToolCallback callback)
                    return XrResult.ErrorRuntimeFailure;

                var parametersJson = parameters == null
                    ? "{}"
                    : Marshal.PtrToStringUTF8((IntPtr)parameters) ?? "{}";
                var startsInvocation = resultBuffer == null || resultBufferCapacityInput == 0;
                var result = callback.ResultFor(parametersJson, startsInvocation);
                var writeResult = WriteResultToBuffer(
                    result,
                    resultBuffer,
                    resultBufferCapacityInput,
                    resultBufferCountOutput);
                if (writeResult == XrResult.Success && resultBuffer != null &&
                    resultBufferCapacityInput > 0)
                    callback.Complete(parametersJson);
                return writeResult;
            }
            catch (Exception exception)
            {
                Debug.LogError($"[QUAK] Operator tool callback failed: {exception}");
                return XrResult.ErrorRuntimeFailure;
            }
        }

        internal static unsafe XrResult WriteResultToBuffer(
            string content,
            byte* resultBuffer,
            uint resultBufferCapacityInput,
            uint* resultBufferCountOutput)
        {
            if (content == null || resultBufferCountOutput == null)
                return XrResult.ErrorValidationFailure;

            var bytes = Encoding.UTF8.GetBytes(content);
            var requiredSize = (uint)bytes.Length + 1;
            *resultBufferCountOutput = requiredSize;
            if (resultBuffer == null || resultBufferCapacityInput == 0)
                return XrResult.Success;
            if (resultBufferCapacityInput < requiredSize)
                return XrResult.ErrorSizeInsufficient;

            Marshal.Copy(bytes, 0, (IntPtr)resultBuffer, bytes.Length);
            resultBuffer[bytes.Length] = 0;
            return XrResult.Success;
        }

        private static unsafe void CopyUtf8(
            string value,
            byte* destination,
            int capacity,
            string argumentName)
        {
            if (string.IsNullOrEmpty(value))
            {
                destination[0] = 0;
                return;
            }

            var bytes = Encoding.UTF8.GetBytes(value);
            if (bytes.Length >= capacity)
                throw new ArgumentException(
                    $"UTF-8 value exceeds the {capacity - 1}-byte OpenXR limit.",
                    argumentName);
            Marshal.Copy(bytes, 0, (IntPtr)destination, bytes.Length);
            destination[bytes.Length] = 0;
        }

        [UnmanagedFunctionPointer(CallingConvention.Winapi)]
        private delegate XrResult GetInstanceProcAddr(
            ulong xrInstance,
            [MarshalAs(UnmanagedType.LPStr)] string name,
            out IntPtr function);

        [UnmanagedFunctionPointer(CallingConvention.Winapi)]
        private unsafe delegate XrResult RegisterExternalTool(
            ulong xrInstance,
            in XrAgenticExternalToolRegisterInfo registerInfo);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private unsafe delegate XrResult NativeToolCallback(
            byte* resultBuffer,
            uint resultBufferCapacityInput,
            uint* resultBufferCountOutput,
            byte* parameters,
            void* userData);
    }

    internal sealed class QuakOperatorToolCallback
    {
        private const int MaxPendingResults = 16;
        private static readonly long MaxPendingAgeTicks = TimeSpan.FromSeconds(30).Ticks;
        private readonly Func<string, string> callback;
        private readonly Func<long> clock;
        private readonly Dictionary<string, Queue<PendingResult>> pendingResults =
            new(StringComparer.Ordinal);
        private int pendingResultCount;

        internal QuakOperatorToolCallback(
            string toolName,
            Func<string, string> callback,
            Func<long> clock = null)
        {
            ToolName = string.IsNullOrWhiteSpace(toolName)
                ? throw new ArgumentException("Tool name is required.", nameof(toolName))
                : toolName;
            this.callback = callback ?? throw new ArgumentNullException(nameof(callback));
            this.clock = clock ?? (() => DateTime.UtcNow.Ticks);
        }

        internal string ToolName { get; }

        internal string ResultFor(string parametersJson, bool startsInvocation = false)
        {
            lock (pendingResults)
            {
                RemoveStaleResults(clock() - MaxPendingAgeTicks);
                var hasResults = pendingResults.TryGetValue(parametersJson, out var results);
                if (startsInvocation || !hasResults || results.Count == 0)
                {
                    if (pendingResultCount >= MaxPendingResults)
                        throw new InvalidOperationException(
                            $"Operator tool {ToolName} has too many unfinished callbacks.");
                    var pending = new PendingResult(
                        callback(parametersJson) ?? throw new InvalidOperationException(
                            $"Operator tool {ToolName} returned null."),
                        clock());
                    if (!hasResults)
                    {
                        results = new Queue<PendingResult>();
                        pendingResults.Add(parametersJson, results);
                    }
                    results.Enqueue(pending);
                    pendingResultCount++;
                    if (startsInvocation)
                        return pending.Value;
                }
                return results.Peek().Value;
            }
        }

        internal void Complete(string parametersJson)
        {
            lock (pendingResults)
            {
                if (!pendingResults.TryGetValue(parametersJson, out var results) ||
                    results.Count == 0)
                    return;
                results.Dequeue();
                pendingResultCount--;
                if (results.Count == 0)
                    pendingResults.Remove(parametersJson);
            }
        }

        private void RemoveStaleResults(long cutoffTicks)
        {
            foreach (var key in new List<string>(pendingResults.Keys))
            {
                var results = pendingResults[key];
                while (results.Count > 0 && results.Peek().CreatedAtTicks <= cutoffTicks)
                {
                    results.Dequeue();
                    pendingResultCount--;
                }
                if (results.Count == 0)
                    pendingResults.Remove(key);
            }
        }

        private readonly struct PendingResult
        {
            internal PendingResult(string value, long createdAtTicks)
            {
                Value = value;
                CreatedAtTicks = createdAtTicks;
            }

            internal string Value { get; }
            internal long CreatedAtTicks { get; }
        }
    }

    internal readonly struct AgenticToolParameter
    {
        internal AgenticToolParameter(
            string name,
            string description,
            XrAgenticExternalToolParameterType parameterType,
            bool isRequired = false,
            XrAgenticExternalToolParameterType arrayItemType = default,
            string objectProperties = null)
        {
            Name = name;
            Description = description;
            ParameterType = parameterType;
            IsRequired = isRequired;
            ArrayItemType = arrayItemType;
            ObjectProperties = objectProperties;
        }

        internal string Name { get; }
        internal string Description { get; }
        internal XrAgenticExternalToolParameterType ParameterType { get; }
        internal bool IsRequired { get; }
        internal XrAgenticExternalToolParameterType ArrayItemType { get; }
        internal string ObjectProperties { get; }
    }

    internal enum XrResult
    {
        Success = 0,
        ErrorValidationFailure = -1,
        ErrorRuntimeFailure = -2,
        ErrorFunctionUnsupported = -7,
        ErrorExtensionNotPresent = -9,
        ErrorSizeInsufficient = -11
    }

    internal enum XrAgenticExternalToolParameterType
    {
        String = 1,
        Number = 2,
        Boolean = 3,
        Array = 4,
        Object = 5
    }

    [StructLayout(LayoutKind.Sequential)]
    internal unsafe struct XrAgenticExternalToolParameter
    {
        internal const int MaxNameLength = 64;
        internal const int MaxDescriptionLength = 1024;
        internal const int MaxObjectPropertiesLength = 4096;
        internal const int StructureType = 1000679000;

        internal int Type;
        internal void* Next;
        internal fixed byte ParameterName[MaxNameLength];
        internal fixed byte ParameterDescription[MaxDescriptionLength];
        internal XrAgenticExternalToolParameterType ParameterType;
        internal uint IsRequired;
        internal XrAgenticExternalToolParameterType ArrayItemType;
        internal fixed byte ObjectProperties[MaxObjectPropertiesLength];
    }

    [StructLayout(LayoutKind.Sequential)]
    internal unsafe struct XrAgenticExternalToolRegisterInfo
    {
        internal const int MaxNameLength = 64;
        internal const int MaxDescriptionLength = 1024;
        internal const int StructureType = 1000679001;

        internal int Type;
        internal void* Next;
        internal fixed byte ToolName[MaxNameLength];
        internal fixed byte ToolDescription[MaxDescriptionLength];
        internal uint ToolParameterCount;
        internal XrAgenticExternalToolParameter* ToolParameters;
        internal IntPtr ToolCallback;
        internal ulong ToolCallbackInfoFlags;
        internal IntPtr ToolUserData;
    }
}
#endif
