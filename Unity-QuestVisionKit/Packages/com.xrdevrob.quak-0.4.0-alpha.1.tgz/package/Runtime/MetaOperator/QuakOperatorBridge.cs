#if USING_XR_SDK_OPENXR
using System;
using System.Linq;
using UnityEngine;
using UnityEngine.XR.OpenXR;

namespace XRDevRob.QUAK.MetaOperator
{
    /// <summary>
    /// Registers QUAK's app-specific contract with Meta XR Operator. QUAK
    /// creates one automatically when its OpenXR feature is enabled.
    /// </summary>
    [DisallowMultipleComponent]
    [DefaultExecutionOrder(10000)]
    [AddComponentMenu("QUAK/Meta XR Operator Bridge")]
    public sealed class QuakOperatorBridge : MonoBehaviour
    {
        private const float RequiredFocusStableSeconds = 1f;

        private static bool registrationAttempted;
        private static bool capabilitiesRegistered;
        private static bool stateRegistered;
        private static bool recentLogsRegistered;
        private static bool invokeRegistered;
        private static bool statusRegistered;
        private static bool contextRegistered;
        private static bool evidenceMarkerRegistered;
        private static string registrationError;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void EnsureBridge()
        {
            if (Debug.isDebugBuild &&
                OpenXRSettings.Instance?.GetFeature<QuakOperatorFeature>()?.enabled == true)
                EnsureBridgeInstance();
        }

        internal static QuakOperatorBridge EnsureBridgeInstance()
        {
            var existing = FindAnyObjectByType<QuakOperatorBridge>();
            if (existing != null)
                return existing;
            var bridge = new GameObject("QUAK Operator Bridge").AddComponent<QuakOperatorBridge>();
            if (Application.isPlaying)
                DontDestroyOnLoad(bridge.gameObject);
            return bridge;
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStatics()
        {
            registrationAttempted = false;
            capabilitiesRegistered = false;
            stateRegistered = false;
            recentLogsRegistered = false;
            invokeRegistered = false;
            statusRegistered = false;
            contextRegistered = false;
            evidenceMarkerRegistered = false;
            registrationError = null;
        }

        private void Update()
        {
            if (!Debug.isDebugBuild)
            {
                enabled = false;
                return;
            }
            if (registrationAttempted)
            {
                enabled = false;
                return;
            }
            if (!QuakOperatorFeature.IsAvailable)
                return;

            // Operator retains registered names for the OpenXR session, so an
            // in-process retry can only turn a partial failure into duplicates.
            registrationAttempted = true;
            var capabilities = QuakOperatorFeature.RegisterAgenticTool(
                "quak_get_capabilities",
                "Returns stable QUAK interaction target IDs, world poses, state providers, and fixture actions.",
                null,
                _ => QuakRegistry.CapabilitiesJson());
            capabilitiesRegistered = capabilities == XrResult.Success;

            var state = QuakOperatorFeature.RegisterAgenticTool(
                "quak_get_state",
                "Returns the application's independently assertable QUAK product state.",
                null,
                _ => QuakRegistry.StateJson());
            stateRegistered = state == XrResult.Success;

            var invoke = QuakOperatorFeature.RegisterAgenticTool(
                "quak_invoke_action",
                "Runs an app-defined deterministic fixture or reset. It must not replace the XR interaction under test.",
                new[]
                {
                    new AgenticToolParameter(
                        "action_id",
                        "Stable fixture or reset action ID advertised by quak_get_capabilities.",
                        XrAgenticExternalToolParameterType.String,
                        true),
                    new AgenticToolParameter(
                        "arguments_json",
                        "JSON object passed to the app action. Use {} when it takes no arguments.",
                        XrAgenticExternalToolParameterType.String),
                    new AgenticToolParameter(
                        "confirm",
                        "Must be true for actions that persistently modify Unity project state.",
                        XrAgenticExternalToolParameterType.Boolean)
                },
                parametersJson =>
                {
                    var input = JsonUtility.FromJson<InvokeInput>(parametersJson) ?? new InvokeInput();
                    return JsonUtility.ToJson(QuakRegistry.InvokeAction(
                        input.action_id,
                        input.arguments_json,
                        input.confirm));
                });
            invokeRegistered = invoke == XrResult.Success;

            var status = QuakOperatorFeature.RegisterAgenticTool(
                "quak_status",
                "Returns live QUAK bridge, application, session, focus, provider, and correlation status.",
                null,
                _ => JsonUtility.ToJson(CaptureStatus()));
            statusRegistered = status == XrResult.Success;

            var context = QuakOperatorFeature.RegisterAgenticTool(
                "quak_set_context",
                "Sets the non-empty action context carried by QUAK status. Apps must persist it in real handlers to prove event or telemetry correlation.",
                new[]
                {
                    new AgenticToolParameter(
                        "correlation_id",
                        "Non-empty action context ID; app handlers must persist it for event or telemetry correlation.",
                        XrAgenticExternalToolParameterType.String,
                        true)
                },
                SetContext);
            contextRegistered = context == XrResult.Success;

            var evidenceMarker = QuakOperatorFeature.RegisterAgenticTool(
                "quak_mark_evidence_target",
                "Draws a non-interactive runtime outline around the exact QUAK target for recorded evidence.",
                new[]
                {
                    new AgenticToolParameter(
                        "target_id",
                        "Stable QUAK target ID advertised by quak_get_capabilities.",
                        XrAgenticExternalToolParameterType.String,
                        true),
                    new AgenticToolParameter(
                        "status",
                        "Marker state: targeted, attempted, passed, failed, inconclusive, or clear.",
                        XrAgenticExternalToolParameterType.String,
                        true),
                    new AgenticToolParameter(
                        "eye",
                        "Camera eye used for normalized target bounds: left, right, or mono.",
                        XrAgenticExternalToolParameterType.String),
                    new AgenticToolParameter(
                        "hide_outline",
                        "Return target bounds without drawing the runtime outline.",
                        XrAgenticExternalToolParameterType.Boolean)
                },
                MarkEvidenceTarget);
            evidenceMarkerRegistered = evidenceMarker == XrResult.Success;

            var recentLogs = QuakOperatorFeature.RegisterAgenticTool(
                "quak_get_recent_logs",
                "Returns the newest bounded Unity log messages, types, and timestamps. Stack traces are omitted.",
                new[]
                {
                    new AgenticToolParameter(
                        "limit",
                        "Newest entries to return (1-200; defaults to 50 and is clamped).",
                        XrAgenticExternalToolParameterType.Number)
                },
                GetRecentLogs);
            recentLogsRegistered = recentLogs == XrResult.Success;

            if (AllRegistered)
            {
                Debug.Log("[QUAK] Meta XR Operator core tools registered through OpenXR.");
            }
            else
            {
                registrationError =
                    $"Operator registration failed: capabilities={capabilities}, state={state}, " +
                    $"invoke={invoke}, status={status}, context={context}, " +
                    $"evidenceMarker={evidenceMarker}. " +
                    "Restart Play mode or the app after fixing the Operator layer/OpenXR setup.";
                Debug.LogError($"[QUAK] {registrationError}");
            }
            if (!recentLogsRegistered)
            {
                Debug.LogWarning(
                    $"[QUAK] Optional recent-log diagnostics are unavailable: {recentLogs}. " +
                    "Core Operator tools remain independent.");
            }
            enabled = false;
        }

        private static bool AllRegistered => capabilitiesRegistered && stateRegistered &&
            invokeRegistered && statusRegistered && contextRegistered && evidenceMarkerRegistered;

        private static OperatorStatus CaptureStatus()
        {
            var runtime = QuakRegistry.CaptureRuntimeStatus();
            var sessionFocused = QuakOperatorFeature.SessionFocused;
            var focusStableSeconds = QuakOperatorFeature.FocusStableSeconds;
            return new OperatorStatus
            {
                ready = AllRegistered && runtime.ready && runtime.applicationFocused &&
                    focusStableSeconds >= RequiredFocusStableSeconds,
                runtime = runtime,
                sessionId = runtime.sessionId,
                sessionAgeSeconds = runtime.sessionAgeSeconds,
                applicationId = runtime.applicationId,
                applicationVersion = runtime.applicationVersion,
                unityVersion = runtime.unityVersion,
                activeScene = runtime.activeScene,
                isEditor = runtime.isEditor,
                runtimePlatform = runtime.runtimePlatform,
                developmentBuild = runtime.developmentBuild,
                correlationId = runtime.correlationId,
                stateProviders = runtime.stateProviders.ToArray(),
                applicationFocused = runtime.applicationFocused,
                inputFocused = sessionFocused,
                vrFocused = sessionFocused,
                focusStableSeconds = focusStableSeconds,
                errors = runtime.errors
                    .Concat(string.IsNullOrEmpty(registrationError)
                        ? Array.Empty<string>()
                        : new[] { registrationError })
                    .ToArray()
            };
        }

        private static string SetContext(string parametersJson)
        {
            try
            {
                var input = JsonUtility.FromJson<ContextInput>(parametersJson) ?? new ContextInput();
                return JsonUtility.ToJson(new ContextResult
                {
                    success = true,
                    correlationId = QuakRegistry.SetCorrelationId(input.correlation_id)
                });
            }
            catch (Exception exception)
            {
                return JsonUtility.ToJson(new ContextResult
                {
                    success = false,
                    error = exception.Message
                });
            }
        }

        private static string GetRecentLogs(string parametersJson)
        {
            var input = string.IsNullOrWhiteSpace(parametersJson)
                ? new RecentLogsInput()
                : JsonUtility.FromJson<RecentLogsInput>(parametersJson) ?? new RecentLogsInput();
            var limit = input.limit > 0f
                ? Mathf.RoundToInt(input.limit)
                : QuakRegistry.DefaultRecentLogLimit;
            return QuakRegistry.RecentLogsJson(limit);
        }

        private static string MarkEvidenceTarget(string parametersJson)
        {
            var input = JsonUtility.FromJson<EvidenceMarkerInput>(parametersJson) ??
                        new EvidenceMarkerInput();
            return JsonUtility.ToJson(QuakRegistry.MarkEvidenceTarget(
                input.target_id,
                input.status,
                string.IsNullOrWhiteSpace(input.eye) ? "mono" : input.eye,
                input.hide_outline));
        }

        [Serializable]
        private sealed class InvokeInput
        {
            public string action_id;
            public string arguments_json = "{}";
            public bool confirm;
        }

        [Serializable]
        private sealed class ContextInput
        {
            public string correlation_id;
        }

        [Serializable]
        private sealed class RecentLogsInput
        {
            public float limit = QuakRegistry.DefaultRecentLogLimit;
        }

        [Serializable]
        private sealed class EvidenceMarkerInput
        {
            public string target_id;
            public string status;
            public string eye;
            public bool hide_outline;
        }

        [Serializable]
        private sealed class ContextResult
        {
            public bool success;
            public string correlationId;
            public string error;
        }

        [Serializable]
        private sealed class OperatorStatus
        {
            public int schemaVersion = 1;
            public bool ready;
            public string backendSource = "live";
            public string bridgeId = "quak-meta-operator";
            public string providerId = "meta-xr-operator";
            public QuakRuntimeStatus runtime;
            public string sessionId;
            public float sessionAgeSeconds;
            public string applicationId;
            public string applicationVersion;
            public string unityVersion;
            public string activeScene;
            public bool isEditor;
            public string runtimePlatform;
            public bool developmentBuild;
            public string correlationId;
            public string[] stateProviders;
            public bool applicationFocused;
            public bool inputFocused;
            public bool vrFocused;
            public float focusStableSeconds;
            public string[] errors;
        }
    }
}
#endif
